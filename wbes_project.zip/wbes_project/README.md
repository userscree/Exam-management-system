# WBES - Starter (Procedural PHP)

This is a functional starter pack for the Web-Based Examination System (WBES) built with plain PHP and MySQL (procedural style).

## What is included
- Basic user registration and login (admin seed included)
- Role-based dashboards for admin/instructor/student
- Instructor can create exams and add MCQ questions
- Student can take exams and get auto-graded results (MCQ)
- Database schema (`db.sql`)

## Quick setup (XAMPP)
1. Copy the `wbes_project` folder into your XAMPP `htdocs` directory.
2. Import `db.sql` into MySQL (phpMyAdmin) or run: `mysql -u root < db.sql`
3. Edit `config.php` to match your DB credentials.
4. Open `http://localhost/wbes_project/index.php`

Default admin: `admin@example.com` / `admin123`

Note: Replace `assets/css/bootstrap.min.css` with the official Bootstrap file for production.
