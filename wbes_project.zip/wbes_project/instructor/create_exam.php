<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Create Exam';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];

// Get instructor's courses and departments
try {
    $stmt = $pdo->prepare("
        SELECT c.*, d.department_name 
        FROM courses c 
        LEFT JOIN departments d ON c.department = d.department_code 
        WHERE c.instructor_id = ? AND c.is_active = 1 
        ORDER BY c.course_code
    ");
    $stmt->execute([$instructor_id]);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all departments for dropdown
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_name");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching courses: ' . $e->getMessage());
    $courses = [];
    $departments = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_exam'])) {
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $course_id = $_POST['course_id'];
    $exam_type = sanitize($_POST['exam_type']);
    $total_marks = $_POST['total_marks'];
    $passing_marks = $_POST['passing_marks'];
    $duration_minutes = $_POST['duration_minutes'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $allow_retake = isset($_POST['allow_retake']) ? 1 : 0;
    $show_results_immediately = isset($_POST['show_results_immediately']) ? 1 : 0;
    
    // Validation
    $errors = [];
    
    if (empty($title)) {
        $errors[] = 'Exam title is required.';
    }
    
    if (empty($course_id)) {
        $errors[] = 'Please select a course.';
    }
    
    if (empty($total_marks) || $total_marks <= 0) {
        $errors[] = 'Total marks must be a positive number.';
    }
    
    if (empty($passing_marks) || $passing_marks <= 0) {
        $errors[] = 'Passing marks must be a positive number.';
    }
    
    if ($passing_marks > $total_marks) {
        $errors[] = 'Passing marks cannot exceed total marks.';
    }
    
    if (empty($duration_minutes) || $duration_minutes <= 0) {
        $errors[] = 'Duration must be a positive number.';
    }
    
    if (empty($start_date)) {
        $errors[] = 'Start date is required.';
    }
    
    if (empty($end_date)) {
        $errors[] = 'End date is required.';
    }
    
    if (!empty($start_date) && !empty($end_date)) {
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        $now = new DateTime();
        
        if ($end <= $start) {
            $errors[] = 'End date must be after start date.';
        }
        
        if ($start < $now) {
            $errors[] = 'Start date cannot be in the past.';
        }
    }
    
    if (empty($errors)) {
        try {
            // Verify that the course belongs to the instructor
            $stmt = $pdo->prepare("SELECT id FROM courses WHERE id = ? AND instructor_id = ?");
            $stmt->execute([$course_id, $instructor_id]);
            
            if (!$stmt->fetch()) {
                setFlash('error', 'Invalid course selection.');
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO exams (title, description, course_id, instructor_id, exam_type, total_marks, passing_marks, duration_minutes, start_date, end_date, is_active, allow_retake, show_results_immediately) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $title, $description, $course_id, $instructor_id, $exam_type, $total_marks, $passing_marks, 
                    $duration_minutes, $start_date, $end_date, $is_active, $allow_retake, $show_results_immediately
                ]);
                
                $exam_id = $pdo->lastInsertId();
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $instructor_id,
                    'exam_created',
                    'Created exam: ' . $title . ' (ID: ' . $exam_id . ')',
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Exam created successfully! You can now add questions to the exam.');
                
                // Redirect to add questions page
                redirect('add_question.php?exam_id=' . $exam_id);
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error creating exam: ' . $e->getMessage());
        }
    } else {
        foreach($errors as $error) {
            setFlash('error', $error);
        }
    }
}
?>

<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-file-alt me-2"></i> Create New Exam
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($courses)): ?>
                    <div class="alert alert-warning text-center">
                        <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
                        <h5>No Courses Available</h5>
                        <p class="mb-3">You need to be assigned to at least one course before creating exams.</p>
                        <a href="../admin/manage_courses.php" class="btn btn-primary">
                            <i class="fas fa-book me-2"></i> Request Course Assignment
                        </a>
                    </div>
                <?php else: ?>
                    <form method="POST" id="createExamForm" novalidate>
                        <!-- Basic Information -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-info-circle me-2 text-primary"></i>
                                Basic Information
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="title" class="form-label">Exam Title *</label>
                                        <input type="text" class="form-control" id="title" name="title" 
                                               placeholder="Enter exam title (e.g., Midterm Examination)" 
                                               value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" 
                                               required>
                                        <div class="invalid-feedback">Please provide an exam title.</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="course_id" class="form-label">Course *</label>
                                        <select class="form-select" id="course_id" name="course_id" required>
                                            <option value="">Select Course</option>
                                            <?php foreach($courses as $course): ?>
                                                <option value="<?php echo $course['id']; ?>" 
                                                    <?php echo (isset($_POST['course_id']) && $_POST['course_id'] == $course['id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                                    <?php if($course['department_name']): ?>
                                                        (<?php echo htmlspecialchars($course['department_name']); ?>)
                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">Please select a course.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" 
                                          rows="3" placeholder="Provide a brief description of the exam..."><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                                <div class="form-text">This description will be visible to students.</div>
                            </div>
                        </div>

                        <!-- Exam Configuration -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-cog me-2 text-success"></i>
                                Exam Configuration
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="exam_type" class="form-label">Exam Type *</label>
                                        <select class="form-select" id="exam_type" name="exam_type" required>
                                            <option value="quiz" <?php echo (isset($_POST['exam_type']) && $_POST['exam_type'] == 'quiz') ? 'selected' : ''; ?>>Quiz</option>
                                            <option value="midterm" <?php echo (isset($_POST['exam_type']) && $_POST['exam_type'] == 'midterm') ? 'selected' : ''; ?>>Midterm</option>
                                            <option value="final" <?php echo (isset($_POST['exam_type']) && $_POST['exam_type'] == 'final') ? 'selected' : ''; ?>>Final</option>
                                            <option value="assignment" <?php echo (isset($_POST['exam_type']) && $_POST['exam_type'] == 'assignment') ? 'selected' : ''; ?>>Assignment</option>
                                        </select>
                                        <div class="invalid-feedback">Please select exam type.</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="total_marks" class="form-label">Total Marks *</label>
                                        <input type="number" class="form-control" id="total_marks" name="total_marks" 
                                               min="1" max="1000" 
                                               value="<?php echo isset($_POST['total_marks']) ? $_POST['total_marks'] : '100'; ?>" 
                                               required>
                                        <div class="invalid-feedback">Please enter valid total marks.</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="passing_marks" class="form-label">Passing Marks *</label>
                                        <input type="number" class="form-control" id="passing_marks" name="passing_marks" 
                                               min="1" 
                                               value="<?php echo isset($_POST['passing_marks']) ? $_POST['passing_marks'] : '40'; ?>" 
                                               required>
                                        <div class="invalid-feedback">Please enter valid passing marks.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="duration_minutes" class="form-label">Duration (minutes) *</label>
                                        <input type="number" class="form-control" id="duration_minutes" name="duration_minutes" 
                                               min="1" max="480" 
                                               value="<?php echo isset($_POST['duration_minutes']) ? $_POST['duration_minutes'] : '60'; ?>" 
                                               required>
                                        <div class="form-text">Maximum 480 minutes (8 hours)</div>
                                        <div class="invalid-feedback">Please enter valid duration.</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Exam Settings</label>
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" id="allow_retake" name="allow_retake" value="1" 
                                                <?php echo (isset($_POST['allow_retake']) && $_POST['allow_retake']) ? 'checked' : 'checked'; ?>>
                                            <label class="form-check-label" for="allow_retake">
                                                Allow students to retake this exam
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="show_results_immediately" name="show_results_immediately" value="1" 
                                                <?php echo (isset($_POST['show_results_immediately']) && $_POST['show_results_immediately']) ? 'checked' : 'checked'; ?>>
                                            <label class="form-check-label" for="show_results_immediately">
                                                Show results immediately after submission
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Schedule -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-calendar-alt me-2 text-warning"></i>
                                Schedule
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="start_date" class="form-label">Start Date & Time *</label>
                                        <input type="datetime-local" class="form-control" id="start_date" name="start_date" 
                                               value="<?php echo isset($_POST['start_date']) ? $_POST['start_date'] : ''; ?>" 
                                               required>
                                        <div class="invalid-feedback">Please select start date and time.</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="end_date" class="form-label">End Date & Time *</label>
                                        <input type="datetime-local" class="form-control" id="end_date" name="end_date" 
                                               value="<?php echo isset($_POST['end_date']) ? $_POST['end_date'] : ''; ?>" 
                                               required>
                                        <div class="invalid-feedback">Please select end date and time.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Note:</strong> Students can only attempt the exam between the specified start and end dates.
                                The exam will be automatically submitted when the time limit is reached.
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-toggle-on me-2 text-info"></i>
                                Status
                            </h6>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" 
                                        <?php echo (isset($_POST['is_active']) && $_POST['is_active']) || !isset($_POST['is_active']) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="is_active">
                                        <strong>Activate this exam immediately</strong>
                                    </label>
                                </div>
                                <div class="form-text">
                                    If unchecked, the exam will be created but won't be visible to students until you activate it later.
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="view_exams.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Back to Exams
                            </a>
                            <div class="btn-group">
                                <button type="submit" name="create_exam" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i> Create Exam
                                </button>
                                <button type="button" class="btn btn-outline-primary" onclick="previewExam()">
                                    <i class="fas fa-eye me-2"></i> Preview
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Quick Tips -->
                    <div class="mt-4">
                        <div class="alert alert-light border">
                            <h6 class="alert-heading">
                                <i class="fas fa-lightbulb me-2 text-warning"></i>Quick Tips
                            </h6>
                            <ul class="mb-0 small">
                                <li>Choose a clear and descriptive title for your exam</li>
                                <li>Set appropriate duration based on exam complexity</li>
                                <li>Ensure passing marks are reasonable for the difficulty level</li>
                                <li>Schedule the exam during appropriate time frames for students</li>
                                <li>You can add questions after creating the exam</li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Exam Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" form="createExamForm" name="create_exam" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i> Create Exam
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function previewExam() {
    // Get form values
    const title = document.getElementById('title').value || 'Exam Title';
    const courseSelect = document.getElementById('course_id');
    const courseText = courseSelect.options[courseSelect.selectedIndex]?.text || 'No course selected';
    const description = document.getElementById('description').value || 'No description provided.';
    const examType = document.getElementById('exam_type').value || 'quiz';
    const totalMarks = document.getElementById('total_marks').value || '100';
    const passingMarks = document.getElementById('passing_marks').value || '40';
    const duration = document.getElementById('duration_minutes').value || '60';
    const startDate = document.getElementById('start_date').value || 'Not set';
    const endDate = document.getElementById('end_date').value || 'Not set';
    const allowRetake = document.getElementById('allow_retake').checked;
    const showResults = document.getElementById('show_results_immediately').checked;
    const isActive = document.getElementById('is_active').checked;

    // Format dates for display
    const formatDate = (dateString) => {
        if (!dateString) return 'Not set';
        const date = new Date(dateString);
        return date.toLocaleString();
    };

    // Create preview content
    const previewContent = `
        <div class="preview-exam">
            <div class="text-center mb-4">
                <h4 class="text-primary">${title}</h4>
                <p class="text-muted">${courseText}</p>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">
                                <i class="fas fa-info-circle me-2 text-primary"></i>Basic Information
                            </h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td><strong>Exam Type:</strong></td>
                                    <td><span class="badge bg-primary">${examType.charAt(0).toUpperCase() + examType.slice(1)}</span></td>
                                </tr>
                                <tr>
                                    <td><strong>Total Marks:</strong></td>
                                    <td>${totalMarks}</td>
                                </tr>
                                <tr>
                                    <td><strong>Passing Marks:</strong></td>
                                    <td>${passingMarks}</td>
                                </tr>
                                <tr>
                                    <td><strong>Duration:</strong></td>
                                    <td>${duration} minutes</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">
                                <i class="fas fa-calendar me-2 text-success"></i>Schedule
                            </h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td><strong>Starts:</strong></td>
                                    <td>${formatDate(startDate)}</td>
                                </tr>
                                <tr>
                                    <td><strong>Ends:</strong></td>
                                    <td>${formatDate(endDate)}</td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td>
                                        <span class="badge bg-${isActive ? 'success' : 'secondary'}">
                                            ${isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fas fa-file-alt me-2 text-info"></i>Description
                    </h6>
                    <p class="mb-0">${description}</p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fas fa-cog me-2 text-warning"></i>Settings
                    </h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" ${allowRetake ? 'checked' : ''} disabled>
                                <label class="form-check-label">Allow Retake</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" ${showResults ? 'checked' : ''} disabled>
                                <label class="form-check-label">Show Results Immediately</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="alert alert-info mt-4">
                <i class="fas fa-info-circle me-2"></i>
                This is a preview of how the exam will appear to students. You can still make changes before creating the exam.
            </div>
        </div>
    `;

    // Display preview
    document.getElementById('previewContent').innerHTML = previewContent;
    const previewModal = new bootstrap.Modal(document.getElementById('previewModal'));
    previewModal.show();
}

// Form validation and auto-calculation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('createExamForm');
    const totalMarksInput = document.getElementById('total_marks');
    const passingMarksInput = document.getElementById('passing_marks');
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');

    // Set default dates
    const now = new Date();
    const defaultStart = new Date(now.getTime() + 24 * 60 * 60 * 1000); // Tomorrow
    const defaultEnd = new Date(defaultStart.getTime() + 7 * 24 * 60 * 60 * 1000); // One week later
    
    if (!startDateInput.value) {
        startDateInput.value = defaultStart.toISOString().slice(0, 16);
    }
    
    if (!endDateInput.value) {
        endDateInput.value = defaultEnd.toISOString().slice(0, 16);
    }

    // Validate passing marks against total marks
    function validateMarks() {
        const totalMarks = parseInt(totalMarksInput.value);
        const passingMarks = parseInt(passingMarksInput.value);
        
        if (passingMarks > totalMarks) {
            passingMarksInput.setCustomValidity('Passing marks cannot exceed total marks');
        } else {
            passingMarksInput.setCustomValidity('');
        }
    }

    totalMarksInput.addEventListener('change', validateMarks);
    passingMarksInput.addEventListener('change', validateMarks);

    // Validate dates
    function validateDates() {
        const startDate = new Date(startDateInput.value);
        const endDate = new Date(endDateInput.value);
        const now = new Date();

        if (startDate >= endDate) {
            startDateInput.setCustomValidity('Start date must be before end date');
            endDateInput.setCustomValidity('End date must be after start date');
        } else if (startDate < now) {
            startDateInput.setCustomValidity('Start date cannot be in the past');
        } else {
            startDateInput.setCustomValidity('');
            endDateInput.setCustomValidity('');
        }
    }

    startDateInput.addEventListener('change', validateDates);
    endDateInput.addEventListener('change', validateDates);

    // Form submission validation
    form.addEventListener('submit', function(e) {
        if (!form.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        form.classList.add('was-validated');
        
        // Additional custom validation
        validateMarks();
        validateDates();
        
        if (!startDateInput.checkValidity() || !endDateInput.checkValidity() || !passingMarksInput.checkValidity()) {
            e.preventDefault();
        }
    });

    // Auto-calculate default passing marks (40% of total marks)
    totalMarksInput.addEventListener('input', function() {
        if (!passingMarksInput.value || passingMarksInput.value == '40') {
            const total = parseInt(this.value) || 100;
            const passing = Math.round(total * 0.4);
            passingMarksInput.value = passing;
        }
        validateMarks();
    });

    // Set minimum datetime for start date to current time
    const nowISO = new Date().toISOString().slice(0, 16);
    startDateInput.min = nowISO;
    endDateInput.min = nowISO;

    // Auto-focus title field
    document.getElementById('title').focus();
});

// Character counter for description
document.addEventListener('DOMContentLoaded', function() {
    const description = document.getElementById('description');
    if (description) {
        // Create character counter
        const counter = document.createElement('div');
        counter.className = 'form-text text-end';
        counter.id = 'descriptionCounter';
        description.parentNode.appendChild(counter);
        
        function updateCounter() {
            const length = description.value.length;
            counter.textContent = `${length} characters`;
            counter.className = `form-text text-end ${length > 500 ? 'text-danger' : 'text-muted'}`;
        }
        
        description.addEventListener('input', updateCounter);
        updateCounter();
    }
});
</script>

<style>
.preview-exam {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.preview-exam .card {
    border: 1px solid #e3e6f0;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
}

.preview-exam .card-title {
    color: #4e73df;
    font-weight: 600;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.invalid-feedback {
    display: block;
}

.was-validated .form-control:invalid,
.was-validated .form-select:invalid {
    border-color: #dc3545;
    padding-right: calc(1.5em + 0.75rem);
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath d='m5.8 3.6.4.4.4-.4'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right calc(0.375em + 0.1875rem) center;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}

.was-validated .form-control:valid,
.was-validated .form-select:valid {
    border-color: #198754;
    padding-right: calc(1.5em + 0.75rem);
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right calc(0.375em + 0.1875rem) center;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}
</style>

<?php require_once '../includes/footer.php'; ?>