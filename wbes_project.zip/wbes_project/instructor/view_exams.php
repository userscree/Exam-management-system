<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'My Exams';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_exam'])) {
        $exam_id = $_POST['exam_id'];
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $exam_type = sanitize($_POST['exam_type']);
        $total_marks = $_POST['total_marks'];
        $passing_marks = $_POST['passing_marks'];
        $duration_minutes = $_POST['duration_minutes'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $allow_retake = isset($_POST['allow_retake']) ? 1 : 0;
        $show_results_immediately = isset($_POST['show_results_immediately']) ? 1 : 0;
        
        try {
            $stmt = $pdo->prepare("UPDATE exams SET title = ?, description = ?, exam_type = ?, total_marks = ?, passing_marks = ?, duration_minutes = ?, start_date = ?, end_date = ?, is_active = ?, allow_retake = ?, show_results_immediately = ?, updated_at = NOW() WHERE id = ? AND instructor_id = ?");
            $stmt->execute([$title, $description, $exam_type, $total_marks, $passing_marks, $duration_minutes, $start_date, $end_date, $is_active, $allow_retake, $show_results_immediately, $exam_id, $instructor_id]);
            
            setFlash('success', 'Exam updated successfully!');
            redirect('view_exams.php?exam_id=' . $exam_id);
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['toggle_exam_status'])) {
        $exam_id = $_POST['exam_id'];
        $current_status = $_POST['current_status'];
        $new_status = $current_status ? 0 : 1;
        
        try {
            $stmt = $pdo->prepare("UPDATE exams SET is_active = ?, updated_at = NOW() WHERE id = ? AND instructor_id = ?");
            $stmt->execute([$new_status, $exam_id, $instructor_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            setFlash('success', "Exam {$status_text} successfully!");
            redirect('view_exams.php?exam_id=' . $exam_id);
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam status: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_exam'])) {
        $exam_id = $_POST['exam_id'];
        
        try {
            // Check if exam has attempts
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?");
            $stmt->execute([$exam_id]);
            $attempt_count = $stmt->fetchColumn();
            
            if ($attempt_count > 0) {
                setFlash('error', 'Cannot delete exam. There are exam attempts associated with this exam. Please delete the attempts first.');
            } else {
                // Delete questions first (due to foreign key constraint)
                $stmt = $pdo->prepare("DELETE FROM questions WHERE exam_id = ?");
                $stmt->execute([$exam_id]);
                
                // Then delete exam
                $stmt = $pdo->prepare("DELETE FROM exams WHERE id = ? AND instructor_id = ?");
                $stmt->execute([$exam_id, $instructor_id]);
                
                setFlash('success', 'Exam deleted successfully!');
                redirect('view_exams.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting exam: ' . $e->getMessage());
        }
    }
}

// Get filter parameters for list view
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$course_filter = $_GET['course'] ?? '';
$search = $_GET['search'] ?? '';

// If no specific exam ID provided, show list of instructor's exams
if ($exam_id === 0) {
    // Build query for exams list
    $query = "
        SELECT e.*, c.course_code, c.course_name,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id) as attempt_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND status = 'graded') as graded_count
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.instructor_id = ?
    ";
    $params = [$instructor_id];

    if (!empty($status_filter)) {
        if ($status_filter === 'active') {
            $query .= " AND e.is_active = 1 AND e.start_date <= NOW() AND e.end_date >= NOW()";
        } elseif ($status_filter === 'upcoming') {
            $query .= " AND e.is_active = 1 AND e.start_date > NOW()";
        } elseif ($status_filter === 'expired') {
            $query .= " AND e.end_date < NOW()";
        } elseif ($status_filter === 'inactive') {
            $query .= " AND e.is_active = 0";
        }
    }

    if (!empty($type_filter)) {
        $query .= " AND e.exam_type = ?";
        $params[] = $type_filter;
    }

    if (!empty($course_filter)) {
        $query .= " AND e.course_id = ?";
        $params[] = $course_filter;
    }

    if (!empty($search)) {
        $query .= " AND (e.title LIKE ? OR e.description LIKE ? OR c.course_name LIKE ?)";
        $search_term = "%$search%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }

    $query .= " ORDER BY e.created_at DESC";

    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get courses for filter dropdown
        $stmt = $pdo->prepare("
            SELECT DISTINCT c.id, c.course_code, c.course_name 
            FROM courses c 
            JOIN exams e ON c.id = e.course_id 
            WHERE e.instructor_id = ? 
            ORDER BY c.course_code
        ");
        $stmt->execute([$instructor_id]);
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get statistics
        $total_exams = count($exams);
        $active_exams = 0;
        $upcoming_exams = 0;
        $expired_exams = 0;
        
        $now = new DateTime();
        foreach($exams as $exam) {
            $start_date = new DateTime($exam['start_date']);
            $end_date = new DateTime($exam['end_date']);
            
            if ($exam['is_active'] && $now >= $start_date && $now <= $end_date) {
                $active_exams++;
            } elseif ($exam['is_active'] && $now < $start_date) {
                $upcoming_exams++;
            } elseif ($now > $end_date) {
                $expired_exams++;
            }
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching exams: ' . $e->getMessage());
        $exams = [];
        $courses = [];
        $total_exams = $active_exams = $upcoming_exams = $expired_exams = 0;
    }
    
    // Show exam list view
    ?>
    <div class="row mb-4">
        <div class="col">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1">My Exams</h1>
                    <p class="text-muted mb-0">Manage your created examinations</p>
                </div>
                <a href="create_exam.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i> Create New Exam
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Exams
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_exams; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Active Exams
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_exams; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-play-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Upcoming Exams
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $upcoming_exams; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Total Attempts
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo array_sum(array_column($exams, 'attempt_count')); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters and Search -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="search" class="form-label">Search Exams</label>
                    <input type="text" class="form-control" id="search" name="search" placeholder="Search by title, description..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <label for="type" class="form-label">Exam Type</label>
                    <select class="form-select" id="type" name="type">
                        <option value="">All Types</option>
                        <option value="quiz" <?php echo $type_filter == 'quiz' ? 'selected' : ''; ?>>Quiz</option>
                        <option value="midterm" <?php echo $type_filter == 'midterm' ? 'selected' : ''; ?>>Midterm</option>
                        <option value="final" <?php echo $type_filter == 'final' ? 'selected' : ''; ?>>Final</option>
                        <option value="assignment" <?php echo $type_filter == 'assignment' ? 'selected' : ''; ?>>Assignment</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="course" class="form-label">Course</label>
                    <select class="form-select" id="course" name="course">
                        <option value="">All Courses</option>
                        <?php foreach($courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_code']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="upcoming" <?php echo $status_filter == 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                        <option value="expired" <?php echo $status_filter == 'expired' ? 'selected' : ''; ?>>Expired</option>
                        <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="btn-group w-100">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter me-2"></i> Filter
                        </button>
                        <a href="view_exams.php" class="btn btn-outline-secondary">
                            <i class="fas fa-redo me-2"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Exams Grid -->
    <?php if(empty($exams)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">No Exams Found</h4>
                <p class="text-muted mb-4">
                    <?php 
                    if (!empty($search) || !empty($status_filter) || !empty($type_filter) || !empty($course_filter)) {
                        echo 'Try adjusting your filters to see more results.';
                    } else {
                        echo 'You haven\'t created any exams yet. Start by creating your first exam.';
                    }
                    ?>
                </p>
                <a href="create_exam.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-plus-circle me-2"></i> Create Your First Exam
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach($exams as $exam): 
                $now = new DateTime();
                $start_date = new DateTime($exam['start_date']);
                $end_date = new DateTime($exam['end_date']);
                $is_ongoing = $exam['is_active'] && $now >= $start_date && $now <= $end_date;
                $is_upcoming = $exam['is_active'] && $now < $start_date;
                $is_expired = $now > $end_date;
            ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 exam-card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="mb-0 text-truncate"><?php echo htmlspecialchars($exam['course_code']); ?></h6>
                                <span class="badge bg-<?php 
                                    if ($is_ongoing) echo 'success';
                                    elseif ($is_upcoming) echo 'warning';
                                    elseif ($is_expired) echo 'secondary';
                                    else echo 'danger';
                                ?>">
                                    <?php 
                                    if ($is_ongoing) echo 'Ongoing';
                                    elseif ($is_upcoming) echo 'Upcoming';
                                    elseif ($is_expired) echo 'Expired';
                                    else echo 'Inactive';
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="card-body">
                            <h6 class="card-title"><?php echo htmlspecialchars($exam['title']); ?></h6>
                            <p class="card-text small text-muted">
                                <?php echo substr(htmlspecialchars($exam['description']), 0, 100); ?>...
                            </p>
                            
                            <div class="mb-3">
                                <span class="badge bg-primary">
                                    <i class="fas fa-<?php 
                                    switch($exam['exam_type']) {
                                        case 'quiz': echo 'bolt'; break;
                                        case 'midterm': echo 'file-medical'; break;
                                        case 'final': echo 'file-contract'; break;
                                        case 'assignment': echo 'tasks'; break;
                                        default: echo 'file-alt';
                                    }
                                    ?> me-1"></i>
                                    <?php echo ucfirst($exam['exam_type']); ?>
                                </span>
                            </div>
                            
                            <div class="row text-center small">
                                <div class="col-4">
                                    <div class="fw-bold text-primary"><?php echo $exam['question_count']; ?></div>
                                    <small class="text-muted">Questions</small>
                                </div>
                                <div class="col-4">
                                    <div class="fw-bold text-info"><?php echo $exam['attempt_count']; ?></div>
                                    <small class="text-muted">Attempts</small>
                                </div>
                                <div class="col-4">
                                    <div class="fw-bold text-success"><?php echo $exam['graded_count']; ?></div>
                                    <small class="text-muted">Graded</small>
                                </div>
                            </div>
                            
                            <div class="mt-3 small text-muted">
                                <div><i class="fas fa-clock me-1"></i> <?php echo $exam['duration_minutes']; ?> mins</div>
                                <div><i class="fas fa-star me-1"></i> <?php echo $exam['passing_marks']; ?>/<?php echo $exam['total_marks']; ?> to pass</div>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="btn-group w-100">
                                <a href="view_exams.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <a href="add_question.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-question-circle"></i> Questions
                                </a>
                                <a href="view_results.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-outline-info btn-sm">
                                    <i class="fas fa-chart-line"></i> Results
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <style>
    .exam-card {
        transition: all 0.3s ease;
        border: 1px solid #e3e6f0;
    }
    
    .exam-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-color: #4e73df;
    }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus search field
        const searchField = document.getElementById('search');
        if (searchField) {
            searchField.focus();
        }
        
        // Add click animations to exam cards
        const examCards = document.querySelectorAll('.exam-card');
        examCards.forEach(card => {
            card.addEventListener('click', function(e) {
                if (!e.target.closest('a')) {
                    const viewLink = this.querySelector('a[href*="view_exams.php?exam_id"]');
                    if (viewLink) {
                        viewLink.click();
                    }
                }
            });
        });
    });
    </script>

    <?php require_once '../includes/footer.php'; ?>
    <?php exit();
}

// If we have a specific exam ID, show detailed view
try {
    $stmt = $pdo->prepare("
        SELECT e.*, 
               c.course_code, c.course_name,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id) as attempt_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND status = 'graded') as graded_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND status = 'in_progress') as in_progress_count,
               (SELECT AVG(obtained_marks) FROM results WHERE exam_id = e.id) as average_marks
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.id = ? AND e.instructor_id = ?
    ");
    $stmt->execute([$exam_id, $instructor_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        setFlash('error', 'Exam not found or you do not have permission to view it.');
        redirect('view_exams.php');
    }
    
    // Get questions for this exam
    $stmt = $pdo->prepare("
        SELECT * FROM questions 
        WHERE exam_id = ? 
        ORDER BY question_order ASC, id ASC
    ");
    $stmt->execute([$exam_id]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent attempts
    $stmt = $pdo->prepare("
        SELECT ea.*, u.first_name, u.last_name, u.username,
               r.obtained_marks, r.percentage, r.grade, r.status as result_status
        FROM exam_attempts ea
        LEFT JOIN users u ON ea.student_id = u.id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE ea.exam_id = ?
        ORDER BY ea.started_at DESC
        LIMIT 10
    ");
    $stmt->execute([$exam_id]);
    $recent_attempts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get question type distribution
    $stmt = $pdo->prepare("
        SELECT question_type, COUNT(*) as count, SUM(marks) as total_marks
        FROM questions 
        WHERE exam_id = ? 
        GROUP BY question_type
    ");
    $stmt->execute([$exam_id]);
    $question_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get performance statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_attempts,
            SUM(CASE WHEN r.status = 'pass' THEN 1 ELSE 0 END) as passed,
            SUM(CASE WHEN r.status = 'fail' THEN 1 ELSE 0 END) as failed,
            MAX(r.obtained_marks) as highest_marks,
            MIN(r.obtained_marks) as lowest_marks
        FROM results r
        WHERE r.exam_id = ?
    ");
    $stmt->execute([$exam_id]);
    $performance_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exam details: ' . $e->getMessage());
    $exam = null;
    $questions = [];
    $recent_attempts = [];
    $question_types = [];
    $performance_stats = [];
}

if (!$exam) {
    setFlash('error', 'Exam not found.');
    redirect('view_exams.php');
}

$now = new DateTime();
$start_date = new DateTime($exam['start_date']);
$end_date = new DateTime($exam['end_date']);
$is_ongoing = $exam['is_active'] && $now >= $start_date && $now <= $end_date;
$is_upcoming = $exam['is_active'] && $now < $start_date;
$is_expired = $now > $end_date;

$page_title = $exam['title'] . ' - Exam Details';
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1"><?php echo htmlspecialchars($exam['title']); ?></h1>
                <p class="text-muted mb-0">
                    <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?>
                    • 
                    <span class="text-<?php 
                        if ($is_ongoing) echo 'success';
                        elseif ($is_upcoming) echo 'warning';
                        elseif ($is_expired) echo 'secondary';
                        else echo 'danger';
                    ?>">
                        <?php 
                        if ($is_ongoing) echo '🟢 Ongoing';
                        elseif ($is_upcoming) echo '🟡 Upcoming';
                        elseif ($is_expired) echo '⚫ Expired';
                        else echo '🔴 Inactive';
                        ?>
                    </span>
                </p>
            </div>
            <div class="btn-group">
                <a href="add_question.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-success">
                    <i class="fas fa-question-circle me-2"></i> Manage Questions
                </a>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editExamModal">
                    <i class="fas fa-edit me-2"></i> Edit Exam
                </button>
                <a href="view_exams.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i> Back to List
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-primary text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $exam['question_count']; ?></div>
                <small>Questions</small>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-info text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $exam['attempt_count']; ?></div>
                <small>Total Attempts</small>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-success text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $exam['graded_count']; ?></div>
                <small>Graded</small>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-warning text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $exam['in_progress_count']; ?></div>
                <small>In Progress</small>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-secondary text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $performance_stats['passed'] ?? 0; ?></div>
                <small>Passed</small>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-6 mb-3">
        <div class="card bg-danger text-white">
            <div class="card-body text-center py-3">
                <div class="h4 mb-0"><?php echo $performance_stats['failed'] ?? 0; ?></div>
                <small>Failed</small>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column - Exam Details -->
    <div class="col-lg-8">
        <!-- Exam Information Card -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-info-circle me-2 text-primary"></i>
                    Exam Information
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td class="text-muted" width="40%">Exam Type:</td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?php echo ucfirst($exam['exam_type']); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Total Marks:</td>
                                <td><strong><?php echo $exam['total_marks']; ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Passing Marks:</td>
                                <td><strong><?php echo $exam['passing_marks']; ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Duration:</td>
                                <td><strong><?php echo $exam['duration_minutes']; ?> minutes</strong></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td class="text-muted" width="40%">Start Date:</td>
                                <td><strong><?php echo formatDate($exam['start_date']); ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">End Date:</td>
                                <td><strong><?php echo formatDate($exam['end_date']); ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Time Remaining:</td>
                                <td>
                                    <?php if ($is_ongoing): ?>
                                        <span class="badge bg-success">
                                            <?php 
                                            $interval = $now->diff($end_date);
                                            echo $interval->format('%a days %h hours %i minutes');
                                            ?>
                                        </span>
                                    <?php elseif ($is_upcoming): ?>
                                        <span class="badge bg-warning">
                                            Starts in <?php 
                                            $interval = $now->diff($start_date);
                                            echo $interval->format('%a days %h hours');
                                            ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Expired</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Status:</td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                                        <input type="hidden" name="current_status" value="<?php echo $exam['is_active']; ?>">
                                        <button type="submit" name="toggle_exam_status" class="btn btn-sm btn-<?php echo $exam['is_active'] ? 'warning' : 'success'; ?>">
                                            <i class="fas fa-<?php echo $exam['is_active'] ? 'pause' : 'play'; ?> me-1"></i>
                                            <?php echo $exam['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <?php if(!empty($exam['description'])): ?>
                    <div class="mt-3">
                        <h6>Description:</h6>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($exam['description'])); ?></p>
                    </div>
                <?php endif; ?>
                
                <div class="mt-3">
                    <h6>Exam Settings:</h6>
                    <div class="d-flex gap-4">
                        <span>
                            <i class="fas fa-<?php echo $exam['allow_retake'] ? 'check text-success' : 'times text-danger'; ?> me-1"></i>
                            Retake Allowed
                        </span>
                        <span>
                            <i class="fas fa-<?php echo $exam['show_results_immediately'] ? 'check text-success' : 'times text-danger'; ?> me-1"></i>
                            Instant Results
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Questions Card -->
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-question-circle me-2 text-success"></i>
                    Questions (<?php echo count($questions); ?>)
                </h5>
                <a href="add_question.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-plus me-1"></i> Add Questions
                </a>
            </div>
            <div class="card-body p-0">
                <?php if(empty($questions)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-question-circle fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Questions Added Yet</h6>
                        <p class="text-muted mb-3">Start by adding questions to your exam.</p>
                        <a href="add_question.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i> Add First Question
                        </a>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($questions as $index => $question): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-primary me-2">#<?php echo $index + 1; ?></span>
                                            <span class="badge bg-<?php 
                                                switch($question['question_type']) {
                                                    case 'multiple_choice': echo 'info'; break;
                                                    case 'true_false': echo 'warning'; break;
                                                    case 'short_answer': echo 'success'; break;
                                                    case 'essay': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?> me-2">
                                                <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <i class="fas fa-star me-1 text-warning"></i>
                                                <?php echo $question['marks']; ?> marks
                                            </span>
                                        </div>
                                        <h6 class="mb-2"><?php echo htmlspecialchars($question['question_text']); ?></h6>
                                        
                                        <?php if($question['question_type'] == 'multiple_choice'): ?>
                                            <div class="row small text-muted">
                                                <?php if(!empty($question['option_a'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>A:</strong> <?php echo htmlspecialchars($question['option_a']); ?>
                                                        <?php if($question['correct_answer'] == 'A'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_b'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>B:</strong> <?php echo htmlspecialchars($question['option_b']); ?>
                                                        <?php if($question['correct_answer'] == 'B'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_c'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>C:</strong> <?php echo htmlspecialchars($question['option_c']); ?>
                                                        <?php if($question['correct_answer'] == 'C'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_d'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>D:</strong> <?php echo htmlspecialchars($question['option_d']); ?>
                                                        <?php if($question['correct_answer'] == 'D'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php elseif($question['question_type'] == 'true_false'): ?>
                                            <div class="small text-muted">
                                                Correct Answer: <strong><?php echo $question['correct_answer']; ?></strong>
                                            </div>
                                        <?php elseif(in_array($question['question_type'], ['short_answer', 'essay'])): ?>
                                            <div class="small text-muted">
                                                Expected Answer: <?php echo !empty($question['correct_answer']) ? htmlspecialchars(substr($question['correct_answer'], 0, 100)) . '...' : 'Not specified'; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-shrink-0 ms-3">
                                        <a href="edit_question.php?question_id=<?php echo $question['id']; ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column - Statistics & Recent Activity -->
    <div class="col-lg-4">
        <!-- Performance Statistics -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-info"></i>
                    Performance Statistics
                </h5>
            </div>
            <div class="card-body">
                <?php if($performance_stats && $performance_stats['total_attempts'] > 0): ?>
                    <div class="text-center mb-3">
                        <div class="h4 text-primary"><?php echo number_format($exam['average_marks'] ?? 0, 1); ?></div>
                        <small class="text-muted">Average Marks</small>
                    </div>
                    
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="h5 text-success"><?php echo $performance_stats['highest_marks'] ?? 0; ?></div>
                            <small class="text-muted">Highest</small>
                        </div>
                        <div class="col-6">
                            <div class="h5 text-danger"><?php echo $performance_stats['lowest_marks'] ?? 0; ?></div>
                            <small class="text-muted">Lowest</small>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Pass Rate</span>
                            <span><?php echo $performance_stats['total_attempts'] > 0 ? number_format(($performance_stats['passed'] / $performance_stats['total_attempts']) * 100, 1) : 0; ?>%</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: <?php echo $performance_stats['total_attempts'] > 0 ? ($performance_stats['passed'] / $performance_stats['total_attempts']) * 100 : 0; ?>%"></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-chart-bar fa-2x mb-2"></i>
                        <p>No performance data available yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Question Type Distribution -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-pie-chart me-2 text-warning"></i>
                    Question Types
                </h5>
            </div>
            <div class="card-body">
                <?php if(!empty($question_types)): ?>
                    <?php foreach($question_types as $type): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $type['question_type'])); ?></span>
                            <div>
                                <span class="badge bg-primary"><?php echo $type['count']; ?></span>
                                <small class="text-muted">(<?php echo $type['total_marks']; ?> marks)</small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted text-center mb-0">No questions added</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Attempts -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-history me-2 text-secondary"></i>
                    Recent Attempts
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_attempts)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-users fa-2x text-muted mb-2"></i>
                        <p class="text-muted mb-0">No attempts yet</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($recent_attempts as $attempt): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($attempt['first_name'] . ' ' . $attempt['last_name']); ?></h6>
                                        <small class="text-muted">@<?php echo htmlspecialchars($attempt['username']); ?></small>
                                    </div>
                                    <div class="text-end">
                                        <?php if($attempt['result_status']): ?>
                                            <span class="badge bg-<?php echo $attempt['result_status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($attempt['result_status']); ?>
                                            </span>
                                            <div class="small text-muted"><?php echo $attempt['obtained_marks']; ?> marks</div>
                                        <?php else: ?>
                                            <span class="badge bg-warning">In Progress</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <small class="text-muted">
                                    <?php echo formatDate($attempt['started_at']); ?>
                                </small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-footer bg-white text-center">
                        <a href="view_results.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-outline-primary btn-sm">
                            View All Results
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit Exam Modal -->
<div class="modal fade" id="editExamModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Exam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_title" class="form-label">Exam Title *</label>
                                <input type="text" class="form-control" id="edit_title" name="title" 
                                       value="<?php echo htmlspecialchars($exam['title']); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_exam_type" class="form-label">Exam Type *</label>
                                <select class="form-select" id="edit_exam_type" name="exam_type" required>
                                    <option value="quiz" <?php echo $exam['exam_type'] == 'quiz' ? 'selected' : ''; ?>>Quiz</option>
                                    <option value="midterm" <?php echo $exam['exam_type'] == 'midterm' ? 'selected' : ''; ?>>Midterm</option>
                                    <option value="final" <?php echo $exam['exam_type'] == 'final' ? 'selected' : ''; ?>>Final</option>
                                    <option value="assignment" <?php echo $exam['exam_type'] == 'assignment' ? 'selected' : ''; ?>>Assignment</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"><?php echo htmlspecialchars($exam['description']); ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_total_marks" class="form-label">Total Marks *</label>
                                <input type="number" class="form-control" id="edit_total_marks" name="total_marks" 
                                       value="<?php echo $exam['total_marks']; ?>" min="1" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_passing_marks" class="form-label">Passing Marks *</label>
                                <input type="number" class="form-control" id="edit_passing_marks" name="passing_marks" 
                                       value="<?php echo $exam['passing_marks']; ?>" min="1" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_duration_minutes" class="form-label">Duration (minutes) *</label>
                                <input type="number" class="form-control" id="edit_duration_minutes" name="duration_minutes" 
                                       value="<?php echo $exam['duration_minutes']; ?>" min="1" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_start_date" class="form-label">Start Date & Time *</label>
                                <input type="datetime-local" class="form-control" id="edit_start_date" name="start_date" 
                                       value="<?php echo date('Y-m-d\TH:i', strtotime($exam['start_date'])); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_end_date" class="form-label">End Date & Time *</label>
                                <input type="datetime-local" class="form-control" id="edit_end_date" name="end_date" 
                                       value="<?php echo date('Y-m-d\TH:i', strtotime($exam['end_date'])); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1" 
                                           <?php echo $exam['is_active'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="edit_is_active">Active Exam</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_allow_retake" name="allow_retake" value="1" 
                                           <?php echo $exam['allow_retake'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="edit_allow_retake">Allow Retake</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_show_results_immediately" name="show_results_immediately" value="1" 
                                           <?php echo $exam['show_results_immediately'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="edit_show_results_immediately">Show Results Immediately</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_exam" class="btn btn-primary">Update Exam</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Validate passing marks in edit form
    const totalMarksInput = document.getElementById('edit_total_marks');
    const passingMarksInput = document.getElementById('edit_passing_marks');
    
    function validatePassingMarks() {
        const total = parseInt(totalMarksInput.value) || 0;
        const passing = parseInt(passingMarksInput.value) || 0;
        
        if (passing > total) {
            passingMarksInput.classList.add('is-invalid');
            return false;
        } else {
            passingMarksInput.classList.remove('is-invalid');
            return true;
        }
    }
    
    totalMarksInput.addEventListener('input', validatePassingMarks);
    passingMarksInput.addEventListener('input', validatePassingMarks);
    
    // Form submission validation
    const editForm = document.querySelector('#editExamModal form');
    if (editForm) {
        editForm.addEventListener('submit', function(e) {
            if (!validatePassingMarks()) {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>