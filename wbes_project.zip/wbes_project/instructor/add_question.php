<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Add Questions';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Debug: Check if exam_id is received
error_log("Exam ID received: " . $exam_id);

// Get instructor's exams for dropdown
try {
    $stmt = $pdo->prepare("
        SELECT e.id, e.title, c.course_code, c.course_name
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.instructor_id = ?
        ORDER BY e.created_at DESC
    ");
    $stmt->execute([$instructor_id]);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    error_log("Instructor exams found: " . count($exams));
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exams: ' . $e->getMessage());
    $exams = [];
}

// If exam_id is provided, get exam details
$exam = null;
if ($exam_id > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT e.*, c.course_code, c.course_name
            FROM exams e 
            LEFT JOIN courses c ON e.course_id = c.id 
            WHERE e.id = ? AND e.instructor_id = ?
        ");
        $stmt->execute([$exam_id, $instructor_id]);
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        error_log("Exam details found: " . ($exam ? 'Yes' : 'No'));
        
        if (!$exam) {
            setFlash('error', 'Exam not found or you do not have permission to access it.');
            $exam_id = 0;
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching exam details: ' . $e->getMessage());
        $exam = null;
        $exam_id = 0;
    }
}

// Get existing questions for the selected exam
$questions = [];
if ($exam_id > 0 && $exam) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM questions 
            WHERE exam_id = ? 
            ORDER BY question_order ASC, id ASC
        ");
        $stmt->execute([$exam_id]);
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Questions found for exam: " . count($questions));
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching questions: ' . $e->getMessage());
        $questions = [];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_question'])) {
        $exam_id = $_POST['exam_id'];
        $question_type = sanitize($_POST['question_type']);
        $question_text = sanitize($_POST['question_text']);
        $marks = $_POST['marks'];
        $question_order = $_POST['question_order'] ?? 0;
        $explanation = sanitize($_POST['explanation'] ?? '');
        
        // Initialize variables for different question types
        $option_a = $option_b = $option_c = $option_d = $correct_answer = '';
        
        switch($question_type) {
            case 'multiple_choice':
                $option_a = sanitize($_POST['option_a']);
                $option_b = sanitize($_POST['option_b']);
                $option_c = sanitize($_POST['option_c'] ?? '');
                $option_d = sanitize($_POST['option_d'] ?? '');
                $correct_answer = sanitize($_POST['correct_answer']);
                break;
                
            case 'true_false':
                $correct_answer = sanitize($_POST['correct_answer_tf']);
                break;
                
            case 'short_answer':
            case 'essay':
                $correct_answer = sanitize($_POST['correct_answer_text']);
                break;
        }
        
        // Validation
        $errors = [];
        
        if (empty($exam_id)) {
            $errors[] = 'Please select an exam.';
        }
        
        if (empty($question_text)) {
            $errors[] = 'Question text is required.';
        }
        
        if (empty($marks) || $marks <= 0) {
            $errors[] = 'Please enter valid marks.';
        }
        
        if ($question_type == 'multiple_choice') {
            if (empty($option_a) || empty($option_b)) {
                $errors[] = 'At least two options are required for multiple choice questions.';
            }
            if (empty($correct_answer)) {
                $errors[] = 'Please select the correct answer.';
            }
        }
        
        if ($question_type == 'true_false' && empty($correct_answer)) {
            $errors[] = 'Please select the correct answer.';
        }
        
        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO questions (exam_id, question_type, question_text, option_a, option_b, option_c, option_d, correct_answer, marks, explanation, question_order) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $exam_id, $question_type, $question_text, $option_a, $option_b, $option_c, $option_d, 
                    $correct_answer, $marks, $explanation, $question_order
                ]);
                
                $question_id = $pdo->lastInsertId();
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $instructor_id,
                    'question_added',
                    'Added question to exam ID: ' . $exam_id,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Question added successfully!');
                
                // Clear form or redirect based on user preference
                if (isset($_POST['add_another'])) {
                    redirect('add_question.php?exam_id=' . $exam_id);
                } else {
                    redirect('add_question.php?exam_id=' . $exam_id);
                }
                
            } catch(PDOException $e) {
                setFlash('error', 'Error adding question: ' . $e->getMessage());
                error_log("Error adding question: " . $e->getMessage());
            }
        } else {
            foreach($errors as $error) {
                setFlash('error', $error);
            }
        }
    }
}
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-question-circle me-2"></i> Add New Question
                </h5>
            </div>
            <div class="card-body">
                <!-- Exam Selection -->
                <div class="mb-4">
                    <label class="form-label fw-bold">Select Exam</label>
                    <select class="form-select" id="exam_selector" onchange="if(this.value) window.location.href = 'add_question.php?exam_id=' + this.value">
                        <option value="">-- Select an Exam --</option>
                        <?php foreach($exams as $exam_item): ?>
                            <option value="<?php echo $exam_item['id']; ?>" 
                                <?php echo $exam_id == $exam_item['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($exam_item['course_code'] . ' - ' . $exam_item['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Select an exam to add questions to it.</div>
                </div>

                <?php if($exam_id > 0 && $exam): ?>
                    <!-- Exam Information -->
                    <div class="alert alert-info">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="alert-heading mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                <p class="mb-1"><?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?></p>
                                <small class="text-muted">
                                    Total Marks: <strong><?php echo $exam['total_marks']; ?></strong> | 
                                    Passing: <strong><?php echo $exam['passing_marks']; ?></strong> | 
                                    Duration: <strong><?php echo $exam['duration_minutes']; ?> mins</strong> |
                                    Type: <strong><?php echo ucfirst($exam['exam_type']); ?></strong>
                                </small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-primary"><?php echo count($questions); ?> Questions</span>
                            </div>
                        </div>
                    </div>

                    <!-- Question Form -->
                    <form method="POST" id="questionForm" novalidate>
                        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                        
                        <!-- Question Type -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-cog me-2 text-primary"></i>
                                Question Type & Settings
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="question_type" class="form-label">Question Type *</label>
                                        <select class="form-select" id="question_type" name="question_type" required onchange="toggleQuestionFields()">
                                            <option value="multiple_choice">Multiple Choice</option>
                                            <option value="true_false">True/False</option>
                                            <option value="short_answer">Short Answer</option>
                                            <option value="essay">Essay</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="marks" class="form-label">Marks *</label>
                                        <input type="number" class="form-control" id="marks" name="marks" 
                                               min="1" max="100" value="1" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3">
                                        <label for="question_order" class="form-label">Order</label>
                                        <input type="number" class="form-control" id="question_order" name="question_order" 
                                               min="0" value="<?php echo count($questions) + 1; ?>">
                                        <div class="form-text">Display order (0 = auto)</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Question Text -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-edit me-2 text-success"></i>
                                Question Content
                            </h6>
                            
                            <div class="mb-3">
                                <label for="question_text" class="form-label">Question Text *</label>
                                <textarea class="form-control" id="question_text" name="question_text" 
                                          rows="3" placeholder="Enter your question here..." required></textarea>
                                <div class="form-text">Write clear and concise questions.</div>
                            </div>
                        </div>

                        <!-- Multiple Choice Options (Initially shown) -->
                        <div class="mb-4" id="multiple_choice_section">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-list-ol me-2 text-info"></i>
                                Multiple Choice Options
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="option_a" class="form-label">Option A *</label>
                                        <div class="input-group">
                                            <span class="input-group-text">A</span>
                                            <input type="text" class="form-control" id="option_a" name="option_a" 
                                                   placeholder="Enter option A">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="option_b" class="form-label">Option B *</label>
                                        <div class="input-group">
                                            <span class="input-group-text">B</span>
                                            <input type="text" class="form-control" id="option_b" name="option_b" 
                                                   placeholder="Enter option B">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="option_c" class="form-label">Option C</label>
                                        <div class="input-group">
                                            <span class="input-group-text">C</span>
                                            <input type="text" class="form-control" id="option_c" name="option_c" 
                                                   placeholder="Enter option C (optional)">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="option_d" class="form-label">Option D</label>
                                        <div class="input-group">
                                            <span class="input-group-text">D</span>
                                            <input type="text" class="form-control" id="option_d" name="option_d" 
                                                   placeholder="Enter option D (optional)">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Correct Answer *</label>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer" id="correct_a" value="A">
                                            <label class="form-check-label" for="correct_a">Option A</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer" id="correct_b" value="B">
                                            <label class="form-check-label" for="correct_b">Option B</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer" id="correct_c" value="C">
                                            <label class="form-check-label" for="correct_c">Option C</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer" id="correct_d" value="D">
                                            <label class="form-check-label" for="correct_d">Option D</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- True/False Options (Initially hidden) -->
                        <div class="mb-4" id="true_false_section" style="display: none;">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-check-circle me-2 text-warning"></i>
                                True/False Options
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Correct Answer *</label>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer_tf" id="correct_true" value="TRUE">
                                            <label class="form-check-label" for="correct_true">True</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="correct_answer_tf" id="correct_false" value="FALSE">
                                            <label class="form-check-label" for="correct_false">False</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Short Answer/Essay Options (Initially hidden) -->
                        <div class="mb-4" id="text_answer_section" style="display: none;">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-align-left me-2 text-success"></i>
                                Expected Answer
                            </h6>
                            
                            <div class="mb-3">
                                <label for="correct_answer_text" class="form-label">Expected Answer</label>
                                <textarea class="form-control" id="correct_answer_text" name="correct_answer_text" 
                                          rows="3" placeholder="Enter the expected answer or key points..."></textarea>
                                <div class="form-text">For essay questions, provide key points or a model answer.</div>
                            </div>
                        </div>

                        <!-- Explanation -->
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-lightbulb me-2 text-warning"></i>
                                Explanation & Feedback
                            </h6>
                            
                            <div class="mb-3">
                                <label for="explanation" class="form-label">Explanation (Optional)</label>
                                <textarea class="form-control" id="explanation" name="explanation" 
                                          rows="2" placeholder="Provide explanation for the correct answer..."></textarea>
                                <div class="form-text">This will be shown to students after they complete the exam.</div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="view_exams.php?exam_id=<?php echo $exam_id; ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Back to Exam
                            </a>
                            <div class="btn-group">
                                <button type="submit" name="add_question" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i> Add Question
                                </button>
                                <button type="submit" name="add_question" class="btn btn-success" onclick="document.getElementById('add_another').value='1';">
                                    <i class="fas fa-plus-circle me-2"></i> Add & New
                                </button>
                            </div>
                        </div>
                        <input type="hidden" name="add_another" id="add_another" value="0">
                    </form>
                <?php elseif($exam_id > 0 && !$exam): ?>
                    <div class="alert alert-danger text-center">
                        <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
                        <h5>Exam Not Found</h5>
                        <p class="mb-0">The selected exam was not found or you don't have permission to access it.</p>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle fa-2x mb-3"></i>
                        <h5>Select an Exam</h5>
                        <p class="mb-3">Please select an exam from the dropdown above to start adding questions.</p>
                        <?php if(empty($exams)): ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                You don't have any exams yet. 
                                <a href="create_exam.php" class="alert-link">Create your first exam</a> to get started.
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Existing Questions Card (Only shown when exam is selected) -->
        <?php if($exam_id > 0 && $exam && !empty($questions)): ?>
            <div class="card mt-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-list me-2 text-primary"></i>
                        Existing Questions (<?php echo count($questions); ?>)
                    </h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach($questions as $index => $question): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-primary me-2">#<?php echo $index + 1; ?></span>
                                            <span class="badge bg-<?php 
                                                switch($question['question_type']) {
                                                    case 'multiple_choice': echo 'info'; break;
                                                    case 'true_false': echo 'warning'; break;
                                                    case 'short_answer': echo 'success'; break;
                                                    case 'essay': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?> me-2">
                                                <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <i class="fas fa-star me-1 text-warning"></i>
                                                <?php echo $question['marks']; ?> marks
                                            </span>
                                        </div>
                                        <h6 class="mb-2"><?php echo htmlspecialchars($question['question_text']); ?></h6>
                                        
                                        <?php if($question['question_type'] == 'multiple_choice'): ?>
                                            <div class="row small text-muted">
                                                <?php if(!empty($question['option_a'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>A:</strong> <?php echo htmlspecialchars($question['option_a']); ?>
                                                        <?php if($question['correct_answer'] == 'A'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_b'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>B:</strong> <?php echo htmlspecialchars($question['option_b']); ?>
                                                        <?php if($question['correct_answer'] == 'B'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_c'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>C:</strong> <?php echo htmlspecialchars($question['option_c']); ?>
                                                        <?php if($question['correct_answer'] == 'C'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($question['option_d'])): ?>
                                                    <div class="col-md-6 mb-1">
                                                        <strong>D:</strong> <?php echo htmlspecialchars($question['option_d']); ?>
                                                        <?php if($question['correct_answer'] == 'D'): ?>
                                                            <i class="fas fa-check text-success ms-1"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php elseif($question['question_type'] == 'true_false'): ?>
                                            <div class="small text-muted">
                                                Correct Answer: <strong><?php echo $question['correct_answer']; ?></strong>
                                            </div>
                                        <?php elseif(in_array($question['question_type'], ['short_answer', 'essay'])): ?>
                                            <div class="small text-muted">
                                                Expected Answer: <?php echo !empty($question['correct_answer']) ? htmlspecialchars(substr($question['correct_answer'], 0, 100)) . '...' : 'Not specified'; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-shrink-0 ms-3">
                                        <a href="edit_question.php?question_id=<?php echo $question['id']; ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleQuestionFields() {
    const questionType = document.getElementById('question_type').value;
    
    // Hide all sections first
    document.getElementById('multiple_choice_section').style.display = 'none';
    document.getElementById('true_false_section').style.display = 'none';
    document.getElementById('text_answer_section').style.display = 'none';
    
    // Show relevant section based on question type
    switch(questionType) {
        case 'multiple_choice':
            document.getElementById('multiple_choice_section').style.display = 'block';
            break;
        case 'true_false':
            document.getElementById('true_false_section').style.display = 'block';
            break;
        case 'short_answer':
        case 'essay':
            document.getElementById('text_answer_section').style.display = 'block';
            break;
    }
    
    // Adjust default marks based on question type
    const marksInput = document.getElementById('marks');
    switch(questionType) {
        case 'multiple_choice':
            marksInput.value = '1';
            break;
        case 'true_false':
            marksInput.value = '1';
            break;
        case 'short_answer':
            marksInput.value = '2';
            break;
        case 'essay':
            marksInput.value = '5';
            break;
    }
}

// Auto-suggest question order
function updateQuestionOrder() {
    const questionCount = <?php echo count($questions); ?>;
    document.getElementById('question_order').value = questionCount + 1;
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    // Initialize question type fields
    toggleQuestionFields();
    
    const form = document.getElementById('questionForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const questionType = document.getElementById('question_type').value;
            let isValid = true;
            
            // Validate multiple choice
            if (questionType === 'multiple_choice') {
                const optionA = document.getElementById('option_a').value.trim();
                const optionB = document.getElementById('option_b').value.trim();
                const correctAnswer = document.querySelector('input[name="correct_answer"]:checked');
                
                if (!optionA || !optionB) {
                    alert('Please fill at least options A and B for multiple choice questions.');
                    isValid = false;
                }
                
                if (!correctAnswer) {
                    alert('Please select the correct answer for the multiple choice question.');
                    isValid = false;
                }
            }
            
            // Validate true/false
            if (questionType === 'true_false') {
                const correctAnswer = document.querySelector('input[name="correct_answer_tf"]:checked');
                if (!correctAnswer) {
                    alert('Please select the correct answer for the true/false question.');
                    isValid = false;
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            form.classList.add('was-validated');
        });
    }
    
    // Auto-focus question text field when exam is selected
    if (document.getElementById('question_text')) {
        document.getElementById('question_text').focus();
    }
    
    // Update question order when page loads
    updateQuestionOrder();
});

// Character counter for question text
document.addEventListener('DOMContentLoaded', function() {
    const questionText = document.getElementById('question_text');
    if (questionText) {
        questionText.addEventListener('input', function() {
            const charCount = this.value.length;
            // You can add character count display if needed
        });
    }
});

// Quick question templates
function loadQuestionTemplate(templateType) {
    const questionText = document.getElementById('question_text');
    const marksInput = document.getElementById('marks');
    
    switch(templateType) {
        case 'definition':
            questionText.value = 'Define the term "______" and provide an example.';
            document.getElementById('question_type').value = 'short_answer';
            marksInput.value = '2';
            break;
        case 'multiple_choice':
            questionText.value = 'Which of the following best describes ______?';
            document.getElementById('question_type').value = 'multiple_choice';
            marksInput.value = '1';
            break;
        case 'true_false':
            questionText.value = 'True or False: ______.';
            document.getElementById('question_type').value = 'true_false';
            marksInput.value = '1';
            break;
        case 'essay':
            questionText.value = 'Discuss the importance of ______ in the context of ______. Provide examples to support your answer.';
            document.getElementById('question_type').value = 'essay';
            marksInput.value = '5';
            break;
    }
    
    toggleQuestionFields();
}
</script>

<style>
.form-section {
    border-left: 4px solid #007bff;
    padding-left: 15px;
    margin-bottom: 20px;
}

.question-preview {
    background-color: #f8f9fa;
    border-radius: 5px;
    padding: 15px;
    margin-bottom: 15px;
}

.template-buttons {
    margin-bottom: 15px;
}

.template-buttons .btn {
    margin-right: 5px;
    margin-bottom: 5px;
}
</style>

<?php require_once '../includes/footer.php'; ?>