<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Settings';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$user = getUserData();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        // Update profile information
        $first_name = sanitize($_POST['first_name']);
        $last_name = sanitize($_POST['last_name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $department = sanitize($_POST['department']);
        $academic_year = sanitize($_POST['academic_year']);
        
        try {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET first_name = ?, last_name = ?, email = ?, phone = ?, department = ?, academic_year = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$first_name, $last_name, $email, $phone, $department, $academic_year, $student_id]);
            
            // Update session data
            $_SESSION['user']['first_name'] = $first_name;
            $_SESSION['user']['last_name'] = $last_name;
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['phone'] = $phone;
            $_SESSION['user']['department'] = $department;
            $_SESSION['user']['academic_year'] = $academic_year;
            
            setFlash('success', 'Profile updated successfully!');
            redirect('settings.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error updating profile: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['change_password'])) {
        // Change password
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validate inputs
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            setFlash('error', 'All password fields are required.');
        } elseif ($new_password !== $confirm_password) {
            setFlash('error', 'New passwords do not match.');
        } elseif (strlen($new_password) < 8) {
            setFlash('error', 'New password must be at least 8 characters long.');
        } else {
            try {
                // Verify current password
                $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
                $stmt->execute([$student_id]);
                $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user_data && verifyPassword($current_password, $user_data['password_hash'])) {
                    // Update password
                    $new_hashed_password = hashPassword($new_password);
                    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$new_hashed_password, $student_id]);
                    
                    setFlash('success', 'Password changed successfully!');
                    redirect('settings.php');
                } else {
                    setFlash('error', 'Current password is incorrect.');
                }
            } catch(PDOException $e) {
                setFlash('error', 'Error changing password: ' . $e->getMessage());
            }
        }
    }
    
    if (isset($_POST['update_preferences'])) {
        // Update notification preferences
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        $exam_reminders = isset($_POST['exam_reminders']) ? 1 : 0;
        $result_notifications = isset($_POST['result_notifications']) ? 1 : 0;
        $announcement_notifications = isset($_POST['announcement_notifications']) ? 1 : 0;
        
        // In a real application, you would store these in a user_preferences table
        // For now, we'll just show a success message
        setFlash('success', 'Notification preferences updated successfully!');
        redirect('settings.php');
    }
}

// Get departments for dropdown
try {
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_code");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $departments = [];
}

// Get user's enrolled courses
try {
    $stmt = $pdo->prepare("
        SELECT c.* 
        FROM courses c 
        INNER JOIN enrollments e ON c.id = e.course_id 
        WHERE e.student_id = ? AND e.status = 'active'
        ORDER BY c.course_code
    ");
    $stmt->execute([$student_id]);
    $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $enrolled_courses = [];
}

// Get user's exam statistics
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_exams,
            AVG(r.percentage) as average_score,
            MAX(r.percentage) as highest_score,
            MIN(r.percentage) as lowest_score,
            SUM(CASE WHEN r.status = 'pass' THEN 1 ELSE 0 END) as passed_exams
        FROM results r
        WHERE r.student_id = ?
    ");
    $stmt->execute([$student_id]);
    $exam_stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $exam_stats = [
        'total_exams' => 0,
        'average_score' => 0,
        'highest_score' => 0,
        'lowest_score' => 0,
        'passed_exams' => 0
    ];
}
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1">Settings</h1>
                <p class="text-muted mb-0">Manage your account settings and preferences</p>
            </div>
            <div class="btn-group">
                <button type="button" class="btn btn-outline-primary" onclick="window.print()">
                    <i class="fas fa-print me-2"></i> Print Profile
                </button>
            </div>
        </div>

        <!-- Settings Navigation -->
        <div class="card mb-4">
            <div class="card-body">
                <ul class="nav nav-pills nav-fill" id="settingsTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab">
                            <i class="fas fa-user me-2"></i> Profile
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab">
                            <i class="fas fa-lock me-2"></i> Password
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="notifications-tab" data-bs-toggle="tab" data-bs-target="#notifications" type="button" role="tab">
                            <i class="fas fa-bell me-2"></i> Notifications
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="privacy-tab" data-bs-toggle="tab" data-bs-target="#privacy" type="button" role="tab">
                            <i class="fas fa-shield-alt me-2"></i> Privacy
                        </button>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Tab Content -->
        <div class="tab-content" id="settingsTabsContent">
            
            <!-- Profile Tab -->
            <div class="tab-pane fade show active" id="profile" role="tabpanel">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user me-2 text-primary"></i> Profile Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="first_name" class="form-label">First Name *</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" 
                                               value="<?php echo htmlspecialchars($user['first_name']); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="last_name" class="form-label">Last Name *</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" 
                                               value="<?php echo htmlspecialchars($user['last_name']); ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email Address *</label>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="department" class="form-label">Department</label>
                                        <select class="form-select" id="department" name="department">
                                            <option value="">Select Department</option>
                                            <?php foreach($departments as $dept): ?>
                                                <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" 
                                                    <?php echo ($user['department'] ?? '') == $dept['department_code'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="academic_year" class="form-label">Academic Year</label>
                                        <select class="form-select" id="academic_year" name="academic_year">
                                            <option value="">Select Year</option>
                                            <option value="2023-2024" <?php echo ($user['academic_year'] ?? '') == '2023-2024' ? 'selected' : ''; ?>>2023-2024</option>
                                            <option value="2024-2025" <?php echo ($user['academic_year'] ?? '') == '2024-2025' ? 'selected' : ''; ?>>2024-2025</option>
                                            <option value="2025-2026" <?php echo ($user['academic_year'] ?? '') == '2025-2026' ? 'selected' : ''; ?>>2025-2026</option>
                                            <option value="2026-2027" <?php echo ($user['academic_year'] ?? '') == '2026-2027' ? 'selected' : ''; ?>>2026-2027</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                                <div class="form-text">Username cannot be changed.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Student ID</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['student_id'] ?? 'Not assigned'); ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">University ID</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['university_id'] ?? 'Not assigned'); ?>" readonly>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Last updated: <?php echo formatDate($user['updated_at'] ?? $user['created_at']); ?></small>
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i> Update Profile
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Academic Information -->
                <div class="card mt-4">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-graduation-cap me-2 text-success"></i> Academic Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Enrolled Courses</h6>
                                <?php if(empty($enrolled_courses)): ?>
                                    <p class="text-muted">No courses enrolled.</p>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach($enrolled_courses as $course): ?>
                                            <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                                                <div>
                                                    <strong><?php echo htmlspecialchars($course['course_code']); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($course['course_name']); ?></small>
                                                </div>
                                                <span class="badge bg-primary"><?php echo $course['credits'] ?? 3; ?> credits</span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h6>Exam Statistics</h6>
                                <div class="row text-center">
                                    <div class="col-6 mb-3">
                                        <div class="h4 text-primary"><?php echo $exam_stats['total_exams']; ?></div>
                                        <small class="text-muted">Total Exams</small>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <div class="h4 text-success"><?php echo $exam_stats['passed_exams']; ?></div>
                                        <small class="text-muted">Passed</small>
                                    </div>
                                    <div class="col-6">
                                        <div class="h4 text-info"><?php echo round($exam_stats['average_score'] ?? 0, 1); ?>%</div>
                                        <small class="text-muted">Average Score</small>
                                    </div>
                                    <div class="col-6">
                                        <div class="h4 text-warning"><?php echo $exam_stats['highest_score'] ?? 0; ?>%</div>
                                        <small class="text-muted">Highest Score</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Password Tab -->
            <div class="tab-pane fade" id="password" role="tabpanel">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-lock me-2 text-warning"></i> Change Password
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="passwordForm">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('current_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('new_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    <div id="password-strength" class="mt-2">
                                        <div class="progress" style="height: 5px;">
                                            <div class="progress-bar" id="password-strength-bar" style="width: 0%"></div>
                                        </div>
                                        <small id="password-strength-text" class="text-muted">Password strength</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="8">
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('confirm_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text" id="password-match"></div>
                            </div>
                            
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Password Requirements:</strong>
                                <ul class="mb-0 mt-1">
                                    <li>Minimum 8 characters</li>
                                    <li>Include uppercase and lowercase letters</li>
                                    <li>Include numbers and special characters</li>
                                </ul>
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <button type="submit" name="change_password" class="btn btn-warning">
                                    <i class="fas fa-key me-2"></i> Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Security Tips -->
                <div class="card mt-4">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-shield-alt me-2 text-info"></i> Security Tips
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="d-flex mb-3">
                                    <i class="fas fa-check text-success me-3 mt-1"></i>
                                    <div>
                                        <strong>Use a strong password</strong>
                                        <p class="text-muted mb-0">Combine letters, numbers, and symbols</p>
                                    </div>
                                </div>
                                <div class="d-flex mb-3">
                                    <i class="fas fa-check text-success me-3 mt-1"></i>
                                    <div>
                                        <strong>Don't reuse passwords</strong>
                                        <p class="text-muted mb-0">Use unique passwords for different accounts</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex mb-3">
                                    <i class="fas fa-check text-success me-3 mt-1"></i>
                                    <div>
                                        <strong>Change regularly</strong>
                                        <p class="text-muted mb-0">Update your password every 3-6 months</p>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <i class="fas fa-check text-success me-3 mt-1"></i>
                                    <div>
                                        <strong>Log out after use</strong>
                                        <p class="text-muted mb-0">Especially on shared computers</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Notifications Tab -->
            <div class="tab-pane fade" id="notifications" role="tabpanel">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-bell me-2 text-info"></i> Notification Preferences
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-4">
                                <h6 class="border-bottom pb-2">Email Notifications</h6>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" checked>
                                    <label class="form-check-label" for="email_notifications">
                                        <strong>Email Notifications</strong>
                                        <p class="text-muted mb-0">Receive important updates via email</p>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h6 class="border-bottom pb-2">Exam Notifications</h6>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="exam_reminders" name="exam_reminders" checked>
                                    <label class="form-check-label" for="exam_reminders">
                                        <strong>Exam Reminders</strong>
                                        <p class="text-muted mb-0">Get reminders before exams start</p>
                                    </label>
                                </div>
                                
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="result_notifications" name="result_notifications" checked>
                                    <label class="form-check-label" for="result_notifications">
                                        <strong>Result Notifications</strong>
                                        <p class="text-muted mb-0">Notify when exam results are published</p>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h6 class="border-bottom pb-2">System Notifications</h6>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="announcement_notifications" name="announcement_notifications" checked>
                                    <label class="form-check-label" for="announcement_notifications">
                                        <strong>Announcements</strong>
                                        <p class="text-muted mb-0">Receive system announcements and updates</p>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <button type="submit" name="update_preferences" class="btn btn-info">
                                    <i class="fas fa-save me-2"></i> Save Preferences
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Notification History -->
                <div class="card mt-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-history me-2 text-secondary"></i> Recent Notifications
                        </h5>
                        <a href="notifications.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <?php
                        try {
                            $stmt = $pdo->prepare("
                                SELECT n.*, un.is_read, un.created_at as received_at
                                FROM notifications n 
                                INNER JOIN user_notifications un ON n.id = un.notification_id 
                                WHERE un.user_id = ? 
                                ORDER BY n.created_at DESC 
                                LIMIT 5
                            ");
                            $stmt->execute([$student_id]);
                            $recent_notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        } catch(PDOException $e) {
                            $recent_notifications = [];
                        }
                        ?>
                        
                        <?php if(empty($recent_notifications)): ?>
                            <div class="text-center text-muted py-3">
                                <i class="fas fa-bell-slash fa-2x mb-2"></i>
                                <p>No recent notifications</p>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach($recent_notifications as $notification): ?>
                                    <div class="list-group-item d-flex align-items-start border-0 px-0">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-bell text-<?php echo $notification['is_read'] ? 'muted' : 'warning'; ?> mt-1"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($notification['title']); ?></h6>
                                            <p class="mb-1 text-muted"><?php echo htmlspecialchars(substr($notification['message'], 0, 100)); ?>...</p>
                                            <small class="text-muted"><?php echo formatDate($notification['received_at']); ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Privacy Tab -->
            <div class="tab-pane fade" id="privacy" role="tabpanel">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-shield-alt me-2 text-success"></i> Privacy Settings
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2">Data Privacy</h6>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Your personal information is protected and will only be used for educational purposes.
                            </div>
                            
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="show_profile" checked>
                                <label class="form-check-label" for="show_profile">
                                    <strong>Show my profile to instructors</strong>
                                    <p class="text-muted mb-0">Allow instructors to view your basic profile information</p>
                                </label>
                            </div>
                            
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="show_results" checked>
                                <label class="form-check-label" for="show_results">
                                    <strong>Show my results in class statistics</strong>
                                    <p class="text-muted mb-0">Your results may be included in anonymous class performance data</p>
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h6 class="border-bottom pb-2">Data Management</h6>
                            <p class="text-muted mb-3">Manage your data and account information</p>
                            
                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-outline-primary text-start" onclick="exportData()">
                                    <i class="fas fa-download me-2"></i> Export My Data
                                </button>
                                <button type="button" class="btn btn-outline-warning text-start" data-bs-toggle="modal" data-bs-target="#deactivateModal">
                                    <i class="fas fa-user-slash me-2"></i> Temporary Deactivation
                                </button>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Important:</strong> Account deletion is permanent and cannot be undone. 
                            Contact system administrator for account deletion requests.
                        </div>
                    </div>
                </div>
                
                <!-- Privacy Policy -->
                <div class="card mt-4">
                    <div class="card-header bg-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-file-contract me-2 text-secondary"></i> Privacy Policy
                        </h5>
                    </div>
                    <div class="card-body">
                        <h6>Data Collection</h6>
                        <p class="text-muted">We collect only necessary information for educational purposes:</p>
                        <ul class="text-muted">
                            <li>Personal identification information</li>
                            <li>Academic records and exam results</li>
                            <li>System usage data for improvement</li>
                        </ul>
                        
                        <h6 class="mt-4">Data Usage</h6>
                        <p class="text-muted">Your data is used for:</p>
                        <ul class="text-muted">
                            <li>Exam administration and grading</li>
                            <li>Academic progress tracking</li>
                            <li>System improvements and analytics</li>
                        </ul>
                        
                        <h6 class="mt-4">Data Protection</h6>
                        <p class="text-muted">We implement security measures to protect your data:</p>
                        <ul class="text-muted">
                            <li>Encrypted data transmission</li>
                            <li>Secure password storage</li>
                            <li>Regular security updates</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Deactivation Modal -->
<div class="modal fade" id="deactivateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-warning">Account Deactivation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center text-warning mb-3">
                    <i class="fas fa-exclamation-triangle fa-3x"></i>
                </div>
                <h6 class="text-center">Temporary Account Deactivation</h6>
                <p class="text-muted text-center">
                    Your account will be temporarily deactivated. You can reactivate it anytime by logging in again.
                </p>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Note:</strong> Your data will be preserved but you won't be able to access the system until you reactivate your account.
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="confirmDeactivation">
                    <label class="form-check-label" for="confirmDeactivation">
                        I understand that my account will be temporarily deactivated
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-warning" id="deactivateAccount" disabled>
                    <i class="fas fa-user-slash me-2"></i> Deactivate Account
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Password strength indicator
function checkPasswordStrength(password) {
    let strength = 0;
    let text = 'Very Weak';
    let color = 'danger';
    
    if (password.length >= 8) strength++;
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
    if (password.match(/\d/)) strength++;
    if (password.match(/[^a-zA-Z\d]/)) strength++;
    
    switch(strength) {
        case 4:
            text = 'Very Strong';
            color = 'success';
            break;
        case 3:
            text = 'Strong';
            color = 'info';
            break;
        case 2:
            text = 'Medium';
            color = 'warning';
            break;
        case 1:
            text = 'Weak';
            color = 'danger';
            break;
        default:
            text = 'Very Weak';
            color = 'danger';
    }
    
    return { strength: strength * 25, text, color };
}

// Toggle password visibility
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = field.parentNode.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        field.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Export data function
function exportData() {
    // In a real application, this would generate and download a data export file
    alert('Data export feature would generate a downloadable file with all your information.');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Password strength indicator
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');
    const strengthBar = document.getElementById('password-strength-bar');
    const strengthText = document.getElementById('password-strength-text');
    const passwordMatch = document.getElementById('password-match');
    
    if (newPassword) {
        newPassword.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            
            strengthBar.style.width = strength.strength + '%';
            strengthBar.className = 'progress-bar bg-' + strength.color;
            strengthText.textContent = strength.text;
            strengthText.className = 'text-' + strength.color;
            
            // Check password match
            if (confirmPassword.value) {
                checkPasswordMatch();
            }
        });
    }
    
    if (confirmPassword) {
        confirmPassword.addEventListener('input', checkPasswordMatch);
    }
    
    function checkPasswordMatch() {
        const newPass = newPassword.value;
        const confirmPass = confirmPassword.value;
        
        if (confirmPass === '') {
            passwordMatch.textContent = '';
            passwordMatch.className = 'form-text';
        } else if (newPass === confirmPass) {
            passwordMatch.textContent = '✓ Passwords match';
            passwordMatch.className = 'form-text text-success';
        } else {
            passwordMatch.textContent = '✗ Passwords do not match';
            passwordMatch.className = 'form-text text-danger';
        }
    }
    
    // Deactivation confirmation
    const confirmDeactivation = document.getElementById('confirmDeactivation');
    const deactivateAccount = document.getElementById('deactivateAccount');
    
    if (confirmDeactivation && deactivateAccount) {
        confirmDeactivation.addEventListener('change', function() {
            deactivateAccount.disabled = !this.checked;
        });
        
        deactivateAccount.addEventListener('click', function() {
            if (confirm('Are you sure you want to temporarily deactivate your account?')) {
                alert('Account deactivation feature would be implemented here.');
                // In real application: make API call to deactivate account
            }
        });
    }
    
    // Form validation
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            const newPass = newPassword.value;
            const confirmPass = confirmPassword.value;
            
            if (newPass !== confirmPass) {
                e.preventDefault();
                alert('Passwords do not match. Please check your entries.');
                newPassword.focus();
            }
            
            if (newPass.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long.');
                newPassword.focus();
            }
        });
    }
    
    // Auto-focus first field in active tab
    const activeTab = document.querySelector('.tab-pane.active');
    if (activeTab) {
        const firstInput = activeTab.querySelector('input, select, textarea');
        if (firstInput && firstInput.type !== 'hidden') {
            firstInput.focus();
        }
    }
    
    // Print styles
    const style = document.createElement('style');
    style.textContent = `
        @media print {
            .nav-pills, .btn, .modal, .toast, .card-header .btn {
                display: none !important;
            }
            .card {
                border: 1px solid #000 !important;
                break-inside: avoid;
            }
            .card-header {
                background: #f8f9fa !important;
                color: #000 !important;
            }
        }
    `;
    document.head.appendChild(style);
});
</script>

<style>
.nav-pills .nav-link {
    border-radius: 0.5rem;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
}

.nav-pills .nav-link.active {
    background-color: #007bff;
    box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3);
}

.nav-pills .nav-link:not(.active):hover {
    background-color: #f8f9fa;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.progress {
    background-color: #e9ecef;
}

.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
}

.list-group-item {
    border: none;
    padding: 0.75rem 0;
}

.btn {
    border-radius: 0.375rem;
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-1px);
}

@media (max-width: 768px) {
    .nav-pills {
        flex-direction: column;
    }
    
    .nav-pills .nav-link {
        margin-bottom: 0.5rem;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?>