<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Exam Results';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];

// Get filter parameters
$exam_filter = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : '';
$status_filter = $_GET['status'] ?? '';
$student_filter = $_GET['student'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';
$filter_ungraded = isset($_GET['filter']) && $_GET['filter'] == 'ungraded';

// Get instructor's exams for dropdown
try {
    $stmt = $pdo->prepare("
        SELECT e.id, e.title, c.course_code, c.course_name
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.instructor_id = ?
        ORDER BY e.created_at DESC
    ");
    $stmt->execute([$instructor_id]);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exams: ' . $e->getMessage());
    $exams = [];
}

// Build query for results
$query = "
    SELECT 
        r.*,
        ea.started_at,
        ea.submitted_at,
        ea.time_spent_seconds,
        ea.status as attempt_status,
        u.first_name,
        u.last_name,
        u.username,
        u.email,
        e.title as exam_title,
        e.total_marks,
        e.exam_type,
        c.course_code,
        c.course_name,
        (SELECT COUNT(*) FROM student_answers sa 
         JOIN questions q ON sa.question_id = q.id 
         WHERE sa.attempt_id = ea.id 
         AND q.question_type IN ('essay', 'short_answer')
         AND (sa.graded_by IS NULL OR sa.awarded_marks IS NULL)) as ungraded_answers
    FROM results r
    JOIN exam_attempts ea ON r.attempt_id = ea.id
    JOIN exams e ON ea.exam_id = e.id
    JOIN users u ON ea.student_id = u.id
    JOIN courses c ON e.course_id = c.id
    WHERE e.instructor_id = ?
";

$params = [$instructor_id];

// Apply filters
if (!empty($exam_filter)) {
    $query .= " AND e.id = ?";
    $params[] = $exam_filter;
}

if (!empty($status_filter)) {
    $query .= " AND r.status = ?";
    $params[] = $status_filter;
}

if (!empty($student_filter)) {
    $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ?)";
    $student_term = "%$student_filter%";
    $params[] = $student_term;
    $params[] = $student_term;
    $params[] = $student_term;
}

if (!empty($date_from)) {
    $query .= " AND DATE(ea.submitted_at) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND DATE(ea.submitted_at) <= ?";
    $params[] = $date_to;
}

if (!empty($search)) {
    $query .= " AND (e.title LIKE ? OR c.course_name LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if ($filter_ungraded) {
    $query .= " AND EXISTS (
        SELECT 1 FROM student_answers sa 
        JOIN questions q ON sa.question_id = q.id 
        WHERE sa.attempt_id = ea.id 
        AND q.question_type IN ('essay', 'short_answer')
        AND (sa.graded_by IS NULL OR sa.awarded_marks IS NULL)
    )";
}

$query .= " ORDER BY ea.submitted_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get statistics
    $total_results = count($results);
    $passed_count = 0;
    $failed_count = 0;
    $average_percentage = 0;
    $total_ungraded = 0;
    
    foreach($results as $result) {
        if ($result['status'] == 'pass') {
            $passed_count++;
        } else {
            $failed_count++;
        }
        $average_percentage += $result['percentage'];
        $total_ungraded += $result['ungraded_answers'];
    }
    
    if ($total_results > 0) {
        $average_percentage = round($average_percentage / $total_results, 2);
    }
    
    // Get recent ungraded submissions for quick access
    $stmt = $pdo->prepare("
        SELECT 
            ea.id as attempt_id,
            u.first_name,
            u.last_name,
            u.username,
            e.title as exam_title,
            c.course_code,
            COUNT(sa.id) as ungraded_count
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        JOIN users u ON ea.student_id = u.id
        JOIN student_answers sa ON ea.id = sa.attempt_id
        JOIN questions q ON sa.question_id = q.id
        WHERE e.instructor_id = ?
        AND q.question_type IN ('essay', 'short_answer')
        AND (sa.graded_by IS NULL OR sa.awarded_marks IS NULL)
        AND ea.status = 'submitted'
        GROUP BY ea.id
        ORDER BY ea.submitted_at DESC
        LIMIT 5
    ");
    $stmt->execute([$instructor_id]);
    $ungraded_submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching results: ' . $e->getMessage());
    $results = [];
    $total_results = $passed_count = $failed_count = $average_percentage = $total_ungraded = 0;
    $ungraded_submissions = [];
}

// Handle manual grading
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['grade_answer'])) {
    $attempt_id = $_POST['attempt_id'];
    $question_id = $_POST['question_id'];
    $awarded_marks = $_POST['awarded_marks'];
    $feedback = sanitize($_POST['feedback'] ?? '');
    
    try {
        // Get question details to validate marks
        $stmt = $pdo->prepare("SELECT marks FROM questions WHERE id = ?");
        $stmt->execute([$question_id]);
        $question = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($question && $awarded_marks >= 0 && $awarded_marks <= $question['marks']) {
            $stmt = $pdo->prepare("UPDATE student_answers SET awarded_marks = ?, feedback = ?, graded_by = ?, graded_at = NOW() WHERE attempt_id = ? AND question_id = ?");
            $stmt->execute([$awarded_marks, $feedback, $instructor_id, $attempt_id, $question_id]);
            
            // Recalculate total marks for the attempt
            $stmt = $pdo->prepare("
                UPDATE results r
                JOIN (
                    SELECT attempt_id, SUM(COALESCE(awarded_marks, 0)) as total_obtained
                    FROM student_answers 
                    WHERE attempt_id = ?
                    GROUP BY attempt_id
                ) sa ON r.attempt_id = sa.attempt_id
                SET r.obtained_marks = sa.total_obtained,
                    r.percentage = (sa.total_obtained / r.total_marks) * 100,
                    r.grade = CASE 
                        WHEN (sa.total_obtained / r.total_marks) * 100 >= 90 THEN 'A+'
                        WHEN (sa.total_obtained / r.total_marks) * 100 >= 80 THEN 'A'
                        WHEN (sa.total_obtained / r.total_marks) * 100 >= 70 THEN 'B'
                        WHEN (sa.total_obtained / r.total_marks) * 100 >= 60 THEN 'C'
                        WHEN (sa.total_obtained / r.total_marks) * 100 >= 50 THEN 'D'
                        ELSE 'F'
                    END,
                    r.status = CASE 
                        WHEN sa.total_obtained >= r.passing_marks THEN 'pass'
                        ELSE 'fail'
                    END
                WHERE r.attempt_id = ?
            ");
            $stmt->execute([$attempt_id, $attempt_id]);
            
            setFlash('success', 'Answer graded successfully!');
            redirect('view_results.php?exam_id=' . $exam_filter);
        } else {
            setFlash('error', 'Invalid marks awarded. Please check the maximum marks for this question.');
        }
    } catch(PDOException $e) {
        setFlash('error', 'Error grading answer: ' . $e->getMessage());
    }
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Exam Results</h1>
                <p class="text-muted mb-0">View and manage student exam results</p>
            </div>
            <?php if($total_ungraded > 0): ?>
                <a href="view_results.php?filter=ungraded" class="btn btn-warning">
                    <i class="fas fa-clipboard-check me-2"></i> 
                    Grade Pending (<?php echo $total_ungraded; ?>)
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Results
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_results; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Passed
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $passed_count; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <?php echo $total_results > 0 ? round(($passed_count / $total_results) * 100, 1) : 0; ?>% success rate
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Failed
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $failed_count; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Average Score
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $average_percentage; ?>%</div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <?php echo $total_ungraded; ?> answers need grading
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Grading Panel -->
<?php if(!empty($ungraded_submissions) && !$filter_ungraded): ?>
<div class="card border-warning mb-4">
    <div class="card-header bg-warning text-dark">
        <h5 class="card-title mb-0">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Quick Grading - Pending Submissions
        </h5>
    </div>
    <div class="card-body">
        <div class="row">
            <?php foreach($ungraded_submissions as $submission): ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h6 class="card-title"><?php echo htmlspecialchars($submission['first_name'] . ' ' . $submission['last_name']); ?></h6>
                            <p class="card-text small text-muted mb-2">
                                <?php echo htmlspecialchars($submission['course_code'] . ' - ' . $submission['exam_title']); ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-warning">
                                    <?php echo $submission['ungraded_count']; ?> ungraded answers
                                </span>
                                <a href="view_results.php?exam_id=<?php echo $exam_filter; ?>&attempt_id=<?php echo $submission['attempt_id']; ?>" 
                                   class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit me-1"></i> Grade
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-3">
            <a href="view_results.php?filter=ungraded" class="btn btn-warning">
                <i class="fas fa-list me-2"></i> View All Pending Grading
            </a>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search students, exams..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="exam_id" class="form-label">Exam</label>
                <select class="form-select" id="exam_id" name="exam_id">
                    <option value="">All Exams</option>
                    <?php foreach($exams as $exam): ?>
                        <option value="<?php echo $exam['id']; ?>" <?php echo $exam_filter == $exam['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Status</option>
                    <option value="pass" <?php echo $status_filter == 'pass' ? 'selected' : ''; ?>>Passed</option>
                    <option value="fail" <?php echo $status_filter == 'fail' ? 'selected' : ''; ?>>Failed</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="date_from" class="form-label">From Date</label>
                <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            <div class="col-md-2">
                <label for="date_to" class="form-label">To Date</label>
                <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="view_results.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
        
        <?php if($filter_ungraded): ?>
            <div class="alert alert-info mt-3">
                <i class="fas fa-info-circle me-2"></i>
                Showing only submissions with ungraded answers.
                <a href="view_results.php" class="alert-link">Show all results</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Results Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Exam Results
            <span class="badge bg-primary ms-2"><?php echo $total_results; ?> results</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if(empty($results)): ?>
            <div class="text-center py-5">
                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No Results Found</h5>
                <p class="text-muted">
                    <?php 
                    if ($filter_ungraded) {
                        echo 'No ungraded submissions found.';
                    } elseif (!empty($search) || !empty($exam_filter) || !empty($status_filter)) {
                        echo 'Try adjusting your filters to see more results.';
                    } else {
                        echo 'No exam results available yet.';
                    }
                    ?>
                </p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Student</th>
                            <th>Exam & Course</th>
                            <th>Score</th>
                            <th>Grade</th>
                            <th>Status</th>
                            <th>Time Spent</th>
                            <th>Submitted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($results as $result): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-2">
                                            <div class="fw-semibold"><?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?></div>
                                            <small class="text-muted">@<?php echo htmlspecialchars($result['username']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($result['exam_title']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($result['course_code'] . ' - ' . $result['course_name']); ?></small>
                                    <div>
                                        <small class="badge bg-light text-dark">
                                            <?php echo ucfirst($result['exam_type']); ?>
                                        </small>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $result['obtained_marks']; ?>/<?php echo $result['total_marks']; ?></div>
                                    <div class="progress" style="height: 6px; width: 80px;">
                                        <div class="progress-bar bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>" 
                                             style="width: <?php echo $result['percentage']; ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo $result['percentage']; ?>%</small>
                                </td>
                                <td>
                                    <span class="badge grade-<?php echo strtolower($result['grade']); ?>">
                                        <?php echo $result['grade']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>">
                                        <i class="fas fa-<?php echo $result['status'] == 'pass' ? 'check' : 'times'; ?> me-1"></i>
                                        <?php echo ucfirst($result['status']); ?>
                                    </span>
                                    <?php if($result['ungraded_answers'] > 0): ?>
                                        <div class="mt-1">
                                            <small class="text-warning">
                                                <i class="fas fa-exclamation-circle me-1"></i>
                                                <?php echo $result['ungraded_answers']; ?> ungraded
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $hours = floor($result['time_spent_seconds'] / 3600);
                                    $minutes = floor(($result['time_spent_seconds'] % 3600) / 60);
                                    $seconds = $result['time_spent_seconds'] % 60;
                                    
                                    if ($hours > 0) {
                                        echo sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                                    } else {
                                        echo sprintf('%02d:%02d', $minutes, $seconds);
                                    }
                                    ?>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($result['submitted_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary view-details" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#resultDetailsModal"
                                                data-result='<?php echo json_encode($result); ?>'
                                                onclick="viewResultDetails(this)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if($result['ungraded_answers'] > 0): ?>
                                            <a href="grade_answers.php?attempt_id=<?php echo $result['attempt_id']; ?>" 
                                               class="btn btn-outline-warning" title="Grade Answers">
                                                <i class="fas fa-edit"></i>
                                                <span class="badge bg-danger"><?php echo $result['ungraded_answers']; ?></span>
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="All answers graded">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        <?php endif; ?>
                                        <a href="student_answers.php?attempt_id=<?php echo $result['attempt_id']; ?>" class="btn btn-outline-info" title="View Answers">
                                            <i class="fas fa-list"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Export Options -->
            <div class="card-footer bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">
                            Showing <?php echo count($results); ?> of <?php echo $total_results; ?> results
                        </small>
                    </div>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-download me-2"></i> Export CSV
                        </button>
                        <button class="btn btn-sm btn-outline-success">
                            <i class="fas fa-file-pdf me-2"></i> Export PDF
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Result Details Modal -->
<div class="modal fade" id="resultDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Result Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="resultDetailsContent">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.grade-a+ { background-color: #28a745; color: white; }
.grade-a { background-color: #28a745; color: white; }
.grade-b { background-color: #17a2b8; color: white; }
.grade-c { background-color: #ffc107; color: #212529; }
.grade-d { background-color: #fd7e14; color: white; }
.grade-f { background-color: #dc3545; color: white; }

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

.view-details:hover {
    background-color: #0d6efd;
    color: white;
}

.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
}

.table th {
    border-top: none;
    font-weight: 600;
    background-color: #f8f9fa;
}
</style>

<script>
function viewResultDetails(button) {
    const result = JSON.parse(button.getAttribute('data-result'));
    
    // Format time spent
    const formatTime = (seconds) => {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        
        if (hours > 0) {
            return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        } else {
            return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
    };
    
    const content = `
        <div class="row">
            <div class="col-md-6">
                <h6>Student Information</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="40%">Name:</td>
                        <td><strong>${result.first_name} ${result.last_name}</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Username:</td>
                        <td>@${result.username}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Email:</td>
                        <td>${result.email}</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Exam Information</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="40%">Exam:</td>
                        <td><strong>${result.exam_title}</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Course:</td>
                        <td>${result.course_code} - ${result.course_name}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Type:</td>
                        <td>${result.exam_type.charAt(0).toUpperCase() + result.exam_type.slice(1)}</td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="row mt-3">
            <div class="col-md-6">
                <h6>Performance</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="50%">Marks Obtained:</td>
                        <td><strong>${result.obtained_marks}/${result.total_marks}</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Percentage:</td>
                        <td><strong>${result.percentage}%</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Grade:</td>
                        <td><span class="badge grade-${result.grade.toLowerCase()}">${result.grade}</span></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Status:</td>
                        <td><span class="badge bg-${result.status === 'pass' ? 'success' : 'danger'}">${result.status.charAt(0).toUpperCase() + result.status.slice(1)}</span></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Timing</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="50%">Started:</td>
                        <td>${new Date(result.started_at).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Submitted:</td>
                        <td>${new Date(result.submitted_at).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Time Spent:</td>
                        <td>${formatTime(result.time_spent_seconds)}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Attempt Status:</td>
                        <td><span class="badge bg-${result.attempt_status === 'graded' ? 'success' : 'warning'}">${result.attempt_status.charAt(0).toUpperCase() + result.attempt_status.slice(1).replace('_', ' ')}</span></td>
                    </tr>
                </table>
            </div>
        </div>
        
        ${result.ungraded_answers > 0 ? `
        <div class="alert alert-warning mt-3">
            <i class="fas fa-exclamation-triangle me-2"></i>
            This attempt has ${result.ungraded_answers} ungraded answers that need evaluation.
            <a href="grade_answers.php?attempt_id=${result.attempt_id}" class="alert-link">Grade now</a>
        </div>
        ` : `
        <div class="alert alert-success mt-3">
            <i class="fas fa-check-circle me-2"></i>
            All answers have been graded for this attempt.
        </div>
        `}
        
        <div class="mt-3">
            <a href="student_answers.php?attempt_id=${result.attempt_id}" class="btn btn-primary btn-sm">
                <i class="fas fa-list me-2"></i> View All Answers
            </a>
            ${result.ungraded_answers > 0 ? `
            <a href="grade_answers.php?attempt_id=${result.attempt_id}" class="btn btn-warning btn-sm">
                <i class="fas fa-edit me-2"></i> Grade Answers
            </a>
            ` : ''}
        </div>
    `;
    
    document.getElementById('resultDetailsContent').innerHTML = content;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add row highlighting for ungraded submissions
    const rows = document.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const ungradedBadge = row.querySelector('.badge.bg-danger');
        if (ungradedBadge) {
            row.classList.add('table-warning');
        }
    });
    
    // Add date range validation
    const dateFrom = document.getElementById('date_from');
    const dateTo = document.getElementById('date_to');
    
    if (dateFrom && dateTo) {
        dateFrom.addEventListener('change', function() {
            if (dateTo.value && this.value > dateTo.value) {
                alert('Start date cannot be after end date!');
                this.value = '';
            }
        });
        
        dateTo.addEventListener('change', function() {
            if (dateFrom.value && this.value < dateFrom.value) {
                alert('End date cannot be before start date!');
                this.value = '';
            }
        });
    }
});

// Quick filter functions
function filterByStatus(status) {
    window.location.href = `view_results.php?status=${status}`;
}

function filterByExam(examId) {
    window.location.href = `view_results.php?exam_id=${examId}`;
}

function filterUngraded() {
    window.location.href = `view_results.php?filter=ungraded`;
}
</script>

<?php require_once '../includes/footer.php'; ?>