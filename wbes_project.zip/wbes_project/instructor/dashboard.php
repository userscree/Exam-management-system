<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Instructor Dashboard';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];
$user = getUserData();

try {
    // Get instructor statistics
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_courses 
        FROM courses 
        WHERE instructor_id = ? AND is_active = 1
    ");
    $stmt->execute([$instructor_id]);
    $total_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_exams 
        FROM exams 
        WHERE instructor_id = ?
    ");
    $stmt->execute([$instructor_id]);
    $total_exams = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as active_exams 
        FROM exams 
        WHERE instructor_id = ? AND is_active = 1 
        AND start_date <= NOW() AND end_date >= NOW()
    ");
    $stmt->execute([$instructor_id]);
    $active_exams = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_attempts 
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id 
        WHERE e.instructor_id = ?
    ");
    $stmt->execute([$instructor_id]);
    $total_attempts = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as graded_attempts 
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id 
        WHERE e.instructor_id = ? AND ea.status = 'graded'
    ");
    $stmt->execute([$instructor_id]);
    $graded_attempts = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ea.student_id) as total_students 
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id 
        WHERE e.instructor_id = ?
    ");
    $stmt->execute([$instructor_id]);
    $total_students = $stmt->fetchColumn();
    
    // Get recent exams
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id) as attempt_count
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.instructor_id = ?
        ORDER BY e.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$instructor_id]);
    $recent_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get upcoming exams (next 7 days)
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.instructor_id = ? 
        AND e.is_active = 1 
        AND e.start_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
        ORDER BY e.start_date ASC 
        LIMIT 5
    ");
    $stmt->execute([$instructor_id]);
    $upcoming_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get courses with exam counts
    $stmt = $pdo->prepare("
        SELECT c.*, 
               COUNT(e.id) as exam_count,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id AND status = 'active') as student_count
        FROM courses c 
        LEFT JOIN exams e ON c.id = e.course_id 
        WHERE c.instructor_id = ? AND c.is_active = 1
        GROUP BY c.id 
        ORDER BY c.course_code
    ");
    $stmt->execute([$instructor_id]);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent student attempts
    $stmt = $pdo->prepare("
        SELECT ea.*, e.title as exam_title, c.course_code,
               u.first_name, u.last_name, u.username,
               r.obtained_marks, r.percentage, r.grade, r.status as result_status
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        JOIN users u ON ea.student_id = u.id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE e.instructor_id = ?
        ORDER BY ea.started_at DESC 
        LIMIT 8
    ");
    $stmt->execute([$instructor_id]);
    $recent_attempts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get exam type distribution
    $stmt = $pdo->prepare("
        SELECT exam_type, COUNT(*) as count 
        FROM exams 
        WHERE instructor_id = ? 
        GROUP BY exam_type
    ");
    $stmt->execute([$instructor_id]);
    $exam_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get grading pending count
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ea.id) as pending_grading
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id
        JOIN questions q ON e.id = q.exam_id
        LEFT JOIN student_answers sa ON ea.id = sa.attempt_id AND q.id = sa.question_id
        WHERE e.instructor_id = ? 
        AND q.question_type IN ('essay', 'short_answer')
        AND (sa.awarded_marks IS NULL OR sa.graded_by IS NULL)
        AND ea.status = 'submitted'
    ");
    $stmt->execute([$instructor_id]);
    $pending_grading = $stmt->fetchColumn();
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching dashboard data: ' . $e->getMessage());
    $total_courses = $total_exams = $active_exams = $total_attempts = $graded_attempts = $total_students = 0;
    $recent_exams = $upcoming_exams = $courses = $recent_attempts = $exam_types = [];
    $pending_grading = 0;
}
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="card-title mb-2">Welcome back, <?php echo $user['first_name']; ?>! 👋</h4>
                        <p class="card-text mb-0">Here's your teaching overview for today.</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="d-flex align-items-center justify-content-md-end">
                            <div class="me-3">
                                <i class="fas fa-chalkboard-teacher fa-3x opacity-50"></i>
                            </div>
                            <div>
                                <h5 class="mb-0">Instructor</h5>
                                <small>Course Management</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            My Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_courses; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-book me-1"></i>
                                Active courses
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book-open fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_exams; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-file-alt me-1"></i>
                                Created exams
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Active Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_exams; ?></div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-play-circle me-1"></i>
                                        Currently running
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-play-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Student Attempts
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_attempts; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-users me-1"></i>
                                Total attempts
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- Quick Actions -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-bolt me-2 text-warning"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <a href="create_exam.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-plus-circle fa-2x text-primary mb-3"></i>
                                <h6 class="card-title">Create New Exam</h6>
                                <p class="card-text small text-muted mb-0">Set up a new examination</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="view_exams.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-list-alt fa-2x text-success mb-3"></i>
                                <h6 class="card-title">Manage Exams</h6>
                                <p class="card-text small text-muted mb-0">View and edit your exams</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="add_question.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-question-circle fa-2x text-info mb-3"></i>
                                <h6 class="card-title">Add Questions</h6>
                                <p class="card-text small text-muted mb-0">Create exam questions</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="view_results.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-chart-line fa-2x text-warning mb-3"></i>
                                <h6 class="card-title">View Results</h6>
                                <p class="card-text small text-muted mb-0">Check student performance</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Exams -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-file-alt me-2 text-primary"></i>
                    Recent Exams
                </h5>
                <a href="view_exams.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_exams)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-file-alt fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Exams Created Yet</h6>
                        <p class="text-muted mb-0">Create your first exam to get started.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($recent_exams as $exam): 
                            $now = new DateTime();
                            $start_date = new DateTime($exam['start_date']);
                            $end_date = new DateTime($exam['end_date']);
                            $is_ongoing = $exam['is_active'] && $now >= $start_date && $now <= $end_date;
                            $is_upcoming = $exam['is_active'] && $now < $start_date;
                        ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                        <p class="mb-1 small text-muted">
                                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?>
                                        </p>
                                        <div class="d-flex gap-3">
                                            <small class="text-muted">
                                                <i class="fas fa-question-circle me-1"></i>
                                                <?php echo $exam['question_count']; ?> questions
                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-users me-1"></i>
                                                <?php echo $exam['attempt_count']; ?> attempts
                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo $exam['duration_minutes']; ?> mins
                                            </small>
                                        </div>
                                    </div>
                                    <div class="flex-shrink-0 ms-3 text-end">
                                        <span class="badge bg-<?php 
                                            if ($is_ongoing) echo 'success';
                                            elseif ($is_upcoming) echo 'warning';
                                            else echo 'secondary';
                                        ?> mb-2">
                                            <?php 
                                            if ($is_ongoing) echo 'Ongoing';
                                            elseif ($is_upcoming) echo 'Upcoming';
                                            else echo 'Inactive';
                                            ?>
                                        </span>
                                        <div>
                                            <a href="view_exams.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Student Attempts -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-history me-2 text-info"></i>
                    Recent Student Attempts
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_attempts)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-users fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Student Attempts Yet</h6>
                        <p class="text-muted mb-0">Student attempts will appear here.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Student</th>
                                    <th>Exam</th>
                                    <th>Course</th>
                                    <th>Status</th>
                                    <th>Marks</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_attempts as $attempt): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0">
                                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                        <i class="fas fa-user"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1 ms-2">
                                                    <div class="fw-semibold"><?php echo htmlspecialchars($attempt['first_name'] . ' ' . $attempt['last_name']); ?></div>
                                                    <small class="text-muted">@<?php echo htmlspecialchars($attempt['username']); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($attempt['exam_title']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($attempt['course_code']); ?></span>
                                        </td>
                                        <td>
                                            <?php if($attempt['status'] == 'graded'): ?>
                                                <span class="badge bg-<?php echo $attempt['result_status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                    <?php echo ucfirst($attempt['result_status']); ?>
                                                </span>
                                            <?php elseif($attempt['status'] == 'submitted'): ?>
                                                <span class="badge bg-warning">Submitted</span>
                                            <?php else: ?>
                                                <span class="badge bg-info">In Progress</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($attempt['obtained_marks']): ?>
                                                <strong><?php echo $attempt['obtained_marks']; ?></strong>
                                                <small class="text-muted">/100</small>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo formatDate($attempt['started_at']); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-white text-center">
                        <a href="view_results.php" class="btn btn-sm btn-outline-primary">View All Results</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Upcoming Exams -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-clock me-2 text-warning"></i>
                    Upcoming Exams (7 days)
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($upcoming_exams)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-clock fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Upcoming Exams</h6>
                        <p class="text-muted mb-0">No exams scheduled for the next 7 days.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($upcoming_exams as $exam): 
                            $start_date = new DateTime($exam['start_date']);
                            $now = new DateTime();
                            $interval = $now->diff($start_date);
                        ?>
                            <div class="list-group-item">
                                <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                <p class="mb-1 small text-muted"><?php echo htmlspecialchars($exam['course_code']); ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo formatDate($exam['start_date']); ?>
                                    </small>
                                    <span class="badge bg-warning">
                                        in <?php echo $interval->format('%a days %h hours'); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Courses -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-book me-2 text-success"></i>
                    My Courses
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($courses)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-book fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Courses Assigned</h6>
                        <p class="text-muted mb-0">You are not assigned to any courses yet.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($courses as $course): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo htmlspecialchars($course['course_name']); ?></p>
                                    </div>
                                    <div class="text-end">
                                        <div class="fw-bold text-primary"><?php echo $course['exam_count']; ?></div>
                                        <small class="text-muted">exams</small>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-users me-1"></i>
                                        <?php echo $course['student_count']; ?> enrolled students
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Exam Type Distribution -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-pie me-2 text-info"></i>
                    Exam Types
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($exam_types)): ?>
                    <p class="text-muted text-center mb-0">No exams created yet</p>
                <?php else: ?>
                    <?php foreach($exam_types as $type): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">
                                <?php 
                                $icon = 'file-alt';
                                $color = 'primary';
                                switch($type['exam_type']) {
                                    case 'quiz': $icon = 'bolt'; $color = 'warning'; break;
                                    case 'midterm': $icon = 'file-medical'; $color = 'info'; break;
                                    case 'final': $icon = 'file-contract'; $color = 'danger'; break;
                                    case 'assignment': $icon = 'tasks'; $color = 'success'; break;
                                }
                                ?>
                                <i class="fas fa-<?php echo $icon; ?> text-<?php echo $color; ?> me-2"></i>
                                <?php echo ucfirst($type['exam_type']); ?>
                            </span>
                            <span class="badge bg-<?php echo $color; ?>"><?php echo $type['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Grading Alerts -->
        <?php if($pending_grading > 0): ?>
            <div class="card border-warning">
                <div class="card-header bg-warning text-dark">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Grading Required
                    </h5>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <i class="fas fa-clipboard-check fa-2x text-warning mb-3"></i>
                        <h5 class="text-warning"><?php echo $pending_grading; ?> submissions need grading</h5>
                        <p class="text-muted">You have subjective answers waiting for your evaluation.</p>
                        <a href="view_results.php?filter=ungraded" class="btn btn-warning">
                            <i class="fas fa-arrow-right me-2"></i> Start Grading
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- System Status -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-tachometer-alt me-2 text-secondary"></i>
                    Teaching Overview
                </h5>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Total Students</span>
                        <span class="fw-bold text-primary"><?php echo $total_students; ?></span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Graded Attempts</span>
                        <span class="fw-bold text-success"><?php echo $graded_attempts; ?></span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Pending Grading</span>
                        <span class="fw-bold text-warning"><?php echo $pending_grading; ?></span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Success Rate</span>
                        <span class="fw-bold text-info">
                            <?php 
                            if ($total_attempts > 0) {
                                echo number_format(($graded_attempts / $total_attempts) * 100, 1) . '%';
                            } else {
                                echo '0%';
                            }
                            ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.action-card {
    transition: all 0.3s ease;
    border: 1px solid #e3e6f0;
}

.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    border-color: #4e73df;
}

.action-card .card-body {
    transition: all 0.3s ease;
}

.action-card:hover .card-body {
    background-color: #f8f9fc;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add click animations to action cards
    const actionCards = document.querySelectorAll('.action-card');
    actionCards.forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Auto-refresh dashboard every 2 minutes
    setInterval(() => {
        // You can add AJAX refresh here if needed
        console.log('Dashboard auto-refresh check');
    }, 120000);

    // Highlight urgent items
    const upcomingExams = document.querySelectorAll('.list-group-item');
    upcomingExams.forEach(item => {
        const badge = item.querySelector('.badge.bg-warning');
        if (badge && badge.textContent.includes('0 days')) {
            item.classList.add('border-warning');
            badge.classList.add('bg-danger');
        }
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>