<?php
require_once '../includes/auth_check.php';
if (!hasRole('instructor')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Edit Question';
require_once '../includes/header.php';

$instructor_id = $_SESSION['user_id'];
$question_id = isset($_GET['question_id']) ? intval($_GET['question_id']) : 0;

// Get question details
$question = null;
$exam = null;
if ($question_id > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT q.*, e.*, c.course_code, c.course_name, e.instructor_id
            FROM questions q
            JOIN exams e ON q.exam_id = e.id
            JOIN courses c ON e.course_id = c.id
            WHERE q.id = ? AND e.instructor_id = ?
        ");
        $stmt->execute([$question_id, $instructor_id]);
        $question = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($question) {
            $exam = $question; // Since we're joining exam data
        } else {
            setFlash('error', 'Question not found or you do not have permission to edit it.');
            redirect('view_exams.php');
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching question: ' . $e->getMessage());
        redirect('view_exams.php');
    }
} else {
    setFlash('error', 'Invalid question ID.');
    redirect('view_exams.php');
}

// Get existing questions for the exam to show order
try {
    $stmt = $pdo->prepare("
        SELECT id, question_order 
        FROM questions 
        WHERE exam_id = ? 
        ORDER BY question_order ASC, id ASC
    ");
    $stmt->execute([$question['exam_id']]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching questions: ' . $e->getMessage());
    $questions = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_question'])) {
        $question_type = sanitize($_POST['question_type']);
        $question_text = sanitize($_POST['question_text']);
        $marks = $_POST['marks'];
        $question_order = $_POST['question_order'] ?? 0;
        $explanation = sanitize($_POST['explanation'] ?? '');
        
        // Initialize variables for different question types
        $option_a = $option_b = $option_c = $option_d = $correct_answer = '';
        
        switch($question_type) {
            case 'multiple_choice':
                $option_a = sanitize($_POST['option_a']);
                $option_b = sanitize($_POST['option_b']);
                $option_c = sanitize($_POST['option_c'] ?? '');
                $option_d = sanitize($_POST['option_d'] ?? '');
                $correct_answer = sanitize($_POST['correct_answer']);
                break;
                
            case 'true_false':
                $correct_answer = sanitize($_POST['correct_answer_tf']);
                break;
                
            case 'short_answer':
            case 'essay':
                $correct_answer = sanitize($_POST['correct_answer_text']);
                break;
        }
        
        // Validation
        $errors = [];
        
        if (empty($question_text)) {
            $errors[] = 'Question text is required.';
        }
        
        if (empty($marks) || $marks <= 0) {
            $errors[] = 'Please enter valid marks.';
        }
        
        if ($question_type == 'multiple_choice') {
            if (empty($option_a) || empty($option_b)) {
                $errors[] = 'At least two options are required for multiple choice questions.';
            }
            if (empty($correct_answer)) {
                $errors[] = 'Please select the correct answer.';
            }
        }
        
        if ($question_type == 'true_false' && empty($correct_answer)) {
            $errors[] = 'Please select the correct answer.';
        }
        
        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE questions 
                    SET question_type = ?, question_text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, 
                        correct_answer = ?, marks = ?, explanation = ?, question_order = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $question_type, $question_text, $option_a, $option_b, $option_c, $option_d, 
                    $correct_answer, $marks, $explanation, $question_order, $question_id
                ]);
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $instructor_id,
                    'question_updated',
                    'Updated question ID: ' . $question_id . ' for exam ID: ' . $question['exam_id'],
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Question updated successfully!');
                redirect('add_question.php?exam_id=' . $question['exam_id']);
                
            } catch(PDOException $e) {
                setFlash('error', 'Error updating question: ' . $e->getMessage());
            }
        } else {
            foreach($errors as $error) {
                setFlash('error', $error);
            }
        }
    }
    
    if (isset($_POST['delete_question'])) {
        try {
            $stmt = $pdo->prepare("DELETE FROM questions WHERE id = ?");
            $stmt->execute([$question_id]);
            
            // Log activity
            $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $instructor_id,
                'question_deleted',
                'Deleted question ID: ' . $question_id . ' from exam ID: ' . $question['exam_id'],
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);
            
            setFlash('success', 'Question deleted successfully!');
            redirect('add_question.php?exam_id=' . $question['exam_id']);
            
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting question: ' . $e->getMessage());
        }
    }
}
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-edit me-2"></i> Edit Question
                </h5>
            </div>
            <div class="card-body">
                <!-- Exam Information -->
                <div class="alert alert-info">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="alert-heading mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                            <p class="mb-1"><?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?></p>
                            <small class="text-muted">
                                Total Marks: <strong><?php echo $exam['total_marks']; ?></strong> | 
                                Passing: <strong><?php echo $exam['passing_marks']; ?></strong> | 
                                Duration: <strong><?php echo $exam['duration_minutes']; ?> mins</strong> |
                                Type: <strong><?php echo ucfirst($exam['exam_type']); ?></strong>
                            </small>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-primary">Question ID: <?php echo $question_id; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Question Form -->
                <form method="POST" id="questionForm" novalidate>
                    <!-- Question Type -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-cog me-2 text-primary"></i>
                            Question Type & Settings
                        </h6>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="question_type" class="form-label">Question Type *</label>
                                    <select class="form-select" id="question_type" name="question_type" required onchange="toggleQuestionFields()">
                                        <option value="multiple_choice" <?php echo $question['question_type'] == 'multiple_choice' ? 'selected' : ''; ?>>Multiple Choice</option>
                                        <option value="true_false" <?php echo $question['question_type'] == 'true_false' ? 'selected' : ''; ?>>True/False</option>
                                        <option value="short_answer" <?php echo $question['question_type'] == 'short_answer' ? 'selected' : ''; ?>>Short Answer</option>
                                        <option value="essay" <?php echo $question['question_type'] == 'essay' ? 'selected' : ''; ?>>Essay</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="marks" class="form-label">Marks *</label>
                                    <input type="number" class="form-control" id="marks" name="marks" 
                                           min="1" max="100" value="<?php echo htmlspecialchars($question['marks']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="question_order" class="form-label">Order</label>
                                    <input type="number" class="form-control" id="question_order" name="question_order" 
                                           min="1" value="<?php echo htmlspecialchars($question['question_order'] ?: (count($questions) + 1)); ?>">
                                    <div class="form-text">Display order in the exam</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Question Text -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-edit me-2 text-success"></i>
                            Question Content
                        </h6>
                        
                        <div class="mb-3">
                            <label for="question_text" class="form-label">Question Text *</label>
                            <textarea class="form-control" id="question_text" name="question_text" 
                                      rows="3" placeholder="Enter your question here..." required><?php echo htmlspecialchars($question['question_text']); ?></textarea>
                            <div class="form-text">Write clear and concise questions.</div>
                        </div>
                    </div>

                    <!-- Multiple Choice Options -->
                    <div class="mb-4" id="multiple_choice_section" style="display: <?php echo $question['question_type'] == 'multiple_choice' ? 'block' : 'none'; ?>;">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-list-ol me-2 text-info"></i>
                            Multiple Choice Options
                        </h6>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="option_a" class="form-label">Option A *</label>
                                    <div class="input-group">
                                        <span class="input-group-text">A</span>
                                        <input type="text" class="form-control" id="option_a" name="option_a" 
                                               value="<?php echo htmlspecialchars($question['option_a'] ?? ''); ?>"
                                               placeholder="Enter option A">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="option_b" class="form-label">Option B *</label>
                                    <div class="input-group">
                                        <span class="input-group-text">B</span>
                                        <input type="text" class="form-control" id="option_b" name="option_b" 
                                               value="<?php echo htmlspecialchars($question['option_b'] ?? ''); ?>"
                                               placeholder="Enter option B">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="option_c" class="form-label">Option C</label>
                                    <div class="input-group">
                                        <span class="input-group-text">C</span>
                                        <input type="text" class="form-control" id="option_c" name="option_c" 
                                               value="<?php echo htmlspecialchars($question['option_c'] ?? ''); ?>"
                                               placeholder="Enter option C (optional)">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="option_d" class="form-label">Option D</label>
                                    <div class="input-group">
                                        <span class="input-group-text">D</span>
                                        <input type="text" class="form-control" id="option_d" name="option_d" 
                                               value="<?php echo htmlspecialchars($question['option_d'] ?? ''); ?>"
                                               placeholder="Enter option D (optional)">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Correct Answer *</label>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer" id="correct_a" value="A" 
                                            <?php echo $question['correct_answer'] == 'A' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_a">Option A</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer" id="correct_b" value="B"
                                            <?php echo $question['correct_answer'] == 'B' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_b">Option B</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer" id="correct_c" value="C"
                                            <?php echo $question['correct_answer'] == 'C' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_c">Option C</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer" id="correct_d" value="D"
                                            <?php echo $question['correct_answer'] == 'D' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_d">Option D</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- True/False Options -->
                    <div class="mb-4" id="true_false_section" style="display: <?php echo $question['question_type'] == 'true_false' ? 'block' : 'none'; ?>;">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-check-circle me-2 text-warning"></i>
                            True/False Options
                        </h6>
                        
                        <div class="mb-3">
                            <label class="form-label">Correct Answer *</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer_tf" id="correct_true" value="TRUE"
                                            <?php echo $question['correct_answer'] == 'TRUE' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_true">True</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="correct_answer_tf" id="correct_false" value="FALSE"
                                            <?php echo $question['correct_answer'] == 'FALSE' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="correct_false">False</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Short Answer/Essay Options -->
                    <div class="mb-4" id="text_answer_section" style="display: <?php echo in_array($question['question_type'], ['short_answer', 'essay']) ? 'block' : 'none'; ?>;">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-align-left me-2 text-success"></i>
                            Expected Answer
                        </h6>
                        
                        <div class="mb-3">
                            <label for="correct_answer_text" class="form-label">Expected Answer</label>
                            <textarea class="form-control" id="correct_answer_text" name="correct_answer_text" 
                                      rows="3" placeholder="Enter the expected answer or key points..."><?php echo htmlspecialchars($question['correct_answer'] ?? ''); ?></textarea>
                            <div class="form-text">For essay questions, provide key points or a model answer.</div>
                        </div>
                    </div>

                    <!-- Explanation -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">
                            <i class="fas fa-lightbulb me-2 text-warning"></i>
                            Explanation & Feedback
                        </h6>
                        
                        <div class="mb-3">
                            <label for="explanation" class="form-label">Explanation (Optional)</label>
                            <textarea class="form-control" id="explanation" name="explanation" 
                                      rows="2" placeholder="Provide explanation for the correct answer..."><?php echo htmlspecialchars($question['explanation'] ?? ''); ?></textarea>
                            <div class="form-text">This will be shown to students after they complete the exam.</div>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <a href="add_question.php?exam_id=<?php echo $question['exam_id']; ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Back to Questions
                            </a>
                            <button type="button" class="btn btn-outline-danger ms-2" data-bs-toggle="modal" data-bs-target="#deleteModal">
                                <i class="fas fa-trash me-2"></i> Delete Question
                            </button>
                        </div>
                        <button type="submit" name="update_question" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update Question
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Question Preview -->
        <div class="card mt-4">
            <div class="card-header bg-light">
                <h5 class="card-title mb-0">
                    <i class="fas fa-eye me-2 text-info"></i>
                    Question Preview
                </h5>
            </div>
            <div class="card-body">
                <div class="question-preview" id="questionPreview">
                    <h6 class="text-primary mb-3">How the question will appear to students:</h6>
                    <div class="preview-content">
                        <p><strong>Question:</strong> <span id="previewQuestionText"><?php echo htmlspecialchars($question['question_text']); ?></span></p>
                        
                        <?php if($question['question_type'] == 'multiple_choice'): ?>
                            <div class="preview-options">
                                <p><strong>Options:</strong></p>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">A. <span id="previewOptionA"><?php echo htmlspecialchars($question['option_a'] ?? ''); ?></span></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">B. <span id="previewOptionB"><?php echo htmlspecialchars($question['option_b'] ?? ''); ?></span></label>
                                </div>
                                <?php if(!empty($question['option_c'])): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">C. <span id="previewOptionC"><?php echo htmlspecialchars($question['option_c']); ?></span></label>
                                </div>
                                <?php endif; ?>
                                <?php if(!empty($question['option_d'])): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">D. <span id="previewOptionD"><?php echo htmlspecialchars($question['option_d']); ?></span></label>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php elseif($question['question_type'] == 'true_false'): ?>
                            <div class="preview-options">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">True</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" disabled>
                                    <label class="form-check-label">False</label>
                                </div>
                            </div>
                        <?php elseif(in_array($question['question_type'], ['short_answer', 'essay'])): ?>
                            <div class="preview-answer">
                                <p><strong>Answer Type:</strong> <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?></p>
                                <textarea class="form-control" rows="3" placeholder="Student will type their answer here..." disabled></textarea>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mt-3">
                            <small class="text-muted">
                                <i class="fas fa-star me-1 text-warning"></i>
                                Marks: <span id="previewMarks"><?php echo $question['marks']; ?></span>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">Delete Question</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center text-danger mb-3">
                    <i class="fas fa-exclamation-triangle fa-3x"></i>
                </div>
                <h6 class="text-center">Are you sure you want to delete this question?</h6>
                <p class="text-center text-muted">This action cannot be undone. The question will be permanently removed from the exam.</p>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <strong>Warning:</strong> If students have already attempted this question, their answers will also be deleted.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" class="d-inline">
                    <button type="submit" name="delete_question" class="btn btn-danger">Delete Question</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleQuestionFields() {
    const questionType = document.getElementById('question_type').value;
    
    // Hide all sections first
    document.getElementById('multiple_choice_section').style.display = 'none';
    document.getElementById('true_false_section').style.display = 'none';
    document.getElementById('text_answer_section').style.display = 'none';
    
    // Show relevant section based on question type
    switch(questionType) {
        case 'multiple_choice':
            document.getElementById('multiple_choice_section').style.display = 'block';
            break;
        case 'true_false':
            document.getElementById('true_false_section').style.display = 'block';
            break;
        case 'short_answer':
        case 'essay':
            document.getElementById('text_answer_section').style.display = 'block';
            break;
    }
    
    updatePreview();
}

function updatePreview() {
    // Update question text
    document.getElementById('previewQuestionText').textContent = document.getElementById('question_text').value;
    
    // Update marks
    document.getElementById('previewMarks').textContent = document.getElementById('marks').value;
    
    // Update options for multiple choice
    const questionType = document.getElementById('question_type').value;
    if (questionType === 'multiple_choice') {
        document.getElementById('previewOptionA').textContent = document.getElementById('option_a').value;
        document.getElementById('previewOptionB').textContent = document.getElementById('option_b').value;
        document.getElementById('previewOptionC').textContent = document.getElementById('option_c').value;
        document.getElementById('previewOptionD').textContent = document.getElementById('option_d').value;
    }
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    // Initialize form fields based on current question type
    toggleQuestionFields();
    
    const form = document.getElementById('questionForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const questionType = document.getElementById('question_type').value;
            let isValid = true;
            
            // Validate multiple choice
            if (questionType === 'multiple_choice') {
                const optionA = document.getElementById('option_a').value.trim();
                const optionB = document.getElementById('option_b').value.trim();
                const correctAnswer = document.querySelector('input[name="correct_answer"]:checked');
                
                if (!optionA || !optionB) {
                    alert('Please fill at least options A and B for multiple choice questions.');
                    isValid = false;
                }
                
                if (!correctAnswer) {
                    alert('Please select the correct answer for the multiple choice question.');
                    isValid = false;
                }
            }
            
            // Validate true/false
            if (questionType === 'true_false') {
                const correctAnswer = document.querySelector('input[name="correct_answer_tf"]:checked');
                if (!correctAnswer) {
                    alert('Please select the correct answer for the true/false question.');
                    isValid = false;
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            form.classList.add('was-validated');
        });
    }
    
    // Add event listeners for real-time preview updates
    const inputsToWatch = ['question_text', 'marks', 'option_a', 'option_b', 'option_c', 'option_d'];
    inputsToWatch.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('input', updatePreview);
        }
    });
    
    document.getElementById('question_type').addEventListener('change', updatePreview);
    
    // Auto-focus question text field
    document.getElementById('question_text').focus();
});

// Character counter for question text
document.addEventListener('DOMContentLoaded', function() {
    const questionText = document.getElementById('question_text');
    if (questionText) {
        // Create character counter
        const counter = document.createElement('div');
        counter.className = 'form-text text-end';
        counter.id = 'questionTextCounter';
        questionText.parentNode.appendChild(counter);
        
        function updateCounter() {
            const length = questionText.value.length;
            counter.textContent = `${length} characters`;
            counter.className = `form-text text-end ${length > 500 ? 'text-danger' : 'text-muted'}`;
        }
        
        questionText.addEventListener('input', updateCounter);
        updateCounter();
    }
});
</script>

<style>
.question-preview {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    border-left: 4px solid #007bff;
}

.preview-content {
    background-color: white;
    padding: 15px;
    border-radius: 5px;
    border: 1px solid #dee2e6;
}

.form-check-input:disabled {
    background-color: #e9ecef;
}

.invalid-feedback {
    display: block;
}

.was-validated .form-control:invalid,
.was-validated .form-select:invalid {
    border-color: #dc3545;
}

.was-validated .form-control:valid,
.was-validated .form-select:valid {
    border-color: #198754;
}

.input-group-text {
    background-color: #f8f9fa;
    font-weight: 600;
}
</style>

<?php require_once '../includes/footer.php'; ?>