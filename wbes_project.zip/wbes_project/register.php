<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = getUserRole();
    redirect($role . '/dashboard.php');
}

// Check if registration is allowed
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'allow_registration'");
    $stmt->execute();
    $allow_registration = $stmt->fetchColumn();
} catch(PDOException $e) {
    $allow_registration = 1;
}

// If registration is disabled, redirect to login
if (!$allow_registration) {
    setFlash('error', 'New user registration is currently disabled.');
    redirect('index.php');
}

// Get system name
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'system_name'");
    $stmt->execute();
    $system_name = $stmt->fetchColumn();
} catch(PDOException $e) {
    $system_name = 'Web-Based Examination System';
}

// Get institution name
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'institution_name'");
    $stmt->execute();
    $institution_name = $stmt->fetchColumn();
} catch(PDOException $e) {
    $institution_name = 'WBES University';
}

// Get departments for dropdown
try {
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_code");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $departments = [];
}

// Function to generate automatic student ID
function generateStudentID($department, $pdo) {
    try {
        // Get current year
        $current_year = date('y'); // Last two digits of current year
        
        // Get department code (first 3 characters)
        $dept_code = strtoupper(substr($department, 0, 3));
        
        // Count existing students in this department for this year
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as student_count 
            FROM users 
            WHERE role = 'student' 
            AND department = ? 
            AND student_id LIKE ?
        ");
        $like_pattern = $dept_code . $current_year . '%';
        $stmt->execute([$department, $like_pattern]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $next_number = ($result['student_count'] ?? 0) + 1;
        
        // Format: DEPT + YEAR + 4-digit sequential number (e.g., CS250001, MATH250001)
        $student_id = $dept_code . $current_year . str_pad($next_number, 4, '0', STR_PAD_LEFT);
        
        return $student_id;
        
    } catch(PDOException $e) {
        // Fallback: timestamp-based ID
        return 'STU' . date('YmdHis') . rand(100, 999);
    }
}

// Process registration form
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $department = sanitize($_POST['department']);
    $university_id = sanitize($_POST['university_id']);
    $academic_year = sanitize($_POST['academic_year']);
    $phone = sanitize($_POST['phone']);
    
    // Generate automatic student ID
    $student_id = generateStudentID($department, $pdo);
    
    // Validation
    $errors = [];
    
    // Required fields
    if (empty($username)) $errors[] = 'Username is required.';
    if (empty($email)) $errors[] = 'Email is required.';
    if (empty($password)) $errors[] = 'Password is required.';
    if (empty($first_name)) $errors[] = 'First name is required.';
    if (empty($last_name)) $errors[] = 'Last name is required.';
    if (empty($department)) $errors[] = 'Department is required.';
    if (empty($university_id)) $errors[] = 'University ID is required.';
    
    // Password validation
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    }
    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }
    
    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    
    // Username validation
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = 'Username can only contain letters, numbers, and underscores.';
    }
    
    if (empty($errors)) {
        try {
            // Check if username or email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Username or email already exists.');
            } else {
                // Check if university ID already exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE university_id = ?");
                $stmt->execute([$university_id]);
                
                if ($stmt->fetch()) {
                    setFlash('error', 'University ID already exists.');
                } else {
                    // Create student account
                    $hashed_password = hashPassword($password);
                    $role = 'student'; // Force student role
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO users (username, email, password_hash, role, first_name, last_name, department, university_id, student_id, academic_year, phone, is_active) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                    ");
                    $stmt->execute([
                        $username, 
                        $email, 
                        $hashed_password, 
                        $role,
                        $first_name, 
                        $last_name, 
                        $department, 
                        $university_id, 
                        $student_id, 
                        $academic_year, 
                        $phone
                    ]);
                    
                    $user_id = $pdo->lastInsertId();
                    
                    // Log registration activity
                    $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $user_id,
                        'registration',
                        'Student registered successfully with ID: ' . $student_id,
                        $_SERVER['REMOTE_ADDR'],
                        $_SERVER['HTTP_USER_AGENT']
                    ]);
                    
                    setFlash('success', 'Registration successful! Your Student ID is: <strong>' . $student_id . '</strong>. You can now login with your credentials.');
                    redirect('index.php?registered=1');
                }
            }
        } catch(PDOException $e) {
            setFlash('error', 'Registration failed. Please try again. Error: ' . $e->getMessage());
        }
    } else {
        foreach($errors as $error) {
            setFlash('error', $error);
        }
    }
}

// Set page title
$page_title = 'Student Registration - ' . $system_name;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        .register-page {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            padding: 2rem 0;
        }
        
        .register-page::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><polygon fill="%23ffffff" fill-opacity="0.05" points="0,1000 1000,0 1000,1000"/></svg>');
            background-size: cover;
        }
        
        .register-container {
            position: relative;
            z-index: 2;
        }
        
        .register-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            overflow: hidden;
            border: 1px solid #e3e6f0;
        }
        
        .register-header {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            color: white;
            padding: 2rem 2rem;
            text-align: center;
            position: relative;
        }
        
        .register-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="white" fill-opacity="0.1"/></svg>');
        }
        
        .institution-logo {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
        }
        
        .register-body {
            padding: 2rem 2rem;
        }
        
        .form-control {
            border-radius: 10px;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d3e2;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .btn-register {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        
        .student-id-preview {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px dashed #6c757d;
            border-radius: 10px;
            padding: 1rem;
            text-align: center;
            margin-bottom: 1rem;
        }
        
        .student-id-value {
            font-family: 'Courier New', monospace;
            font-size: 1.2rem;
            font-weight: bold;
            color: #4e73df;
            background: white;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            border: 1px solid #d1d3e2;
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .step-indicator::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 0;
            right: 0;
            height: 2px;
            background-color: #e3e6f0;
            z-index: 1;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 2;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e3e6f0;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        
        .step.active .step-number {
            background-color: #4e73df;
            color: white;
        }
        
        .step-label {
            font-size: 0.875rem;
            color: #6c757d;
            text-align: center;
        }
        
        .step.active .step-label {
            color: #4e73df;
            font-weight: 600;
        }
        
        .floating-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 1;
        }
        
        .shape {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .shape-1 {
            width: 100px;
            height: 100px;
            top: 10%;
            left: 10%;
            animation: float 6s ease-in-out infinite;
        }
        
        .shape-2 {
            width: 150px;
            height: 150px;
            bottom: 20%;
            right: 10%;
            animation: float 8s ease-in-out infinite;
        }
        
        .shape-3 {
            width: 80px;
            height: 80px;
            top: 50%;
            left: 5%;
            animation: float 7s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }
    </style>
</head>
<body class="register-page">
    <!-- Floating Shapes -->
    <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
    </div>

    <div class="container register-container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="register-card">
                    <div class="register-header">
                        <div class="institution-logo">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h2 class="mb-2">Student Registration</h2>
                        <p class="mb-0 opacity-75"><?php echo $institution_name; ?></p>
                    </div>
                    
                    <div class="register-body">
                        <div class="text-center mb-4">
                            <h4 class="text-primary">Create Your Student Account</h4>
                            <p class="text-muted">Join our learning community and start your educational journey</p>
                        </div>

                        <!-- Step Indicator -->
                        <div class="step-indicator">
                            <div class="step active" data-step="1">
                                <div class="step-number">1</div>
                                <div class="step-label">Personal Info</div>
                            </div>
                            <div class="step" data-step="2">
                                <div class="step-number">2</div>
                                <div class="step-label">Academic Info</div>
                            </div>
                            <div class="step" data-step="3">
                                <div class="step-number">3</div>
                                <div class="step-label">Account Setup</div>
                            </div>
                        </div>

                        <?php
                        $flash = getFlash();
                        if ($flash): 
                            $alert_class = $flash['type'] == 'error' ? 'danger' : 'success';
                        ?>
                            <div class="alert alert-<?php echo $alert_class; ?> alert-dismissible fade show">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-<?php echo $flash['type'] == 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
                                    <div><?php echo $flash['message']; ?></div>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" id="registerForm" novalidate>
                            <input type="hidden" name="register" value="1">
                            
                            <!-- Step 1: Personal Information -->
                            <div class="step-content active" data-step="1">
                                <h5 class="border-bottom pb-2 mb-4 text-primary">
                                    <i class="fas fa-user me-2"></i>Personal Information
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="first_name" class="form-label">First Name *</label>
                                            <input type="text" class="form-control" id="first_name" name="first_name" 
                                                   placeholder="Enter your first name" required
                                                   value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
                                            <div class="invalid-feedback">Please enter your first name.</div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="last_name" class="form-label">Last Name *</label>
                                            <input type="text" class="form-control" id="last_name" name="last_name" 
                                                   placeholder="Enter your last name" required
                                                   value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
                                            <div class="invalid-feedback">Please enter your last name.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="phone" class="form-label">Phone Number</label>
                                            <input type="tel" class="form-control" id="phone" name="phone" 
                                                   placeholder="Enter your phone number"
                                                   value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email Address *</label>
                                            <input type="email" class="form-control" id="email" name="email" 
                                                   placeholder="Enter your email address" required
                                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                                            <div class="invalid-feedback">Please enter a valid email address.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <div></div> <!-- Empty div for spacing -->
                                    <button type="button" class="btn btn-primary next-step" data-next="2">
                                        Next <i class="fas fa-arrow-right ms-2"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Step 2: Academic Information -->
                            <div class="step-content" data-step="2">
                                <h5 class="border-bottom pb-2 mb-4 text-primary">
                                    <i class="fas fa-graduation-cap me-2"></i>Academic Information
                                </h5>
                                
                                <!-- Student ID Preview -->
                                <div class="student-id-preview">
                                    <small class="text-muted d-block mb-2">Your Student ID will be automatically generated:</small>
                                    <div class="student-id-value" id="studentIdPreview">
                                        Select department to preview ID
                                    </div>
                                    <small class="text-muted mt-2">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Format: Department Code + Year + Sequential Number
                                    </small>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="university_id" class="form-label">University ID *</label>
                                            <input type="text" class="form-control" id="university_id" name="university_id" 
                                                   placeholder="Enter your university ID" required
                                                   value="<?php echo isset($_POST['university_id']) ? htmlspecialchars($_POST['university_id']) : ''; ?>">
                                            <div class="form-text">Your official university identification number</div>
                                            <div class="invalid-feedback">Please enter your university ID.</div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="department" class="form-label">Department *</label>
                                            <select class="form-select" id="department" name="department" required>
                                                <option value="">Select Department</option>
                                                <?php foreach($departments as $dept): ?>
                                                    <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" 
                                                        <?php echo (isset($_POST['department']) && $_POST['department'] == $dept['department_code']) ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">Please select your department.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="academic_year" class="form-label">Academic Year</label>
                                            <select class="form-select" id="academic_year" name="academic_year">
                                                <option value="">Select Academic Year</option>
                                                <option value="2023-2024" <?php echo (isset($_POST['academic_year']) && $_POST['academic_year'] == '2023-2024') ? 'selected' : ''; ?>>2023-2024</option>
                                                <option value="2024-2025" <?php echo (isset($_POST['academic_year']) && $_POST['academic_year'] == '2024-2025') ? 'selected' : ''; ?>>2024-2025</option>
                                                <option value="2025-2026" <?php echo (isset($_POST['academic_year']) && $_POST['academic_year'] == '2025-2026') ? 'selected' : ''; ?>>2025-2026</option>
                                                <option value="2026-2027" <?php echo (isset($_POST['academic_year']) && $_POST['academic_year'] == '2026-2027') ? 'selected' : ''; ?>>2026-2027</option>
                                                <option value="2027-2028" <?php echo (isset($_POST['academic_year']) && $_POST['academic_year'] == '2027-2028') ? 'selected' : ''; ?>>2027-2028</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <button type="button" class="btn btn-outline-primary prev-step" data-prev="1">
                                        <i class="fas fa-arrow-left me-2"></i> Previous
                                    </button>
                                    <button type="button" class="btn btn-primary next-step" data-next="3">
                                        Next <i class="fas fa-arrow-right ms-2"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Step 3: Account Setup -->
                            <div class="step-content" data-step="3">
                                <h5 class="border-bottom pb-2 mb-4 text-primary">
                                    <i class="fas fa-lock me-2"></i>Account Setup
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Username *</label>
                                            <input type="text" class="form-control" id="username" name="username" 
                                                   placeholder="Choose a username" required
                                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                                            <div class="form-text">Only letters, numbers, and underscores allowed</div>
                                            <div class="invalid-feedback">Please choose a username.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Password *</label>
                                            <input type="password" class="form-control" id="password" name="password" 
                                                   placeholder="Create a password" required minlength="8">
                                            <div class="password-strength strength-0" id="passwordStrength"></div>
                                            <div class="form-text">Minimum 8 characters</div>
                                            <div class="invalid-feedback">Password must be at least 8 characters long.</div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="confirm_password" class="form-label">Confirm Password *</label>
                                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                                   placeholder="Confirm your password" required>
                                            <div class="invalid-feedback">Passwords do not match.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="agree_terms" name="agree_terms" required>
                                    <label class="form-check-label" for="agree_terms">
                                        I agree to the <a href="#" class="text-primary">Terms of Service</a> and <a href="#" class="text-primary">Privacy Policy</a> *
                                    </label>
                                    <div class="invalid-feedback">You must agree to the terms and conditions.</div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <button type="button" class="btn btn-outline-primary prev-step" data-prev="2">
                                        <i class="fas fa-arrow-left me-2"></i> Previous
                                    </button>
                                    <button type="submit" class="btn btn-register">
                                        <i class="fas fa-user-plus me-2"></i> Create Account
                                    </button>
                                </div>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4 pt-3 border-top">
                            <p class="mb-2">Already have an account?</p>
                            <a href="index.php" class="btn btn-outline-primary">
                                <i class="fas fa-sign-in-alt me-2"></i> Sign In
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Footer -->
                <div class="text-center mt-4">
                    <p class="text-white mb-1">
                        &copy; <?php echo date('Y'); ?> <?php echo $institution_name; ?>. All rights reserved.
                    </p>
                    <div class="text-white opacity-75">
                        <small>
                            <i class="fas fa-shield-alt me-1"></i>Secure Registration 
                            <span class="mx-2">•</span>
                            <i class="fas fa-user-graduate me-1"></i>Student Portal
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        // Multi-step form functionality
        class RegistrationForm {
            constructor() {
                this.currentStep = 1;
                this.totalSteps = 3;
                this.init();
            }
            
            init() {
                this.initStepNavigation();
                this.initPasswordStrength();
                this.initFormValidation();
                this.initStudentIDPreview();
                this.showStep(this.currentStep);
            }
            
            initStepNavigation() {
                // Next step buttons
                document.querySelectorAll('.next-step').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const nextStep = parseInt(e.target.getAttribute('data-next'));
                        if (this.validateStep(this.currentStep)) {
                            this.showStep(nextStep);
                        }
                    });
                });
                
                // Previous step buttons
                document.querySelectorAll('.prev-step').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const prevStep = parseInt(e.target.getAttribute('data-prev'));
                        this.showStep(prevStep);
                    });
                });
            }
            
            initPasswordStrength() {
                const passwordInput = document.getElementById('password');
                const strengthBar = document.getElementById('passwordStrength');
                
                if (passwordInput && strengthBar) {
                    passwordInput.addEventListener('input', () => {
                        const strength = this.calculatePasswordStrength(passwordInput.value);
                        strengthBar.className = `password-strength strength-${strength.level}`;
                    });
                }
            }
            
            initStudentIDPreview() {
                const departmentSelect = document.getElementById('department');
                const studentIdPreview = document.getElementById('studentIdPreview');
                
                if (departmentSelect && studentIdPreview) {
                    departmentSelect.addEventListener('change', () => {
                        this.updateStudentIDPreview();
                    });
                    
                    // Initial preview
                    this.updateStudentIDPreview();
                }
            }
            
            updateStudentIDPreview() {
                const departmentSelect = document.getElementById('department');
                const studentIdPreview = document.getElementById('studentIdPreview');
                
                if (departmentSelect.value) {
                    const deptCode = departmentSelect.value.substring(0, 3).toUpperCase();
                    const currentYear = new Date().getFullYear().toString().substring(2);
                    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
                    
                    // Preview format: DEP + YEAR + 3 random digits (final will be 4 digits from server)
                    const previewId = deptCode + currentYear + randomNum;
                    studentIdPreview.textContent = previewId;
                    studentIdPreview.style.color = '#4e73df';
                } else {
                    studentIdPreview.textContent = 'Select department to preview ID';
                    studentIdPreview.style.color = '#6c757d';
                }
            }
            
            initFormValidation() {
                const form = document.getElementById('registerForm');
                
                // Real-time validation for password confirmation
                const passwordInput = document.getElementById('password');
                const confirmInput = document.getElementById('confirm_password');
                
                if (passwordInput && confirmInput) {
                    confirmInput.addEventListener('input', () => {
                        if (passwordInput.value !== confirmInput.value) {
                            confirmInput.setCustomValidity('Passwords do not match.');
                        } else {
                            confirmInput.setCustomValidity('');
                        }
                    });
                }
                
                // Form submission
                form.addEventListener('submit', (e) => {
                    if (!this.validateStep(3) || !form.checkValidity()) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    form.classList.add('was-validated');
                });
            }
            
            showStep(stepNumber) {
                // Hide all steps
                document.querySelectorAll('.step-content').forEach(step => {
                    step.classList.remove('active');
                });
                
                // Show current step
                const currentStepElement = document.querySelector(`[data-step="${stepNumber}"]`);
                if (currentStepElement) {
                    currentStepElement.classList.add('active');
                }
                
                // Update step indicators
                document.querySelectorAll('.step').forEach(step => {
                    step.classList.remove('active');
                });
                
                const currentIndicator = document.querySelector(`[data-step="${stepNumber}"]`);
                if (currentIndicator) {
                    currentIndicator.classList.add('active');
                }
                
                this.currentStep = stepNumber;
                
                // Update student ID preview when showing step 2
                if (stepNumber === 2) {
                    this.updateStudentIDPreview();
                }
            }
            
            validateStep(stepNumber) {
                const stepElement = document.querySelector(`.step-content[data-step="${stepNumber}"]`);
                const inputs = stepElement.querySelectorAll('input[required], select[required]');
                let isValid = true;
                
                inputs.forEach(input => {
                    if (!input.checkValidity()) {
                        input.reportValidity();
                        isValid = false;
                    }
                });
                
                return isValid;
            }
            
            calculatePasswordStrength(password) {
                let strength = 0;
                let text = 'Very Weak';
                let level = 0;

                if (password.length >= 8) strength++;
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
                if (password.match(/\d/)) strength++;
                if (password.match(/[^a-zA-Z\d]/)) strength++;

                switch(strength) {
                    case 4:
                        text = 'Very Strong';
                        level = 4;
                        break;
                    case 3:
                        text = 'Strong';
                        level = 3;
                        break;
                    case 2:
                        text = 'Medium';
                        level = 2;
                        break;
                    case 1:
                        text = 'Weak';
                        level = 1;
                        break;
                    default:
                        text = 'Very Weak';
                        level = 0;
                }

                return { level, text };
            }
        }
        
        // Initialize registration form when page loads
        document.addEventListener('DOMContentLoaded', function() {
            window.registrationForm = new RegistrationForm();
            
            // Auto-capitalize first letter of names
            const nameInputs = document.querySelectorAll('input[name="first_name"], input[name="last_name"]');
            nameInputs.forEach(input => {
                input.addEventListener('blur', function() {
                    if (this.value) {
                        this.value = this.value.charAt(0).toUpperCase() + this.value.slice(1).toLowerCase();
                    }
                });
            });
        });
    </script>
</body>
</html>