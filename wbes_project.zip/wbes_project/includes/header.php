<?php
require_once __DIR__ . '/../config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: ../index.php');
    exit();
}

$user = getUserData();
$user_role = getUserRole();

// Get unread notifications count
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM user_notifications un 
        INNER JOIN notifications n ON un.notification_id = n.id 
        WHERE un.user_id = ? AND un.is_read = 0 
        AND n.is_active = 1 
        AND (n.expires_at IS NULL OR n.expires_at > NOW())
    ");
    $stmt->execute([$user['id']]);
    $unread_notifications = $stmt->fetchColumn();
} catch(PDOException $e) {
    $unread_notifications = 0;
}

// Determine active page for menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);

// Role-based menu items
$admin_menu = [
    'dashboard.php' => ['title' => 'Dashboard', 'icon' => 'tachometer-alt'],
    'manage_users.php' => ['title' => 'Manage Users', 'icon' => 'users'],
    'manage_departments.php' => ['title' => 'Manage Department', 'icon' => 'school'],
     'enroll_students.php' => ['title' => 'Enroll students', 'icon' => 'link'],
    'manage_attempt_limits.php' => ['title' => 'Manage Attempt', 'icon' => 'sliders-h'],
    'manage_courses.php' => ['title' => 'Manage Courses', 'icon' => 'book'], 
    'manage_exams.php' => ['title' => 'Manage Exams', 'icon' => 'file-alt'],
    'view_reports.php' => ['title' => 'Reports', 'icon' => 'chart-bar'],
    'view_results.php' => ['title' => 'Results', 'icon' => 'chart-line'],
    'settings.php' => ['title' => 'Settings', 'icon' => 'cogs']
];

$instructor_menu = [
    'dashboard.php' => ['title' => 'Dashboard', 'icon' => 'tachometer-alt'],
    'create_exam.php' => ['title' => 'Create Exam', 'icon' => 'plus-circle'],
    'view_exams.php' => ['title' => 'My Exams', 'icon' => 'list'],
    'add_question.php' => ['title' => 'Add Questions', 'icon' => 'question-circle'],
    'view_results.php' => ['title' => 'Results', 'icon' => 'chart-line'],
    'notifications.php' => ['title' => 'Notifications', 'icon' => 'bell']
];

$student_menu = [
    'dashboard.php' => ['title' => 'Dashboard', 'icon' => 'tachometer-alt'],
    'take_exam.php' => ['title' => 'Available Exams', 'icon' => 'pencil-alt'],
    'my_results.php' => ['title' => 'My Results', 'icon' => 'award'],
    'notifications.php' => ['title' => 'Notifications', 'icon' => 'bell']
];

// Select appropriate menu based on role
$menu_items = [];
switch($user_role) {
    case 'admin':
        $menu_items = $admin_menu;
        break;
    case 'instructor':
        $menu_items = $instructor_menu;
        break;
    case 'student':
        $menu_items = $student_menu;
        break;
}

// Get system name from settings
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'system_name'");
    $stmt->execute();
    $system_name = $stmt->fetchColumn();
} catch(PDOException $e) {
    $system_name = 'Web-Based Examination System';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . $system_name : $system_name; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        .navbar-brand {
            font-weight: 600;
        }
        
        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 0.375rem;
            margin: 0 0.125rem;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 600;
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            border-radius: 0.5rem;
        }
        
        .dropdown-item {
            padding: 0.5rem 1rem;
            transition: all 0.2s ease;
        }
        
        .dropdown-item:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }
        
        .badge-notification {
            font-size: 0.6rem;
            position: absolute;
            top: 5px;
            right: 5px;
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.875rem;
        }
        
        .breadcrumb {
            background: transparent;
            margin-bottom: 0;
            padding: 0.75rem 0;
        }
        
        .breadcrumb-item + .breadcrumb-item::before {
            color: #6c757d;
        }
        
        .alert {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
        <div class="container-fluid">
            <!-- Brand/Logo -->
            <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                <i class="fas fa-graduation-cap me-2"></i>
                <span class="d-none d-sm-inline"><?php echo $system_name; ?></span>
            </a>

            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation Links -->
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto">
                    <?php foreach($menu_items as $page => $menu_item): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($current_page == $page) ? 'active' : ''; ?>" 
                               href="<?php echo $page; ?>">
                                <i class="fas fa-<?php echo $menu_item['icon']; ?> me-1"></i>
                                <?php echo $menu_item['title']; ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <!-- User Menu -->
                <ul class="navbar-nav ms-auto">
                    <!-- Notifications Bell -->
                    <li class="nav-item dropdown">
                        <a class="nav-link position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell"></i>
                            <?php if($unread_notifications > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                                    <?php echo $unread_notifications; ?>
                                    <span class="visually-hidden">unread notifications</span>
                                </span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="notifications.php">
                                    <i class="fas fa-bell me-2"></i>
                                    Notifications
                                    <?php if($unread_notifications > 0): ?>
                                        <span class="badge bg-primary float-end"><?php echo $unread_notifications; ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="notifications.php?filter=unread">
                                    <i class="fas fa-envelope me-2"></i>
                                    Unread Notifications
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- User Profile Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-avatar me-2">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div class="d-none d-md-block">
                                <span class="fw-bold text-white"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></span>
                                <small class="d-block text-light opacity-75"><?php echo ucfirst($user_role); ?></small>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user me-2"></i>
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="notifications.php">
                                    <i class="fas fa-bell me-2"></i>
                                    Notifications
                                    <?php if($unread_notifications > 0): ?>
                                        <span class="badge bg-primary ms-2"><?php echo $unread_notifications; ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="settings.php">
                                    <i class="fas fa-cog me-2"></i>
                                    Settings
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="../logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i>
                                    Logout
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Breadcrumb Navigation -->
    <div class="bg-light border-bottom">
        <div class="container-fluid">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb py-2 mb-0">
                    <li class="breadcrumb-item">
                        <a href="dashboard.php" class="text-decoration-none text-muted">
                            <i class="fas fa-home me-1"></i> Dashboard
                        </a>
                    </li>
                    <?php if(isset($page_title) && $current_page != 'dashboard.php'): ?>
                        <li class="breadcrumb-item active" aria-current="page">
                            <?php 
                            // Get page title from menu items or use the set page_title
                            $breadcrumb_title = isset($menu_items[$current_page]) ? $menu_items[$current_page]['title'] : $page_title;
                            echo $breadcrumb_title;
                            ?>
                        </li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content Container -->
    <main class="container-fluid py-4">
        <!-- Flash Messages -->
        <?php
        $flash = getFlash();
        if ($flash): 
            $alert_class = $flash['type'] == 'error' ? 'danger' : 
                          ($flash['type'] == 'success' ? 'success' : 
                          ($flash['type'] == 'warning' ? 'warning' : 'info'));
        ?>
            <div class="alert alert-<?php echo $alert_class; ?> alert-dismissible fade show mb-4" role="alert">
                <div class="d-flex align-items-center">
                    <?php if($flash['type'] == 'success'): ?>
                        <i class="fas fa-check-circle me-2"></i>
                    <?php elseif($flash['type'] == 'error'): ?>
                        <i class="fas fa-exclamation-circle me-2"></i>
                    <?php elseif($flash['type'] == 'warning'): ?>
                        <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php else: ?>
                        <i class="fas fa-info-circle me-2"></i>
                    <?php endif; ?>
                    <div class="flex-grow-1">
                        <?php echo $flash['message']; ?>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

       
        <script>
        // Main JavaScript functionality for WBES

document.addEventListener('DOMContentLoaded', function() {
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Confirm before destructive actions
    const confirmButtons = document.querySelectorAll('[data-confirm]');
    confirmButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm') || 'Are you sure you want to proceed?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Form validation enhancement
    const forms = document.querySelectorAll('form[novalidate]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });

    // Auto-hide success messages after form submission
    const successAlerts = document.querySelectorAll('.alert-success');
    successAlerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 3000);
    });

    // Tooltip initialization
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Popover initialization
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-capitalize first letter of inputs
    const nameInputs = document.querySelectorAll('input[name="first_name"], input[name="last_name"]');
    nameInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value) {
                this.value = this.value.charAt(0).toUpperCase() + this.value.slice(1).toLowerCase();
            }
        });
    });

    // Password strength indicator
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        input.addEventListener('input', function() {
            const strengthIndicator = this.parentNode.querySelector('.password-strength');
            if (strengthIndicator) {
                const strength = calculatePasswordStrength(this.value);
                strengthIndicator.className = `password-strength strength-${strength.level}`;
                strengthIndicator.textContent = strength.text;
            }
        });
    });

    // Auto-save forms with data-auto-save attribute
    const autoSaveForms = document.querySelectorAll('form[data-auto-save]');
    autoSaveForms.forEach(form => {
        let saveTimeout;
        
        form.addEventListener('input', function() {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(() => {
                saveFormData(this);
            }, 1000);
        });
    });

    // Mark notifications as read when dropdown is opened
    const notificationDropdown = document.getElementById('notificationDropdown');
    if (notificationDropdown) {
        notificationDropdown.addEventListener('show.bs.dropdown', function() {
            markNotificationsAsRead();
        });
    });
});

// Password strength calculator
function calculatePasswordStrength(password) {
    let strength = 0;
    let text = 'Very Weak';
    let level = 0;

    if (password.length >= 8) strength++;
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
    if (password.match(/\d/)) strength++;
    if (password.match(/[^a-zA-Z\d]/)) strength++;

    switch(strength) {
        case 4:
            text = 'Very Strong';
            level = 4;
            break;
        case 3:
            text = 'Strong';
            level = 3;
            break;
        case 2:
            text = 'Medium';
            level = 2;
            break;
        case 1:
            text = 'Weak';
            level = 1;
            break;
        default:
            text = 'Very Weak';
            level = 0;
    }

    return { level, text };
}

// Auto-save form data
function saveFormData(form) {
    const formData = new FormData(form);
    const autoSaveUrl = form.getAttribute('data-save-url') || '../process/auto_save.php';
    
    fetch(autoSaveUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAutoSaveIndicator('success');
        } else {
            showAutoSaveIndicator('error');
        }
    })
    .catch(error => {
        console.error('Auto-save failed:', error);
        showAutoSaveIndicator('error');
    });
}

// Show auto-save indicator
function showAutoSaveIndicator(type) {
    let indicator = document.getElementById('auto-save-indicator');
    if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'auto-save-indicator';
        indicator.className = 'position-fixed bottom-0 end-0 m-3 p-2 rounded shadow-sm';
        document.body.appendChild(indicator);
    }

    if (type === 'success') {
        indicator.innerHTML = '<i class="fas fa-check text-success me-1"></i> Progress saved';
        indicator.className = 'position-fixed bottom-0 end-0 m-3 p-2 rounded shadow-sm bg-light text-success';
    } else {
        indicator.innerHTML = '<i class="fas fa-times text-danger me-1"></i> Save failed';
        indicator.className = 'position-fixed bottom-0 end-0 m-3 p-2 rounded shadow-sm bg-light text-danger';
    }

    setTimeout(() => {
        indicator.style.opacity = '0';
        setTimeout(() => indicator.remove(), 300);
    }, 2000);
}

// Mark notifications as read
function markNotificationsAsRead() {
    fetch('../process/mark_notifications_read.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update notification badge
            const badge = document.querySelector('.nav-link .badge');
            if (badge) {
                badge.remove();
            }
        }
    })
    .catch(error => console.error('Failed to mark notifications as read:', error));
}

// Utility function to format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Export functions for use in other scripts
window.WBES = {
    calculatePasswordStrength,
    saveFormData,
    formatFileSize
};
        </script>