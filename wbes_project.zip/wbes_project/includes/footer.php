<?php
// This file should be included at the end of every page
?>
        </main>

        <!-- Footer -->
        <footer class="footer mt-auto py-3 bg-light border-top">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <span class="text-muted">
                            &copy; <?php echo date('Y'); ?> <?php echo $system_name ?? 'Web-Based Examination System'; ?>. 
                            All rights reserved.
                        </span>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="text-muted">
                            <i class="fas fa-user-shield text-primary me-1"></i>
                            Logged in as: <?php echo ucfirst($user_role ?? 'Guest'); ?>
                            | 
                            <i class="fas fa-clock text-primary me-1"></i>
                            <?php echo date('Y-m-d H:i:s'); ?>
                        </span>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Bootstrap 5 JavaScript with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- Custom JavaScript -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-dismiss alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    if (alert.classList.contains('show')) {
                        const bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    }
                }, 5000);
            });

            // Add active class to current page in navigation
            const currentPage = '<?php echo $current_page; ?>';
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (href === currentPage) {
                    link.classList.add('active');
                }
            });

            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Initialize popovers
            const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
            const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
                return new bootstrap.Popover(popoverTriggerEl);
            });
        });

        // Utility function to show loading state
        function showLoading(button) {
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
            button.disabled = true;
            return originalText;
        }

        // Utility function to hide loading state
        function hideLoading(button, originalText) {
            button.innerHTML = originalText;
            button.disabled = false;
        }
        </script>
        
        <!-- Additional scripts can be added per page -->
        <?php if(isset($additional_scripts)): ?>
            <?php echo $additional_scripts; ?>
        <?php endif; ?>
    </body>
</html>