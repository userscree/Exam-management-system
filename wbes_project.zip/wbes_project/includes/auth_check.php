<?php
// auth_check.php - Updated version
require_once __DIR__ . '/../config.php';

if (!isLoggedIn()) {
    setFlash('error', 'Please login to access this page.');
    redirect('../index.php');
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);
$user_role = getUserRole();

// Debug information (you can remove this after testing)
error_log("Current page: $current_page");
error_log("User role: $user_role");
error_log("User ID: " . ($_SESSION['user_id'] ?? 'Not set'));

// Role-based access control
$allowed_pages = [
    'admin' => [
        'dashboard.php', 'manage_users.php', 'manage_courses.php', 
        'manage_exams.php', 'view_reports.php', 'view_results.php', 
        'settings.php', 'profile.php','manage_departments.php','enroll_students.php','manage_attempt_limits.php','notifications.php','audit_logs.php'
    ],
    'instructor' => [
        'dashboard.php', 'create_exam.php', 'add_question.php', 
        'edit_question.php', 'view_exams.php', 'view_results.php', 
        'notifications.php', 'profile.php','settings.php'
    ],
    'student' => [
        'dashboard.php', 'take_exam.php', 'exam_instructions.php', 
        'questions.php', 'submit_exam.php', 'my_results.php', 
        'notifications.php', 'profile.php','result_details.php','settings.php'
    ]
];

// Check if user role exists in allowed pages
if (!isset($allowed_pages[$user_role])) {
    error_log("Invalid user role: $user_role");
    setFlash('error', 'Invalid user role configuration.');
    redirect('../index.php');
    exit();
}

// Check if current page is allowed for user role
if (!in_array($current_page, $allowed_pages[$user_role])) {
    error_log("Access denied: $user_role trying to access $current_page");
    setFlash('error', 'You do not have permission to access this page.');
    
    // Redirect to appropriate dashboard
    switch($user_role) {
        case 'admin':
           redirect('../index.php');
            break;
        case 'instructor':
           redirect('../index.php');
            break;
        case 'student':
           redirect('../index.php');
            break;
        default:
            redirect('../index.php');
    }
    exit();
}
// Check for exam attempt limits for students
if ($user_role === 'student' && in_array($current_page, ['questions.php', 'exam_instructions.php', 'submit_exam.php'])) {
    checkExamAttemptLimits();
}

/**
 * Check exam attempt limits for students
 */
function checkExamAttemptLimits() {
    global $pdo;
    
    $student_id = $_SESSION['user_id'];
    
    // Get exam ID from URL parameters
    $exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;
    $attempt_id = isset($_GET['attempt_id']) ? intval($_GET['attempt_id']) : 0;
    
    if ($exam_id <= 0) {
        return; // No exam ID provided, skip checking
    }
    
    try {
        // Get exam details including attempt limits
        $stmt = $pdo->prepare("
            SELECT e.*, c.course_name, c.course_code,
                   (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ?) as total_attempts,
                   (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ? AND status IN ('submitted', 'graded')) as completed_attempts
            FROM exams e 
            LEFT JOIN courses c ON e.course_id = c.id 
            WHERE e.id = ?
        ");
        $stmt->execute([$student_id, $student_id, $exam_id]);
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$exam) {
            setFlash('error', 'Exam not found.');
            redirect('take_exam.php');
        }
        
        // Check if exam is active and within date range
        $now = new DateTime();
        $start_date = new DateTime($exam['start_date']);
        $end_date = new DateTime($exam['end_date']);
        
        if (!$exam['is_active']) {
            setFlash('error', 'This exam is no longer active.');
            redirect('take_exam.php');
        }
        
        if ($now < $start_date) {
            setFlash('error', 'This exam has not started yet. It will be available on ' . formatDate($exam['start_date']));
            redirect('take_exam.php');
        }
        
        if ($now > $end_date) {
            setFlash('error', 'This exam has expired. The deadline was ' . formatDate($exam['end_date']));
            redirect('take_exam.php');
        }
        
        // Check attempt limits
        $max_attempts = $exam['allow_retake'] ? 3 : 1; // Default limits
        $completed_attempts = $exam['completed_attempts'] ?? 0;
        
        // Custom attempt limits can be added to exams table if needed
        // For now, using simple logic: 1 attempt unless retakes allowed, then 3 attempts max
        
        if ($completed_attempts >= $max_attempts) {
            setFlash('error', 'You have reached the maximum number of attempts (' . $max_attempts . ') for this exam.');
            redirect('take_exam.php');
        }
        
        // Check for existing in-progress attempt
        if ($attempt_id <= 0) {
            $stmt = $pdo->prepare("
                SELECT id FROM exam_attempts 
                WHERE exam_id = ? AND student_id = ? AND status = 'in_progress'
            ");
            $stmt->execute([$exam_id, $student_id]);
            $existing_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing_attempt) {
                // Redirect to existing attempt instead of creating new one
                redirect('questions.php?exam_id=' . $exam_id . '&attempt_id=' . $existing_attempt['id']);
            }
        }
        
        // Verify attempt belongs to student
        if ($attempt_id > 0) {
            $stmt = $pdo->prepare("
                SELECT id FROM exam_attempts 
                WHERE id = ? AND student_id = ? AND exam_id = ?
            ");
            $stmt->execute([$attempt_id, $student_id, $exam_id]);
            $valid_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$valid_attempt) {
                setFlash('error', 'Invalid exam attempt.');
                redirect('take_exam.php');
            }
        }
        
    } catch(PDOException $e) {
        error_log("Attempt limit check error: " . $e->getMessage());
        setFlash('error', 'Error verifying exam access. Please try again.');
        redirect('take_exam.php');
    }
}

/**
 * Check if user has exceeded maximum allowed concurrent exam attempts
 */
function checkConcurrentAttemptLimit($student_id) {
    global $pdo;
    
    try {
        // Get maximum concurrent attempts from settings (default: 2)
        $max_concurrent = 2; // Can be moved to settings table
        
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as concurrent_attempts 
            FROM exam_attempts 
            WHERE student_id = ? AND status = 'in_progress'
        ");
        $stmt->execute([$student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result && $result['concurrent_attempts'] >= $max_concurrent) {
            setFlash('error', 'You have reached the maximum number of concurrent exam attempts (' . $max_concurrent . '). Please complete one exam before starting another.');
            redirect('take_exam.php');
        }
        
        return true;
        
    } catch(PDOException $e) {
        error_log("Concurrent attempt check error: " . $e->getMessage());
        return true; // Allow on error
    }
}

/**
 * Check time-based attempt restrictions
 */
function checkTimeBasedRestrictions($exam_id, $student_id) {
    global $pdo;
    
    try {
        // Check if there's a minimum time between attempts
        $min_retake_interval = 30; // minutes - can be moved to exam settings
        
        $stmt = $pdo->prepare("
            SELECT submitted_at 
            FROM exam_attempts 
            WHERE exam_id = ? AND student_id = ? AND status IN ('submitted', 'graded')
            ORDER BY submitted_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$exam_id, $student_id]);
        $last_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($last_attempt && $last_attempt['submitted_at']) {
            $last_attempt_time = new DateTime($last_attempt['submitted_at']);
            $current_time = new DateTime();
            $time_diff = $current_time->getTimestamp() - $last_attempt_time->getTimestamp();
            $minutes_diff = floor($time_diff / 60);
            
            if ($minutes_diff < $min_retake_interval) {
                $remaining_time = $min_retake_interval - $minutes_diff;
                setFlash('error', 'You must wait ' . $remaining_time . ' minutes before retaking this exam.');
                redirect('take_exam.php');
            }
        }
        
        return true;
        
    } catch(PDOException $e) {
        error_log("Time restriction check error: " . $e->getMessage());
        return true; // Allow on error
    }
}

/**
 * Log security events for monitoring
 */
function logSecurityEvent($user_id, $event_type, $description) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user_id,
            $event_type,
            $description,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
    } catch(PDOException $e) {
        error_log("Security event logging failed: " . $e->getMessage());
    }
}

// Additional security checks for all users
performSecurityChecks();

/**
 * Perform additional security checks
 */
function performSecurityChecks() {
    // Check session timeout
    checkSessionTimeout();
    
    // Check for suspicious activity
    checkSuspiciousActivity();
    
    // Validate user agent consistency
    validateUserAgent();
}

/**
 * Check session timeout
 */
function checkSessionTimeout() {
    $session_timeout = 3600; // 1 hour in seconds
    
    if (isset($_SESSION['logged_in_at']) && (time() - $_SESSION['logged_in_at']) > $session_timeout) {
        session_destroy();
        setFlash('error', 'Your session has expired. Please login again.');
        redirect('../index.php?expired=1');
    }
    
    // Update last activity time
    $_SESSION['last_activity'] = time();
}

/**
 * Check for suspicious activity
 */
function checkSuspiciousActivity() {
    $user_id = $_SESSION['user_id'];
    
    // Check for rapid page requests (basic rate limiting)
    if (!isset($_SESSION['last_request'])) {
        $_SESSION['last_request'] = time();
        $_SESSION['request_count'] = 1;
    } else {
        $current_time = time();
        $time_diff = $current_time - $_SESSION['last_request'];
        
        if ($time_diff < 1) { // Less than 1 second between requests
            $_SESSION['request_count']++;
            
            if ($_SESSION['request_count'] > 10) { // More than 10 requests per second
                logSecurityEvent($user_id, 'suspicious_activity', 'High request rate detected');
                setFlash('error', 'Suspicious activity detected. Please slow down your requests.');
                redirect('dashboard.php');
            }
        } else {
            // Reset counter if more than 1 second has passed
            $_SESSION['last_request'] = $current_time;
            $_SESSION['request_count'] = 1;
        }
    }
}

/**
 * Validate user agent consistency
 */
function validateUserAgent() {
    if (!isset($_SESSION['original_user_agent'])) {
        $_SESSION['original_user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    } else {
        if ($_SESSION['original_user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
            logSecurityEvent($_SESSION['user_id'], 'user_agent_change', 'User agent changed during session');
            // Don't block, just log for now
        }
    }
}

/**
 * Check if user's account is still active
 */
function checkAccountStatus($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !$user['is_active']) {
            session_destroy();
            setFlash('error', 'Your account has been deactivated. Please contact administrator.');
            redirect('../index.php');
        }
    } catch(PDOException $e) {
        error_log("Account status check error: " . $e->getMessage());
    }
}

// Check account status on every page load
checkAccountStatus($_SESSION['user_id']);
?>