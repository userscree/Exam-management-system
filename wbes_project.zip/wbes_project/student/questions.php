<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Exam Questions';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;
$attempt_id = isset($_GET['attempt_id']) ? intval($_GET['attempt_id']) : 0;

if ($exam_id <= 0) {
    setFlash('error', 'Invalid exam selected.');
    redirect('take_exam.php');
}

// Get exam details
try {
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name
        FROM exams e 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE e.id = ? 
        AND e.is_active = 1 
        AND e.start_date <= NOW() 
        AND e.end_date >= NOW()
    ");
    $stmt->execute([$exam_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        setFlash('error', 'Exam not found or not available.');
        redirect('take_exam.php');
    }
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exam details: ' . $e->getMessage());
    redirect('take_exam.php');
}

// Handle exam attempt
if ($attempt_id > 0) {
    // Continue existing attempt
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM exam_attempts 
            WHERE id = ? AND student_id = ? AND exam_id = ? AND status = 'in_progress'
        ");
        $stmt->execute([$attempt_id, $student_id, $exam_id]);
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attempt) {
            setFlash('error', 'Invalid attempt or exam already completed.');
            redirect('take_exam.php');
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching attempt details: ' . $e->getMessage());
        redirect('take_exam.php');
    }
} else {
    // Start new attempt - IMPROVED RETAKE LOGIC
    try {
        // Check if there's already an in-progress attempt
        $stmt = $pdo->prepare("
            SELECT id FROM exam_attempts 
            WHERE exam_id = ? AND student_id = ? AND status = 'in_progress'
        ");
        $stmt->execute([$exam_id, $student_id]);
        $existing_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_attempt) {
            // Redirect to existing attempt
            redirect('questions.php?exam_id=' . $exam_id . '&attempt_id=' . $existing_attempt['id']);
        }
        
        // Check if retake is allowed - count only completed attempts
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM exam_attempts 
            WHERE exam_id = ? AND student_id = ? AND status IN ('submitted', 'graded', 'time_up')
        ");
        $stmt->execute([$exam_id, $student_id]);
        $completed_attempts = $stmt->fetchColumn();
        
        if ($completed_attempts > 0) {
            if ($exam['allow_retake'] == 0) {
                setFlash('error', 'You have already completed this exam and retakes are not allowed.');
                redirect('take_exam.php');
            }
            
            // For retakes, we need to create a new attempt regardless of previous ones
            // The system allows multiple attempts when allow_retake is enabled
        }
        
        // Create new attempt - CLEAN START FOR RETAKE
        $stmt = $pdo->prepare("
            INSERT INTO exam_attempts (student_id, exam_id, started_at, total_questions, status) 
            VALUES (?, ?, NOW(), (SELECT COUNT(*) FROM questions WHERE exam_id = ?), 'in_progress')
        ");
        $stmt->execute([$student_id, $exam_id, $exam_id]);
        $attempt_id = $pdo->lastInsertId();
        
        // Log activity
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $student_id,
            'exam_started',
            'Started exam: ' . $exam['title'] . ($completed_attempts > 0 ? ' (Retake)' : ''),
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
        
    } catch(PDOException $e) {
        setFlash('error', 'Error starting exam: ' . $e->getMessage());
        redirect('exam_instructions.php?exam_id=' . $exam_id);
    }
}

// Get questions for this exam
try {
    $stmt = $pdo->prepare("
        SELECT * FROM questions 
        WHERE exam_id = ? 
        ORDER BY question_order ASC, id ASC
    ");
    $stmt->execute([$exam_id]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($questions)) {
        setFlash('error', 'No questions found for this exam.');
        redirect('take_exam.php');
    }
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching questions: ' . $e->getMessage());
    redirect('take_exam.php');
}

// Get existing answers
$existing_answers = [];
try {
    $stmt = $pdo->prepare("
        SELECT question_id, student_answer FROM student_answers 
        WHERE attempt_id = ?
    ");
    $stmt->execute([$attempt_id]);
    $existing_answers = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
} catch(PDOException $e) {
    // Continue without existing answers
}

// Calculate time remaining
$start_time = strtotime($attempt['started_at'] ?? date('Y-m-d H:i:s'));
$end_time = $start_time + ($exam['duration_minutes'] * 60);
$time_remaining = $end_time - time();

if ($time_remaining <= 0) {
    // Time's up - auto submit
    try {
        $stmt = $pdo->prepare("UPDATE exam_attempts SET status = 'time_up', submitted_at = NOW() WHERE id = ?");
        $stmt->execute([$attempt_id]);
        setFlash('error', 'Exam time has expired.');
        redirect('my_results.php');
    } catch(PDOException $e) {
        setFlash('error', 'Error updating exam status.');
        redirect('my_results.php');
    }
}
?>

<!-- Exam Header -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <div>
            <h5 class="card-title mb-0">
                <i class="fas fa-file-alt me-2"></i> <?php echo htmlspecialchars($exam['title']); ?>
            </h5>
            <small class="opacity-75"><?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?></small>
        </div>
        <div class="text-end">
            <div id="examTimer" class="h5 mb-0" data-end-time="<?php echo $end_time; ?>"></div>
            <small class="opacity-75">Time Remaining</small>
        </div>
    </div>
</div>

<div class="row">
    <!-- Questions Navigation -->
    <div class="col-lg-3">
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h6 class="card-title mb-0">
                    <i class="fas fa-list me-2"></i> Questions
                </h6>
            </div>
            <div class="card-body p-2">
                <div class="questions-nav" id="questionsNav">
                    <?php foreach($questions as $index => $question): 
                        $question_number = $index + 1;
                        $is_answered = isset($existing_answers[$question['id']]) && !empty($existing_answers[$question['id']]);
                    ?>
                        <button type="button" class="btn btn-sm mb-1 question-nav-btn <?php echo $is_answered ? 'btn-success' : 'btn-outline-primary'; ?>" 
                                data-question="<?php echo $question_number; ?>">
                            Q<?php echo $question_number; ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="card-footer bg-light">
                <div class="small">
                    <span class="badge bg-success me-2">Answered</span>
                    <span class="badge bg-outline-primary">Unanswered</span>
                </div>
            </div>
        </div>

        <!-- Exam Progress -->
        <div class="card">
            <div class="card-header bg-light">
                <h6 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2"></i> Progress
                </h6>
            </div>
            <div class="card-body">
                <?php
                $answered_count = 0;
                foreach($questions as $question) {
                    if (isset($existing_answers[$question['id']]) && !empty($existing_answers[$question['id']])) {
                        $answered_count++;
                    }
                }
                $progress_percentage = round(($answered_count / count($questions)) * 100);
                ?>
                <div class="text-center mb-3">
                    <div class="h4 text-primary"><?php echo $progress_percentage; ?>%</div>
                    <small class="text-muted">Exam Progress</small>
                </div>
                <div class="progress mb-2" style="height: 8px;">
                    <div class="progress-bar bg-success" style="width: <?php echo $progress_percentage; ?>%"></div>
                </div>
                <div class="row text-center small">
                    <div class="col-6">
                        <div class="fw-bold text-success"><?php echo $answered_count; ?></div>
                        <div class="text-muted">Answered</div>
                    </div>
                    <div class="col-6">
                        <div class="fw-bold text-primary"><?php echo count($questions) - $answered_count; ?></div>
                        <div class="text-muted">Remaining</div>
                    </div>
                </div>
            </div>
        </div>
        
       
    </div>

    <!-- Questions Container -->
    <div class="col-lg-9">
        <div class="card">
            <div class="card-header bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-question-circle me-2 text-primary"></i>
                        Question <span id="currentQuestion">1</span> of <?php echo count($questions); ?>
                    </h6>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary btn-sm" id="markForReview">
                            <i class="fas fa-flag me-1"></i> Mark for Review
                        </button>
                        <button type="button" class="btn btn-outline-warning btn-sm" id="clearAnswer">
                            <i class="fas fa-eraser me-1"></i> Clear
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <form id="examForm" method="POST" action="../process/process_exam.php">
                    <input type="hidden" name="attempt_id" value="<?php echo $attempt_id; ?>">
                    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                    <input type="hidden" name="submit_exam" value="1">
                    
                    <div id="questionsContainer">
                        <?php foreach($questions as $index => $question): 
                            $question_number = $index + 1;
                            $current_answer = $existing_answers[$question['id']] ?? '';
                        ?>
                            <div class="question-panel <?php echo $index === 0 ? 'active' : ''; ?>" 
                                 id="question-<?php echo $question_number; ?>" 
                                 data-question-id="<?php echo $question['id']; ?>">
                                
                                <!-- Question Header -->
                                <div class="question-header mb-4">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <span class="badge bg-primary me-2">Q<?php echo $question_number; ?></span>
                                            <span class="badge bg-<?php 
                                                switch($question['question_type']) {
                                                    case 'multiple_choice': echo 'info'; break;
                                                    case 'true_false': echo 'success'; break;
                                                    case 'short_answer': echo 'warning'; break;
                                                    case 'essay': echo 'danger'; break;
                                                    default: echo 'secondary';
                                                }
                                            ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?>
                                            </span>
                                            <span class="badge bg-light text-dark ms-2">
                                                <i class="fas fa-star text-warning me-1"></i>
                                                <?php echo $question['marks']; ?> marks
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <!-- Question Text -->
                                    <div class="question-text mb-4">
                                        <h6><?php echo htmlspecialchars($question['question_text']); ?></h6>
                                    </div>
                                </div>

                                <!-- Answer Section -->
                                <div class="answer-section">
                                    <?php if($question['question_type'] == 'multiple_choice'): ?>
                                        <div class="options-list">
                                            <?php 
                                            $options = [
                                                'A' => $question['option_a'],
                                                'B' => $question['option_b'],
                                                'C' => $question['option_c'],
                                                'D' => $question['option_d']
                                            ];
                                            
                                            foreach($options as $letter => $option):
                                                if (!empty($option)):
                                            ?>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="radio" 
                                                           name="answer[<?php echo $question['id']; ?>]" 
                                                           id="q<?php echo $question['id']; ?>_<?php echo $letter; ?>" 
                                                           value="<?php echo $letter; ?>"
                                                           <?php echo ($current_answer == $letter) ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="q<?php echo $question['id']; ?>_<?php echo $letter; ?>">
                                                        <strong><?php echo $letter; ?>.</strong> <?php echo htmlspecialchars($option); ?>
                                                    </label>
                                                </div>
                                            <?php 
                                                endif;
                                            endforeach; 
                                            ?>
                                        </div>

                                    <?php elseif($question['question_type'] == 'true_false'): ?>
                                        <div class="options-list">
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="radio" 
                                                       name="answer[<?php echo $question['id']; ?>]" 
                                                       id="q<?php echo $question['id']; ?>_true" 
                                                       value="TRUE"
                                                       <?php echo ($current_answer == 'TRUE') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="q<?php echo $question['id']; ?>_true">
                                                    <strong>True</strong>
                                                </label>
                                            </div>
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="radio" 
                                                       name="answer[<?php echo $question['id']; ?>]" 
                                                       id="q<?php echo $question['id']; ?>_false" 
                                                       value="FALSE"
                                                       <?php echo ($current_answer == 'FALSE') ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="q<?php echo $question['id']; ?>_false">
                                                    <strong>False</strong>
                                                </label>
                                            </div>
                                        </div>

                                    <?php elseif(in_array($question['question_type'], ['short_answer', 'essay'])): ?>
                                        <div class="form-group">
                                            <textarea class="form-control answer-textarea" 
                                                      name="answer[<?php echo $question['id']; ?>]" 
                                                      rows="<?php echo $question['question_type'] == 'essay' ? 6 : 3; ?>" 
                                                      placeholder="Type your answer here..."><?php echo htmlspecialchars($current_answer); ?></textarea>
                                            <?php if($question['question_type'] == 'essay'): ?>
                                                <div class="form-text">
                                                    <i class="fas fa-info-circle me-1"></i>
                                                    Provide a detailed answer. You can write multiple paragraphs.
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Navigation Buttons -->
                    <div class="d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-primary" id="prevQuestion" disabled>
                            <i class="fas fa-arrow-left me-2"></i> Previous
                        </button>
                        
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-info" id="saveProgress">
                                <i class="fas fa-save me-2"></i> Save Progress
                            </button>
                            
                            <?php if($exam['show_results_immediately']): ?>
                                <button type="submit" class="btn btn-success" name="submit_exam">
                                    <i class="fas fa-paper-plane me-2"></i> Submit Exam
                                </button>
                            <?php else: ?>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#submitModal">
                                    <i class="fas fa-paper-plane me-2"></i> Submit Exam
                                </button>
                            <?php endif; ?>
                        </div>
                        
                        <button type="button" class="btn btn-outline-primary" id="nextQuestion">
                            Next <i class="fas fa-arrow-right ms-2"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Submit Confirmation Modal -->
<div class="modal fade" id="submitModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Submit Exam</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <i class="fas fa-paper-plane fa-3x text-success mb-3"></i>
                    <h5>Ready to Submit?</h5>
                    <p class="text-muted">You are about to submit your exam answers.</p>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Answered Questions:</strong> <span id="answeredCount"><?php echo $answered_count; ?></span> of <?php echo count($questions); ?><br>
                    <strong>Time Remaining:</strong> <span id="timeRemainingDisplay"></span>
                </div>
                
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="confirmSubmit">
                    <label class="form-check-label" for="confirmSubmit">
                        I confirm that I have reviewed all my answers and want to submit the exam
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Continue Exam</button>
                <button type="button" class="btn btn-success" id="finalSubmit" disabled>
                    <i class="fas fa-paper-plane me-2"></i> Submit Exam
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Auto-save Indicator -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="autoSaveToast" class="toast" role="alert">
        <div class="toast-header">
            <i class="fas fa-save text-primary me-2"></i>
            <strong class="me-auto">Auto-save</strong>
            <small>Just now</small>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body" id="toastMessage">
            Progress saved successfully.
        </div>
    </div>
</div>

<script>
// Exam functionality
class ExamManager {
    constructor() {
        this.currentQuestion = 1;
        this.totalQuestions = <?php echo count($questions); ?>;
        this.attemptId = <?php echo $attempt_id; ?>;
        this.examId = <?php echo $exam_id; ?>;
        this.endTime = <?php echo $end_time; ?>;
        this.autoSaveInterval = null;
        this.markedQuestions = new Set();
        this.isSaving = false;
        
        this.init();
    }
    
    init() {
        this.initTimer();
        this.initNavigation();
        this.initAutoSave();
        this.initEventListeners();
        this.updateProgress();
        console.log('ExamManager initialized:', {
            attemptId: this.attemptId,
            examId: this.examId,
            totalQuestions: this.totalQuestions
        });
    }
    
    initTimer() {
        const timerElement = document.getElementById('examTimer');
        const endTime = this.endTime * 1000; // Convert to milliseconds
        
        const updateTimer = () => {
            const now = new Date().getTime();
            const distance = endTime - now;
            
            if (distance <= 0) {
                timerElement.innerHTML = '<span class="text-danger">TIME\'S UP!</span>';
                this.autoSubmit();
                return;
            }
            
            // Calculate time units
            const hours = Math.floor(distance / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            // Display timer
            let timerText = '';
            if (hours > 0) {
                timerText += `${hours.toString().padStart(2, '0')}:`;
            }
            timerText += `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            timerElement.textContent = timerText;
            
            // Change color when less than 5 minutes remaining
            if (distance < 5 * 60 * 1000) {
                timerElement.className = 'h5 mb-0 text-danger';
            } else if (distance < 15 * 60 * 1000) {
                timerElement.className = 'h5 mb-0 text-warning';
            }
        };
        
        // Update timer immediately and every second
        updateTimer();
        setInterval(updateTimer, 1000);
    }
    
    initNavigation() {
        // Question navigation buttons
        document.querySelectorAll('.question-nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const questionNum = parseInt(btn.getAttribute('data-question'));
                this.showQuestion(questionNum);
            });
        });
        
        // Next/Previous buttons
        document.getElementById('prevQuestion').addEventListener('click', () => {
            this.showQuestion(this.currentQuestion - 1);
        });
        
        document.getElementById('nextQuestion').addEventListener('click', () => {
            this.showQuestion(this.currentQuestion + 1);
        });
        
        // Mark for review
        document.getElementById('markForReview').addEventListener('click', () => {
            this.toggleMarkForReview();
        });
        
        // Clear answer
        document.getElementById('clearAnswer').addEventListener('click', () => {
            this.clearCurrentAnswer();
        });
    }
    
    initAutoSave() {
        // Auto-save every 30 seconds
        this.autoSaveInterval = setInterval(() => {
            if (!this.isSaving) {
                this.saveProgress(false);
            }
        }, 30000);
        
        // Also save on answer change
        document.querySelectorAll('input[type="radio"], textarea').forEach(element => {
            element.addEventListener('change', () => {
                if (!this.isSaving) {
                    this.saveProgress(true);
                }
            });
        });
        
        // Save on input for textareas (with debounce)
        let textareaTimeout;
        document.querySelectorAll('textarea').forEach(textarea => {
            textarea.addEventListener('input', () => {
                clearTimeout(textareaTimeout);
                textareaTimeout = setTimeout(() => {
                    if (!this.isSaving) {
                        this.saveProgress(true);
                    }
                }, 1000);
            });
        });
    }
    
    initEventListeners() {
        // Submit confirmation
        const confirmSubmit = document.getElementById('confirmSubmit');
        const finalSubmit = document.getElementById('finalSubmit');
        
        if (confirmSubmit && finalSubmit) {
            confirmSubmit.addEventListener('change', () => {
                finalSubmit.disabled = !confirmSubmit.checked;
            });
            
            finalSubmit.addEventListener('click', () => {
                document.getElementById('examForm').submit();
            });
        }
        
        // Update submit modal info
        const submitModal = document.getElementById('submitModal');
        if (submitModal) {
            submitModal.addEventListener('show.bs.modal', () => {
                this.updateSubmitModal();
            });
        }
        
        // Manual save progress
        document.getElementById('saveProgress').addEventListener('click', () => {
            this.saveProgress(true);
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey) {
                switch(e.key) {
                    case 'ArrowLeft':
                        e.preventDefault();
                        this.showQuestion(this.currentQuestion - 1);
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        this.showQuestion(this.currentQuestion + 1);
                        break;
                    case 's':
                        e.preventDefault();
                        this.saveProgress(true);
                        break;
                }
            }
        });
        
        // Prevent accidental navigation
        window.addEventListener('beforeunload', (e) => {
            if (this.hasUnsavedChanges()) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
                return e.returnValue;
            }
        });
    }
    
    showQuestion(questionNum) {
        if (questionNum < 1 || questionNum > this.totalQuestions) return;
        
        // Hide current question
        const currentQuestionElement = document.getElementById(`question-${this.currentQuestion}`);
        const currentNavButton = document.querySelector(`[data-question="${this.currentQuestion}"]`);
        
        if (currentQuestionElement) {
            currentQuestionElement.classList.remove('active');
        }
        if (currentNavButton) {
            currentNavButton.classList.remove('active');
        }
        
        // Show new question
        this.currentQuestion = questionNum;
        const newQuestionElement = document.getElementById(`question-${questionNum}`);
        const newNavButton = document.querySelector(`[data-question="${questionNum}"]`);
        
        if (newQuestionElement) {
            newQuestionElement.classList.add('active');
        }
        if (newNavButton) {
            newNavButton.classList.add('active');
        }
        
        document.getElementById('currentQuestion').textContent = questionNum;
        
        // Update navigation buttons
        document.getElementById('prevQuestion').disabled = (questionNum === 1);
        document.getElementById('nextQuestion').disabled = (questionNum === this.totalQuestions);
        
        // Update marked status
        this.updateMarkButton();
    }
    
    toggleMarkForReview() {
        const btn = document.querySelector(`[data-question="${this.currentQuestion}"]`);
        
        if (this.markedQuestions.has(this.currentQuestion)) {
            this.markedQuestions.delete(this.currentQuestion);
            btn.classList.remove('btn-warning');
            btn.classList.add('btn-outline-primary');
        } else {
            this.markedQuestions.add(this.currentQuestion);
            btn.classList.remove('btn-outline-primary');
            btn.classList.add('btn-warning');
        }
        
        this.updateMarkButton();
    }
    
    updateMarkButton() {
        const markBtn = document.getElementById('markForReview');
        const isMarked = this.markedQuestions.has(this.currentQuestion);
        
        if (isMarked) {
            markBtn.innerHTML = '<i class="fas fa-flag me-1"></i> Unmark';
            markBtn.classList.remove('btn-outline-primary');
            markBtn.classList.add('btn-warning');
        } else {
            markBtn.innerHTML = '<i class="fas fa-flag me-1"></i> Mark for Review';
            markBtn.classList.remove('btn-warning');
            markBtn.classList.add('btn-outline-primary');
        }
    }
    
    clearCurrentAnswer() {
        const currentPanel = document.getElementById(`question-${this.currentQuestion}`);
        if (!currentPanel) return;
        
        const inputs = currentPanel.querySelectorAll('input[type="radio"], input[type="text"], textarea');
        
        inputs.forEach(input => {
            if (input.type === 'radio') {
                input.checked = false;
            } else {
                input.value = '';
            }
        });
        
        this.saveProgress(true);
        this.updateQuestionStatus(this.currentQuestion, false);
    }
    
    // In the saveProgress method - add more detailed logging
async saveProgress(showToast = false) {
    if (this.isSaving) {
        console.log('Save already in progress, skipping...');
        return false;
    }
    
    this.isSaving = true;
    console.log('Starting save process...');
    
    try {
        // Collect all answers
        const answers = {};
        let answerCount = 0;
        
        document.querySelectorAll('.question-panel').forEach(panel => {
            const questionId = panel.getAttribute('data-question-id');
            
            // Check radio buttons
            const checkedRadio = panel.querySelector('input[type="radio"]:checked');
            if (checkedRadio) {
                answers[questionId] = checkedRadio.value;
                answerCount++;
                console.log(`Radio answer - Q${questionId}: ${checkedRadio.value}`);
            }
            
            // Check textareas
            const textarea = panel.querySelector('textarea');
            if (textarea && textarea.value.trim()) {
                answers[questionId] = textarea.value;
                answerCount++;
                console.log(`Text answer - Q${questionId}: ${textarea.value.substring(0, 50)}...`);
            }
        });
        
        console.log(`Collected ${answerCount} answers for ${Object.keys(answers).length} questions`);
        console.log('Answers object:', answers);
        
        const formData = new FormData();
        formData.append('save_progress', '1');
        formData.append('attempt_id', this.attemptId.toString());
        formData.append('exam_id', this.examId.toString());
        formData.append('answers', JSON.stringify(answers));
        
        console.log('Sending request to process_exam.php...');
        
        const response = await fetch('../process/process_exam.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        console.log('Save response:', result);
        
        if (result.success) {
            this.updateQuestionStatuses(answers);
            this.updateProgress();
            
            if (showToast) {
                this.showToast(`Progress saved! ${result.saved_count} answers updated.`, 'success');
            }
            this.isSaving = false;
            return true;
        } else {
            console.error('Save error:', result.message);
            if (showToast) {
                this.showToast('Error: ' + result.message, 'error');
            }
            this.isSaving = false;
            return false;
        }
    } catch (error) {
        console.error('Save error:', error);
        if (showToast) {
            this.showToast('Network error: ' + error.message, 'error');
        }
        this.isSaving = false;
        return false;
    }
}
    
    updateQuestionStatuses(answers) {
        Object.keys(answers).forEach(questionId => {
            // Find the question number from the question ID
            const questionPanel = document.querySelector(`[data-question-id="${questionId}"]`);
            if (questionPanel) {
                const questionNum = parseInt(questionPanel.id.split('-')[1]);
                this.updateQuestionStatus(questionNum, true);
            }
        });
    }
    
    updateQuestionStatus(questionNum, isAnswered) {
        const navBtn = document.querySelector(`[data-question="${questionNum}"]`);
        if (navBtn) {
            if (isAnswered) {
                navBtn.classList.remove('btn-outline-primary');
                navBtn.classList.add('btn-success');
            } else {
                navBtn.classList.remove('btn-success');
                navBtn.classList.add('btn-outline-primary');
            }
        }
    }
    
    updateProgress() {
        const answeredCount = document.querySelectorAll('.question-nav-btn.btn-success').length;
        const answeredCountElement = document.getElementById('answeredCount');
        if (answeredCountElement) {
            answeredCountElement.textContent = answeredCount;
        }
        
        // Update progress bar
        const progressPercentage = Math.round((answeredCount / this.totalQuestions) * 100);
        const progressBar = document.querySelector('.progress-bar');
        if (progressBar) {
            progressBar.style.width = `${progressPercentage}%`;
        }
        
        console.log(`Progress updated: ${answeredCount}/${this.totalQuestions} (${progressPercentage}%)`);
    }
    
    updateSubmitModal() {
        const answeredCount = document.querySelectorAll('.question-nav-btn.btn-success').length;
        const answeredCountElement = document.getElementById('answeredCount');
        if (answeredCountElement) {
            answeredCountElement.textContent = answeredCount;
        }
        
        const timeRemaining = document.getElementById('examTimer').textContent;
        const timeRemainingDisplay = document.getElementById('timeRemainingDisplay');
        if (timeRemainingDisplay) {
            timeRemainingDisplay.textContent = timeRemaining;
        }
    }
    
    showToast(message, type = 'info') {
        const toastElement = document.getElementById('autoSaveToast');
        const toastMessageElement = document.getElementById('toastMessage');
        
        if (!toastElement || !toastMessageElement) {
            console.log('Toast elements not found');
            return;
        }
        
        toastMessageElement.textContent = message;
        
        // Update icon based on type
        const toastIcon = toastElement.querySelector('.toast-header i');
        if (toastIcon) {
            switch(type) {
                case 'success':
                    toastIcon.className = 'fas fa-check text-success me-2';
                    break;
                case 'error':
                    toastIcon.className = 'fas fa-exclamation-triangle text-danger me-2';
                    break;
                default:
                    toastIcon.className = 'fas fa-save text-primary me-2';
            }
        }
        
        const toast = new bootstrap.Toast(toastElement);
        toast.show();
    }
    
    autoSubmit() {
        if (confirm('Time\'s up! Your exam will be automatically submitted.')) {
            document.getElementById('examForm').submit();
        } else {
            document.getElementById('examForm').submit();
        }
    }
    
    hasUnsavedChanges() {
        // Check if there are any answers that haven't been saved
        const hasRadioAnswers = document.querySelectorAll('input[type="radio"]:checked').length > 0;
        const hasTextAnswers = Array.from(document.querySelectorAll('textarea[name^="answer"]'))
            .some(textarea => textarea.value.trim() !== '');
        
        return hasRadioAnswers || hasTextAnswers;
    }
    
    // Debug methods
    debugSave() {
        console.log('=== DEBUG SAVE ===');
        console.log('Attempt ID:', this.attemptId);
        console.log('Exam ID:', this.examId);
        console.log('Is Saving:', this.isSaving);
        
        const answers = {};
        
        // Collect radio button answers
        document.querySelectorAll('input[type="radio"]:checked').forEach(input => {
            const match = input.name.match(/answer\[(\d+)\]/);
            if (match) {
                answers[match[1]] = input.value;
            }
        });
        
        // Collect textarea answers
        document.querySelectorAll('textarea[name^="answer"]').forEach(textarea => {
            const match = textarea.name.match(/answer\[(\d+)\]/);
            if (match) {
                answers[match[1]] = textarea.value;
            }
        });
        
        console.log('Answers to save:', answers);
        console.log('Answers JSON:', JSON.stringify(answers));
        console.log('==================');
        
        this.showToast('Check console for debug info', 'info');
    }
}

// Initialize exam manager when page loads
document.addEventListener('DOMContentLoaded', function() {
    window.examManager = new ExamManager();
    
    // Add answer change listeners to update question status
    document.querySelectorAll('input[type="radio"], textarea').forEach(element => {
        element.addEventListener('change', function() {
            const questionPanel = this.closest('.question-panel');
            if (questionPanel) {
                const questionNum = parseInt(questionPanel.id.split('-')[1]);
                const isAnswered = this.type === 'radio' ? this.checked : this.value.trim() !== '';
                
                window.examManager.updateQuestionStatus(questionNum, isAnswered);
            }
        });
    });
    
    console.log('Exam page loaded successfully');
});
</script>

<style>
.question-panel {
    display: none;
}

.question-panel.active {
    display: block;
}

.questions-nav {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 5px;
}

.question-nav-btn {
    width: 100%;
    font-size: 0.8rem;
    padding: 0.25rem 0.5rem;
}

.question-nav-btn.active {
    border-width: 2px;
    font-weight: bold;
}

.answer-textarea {
    resize: vertical;
    min-height: 100px;
}

.options-list .form-check {
    padding: 0.75rem;
    border: 1px solid #e9ecef;
    border-radius: 0.375rem;
    transition: all 0.2s ease;
}

.options-list .form-check:hover {
    background-color: #f8f9fa;
    border-color: #007bff;
}

.options-list .form-check-input:checked ~ .form-check-label {
    font-weight: bold;
    color: #007bff;
}

.toast {
    background-color: white;
    border: 1px solid #e9ecef;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.progress {
    background-color: #e9ecef;
}

.progress-bar {
    transition: width 0.3s ease;
}

.btn {
    border-radius: 0.375rem;
}

.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
}

.question-header {
    border-bottom: 2px solid #f8f9fa;
    padding-bottom: 1rem;
}

.answer-section {
    padding: 1rem 0;
}

@media (max-width: 768px) {
    .questions-nav {
        grid-template-columns: repeat(3, 1fr);
    }
    
    .btn-group {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .btn-group .btn {
        margin: 0 !important;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?>