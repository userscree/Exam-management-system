<?php
require_once '../config.php';

if (!isLoggedIn()) {
    die("Please login first");
}

$attempt_id = 12; // Replace with your actual attempt ID

try {
    // Get attempt details
    $stmt = $pdo->prepare("
        SELECT ea.*, e.title, e.total_marks, e.passing_marks 
        FROM exam_attempts ea 
        JOIN exams e ON ea.exam_id = e.id 
        WHERE ea.id = ? AND ea.student_id = ?
    ");
    $stmt->execute([$attempt_id, $_SESSION['user_id']]);
    $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$attempt) {
        die("Attempt not found");
    }
    
    echo "<h3>Debug Results for Attempt {$attempt_id}</h3>";
    echo "<p>Exam: {$attempt['title']}</p>";
    
    // Get all questions and answers
    $stmt = $pdo->prepare("
        SELECT 
            q.id,
            q.question_text,
            q.question_type,
            q.correct_answer,
            q.marks as max_marks,
            sa.student_answer,
            sa.awarded_marks,
            sa.is_correct
        FROM questions q
        LEFT JOIN student_answers sa ON q.id = sa.question_id AND sa.attempt_id = ?
        WHERE q.exam_id = ?
        ORDER BY q.id
    ");
    $stmt->execute([$attempt_id, $attempt['exam_id']]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='width:100%'>";
    echo "<tr>
            <th>Q ID</th>
            <th>Type</th>
            <th>Question</th>
            <th>Student Answer</th>
            <th>Correct Answer</th>
            <th>Match</th>
            <th>Max Marks</th>
            <th>Awarded</th>
            <th>Is Correct</th>
        </tr>";
    
    $total_obtained = 0;
    $total_max_marks = 0;
    
    foreach ($questions as $q) {
        $student_ans = strtoupper(trim($q['student_answer'] ?? ''));
        $correct_ans = strtoupper(trim($q['correct_answer'] ?? ''));
        $matches = ($student_ans == $correct_ans) ? 'YES' : 'NO';
        
        $total_obtained += $q['awarded_marks'] ?? 0;
        $total_max_marks += $q['max_marks'];
        
        echo "<tr>
                <td>{$q['id']}</td>
                <td>{$q['question_type']}</td>
                <td>" . substr($q['question_text'], 0, 50) . "...</td>
                <td><strong>{$q['student_answer']}</strong></td>
                <td><strong>{$q['correct_answer']}</strong></td>
                <td>{$matches}</td>
                <td>{$q['max_marks']}</td>
                <td>{$q['awarded_marks']}</td>
                <td>{$q['is_correct']}</td>
              </tr>";
    }
    
    $percentage = $total_max_marks > 0 ? round(($total_obtained / $total_max_marks) * 100, 2) : 0;
    
    echo "</table>";
    
    echo "<h4>Summary:</h4>";
    echo "<p>Total Obtained: {$total_obtained}</p>";
    echo "<p>Total Maximum: {$total_max_marks}</p>";
    echo "<p>Percentage: {$percentage}%</p>";
    echo "<p>Grade: " . calculateGrade($percentage) . "</p>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

function calculateGrade($percentage) {
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B';
    if ($percentage >= 60) return 'C';
    if ($percentage >= 50) return 'D';
    return 'F';
}
?>