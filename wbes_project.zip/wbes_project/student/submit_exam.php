<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Exam Submission';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];

// Handle exam submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_exam'])) {
    $attempt_id = isset($_POST['attempt_id']) ? intval($_POST['attempt_id']) : 0;
    $exam_id = isset($_POST['exam_id']) ? intval($_POST['exam_id']) : 0;
    
    if ($attempt_id <= 0 || $exam_id <= 0) {
        setFlash('error', 'Invalid exam submission data.');
        redirect('take_exam.php');
    }
    
    // Verify the attempt belongs to the student
    try {
        $stmt = $pdo->prepare("
            SELECT ea.*, e.title, e.total_marks, e.passing_marks, e.show_results_immediately, e.allow_retake
            FROM exam_attempts ea
            JOIN exams e ON ea.exam_id = e.id
            WHERE ea.id = ? AND ea.student_id = ? AND ea.status = 'in_progress'
        ");
        $stmt->execute([$attempt_id, $student_id]);
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attempt) {
            setFlash('error', 'Invalid exam attempt or exam already submitted.');
            redirect('take_exam.php');
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error verifying exam attempt: ' . $e->getMessage());
        redirect('take_exam.php');
    }
    
    // Process submission
    try {
        $pdo->beginTransaction();
        
        // Update attempt status
        $stmt = $pdo->prepare("
            UPDATE exam_attempts 
            SET status = 'submitted', submitted_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$attempt_id]);
        
        // Save answers if provided
        if (isset($_POST['answers']) && is_array($_POST['answers'])) {
            foreach ($_POST['answers'] as $question_id => $answer) {
                $question_id = intval($question_id);
                $student_answer = sanitize($answer);
                
                if (!empty($student_answer)) {
                    $stmt = $pdo->prepare("
                        INSERT INTO student_answers (attempt_id, question_id, student_answer, created_at)
                        VALUES (?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE student_answer = ?, created_at = NOW()
                    ");
                    $stmt->execute([$attempt_id, $question_id, $student_answer, $student_answer]);
                }
            }
        }
        
        // Calculate results
        $result = calculateExamResults($pdo, $attempt_id, $exam_id, $student_id);
        
        if ($result) {
            $pdo->commit();
            
            // Log activity
            $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $student_id,
                'exam_submitted',
                'Submitted exam: ' . $attempt['title'],
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);
            
            setFlash('success', 'Exam submitted successfully! ' . ($attempt['show_results_immediately'] ? 'Your results are available below.' : 'Your results will be available after grading.'));
            
            // Redirect to show results if immediate results are enabled
            if ($attempt['show_results_immediately']) {
                redirect('submit_exam.php?attempt_id=' . $attempt_id . '&results=1');
            } else {
                redirect('submit_exam.php?attempt_id=' . $attempt_id);
            }
            
        } else {
            $pdo->rollBack();
            setFlash('error', 'Error calculating exam results.');
        }
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        setFlash('error', 'Error submitting exam: ' . $e->getMessage());
    }
}

// Display results if requested
$attempt_id = isset($_GET['attempt_id']) ? intval($_GET['attempt_id']) : 0;
$show_results = isset($_GET['results']) && $_GET['results'] == 1;

if ($attempt_id > 0) {
    try {
        // Get attempt and result details
        $stmt = $pdo->prepare("
            SELECT 
                ea.*, 
                e.title as exam_title, 
                e.exam_type,
                e.total_marks as exam_total_marks,
                e.passing_marks,
                e.show_results_immediately,
                e.allow_retake,
                c.course_code, 
                c.course_name,
                r.obtained_marks,
                r.percentage,
                r.grade,
                r.status as result_status,
                r.finalized_at
            FROM exam_attempts ea
            JOIN exams e ON ea.exam_id = e.id
            JOIN courses c ON e.course_id = c.id
            LEFT JOIN results r ON ea.id = r.attempt_id
            WHERE ea.id = ? AND ea.student_id = ?
        ");
        $stmt->execute([$attempt_id, $student_id]);
        $submission = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$submission) {
            setFlash('error', 'Submission not found.');
            redirect('take_exam.php');
        }
        
        // Get detailed results if available
        if ($submission['obtained_marks'] !== null) {
            $stmt = $pdo->prepare("
                SELECT 
                    q.*,
                    sa.student_answer,
                    sa.awarded_marks,
                    sa.feedback,
                    sa.is_correct
                FROM questions q
                LEFT JOIN student_answers sa ON q.id = sa.question_id AND sa.attempt_id = ?
                WHERE q.exam_id = ?
                ORDER BY q.question_order ASC, q.id ASC
            ");
            $stmt->execute([$attempt_id, $submission['exam_id']]);
            $question_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Check retake eligibility
        $can_retake = false;
        $retake_message = '';
        
        if ($submission['status'] == 'submitted' && $submission['obtained_marks'] !== null) {
            // Count previous attempts (excluding current one)
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as previous_attempts 
                FROM exam_attempts 
                WHERE exam_id = ? AND student_id = ? AND id != ? AND status IN ('submitted', 'graded', 'time_up')
            ");
            $stmt->execute([$submission['exam_id'], $student_id, $attempt_id]);
            $previous_attempts = $stmt->fetch(PDO::FETCH_ASSOC)['previous_attempts'];
            
            // Determine retake eligibility
            if ($submission['result_status'] == 'fail') {
                $can_retake = true;
                $retake_message = 'You can retake this exam since you did not pass.';
            } elseif ($submission['allow_retake']) {
                // Check if we haven't exceeded reasonable retake limits
                if ($previous_attempts < 3) { // Allow up to 3 retakes
                    $can_retake = true;
                    $retake_message = 'Retakes are allowed for this exam.';
                } else {
                    $retake_message = 'Maximum retake limit reached for this exam.';
                }
            } else {
                $retake_message = 'Retakes are not allowed for this exam.';
            }
        }
        
    } catch(PDOException $e) {
        setFlash('error', 'Error fetching submission details: ' . $e->getMessage());
        $submission = null;
        $question_results = [];
        $can_retake = false;
        $retake_message = '';
    }
} else {
    setFlash('error', 'No submission specified.');
    redirect('take_exam.php');
}

// Function to calculate exam results
function calculateExamResults($pdo, $attempt_id, $exam_id, $student_id) {
    try {
        // Get exam details including passing marks
        $stmt = $pdo->prepare("SELECT total_marks, passing_marks FROM exams WHERE id = ?");
        $stmt->execute([$exam_id]);
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$exam) {
            return false;
        }
        
        // Get all questions for the exam
        $stmt = $pdo->prepare("
            SELECT id, question_type, correct_answer, marks 
            FROM questions 
            WHERE exam_id = ?
        ");
        $stmt->execute([$exam_id]);
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get student answers
        $stmt = $pdo->prepare("
            SELECT question_id, student_answer 
            FROM student_answers 
            WHERE attempt_id = ?
        ");
        $stmt->execute([$attempt_id]);
        $student_answers = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        $total_obtained = 0;
        $total_marks = $exam['total_marks'];
        
        // Calculate marks for each question
        foreach ($questions as $question) {
            $student_answer = $student_answers[$question['id']] ?? '';
            
            if (!empty($student_answer)) {
                $is_correct = false;
                $awarded_marks = 0;
                
                switch ($question['question_type']) {
                    case 'multiple_choice':
                    case 'true_false':
                        if (strtoupper(trim($student_answer)) == strtoupper(trim($question['correct_answer']))) {
                            $is_correct = true;
                            $awarded_marks = $question['marks'];
                        }
                        break;
                        
                    case 'short_answer':
                        // For short answer, do basic comparison (case insensitive, trim spaces)
                        if (strtolower(trim($student_answer)) == strtolower(trim($question['correct_answer']))) {
                            $is_correct = true;
                            $awarded_marks = $question['marks'];
                        }
                        break;
                        
                    case 'essay':
                        // Essay questions need manual grading - award 0 initially
                        $awarded_marks = 0;
                        $is_correct = null;
                        break;
                }
                
                // Update student answer with calculated marks
                $stmt = $pdo->prepare("
                    UPDATE student_answers 
                    SET is_correct = ?, awarded_marks = ?
                    WHERE attempt_id = ? AND question_id = ?
                ");
                $stmt->execute([$is_correct, $awarded_marks, $attempt_id, $question['id']]);
                
                $total_obtained += $awarded_marks;
            }
        }
        
        // Calculate percentage and grade
        $percentage = $total_marks > 0 ? round(($total_obtained / $total_marks) * 100, 2) : 0;
        $grade = calculateGrade($percentage);
        $status = $total_obtained >= $exam['passing_marks'] ? 'pass' : 'fail';
        
        // Insert or update results
        $stmt = $pdo->prepare("
            INSERT INTO results (attempt_id, student_id, exam_id, total_marks, obtained_marks, percentage, grade, status, finalized_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE 
                obtained_marks = ?, percentage = ?, grade = ?, status = ?, finalized_at = NOW()
        ");
        $stmt->execute([
            $attempt_id, $student_id, $exam_id, $total_marks, $total_obtained, $percentage, $grade, $status,
            $total_obtained, $percentage, $grade, $status
        ]);
        
        return true;
        
    } catch(PDOException $e) {
        error_log("Error calculating exam results: " . $e->getMessage());
        return false;
    }
}

// Function to calculate grade based on percentage
function calculateGrade($percentage) {
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B';
    if ($percentage >= 60) return 'C';
    if ($percentage >= 50) return 'D';
    return 'F';
}
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Submission Header -->
        <div class="card mb-4">
            <div class="card-header bg-<?php echo $submission['status'] == 'submitted' ? 'success' : 'primary'; ?> text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="card-title mb-0">
                            <i class="fas fa-check-circle me-2"></i>
                            Exam Submission 
                            <?php if($submission['status'] == 'submitted'): ?>
                                - Completed
                            <?php else: ?>
                                - In Progress
                            <?php endif; ?>
                        </h4>
                        <small class="opacity-75"><?php echo htmlspecialchars($submission['exam_title']); ?></small>
                    </div>
                    <div class="text-end">
                        <div class="h5 mb-0"><?php echo formatDate($submission['submitted_at'] ?? date('Y-m-d H:i:s')); ?></div>
                        <small class="opacity-75">Submitted</small>
                    </div>
                </div>
            </div>
        </div>

        <?php if($submission['status'] == 'submitted' && $submission['obtained_marks'] !== null): ?>
            <!-- Results Summary -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0 text-primary">
                        <i class="fas fa-chart-line me-2"></i> Exam Results
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <!-- Overall Score -->
                        <div class="col-md-3 mb-3">
                            <div class="border rounded p-3">
                                <div class="h2 text-primary mb-1"><?php echo $submission['percentage']; ?>%</div>
                                <div class="text-muted">Overall Score</div>
                                <div class="progress mt-2" style="height: 8px;">
                                    <div class="progress-bar bg-primary" style="width: <?php echo $submission['percentage']; ?>%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Marks Obtained -->
                        <div class="col-md-3 mb-3">
                            <div class="border rounded p-3">
                                <div class="h2 text-success mb-1"><?php echo $submission['obtained_marks']; ?>/<?php echo $submission['exam_total_marks']; ?></div>
                                <div class="text-muted">Marks Obtained</div>
                                <small class="text-success">
                                    <i class="fas fa-star me-1"></i>
                                    <?php echo $submission['obtained_marks']; ?> points
                                </small>
                            </div>
                        </div>
                        
                        <!-- Grade -->
                        <div class="col-md-3 mb-3">
                            <div class="border rounded p-3">
                                <div class="h2 text-<?php echo $submission['result_status'] == 'pass' ? 'success' : 'danger'; ?> mb-1">
                                    <?php echo $submission['grade']; ?>
                                </div>
                                <div class="text-muted">Grade</div>
                                <span class="badge bg-<?php echo $submission['result_status'] == 'pass' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($submission['result_status']); ?>
                                </span>
                            </div>
                        </div>
                        
                        <!-- Passing Status -->
                        <div class="col-md-3 mb-3">
                            <div class="border rounded p-3">
                                <div class="h2 text-<?php echo $submission['result_status'] == 'pass' ? 'success' : 'danger'; ?> mb-1">
                                    <i class="fas fa-<?php echo $submission['result_status'] == 'pass' ? 'check' : 'times'; ?>"></i>
                                </div>
                                <div class="text-muted">Status</div>
                                <div class="fw-bold text-<?php echo $submission['result_status'] == 'pass' ? 'success' : 'danger'; ?>">
                                    <?php echo $submission['result_status'] == 'pass' ? 'PASSED' : 'FAILED'; ?>
                                </div>
                                <small class="text-muted">
                                    Required: <?php echo $submission['passing_marks']; ?> marks
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Performance Message -->
                    <div class="text-center mt-3">
                        <?php if($submission['percentage'] >= 90): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-trophy me-2"></i>
                                <strong>Excellent work!</strong> You have demonstrated outstanding understanding of the material.
                            </div>
                        <?php elseif($submission['percentage'] >= 80): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-star me-2"></i>
                                <strong>Great job!</strong> You have shown strong knowledge of the subject.
                            </div>
                        <?php elseif($submission['percentage'] >= 70): ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-thumbs-up me-2"></i>
                                <strong>Good effort!</strong> You have a solid understanding of the basics.
                            </div>
                        <?php elseif($submission['result_status'] == 'pass'): ?>
                            <div class="alert alert-primary">
                                <i class="fas fa-check me-2"></i>
                                <strong>You passed!</strong> Consider reviewing areas for improvement.
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-book me-2"></i>
                                <strong>Keep studying!</strong> Review the material and try again.
                                <?php if($can_retake): ?>
                                    <br><small>You can retake this exam to improve your score.</small>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Detailed Question Results -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0 text-primary">
                        <i class="fas fa-list-ol me-2"></i> Question-wise Results
                    </h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach($question_results as $index => $question): 
                            $question_number = $index + 1;
                            $is_correct = $question['is_correct'];
                            $awarded_marks = $question['awarded_marks'] ?? 0;
                            $max_marks = $question['marks'];
                            
                            // Determine status and styling
                            if ($question['question_type'] == 'essay') {
                                $status_class = 'warning';
                                $status_text = 'Needs Grading';
                                $status_icon = 'clock';
                            } elseif ($is_correct) {
                                $status_class = 'success';
                                $status_text = 'Correct';
                                $status_icon = 'check';
                            } elseif ($is_correct === false) {
                                $status_class = 'danger';
                                $status_text = 'Incorrect';
                                $status_icon = 'times';
                            } else {
                                $status_class = 'secondary';
                                $status_text = 'Not Answered';
                                $status_icon = 'minus';
                            }
                        ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-primary me-2">Q<?php echo $question_number; ?></span>
                                            <span class="badge bg-<?php echo $status_class; ?> me-2">
                                                <i class="fas fa-<?php echo $status_icon; ?> me-1"></i>
                                                <?php echo $status_text; ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <i class="fas fa-star text-warning me-1"></i>
                                                <?php echo $awarded_marks; ?>/<?php echo $max_marks; ?>
                                            </span>
                                        </div>
                                        
                                        <h6 class="mb-2"><?php echo htmlspecialchars($question['question_text']); ?></h6>
                                        
                                        <!-- Student Answer -->
                                        <div class="mb-2">
                                            <small class="text-muted">Your Answer:</small>
                                            <div class="border rounded p-2 bg-light">
                                                <?php if(!empty($question['student_answer'])): ?>
                                                    <?php echo htmlspecialchars($question['student_answer']); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">No answer provided</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <!-- Correct Answer (for objective questions) -->
                                        <?php if(in_array($question['question_type'], ['multiple_choice', 'true_false', 'short_answer']) && $is_correct === false): ?>
                                            <div class="mb-2">
                                                <small class="text-muted">Correct Answer:</small>
                                                <div class="border rounded p-2 bg-success bg-opacity-10">
                                                    <?php echo htmlspecialchars($question['correct_answer']); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <!-- Feedback -->
                                        <?php if(!empty($question['feedback'])): ?>
                                            <div class="mb-2">
                                                <small class="text-muted">Instructor Feedback:</small>
                                                <div class="border rounded p-2 bg-info bg-opacity-10">
                                                    <i class="fas fa-comment text-info me-1"></i>
                                                    <?php echo htmlspecialchars($question['feedback']); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <!-- Explanation -->
                                        <?php if(!empty($question['explanation'])): ?>
                                            <div class="mt-2">
                                                <small class="text-muted">Explanation:</small>
                                                <div class="border rounded p-2 bg-warning bg-opacity-10">
                                                    <i class="fas fa-lightbulb text-warning me-1"></i>
                                                    <?php echo htmlspecialchars($question['explanation']); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
        <?php elseif($submission['status'] == 'submitted'): ?>
            <!-- Waiting for Results -->
            <div class="card mb-4">
                <div class="card-body text-center py-5">
                    <i class="fas fa-clock fa-3x text-warning mb-3"></i>
                    <h4 class="text-warning">Results Pending</h4>
                    <p class="text-muted mb-3">
                        Your exam has been submitted successfully. 
                        <?php if($submission['show_results_immediately']): ?>
                            Results are being calculated and will be available shortly.
                        <?php else: ?>
                            Your results will be available after manual grading by your instructor.
                        <?php endif; ?>
                    </p>
                    <div class="spinner-border text-warning mb-3" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        You will be notified when your results are ready. Check back later or view from "My Results" page.
                    </div>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Submission in Progress -->
            <div class="card mb-4">
                <div class="card-body text-center py-5">
                    <i class="fas fa-sync-alt fa-3x text-primary mb-3 fa-spin"></i>
                    <h4 class="text-primary">Processing Submission</h4>
                    <p class="text-muted mb-3">Please wait while we process your exam submission...</p>
                    <div class="progress mb-3" style="height: 10px;">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
                    </div>
                </div>
            </div>
            
            <script>
            // Auto-refresh to check for results
            setTimeout(() => {
                window.location.reload();
            }, 3000);
            </script>
        <?php endif; ?>

        <!-- Action Buttons -->
        <div class="card">
            <div class="card-body">
                <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                    <a href="take_exam.php" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i> Back to Available Exams
                    </a>
                    
                    <div class="btn-group">
                        <a href="my_results.php" class="btn btn-primary">
                            <i class="fas fa-chart-line me-2"></i> View All Results
                        </a>
                        
                        <?php if($submission['status'] == 'submitted' && $submission['obtained_marks'] !== null): ?>
                            <button type="button" class="btn btn-success" onclick="window.print()">
                                <i class="fas fa-print me-2"></i> Print Results
                            </button>
                            
                            <?php if($can_retake): ?>
                                <a href="../process/process_retake.php?exam_id=<?php echo $submission['exam_id']; ?>" 
                                   class="btn btn-warning" 
                                   onclick="return confirm('Are you sure you want to retake this exam? This will start a new attempt and your previous results will be preserved.');">
                                    <i class="fas fa-redo me-2"></i> Retake Exam
                                </a>
                            <?php else: ?>
                                <button type="button" class="btn btn-outline-secondary" disabled title="<?php echo htmlspecialchars($retake_message); ?>">
                                    <i class="fas fa-redo me-2"></i> Retake Not Available
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Retake Information -->
                <?php if($submission['status'] == 'submitted' && $submission['obtained_marks'] !== null && !empty($retake_message)): ?>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            <?php echo $retake_message; ?>
                        </small>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Exam Statistics (if results available) -->
        <?php if($submission['status'] == 'submitted' && $submission['obtained_marks'] !== null && !empty($question_results)): 
            $correct_count = 0;
            $incorrect_count = 0;
            $ungraded_count = 0;
            $unanswered_count = 0;
            
            foreach($question_results as $question) {
                if ($question['is_correct'] === true) {
                    $correct_count++;
                } elseif ($question['is_correct'] === false) {
                    $incorrect_count++;
                } elseif ($question['question_type'] == 'essay' && $question['awarded_marks'] === null) {
                    $ungraded_count++;
                } elseif (empty($question['student_answer'])) {
                    $unanswered_count++;
                }
            }
        ?>
            <div class="card mt-4">
                <div class="card-header bg-light">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-chart-pie me-2"></i> Performance Statistics
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-2 col-6 mb-3">
                            <div class="h4 text-success"><?php echo $correct_count; ?></div>
                            <small class="text-muted">Correct</small>
                            <div class="progress mt-1" style="height: 4px;">
                                <div class="progress-bar bg-success" style="width: <?php echo ($correct_count / count($question_results)) * 100; ?>%"></div>
                            </div>
                        </div>
                        <div class="col-md-2 col-6 mb-3">
                            <div class="h4 text-danger"><?php echo $incorrect_count; ?></div>
                            <small class="text-muted">Incorrect</small>
                            <div class="progress mt-1" style="height: 4px;">
                                <div class="progress-bar bg-danger" style="width: <?php echo ($incorrect_count / count($question_results)) * 100; ?>%"></div>
                            </div>
                        </div>
                        <div class="col-md-2 col-6 mb-3">
                            <div class="h4 text-warning"><?php echo $ungraded_count; ?></div>
                            <small class="text-muted">Ungraded</small>
                            <div class="progress mt-1" style="height: 4px;">
                                <div class="progress-bar bg-warning" style="width: <?php echo ($ungraded_count / count($question_results)) * 100; ?>%"></div>
                            </div>
                        </div>
                        <div class="col-md-2 col-6 mb-3">
                            <div class="h4 text-secondary"><?php echo $unanswered_count; ?></div>
                            <small class="text-muted">Unanswered</small>
                            <div class="progress mt-1" style="height: 4px;">
                                <div class="progress-bar bg-secondary" style="width: <?php echo ($unanswered_count / count($question_results)) * 100; ?>%"></div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="h4 text-primary"><?php echo count($question_results); ?></div>
                            <small class="text-muted">Total Questions</small>
                            <div class="small text-muted">
                                Accuracy: <?php echo ($correct_count + $incorrect_count) > 0 ? round(($correct_count / ($correct_count + $incorrect_count)) * 100, 1) : 0; ?>%
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Print Styles -->
<style>
@media print {
    .btn, .card-header, .alert, .progress {
        display: none !important;
    }
    
    .card {
        border: 1px solid #000 !important;
        box-shadow: none !important;
    }
    
    .text-primary {
        color: #000 !important;
    }
    
    .badge {
        border: 1px solid #000 !important;
        background: white !important;
        color: #000 !important;
    }
    
    .list-group-item {
        border: 1px solid #000 !important;
        margin-bottom: 10px !important;
    }
}

/* Animation styles */
.card {
    transition: all 0.3s ease;
}

.badge {
    font-size: 0.75em;
}

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

.alert {
    border: none;
    border-radius: 0.5rem;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add animation to result cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Auto-scroll to results if they just became available
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('results') && urlParams.get('results') == '1') {
        setTimeout(() => {
            const resultsCard = document.querySelector('.card .card-header.bg-white');
            if (resultsCard) {
                resultsCard.scrollIntoView({ behavior: 'smooth' });
            }
        }, 500);
    }
    
    // Share results functionality
    function shareResults() {
        if (navigator.share) {
            navigator.share({
                title: 'My Exam Results - <?php echo htmlspecialchars($submission['exam_title']); ?>',
                text: `I scored <?php echo $submission['percentage']; ?>% on <?php echo htmlspecialchars($submission['exam_title']); ?>!`,
                url: window.location.href
            });
        } else {
            // Fallback: copy to clipboard
            const resultText = `Exam: <?php echo htmlspecialchars($submission['exam_title']); ?>

Score: <?php echo $submission['percentage']; ?>%
Grade: <?php echo $submission['grade']; ?>
Status: <?php echo ucfirst($submission['result_status']); ?>

Marks: <?php echo $submission['obtained_marks']; ?>/<?php echo $submission['exam_total_marks']; ?>`;
            
            navigator.clipboard.writeText(resultText).then(() => {
                alert('Results copied to clipboard!');
            });
        }
    }
    
    // Add share button if supported
    if (navigator.share || navigator.clipboard) {
        const actionButtons = document.querySelector('.btn-group');
        if (actionButtons) {
            const shareBtn = document.createElement('button');
            shareBtn.className = 'btn btn-info';
            shareBtn.innerHTML = '<i class="fas fa-share me-2"></i> Share Results';
            shareBtn.onclick = shareResults;
            actionButtons.appendChild(shareBtn);
        }
    }
    
    // Add retake confirmation with more info
    const retakeButtons = document.querySelectorAll('a[href*="process_retake"]');
    retakeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Starting a retake will create a new exam attempt. Your previous results will be preserved.\n\nAre you sure you want to continue?')) {
                e.preventDefault();
            }
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>