<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Result Details';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$attempt_id = isset($_GET['attempt_id']) ? intval($_GET['attempt_id']) : 0;

if ($attempt_id <= 0) {
    setFlash('error', 'Invalid result specified.');
    redirect('my_results.php');
}

// Get detailed result information
try {
    // Get attempt and result details
    $stmt = $pdo->prepare("
        SELECT 
            ea.*,
            e.title as exam_title,
            e.exam_type,
            e.total_marks as exam_total_marks,
            e.passing_marks,
            e.duration_minutes,
            e.show_results_immediately,
            c.course_code, 
            c.course_name,
            r.obtained_marks,
            r.percentage,
            r.grade,
            r.status as result_status,
            r.finalized_at,
            u.first_name,
            u.last_name,
            u.username
        FROM exam_attempts ea
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        JOIN users u ON ea.student_id = u.id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE ea.id = ? AND ea.student_id = ?
    ");
    $stmt->execute([$attempt_id, $student_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$result) {
        setFlash('error', 'Result not found or you do not have permission to view it.');
        redirect('my_results.php');
    }
    
    // Get detailed question results
    $stmt = $pdo->prepare("
        SELECT 
            q.*,
            sa.student_answer,
            sa.awarded_marks,
            sa.feedback,
            sa.is_correct,
            sa.graded_at,
            grader.first_name as grader_first_name,
            grader.last_name as grader_last_name
        FROM questions q
        LEFT JOIN student_answers sa ON q.id = sa.question_id AND sa.attempt_id = ?
        LEFT JOIN users grader ON sa.graded_by = grader.id
        WHERE q.exam_id = ?
        ORDER BY q.question_order ASC, q.id ASC
    ");
    $stmt->execute([$attempt_id, $result['exam_id']]);
    $question_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate statistics
    $total_questions = count($question_results);
    $correct_count = 0;
    $incorrect_count = 0;
    $ungraded_count = 0;
    $unanswered_count = 0;
    $total_possible_marks = 0;
    $total_awarded_marks = 0;
    
    foreach ($question_results as $question) {
        $total_possible_marks += $question['marks'];
        $total_awarded_marks += $question['awarded_marks'] ?? 0;
        
        if ($question['question_type'] == 'essay' && ($question['awarded_marks'] === null || $question['graded_by'] === null)) {
            $ungraded_count++;
        } elseif (empty($question['student_answer'])) {
            $unanswered_count++;
        } elseif ($question['is_correct'] === true) {
            $correct_count++;
        } elseif ($question['is_correct'] === false) {
            $incorrect_count++;
        }
    }
    
    $accuracy = ($correct_count + $incorrect_count) > 0 ? 
        round(($correct_count / ($correct_count + $incorrect_count)) * 100, 1) : 0;
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching result details: ' . $e->getMessage());
    $result = null;
    $question_results = [];
    $total_questions = $correct_count = $incorrect_count = $ungraded_count = $unanswered_count = 0;
    $accuracy = 0;
}
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Result Header -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="card-title mb-0">
                            <i class="fas fa-chart-line me-2"></i>
                            Exam Result Details
                        </h4>
                        <small class="opacity-75"><?php echo htmlspecialchars($result['exam_title']); ?></small>
                    </div>
                    <div class="text-end">
                        <div class="h5 mb-0"><?php echo formatDate($result['finalized_at'] ?? $result['submitted_at']); ?></div>
                        <small class="opacity-75"><?php echo $result['finalized_at'] ? 'Graded' : 'Submitted'; ?></small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center border-0 bg-light">
                    <div class="card-body">
                        <div class="h2 text-primary mb-1"><?php echo $result['percentage']; ?>%</div>
                        <div class="text-muted">Overall Score</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center border-0 bg-light">
                    <div class="card-body">
                        <div class="h2 text-success mb-1"><?php echo $result['obtained_marks']; ?>/<?php echo $result['exam_total_marks']; ?></div>
                        <div class="text-muted">Marks Obtained</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center border-0 bg-light">
                    <div class="card-body">
                        <div class="h2 text-<?php echo $result['result_status'] == 'pass' ? 'success' : 'danger'; ?> mb-1">
                            <?php echo $result['grade']; ?>
                        </div>
                        <div class="text-muted">Grade</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center border-0 bg-light">
                    <div class="card-body">
                        <div class="h2 text-<?php echo $result['result_status'] == 'pass' ? 'success' : 'danger'; ?> mb-1">
                            <i class="fas fa-<?php echo $result['result_status'] == 'pass' ? 'check' : 'times'; ?>"></i>
                        </div>
                        <div class="text-muted">Status</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Left Column - Exam Information -->
            <div class="col-lg-4">
                <!-- Exam Information -->
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-info-circle me-2 text-primary"></i> Exam Information
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td class="text-muted" width="40%">Exam:</td>
                                <td><strong><?php echo htmlspecialchars($result['exam_title']); ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Course:</td>
                                <td><?php echo htmlspecialchars($result['course_code'] . ' - ' . $result['course_name']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Type:</td>
                                <td><span class="badge bg-primary"><?php echo ucfirst($result['exam_type']); ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Duration:</td>
                                <td><?php echo $result['duration_minutes']; ?> minutes</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Passing Marks:</td>
                                <td><?php echo $result['passing_marks']; ?>/<?php echo $result['exam_total_marks']; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Student Information -->
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-user me-2 text-success"></i> Student Information
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td class="text-muted" width="40%">Name:</td>
                                <td><?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Username:</td>
                                <td>@<?php echo htmlspecialchars($result['username']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Started:</td>
                                <td><?php echo formatDate($result['started_at']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Submitted:</td>
                                <td><?php echo formatDate($result['submitted_at']); ?></td>
                            </tr>
                            <?php if($result['finalized_at']): ?>
                            <tr>
                                <td class="text-muted">Graded:</td>
                                <td><?php echo formatDate($result['finalized_at']); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>

                <!-- Performance Statistics -->
                <div class="card">
                    <div class="card-header bg-white">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-chart-pie me-2 text-warning"></i> Performance Statistics
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Correct Answers</span>
                                <span><?php echo $correct_count; ?> (<?php echo round(($correct_count / $total_questions) * 100, 1); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar bg-success" style="width: <?php echo ($correct_count / $total_questions) * 100; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Incorrect Answers</span>
                                <span><?php echo $incorrect_count; ?> (<?php echo round(($incorrect_count / $total_questions) * 100, 1); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar bg-danger" style="width: <?php echo ($incorrect_count / $total_questions) * 100; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Ungraded Answers</span>
                                <span><?php echo $ungraded_count; ?> (<?php echo round(($ungraded_count / $total_questions) * 100, 1); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar bg-warning" style="width: <?php echo ($ungraded_count / $total_questions) * 100; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Unanswered</span>
                                <span><?php echo $unanswered_count; ?> (<?php echo round(($unanswered_count / $total_questions) * 100, 1); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar bg-secondary" style="width: <?php echo ($unanswered_count / $total_questions) * 100; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="text-center mt-3 p-2 border rounded bg-light">
                            <div class="h5 text-primary mb-1"><?php echo $accuracy; ?>%</div>
                            <small class="text-muted">Answer Accuracy</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column - Detailed Results -->
            <div class="col-lg-8">
                <!-- Question-wise Results -->
                <div class="card">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-list-ol me-2 text-primary"></i> Question-wise Results
                        </h6>
                        <span class="badge bg-primary"><?php echo $total_questions; ?> Questions</span>
                    </div>
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush">
                            <?php foreach($question_results as $index => $question): 
                                $question_number = $index + 1;
                                $is_correct = $question['is_correct'];
                                $awarded_marks = $question['awarded_marks'] ?? 0;
                                $max_marks = $question['marks'];
                                
                                // Determine status and styling
                                if ($question['question_type'] == 'essay' && $question['graded_by'] === null) {
                                    $status_class = 'warning';
                                    $status_text = 'Awaiting Grading';
                                    $status_icon = 'clock';
                                } elseif ($question['question_type'] == 'essay' && $question['graded_by'] !== null) {
                                    $status_class = 'info';
                                    $status_text = 'Graded';
                                    $status_icon = 'check-double';
                                } elseif ($is_correct) {
                                    $status_class = 'success';
                                    $status_text = 'Correct';
                                    $status_icon = 'check';
                                } elseif ($is_correct === false) {
                                    $status_class = 'danger';
                                    $status_text = 'Incorrect';
                                    $status_icon = 'times';
                                } else {
                                    $status_class = 'secondary';
                                    $status_text = 'Not Answered';
                                    $status_icon = 'minus';
                                }
                            ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div class="flex-grow-1">
                                            <div class="d-flex align-items-center mb-2">
                                                <span class="badge bg-primary me-2">Q<?php echo $question_number; ?></span>
                                                <span class="badge bg-<?php echo $status_class; ?> me-2">
                                                    <i class="fas fa-<?php echo $status_icon; ?> me-1"></i>
                                                    <?php echo $status_text; ?>
                                                </span>
                                                <span class="badge bg-light text-dark">
                                                    <i class="fas fa-star text-warning me-1"></i>
                                                    <?php echo $awarded_marks; ?>/<?php echo $max_marks; ?>
                                                </span>
                                                <span class="badge bg-light text-dark ms-2">
                                                    <i class="fas fa-<?php 
                                                        switch($question['question_type']) {
                                                            case 'multiple_choice': echo 'list-ol'; break;
                                                            case 'true_false': echo 'check-circle'; break;
                                                            case 'short_answer': echo 'pen'; break;
                                                            case 'essay': echo 'file-alt'; break;
                                                            default: echo 'question';
                                                        }
                                                    ?> me-1"></i>
                                                    <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?>
                                                </span>
                                            </div>
                                            
                                            <h6 class="mb-3"><?php echo htmlspecialchars($question['question_text']); ?></h6>
                                            
                                            <!-- Student Answer -->
                                            <div class="mb-3">
                                                <small class="text-muted fw-bold">Your Answer:</small>
                                                <div class="border rounded p-3 bg-light">
                                                    <?php if(!empty($question['student_answer'])): ?>
                                                        <?php echo nl2br(htmlspecialchars($question['student_answer'])); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted fst-italic">No answer provided</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <!-- Correct Answer (for objective questions) -->
                                            <?php if(in_array($question['question_type'], ['multiple_choice', 'true_false', 'short_answer']) && $is_correct === false && !empty($question['correct_answer'])): ?>
                                                <div class="mb-3">
                                                    <small class="text-muted fw-bold">Correct Answer:</small>
                                                    <div class="border rounded p-3 bg-success bg-opacity-10">
                                                        <?php echo htmlspecialchars($question['correct_answer']); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <!-- Options for multiple choice -->
                                            <?php if($question['question_type'] == 'multiple_choice'): ?>
                                                <div class="mb-3">
                                                    <small class="text-muted fw-bold">Options:</small>
                                                    <div class="border rounded p-3 bg-light">
                                                        <?php 
                                                        $options = [
                                                            'A' => $question['option_a'],
                                                            'B' => $question['option_b'],
                                                            'C' => $question['option_c'],
                                                            'D' => $question['option_d']
                                                        ];
                                                        
                                                        foreach($options as $letter => $option):
                                                            if (!empty($option)):
                                                                $is_selected = $question['student_answer'] == $letter;
                                                                $is_correct_option = $question['correct_answer'] == $letter;
                                                        ?>
                                                            <div class="form-check mb-2">
                                                                <input class="form-check-input" type="radio" 
                                                                       <?php echo $is_selected ? 'checked' : ''; ?> disabled>
                                                                <label class="form-check-label <?php echo $is_correct_option ? 'text-success fw-bold' : ($is_selected && !$is_correct_option ? 'text-danger' : ''); ?>">
                                                                    <strong><?php echo $letter; ?>.</strong> <?php echo htmlspecialchars($option); ?>
                                                                    <?php if($is_correct_option): ?>
                                                                        <i class="fas fa-check text-success ms-1"></i>
                                                                    <?php elseif($is_selected && !$is_correct_option): ?>
                                                                        <i class="fas fa-times text-danger ms-1"></i>
                                                                    <?php endif; ?>
                                                                </label>
                                                            </div>
                                                        <?php 
                                                            endif;
                                                        endforeach; 
                                                        ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <!-- Feedback -->
                                            <?php if(!empty($question['feedback'])): ?>
                                                <div class="mb-3">
                                                    <small class="text-muted fw-bold">Instructor Feedback:</small>
                                                    <div class="border rounded p-3 bg-info bg-opacity-10">
                                                        <div class="d-flex">
                                                            <i class="fas fa-comment text-info me-2 mt-1"></i>
                                                            <div>
                                                                <?php echo nl2br(htmlspecialchars($question['feedback'])); ?>
                                                                <?php if($question['grader_first_name']): ?>
                                                                    <div class="text-muted small mt-1">
                                                                        - <?php echo htmlspecialchars($question['grader_first_name'] . ' ' . $question['grader_last_name']); ?>
                                                                        <?php if($question['graded_at']): ?>
                                                                            on <?php echo formatDate($question['graded_at']); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <!-- Explanation -->
                                            <?php if(!empty($question['explanation'])): ?>
                                                <div class="mt-3">
                                                    <small class="text-muted fw-bold">Explanation:</small>
                                                    <div class="border rounded p-3 bg-warning bg-opacity-10">
                                                        <div class="d-flex">
                                                            <i class="fas fa-lightbulb text-warning me-2 mt-1"></i>
                                                            <div><?php echo nl2br(htmlspecialchars($question['explanation'])); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Performance Summary -->
                <div class="card mt-4">
                    <div class="card-header bg-white">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-chart-bar me-2 text-success"></i> Performance Summary
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-4 mb-3">
                                <div class="p-3 border rounded">
                                    <div class="h4 text-success mb-1"><?php echo $correct_count; ?></div>
                                    <small class="text-muted">Correct Answers</small>
                                    <div class="small text-success">
                                        +<?php echo $correct_count * 1; ?> points
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="p-3 border rounded">
                                    <div class="h4 text-danger mb-1"><?php echo $incorrect_count; ?></div>
                                    <small class="text-muted">Incorrect Answers</small>
                                    <div class="small text-muted">
                                        No points
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="p-3 border rounded">
                                    <div class="h4 text-warning mb-1"><?php echo $ungraded_count; ?></div>
                                    <small class="text-muted">Awaiting Grading</small>
                                    <div class="small text-warning">
                                        Potential points
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Performance Message -->
                        <div class="text-center mt-3">
                            <?php if($result['percentage'] >= 90): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-trophy me-2"></i>
                                    <strong>Outstanding Performance!</strong> You have demonstrated excellent understanding of the material.
                                </div>
                            <?php elseif($result['percentage'] >= 80): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-star me-2"></i>
                                    <strong>Excellent Work!</strong> You have shown strong knowledge and comprehension.
                                </div>
                            <?php elseif($result['percentage'] >= 70): ?>
                                <div class="alert alert-primary">
                                    <i class="fas fa-thumbs-up me-2"></i>
                                    <strong>Good Performance!</strong> You have a solid understanding of the subject.
                                </div>
                            <?php elseif($result['result_status'] == 'pass'): ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-check me-2"></i>
                                    <strong>You Passed!</strong> Consider reviewing areas where you can improve.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-book me-2"></i>
                                    <strong>Areas for Improvement</strong> Focus on the topics where you lost marks.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="card mt-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <a href="my_results.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i> Back to Results
                        </a>
                        <a href="take_exam.php" class="btn btn-outline-secondary ms-2">
                            <i class="fas fa-list me-2"></i> Available Exams
                        </a>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-success" onclick="window.print()">
                            <i class="fas fa-print me-2"></i> Print Results
                        </button>
                        <?php if($result['result_status'] == 'fail'): ?>
                            <a href="exam_instructions.php?exam_id=<?php echo $result['exam_id']; ?>" class="btn btn-warning">
                                <i class="fas fa-redo me-2"></i> Retake Exam
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Print Styles -->
<style>
@media print {
    .btn, .card-header, .alert, .progress, .badge:not(.bg-primary) {
        display: none !important;
    }
    
    .card {
        border: 1px solid #000 !important;
        box-shadow: none !important;
        margin-bottom: 1rem !important;
    }
    
    .text-primary {
        color: #000 !important;
    }
    
    .bg-light {
        background-color: #f8f9fa !important;
    }
    
    .border {
        border: 1px solid #dee2e6 !important;
    }
    
    .list-group-item {
        break-inside: avoid;
    }
    
    .col-lg-4, .col-lg-8 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

/* Custom styles for better readability */
.question-result {
    border-left: 4px solid #007bff;
    padding-left: 1rem;
    margin-bottom: 1.5rem;
}

.correct-answer {
    border-left-color: #28a745;
}

.incorrect-answer {
    border-left-color: #dc3545;
}

.ungraded-answer {
    border-left-color: #ffc107;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Add question filtering functionality
    const filterButtons = document.createElement('div');
    filterButtons.className = 'btn-group mb-3';
    filterButtons.innerHTML = `
        <button type="button" class="btn btn-outline-primary active" data-filter="all">All Questions</button>
        <button type="button" class="btn btn-outline-success" data-filter="correct">Correct</button>
        <button type="button" class="btn btn-outline-danger" data-filter="incorrect">Incorrect</button>
        <button type="button" class="btn btn-outline-warning" data-filter="ungraded">Ungraded</button>
        <button type="button" class="btn btn-outline-secondary" data-filter="unanswered">Unanswered</button>
    `;
    
    const questionsCard = document.querySelector('.col-lg-8 .card');
    if (questionsCard) {
        questionsCard.querySelector('.card-header').appendChild(filterButtons);
    }
    
    // Filter functionality
    document.querySelectorAll('[data-filter]').forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active button
            document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Filter questions
            document.querySelectorAll('.list-group-item').forEach(item => {
                let show = false;
                
                switch(filter) {
                    case 'all':
                        show = true;
                        break;
                    case 'correct':
                        show = item.querySelector('.badge.bg-success') !== null;
                        break;
                    case 'incorrect':
                        show = item.querySelector('.badge.bg-danger') !== null;
                        break;
                    case 'ungraded':
                        show = item.querySelector('.badge.bg-warning') !== null;
                        break;
                    case 'unanswered':
                        show = item.querySelector('.badge.bg-secondary') !== null;
                        break;
                }
                
                item.style.display = show ? 'block' : 'none';
            });
        });
    });
    
    // Add scroll to top functionality for long result pages
    const scrollTopBtn = document.createElement('button');
    scrollTopBtn.className = 'btn btn-primary position-fixed';
    scrollTopBtn.style.cssText = 'bottom: 20px; right: 20px; z-index: 1000; display: none;';
    scrollTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    scrollTopBtn.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
    document.body.appendChild(scrollTopBtn);
    
    window.addEventListener('scroll', () => {
        scrollTopBtn.style.display = window.scrollY > 300 ? 'block' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>