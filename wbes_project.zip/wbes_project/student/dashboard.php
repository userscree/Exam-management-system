<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Student Dashboard';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$user = getUserData();

try {
    // Get student statistics
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as enrolled_courses 
        FROM enrollments 
        WHERE student_id = ? AND status = 'active'
    ");
    $stmt->execute([$student_id]);
    $enrolled_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as completed_exams 
        FROM exam_attempts 
        WHERE student_id = ? AND status = 'graded'
    ");
    $stmt->execute([$student_id]);
    $completed_exams = $stmt->fetchColumn();
    
    // Get available exams (exams from enrolled courses that are active and within date range)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT e.id) as available_exams 
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        WHERE en.student_id = ? 
        AND e.is_active = 1 
        AND e.start_date <= NOW() 
        AND e.end_date >= NOW()
        AND e.id NOT IN (
            SELECT exam_id FROM exam_attempts 
            WHERE student_id = ? AND status IN ('submitted', 'graded')
        )
    ");
    $stmt->execute([$student_id, $student_id]);
    $available_exams = $stmt->fetchColumn();
    
    // Get upcoming exams (exams from enrolled courses that start in the future)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT e.id) as upcoming_exams 
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        WHERE en.student_id = ? 
        AND e.is_active = 1 
        AND e.start_date > NOW()
    ");
    $stmt->execute([$student_id]);
    $upcoming_exams = $stmt->fetchColumn();
    
    // Get average performance
    $stmt = $pdo->prepare("
        SELECT AVG(r.percentage) as average_score,
               COUNT(r.id) as total_graded_exams
        FROM results r
        WHERE r.student_id = ?
    ");
    $stmt->execute([$student_id]);
    $performance = $stmt->fetch(PDO::FETCH_ASSOC);
    $average_score = $performance['average_score'] ? round($performance['average_score'], 1) : 0;
    $total_graded_exams = $performance['total_graded_exams'] ?? 0;
    
    // Get recent exam results
    $stmt = $pdo->prepare("
        SELECT r.*, e.title as exam_title, e.exam_type, c.course_code, c.course_name,
               ea.submitted_at
        FROM results r
        JOIN exam_attempts ea ON r.attempt_id = ea.id
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY ea.submitted_at DESC
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $recent_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get available exams with full details
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name, c.department,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE en.student_id = ? 
        AND e.is_active = 1 
        AND e.start_date <= NOW() 
        AND e.end_date >= NOW()
        AND e.id NOT IN (
            SELECT exam_id FROM exam_attempts 
            WHERE student_id = ? AND status IN ('submitted', 'graded')
        )
        ORDER BY e.end_date ASC
        LIMIT 5
    ");
    $stmt->execute([$student_id, $student_id]);
    $available_exams_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get upcoming exams with full details
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name, c.department
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE en.student_id = ? 
        AND e.is_active = 1 
        AND e.start_date > NOW()
        ORDER BY e.start_date ASC
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $upcoming_exams_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get ongoing exams (exams that are currently available and student hasn't completed)
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name, c.department,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE en.student_id = ? 
        AND e.is_active = 1 
        AND e.start_date <= NOW() 
        AND e.end_date >= NOW()
        AND e.id NOT IN (
            SELECT exam_id FROM exam_attempts 
            WHERE student_id = ? AND status IN ('submitted', 'graded')
        )
        ORDER BY e.end_date ASC
        LIMIT 3
    ");
    $stmt->execute([$student_id, $student_id]);
    $ongoing_exams_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get enrolled courses
    $stmt = $pdo->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM exams WHERE course_id = c.id AND is_active = 1) as exam_count
        FROM courses c
        INNER JOIN enrollments en ON c.id = en.course_id
        WHERE en.student_id = ? AND en.status = 'active'
        ORDER BY c.course_code
    ");
    $stmt->execute([$student_id]);
    $enrolled_courses_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent notifications
    $stmt = $pdo->prepare("
        SELECT n.*, un.is_read, un.created_at as received_at
        FROM notifications n 
        INNER JOIN user_notifications un ON n.id = un.notification_id 
        WHERE un.user_id = ? 
        AND n.is_active = 1 
        AND (n.expires_at IS NULL OR n.expires_at > NOW())
        ORDER BY n.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Count unread notifications
    $unread_notifications = 0;
    foreach($notifications as $notification) {
        if (!$notification['is_read']) {
            $unread_notifications++;
        }
    }
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching dashboard data: ' . $e->getMessage());
    $enrolled_courses = $completed_exams = $upcoming_exams = $available_exams = 0;
    $average_score = $total_graded_exams = 0;
    $recent_results = $available_exams_list = $upcoming_exams_list = $ongoing_exams_list = $enrolled_courses_list = $notifications = [];
    $unread_notifications = 0;
}
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="card-title mb-2">Welcome back, <?php echo $user['first_name']; ?>! 👋</h4>
                        <p class="card-text mb-0">Ready to ace your next exam? Here's your learning overview.</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="d-flex align-items-center justify-content-md-end">
                            <div class="me-3">
                                <i class="fas fa-user-graduate fa-3x opacity-50"></i>
                            </div>
                            <div>
                                <h5 class="mb-0">Student</h5>
                                <small>Learning Dashboard</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Enrolled Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $enrolled_courses; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-book me-1"></i>
                                Active courses
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book-open fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Completed Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $completed_exams; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-check-circle me-1"></i>
                                Graded attempts
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Ongoing Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($ongoing_exams_list); ?></div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-play-circle me-1"></i>
                                        Available now
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-play-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Average Score
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $average_score; ?>%</div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-chart-line me-1"></i>
                                <?php echo $total_graded_exams; ?> graded exams
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- Ongoing Exams -->
        <?php if(!empty($ongoing_exams_list)): ?>
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-play-circle me-2"></i>
                    Ongoing Exams - Available Now!
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php foreach($ongoing_exams_list as $exam): 
                        $now = new DateTime();
                        $end_date = new DateTime($exam['end_date']);
                        $time_remaining = $now->diff($end_date);
                    ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="flex-grow-1">
                                    <h6 class="mb-1 text-success"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                    <p class="mb-1 small text-muted">
                                        <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?>
                                        <?php if($exam['department']): ?>
                                            <span class="badge bg-light text-dark ms-2"><?php echo htmlspecialchars($exam['department']); ?></span>
                                        <?php endif; ?>
                                    </p>
                                    <div class="d-flex gap-3">
                                        <small class="text-muted">
                                            <i class="fas fa-question-circle me-1"></i>
                                            <?php echo $exam['question_count']; ?> questions
                                        </small>
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i>
                                            <?php echo $exam['duration_minutes']; ?> mins
                                        </small>
                                        <small class="text-muted">
                                            <i class="fas fa-star me-1"></i>
                                            <?php echo $exam['total_marks']; ?> marks
                                        </small>
                                    </div>
                                </div>
                                <div class="flex-shrink-0 ms-3 text-end">
                                    <span class="badge bg-danger mb-2">
                                        <i class="fas fa-clock me-1"></i>
                                        <?php 
                                        if ($time_remaining->d > 0) {
                                            echo $time_remaining->d . ' days left';
                                        } elseif ($time_remaining->h > 0) {
                                            echo $time_remaining->h . ' hours left';
                                        } else {
                                            echo $time_remaining->i . ' minutes left';
                                        }
                                        ?>
                                    </span>
                                    <div>
                                        <a href="exam_instructions.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-success btn-sm">
                                            <i class="fas fa-play me-1"></i> Start Exam
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-bolt me-2 text-warning"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <a href="take_exam.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-play-circle fa-2x text-primary mb-3"></i>
                                <h6 class="card-title">Take Available Exam</h6>
                                <p class="card-text small text-muted mb-0">Start a new examination</p>
                                <?php if($available_exams > 0): ?>
                                    <span class="badge bg-success mt-2"><?php echo $available_exams; ?> available</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="my_results.php" class="card action-card text-decoration-none">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-chart-line fa-2x text-success mb-3"></i>
                                <h6 class="card-title">View My Results</h6>
                                <p class="card-text small text-muted mb-0">Check your performance</p>
                                <?php if($completed_exams > 0): ?>
                                    <span class="badge bg-info mt-2"><?php echo $completed_exams; ?> completed</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Results -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-history me-2 text-info"></i>
                    Recent Exam Results
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_results)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-chart-line fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Exam Results Yet</h6>
                        <p class="text-muted mb-0">Your exam results will appear here after completion.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Exam</th>
                                    <th>Course</th>
                                    <th>Score</th>
                                    <th>Grade</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_results as $result): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($result['exam_title']); ?></div>
                                            <small class="text-muted"><?php echo ucfirst($result['exam_type']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($result['course_code']); ?></span>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-primary"><?php echo $result['obtained_marks']; ?>/<?php echo $result['total_marks']; ?></div>
                                            <div class="progress" style="height: 6px; width: 80px;">
                                                <div class="progress-bar bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>" 
                                                     style="width: <?php echo $result['percentage']; ?>%"></div>
                                            </div>
                                            <small class="text-muted"><?php echo $result['percentage']; ?>%</small>
                                        </td>
                                        <td>
                                            <span class="badge grade-<?php echo strtolower($result['grade']); ?>">
                                                <?php echo $result['grade']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                <i class="fas fa-<?php echo $result['status'] == 'pass' ? 'check' : 'times'; ?> me-1"></i>
                                                <?php echo ucfirst($result['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo formatDate($result['submitted_at']); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-white text-center">
                        <a href="my_results.php" class="btn btn-sm btn-outline-primary">View All Results</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Upcoming Exams -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-clock me-2 text-warning"></i>
                    Upcoming Exams
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($upcoming_exams_list)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-clock fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Upcoming Exams</h6>
                        <p class="text-muted mb-0">No exams scheduled for the near future.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($upcoming_exams_list as $exam): 
                            $start_date = new DateTime($exam['start_date']);
                            $now = new DateTime();
                            $time_until = $now->diff($start_date);
                        ?>
                            <div class="list-group-item">
                                <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                <p class="mb-1 small text-muted">
                                    <?php echo htmlspecialchars($exam['course_code']); ?>
                                    <?php if($exam['department']): ?>
                                        <span class="badge bg-light text-dark ms-2"><?php echo htmlspecialchars($exam['department']); ?></span>
                                    <?php endif; ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo formatDate($exam['start_date']); ?>
                                    </small>
                                    <span class="badge bg-info">
                                        in 
                                        <?php 
                                        if ($time_until->d > 0) {
                                            echo $time_until->d . 'd ' . $time_until->h . 'h';
                                        } else {
                                            echo $time_until->h . 'h ' . $time_until->i . 'm';
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-footer bg-white text-center">
                        <a href="take_exam.php" class="btn btn-sm btn-outline-warning">View All Upcoming</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Courses -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-book me-2 text-success"></i>
                    My Courses
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($enrolled_courses_list)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-book fa-2x text-muted mb-3"></i>
                        <h6 class="text-muted">No Courses Enrolled</h6>
                        <p class="text-muted mb-0">You are not enrolled in any courses yet.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($enrolled_courses_list as $course): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo htmlspecialchars($course['course_name']); ?></p>
                                        <?php if($course['department']): ?>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($course['department']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-end">
                                        <div class="fw-bold text-primary"><?php echo $course['exam_count']; ?></div>
                                        <small class="text-muted">exams</small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Notifications -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-bell me-2 text-warning"></i>
                    Notifications
                    <?php if($unread_notifications > 0): ?>
                        <span class="badge bg-danger ms-2"><?php echo $unread_notifications; ?> new</span>
                    <?php endif; ?>
                </h5>
                <a href="notifications.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if(empty($notifications)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-bell-slash fa-2x text-muted mb-3"></i>
                        <p class="text-muted mb-0">No notifications</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($notifications as $notification): ?>
                            <div class="list-group-item <?php echo !$notification['is_read'] ? 'bg-light' : ''; ?>">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($notification['title']); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo htmlspecialchars(substr($notification['message'], 0, 80)); ?>...</p>
                                        <small class="text-muted">
                                            <?php echo formatDate($notification['received_at']); ?>
                                            <?php if(!$notification['is_read']): ?>
                                                <span class="badge bg-success ms-2">New</span>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Performance Summary -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-trophy me-2 text-primary"></i>
                    Performance Summary
                </h5>
            </div>
            <div class="card-body">
                <?php if($total_graded_exams > 0): ?>
                    <div class="text-center mb-3">
                        <div class="h4 text-primary"><?php echo $average_score; ?>%</div>
                        <small class="text-muted">Average Score</small>
                    </div>
                    
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="h5 text-success"><?php echo $completed_exams; ?></div>
                            <small class="text-muted">Completed</small>
                        </div>
                        <div class="col-6">
                            <div class="h5 text-info"><?php echo $available_exams; ?></div>
                            <small class="text-muted">Available</small>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Success Rate</span>
                            <span>
                                <?php 
                                $success_rate = $completed_exams > 0 ? 
                                    (array_reduce($recent_results, function($carry, $result) {
                                        return $carry + ($result['status'] == 'pass' ? 1 : 0);
                                    }, 0) / $completed_exams * 100) : 0;
                                echo round($success_rate, 1); 
                                ?>%
                            </span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: <?php echo $success_rate; ?>%"></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-chart-line fa-2x mb-2"></i>
                        <p>Complete your first exam to see performance data.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.action-card {
    transition: all 0.3s ease;
    border: 1px solid #e3e6f0;
}

.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    border-color: #4e73df;
}

.action-card .card-body {
    transition: all 0.3s ease;
}

.action-card:hover .card-body {
    background-color: #f8f9fc;
}

.grade-a+ { background-color: #28a745; color: white; }
.grade-a { background-color: #28a745; color: white; }
.grade-b { background-color: #17a2b8; color: white; }
.grade-c { background-color: #ffc107; color: #212529; }
.grade-d { background-color: #fd7e14; color: white; }
.grade-f { background-color: #dc3545; color: white; }

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

/* Highlight ongoing exams */
.card-header.bg-success {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add click animations to action cards
    const actionCards = document.querySelectorAll('.action-card');
    actionCards.forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Auto-refresh dashboard every 2 minutes
    setInterval(() => {
        // You can add AJAX refresh here if needed
        console.log('Dashboard auto-refresh check');
    }, 120000);

    // Highlight urgent exams (less than 1 hour remaining)
    const ongoingExams = document.querySelectorAll('.list-group-item');
    ongoingExams.forEach(item => {
        const badge = item.querySelector('.badge.bg-danger');
        if (badge && badge.textContent.includes('minutes')) {
            const minutesText = badge.textContent.match(/(\d+)\s*minutes/);
            if (minutesText && parseInt(minutesText[1]) < 60) {
                item.classList.add('border-warning');
                item.classList.add('bg-warning', 'bg-opacity-10');
            }
        }
    });

    // Show motivational message based on performance
    const averageScore = <?php echo $average_score; ?>;
    if (averageScore > 0) {
        let message = '';
        if (averageScore >= 90) {
            message = 'Excellent work! Keep up the great performance! 🎉';
        } else if (averageScore >= 80) {
            message = 'Great job! You are doing well! 👍';
        } else if (averageScore >= 70) {
            message = 'Good progress! Keep practicing! 💪';
        } else if (averageScore >= 60) {
            message = 'You are improving! Focus on weak areas. 📚';
        } else {
            message = 'Keep studying! You can do better! 🌟';
        }
        
        // Create motivational toast
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-primary border-0 position-fixed bottom-0 end-0 m-3';
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        document.body.appendChild(toast);
        
        // Show toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
    
    // Countdown for ongoing exams
    function updateExamCountdowns() {
        const examBadges = document.querySelectorAll('.badge.bg-danger');
        examBadges.forEach(badge => {
            const text = badge.textContent;
            if (text.includes('minutes') || text.includes('hours') || text.includes('days')) {
                // This is where you could update the countdown in real-time
                // For now, we'll just log it
                console.log('Exam countdown:', text);
            }
        });
    }
    
    // Update countdowns every minute
    setInterval(updateExamCountdowns, 60000);
});
</script>

<?php require_once '../includes/footer.php'; ?>