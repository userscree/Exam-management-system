<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Exam Instructions';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Debug: Check if exam_id is received
error_log("Exam ID received: " . $exam_id);

if ($exam_id <= 0) {
    setFlash('error', 'Invalid exam selected.');
    redirect('take_exam.php');
}

// Get exam details and verify student can take it
try {
    // First, let's check if the exam exists and is active
    $stmt = $pdo->prepare("
        SELECT e.*, c.course_code, c.course_name 
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        WHERE e.id = ? AND e.is_active = 1
    ");
    $stmt->execute([$exam_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        setFlash('error', 'Exam not found or not active.');
        redirect('take_exam.php');
    }
    
    // Check if student is enrolled in the course
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM enrollments 
        WHERE student_id = ? AND course_id = ? AND status = 'active'
    ");
    $stmt->execute([$student_id, $exam['course_id']]);
    $is_enrolled = $stmt->fetchColumn();
    
    if (!$is_enrolled) {
        setFlash('error', 'You are not enrolled in this course.');
        redirect('take_exam.php');
    }
    
    // Check exam availability dates
    $now = date('Y-m-d H:i:s');
    if ($now < $exam['start_date']) {
        setFlash('error', 'This exam is not available yet. It starts on ' . date('M j, Y g:i A', strtotime($exam['start_date'])));
        redirect('take_exam.php');
    }
    
    if ($now > $exam['end_date']) {
        setFlash('error', 'This exam has ended. The deadline was ' . date('M j, Y g:i A', strtotime($exam['end_date'])));
        redirect('take_exam.php');
    }
    
    // Get question count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM questions WHERE exam_id = ?");
    $stmt->execute([$exam_id]);
    $question_count = $stmt->fetchColumn();
    
    // Get instructor info
    $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
    $stmt->execute([$exam['instructor_id']]);
    $instructor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get previous attempts
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM exam_attempts 
        WHERE exam_id = ? AND student_id = ? AND status IN ('submitted', 'graded')
    ");
    $stmt->execute([$exam_id, $student_id]);
    $previous_attempts = $stmt->fetchColumn();
    
    // Check if retake is allowed
    if ($previous_attempts > 0 && $exam['allow_retake'] == 0) {
        setFlash('error', 'You have already completed this exam and retakes are not allowed.');
        redirect('take_exam.php');
    }
    
    // Get question type distribution
    $stmt = $pdo->prepare("
        SELECT question_type, COUNT(*) as count, SUM(marks) as total_marks
        FROM questions 
        WHERE exam_id = ? 
        GROUP BY question_type
    ");
    $stmt->execute([$exam_id]);
    $question_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check if student has any in-progress attempts
    $stmt = $pdo->prepare("
        SELECT id, started_at, time_spent_seconds 
        FROM exam_attempts 
        WHERE exam_id = ? AND student_id = ? AND status = 'in_progress'
        ORDER BY started_at DESC 
        LIMIT 1
    ");
    $stmt->execute([$exam_id, $student_id]);
    $in_progress_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Add additional fields to exam array for easier access
    $exam['question_count'] = $question_count;
    $exam['previous_attempts'] = $previous_attempts;
    $exam['instructor_first_name'] = $instructor['first_name'];
    $exam['instructor_last_name'] = $instructor['last_name'];
    
} catch(PDOException $e) {
    error_log("Database error in exam_instructions: " . $e->getMessage());
    setFlash('error', 'Error loading exam details. Please try again.');
    redirect('take_exam.php');
}

// Handle exam start
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_exam'])) {
    try {
        // Check if there's an existing in-progress attempt
        if ($in_progress_attempt) {
            $attempt_id = $in_progress_attempt['id'];
            setFlash('info', 'Resuming your previous exam attempt.');
        } else {
            // Create new exam attempt
            $stmt = $pdo->prepare("
                INSERT INTO exam_attempts (student_id, exam_id, started_at, total_questions, status) 
                VALUES (?, ?, NOW(), ?, 'in_progress')
            ");
            $stmt->execute([$student_id, $exam_id, $exam['question_count']]);
            $attempt_id = $pdo->lastInsertId();
            
            // Log activity
            $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $student_id,
                'exam_started',
                'Started exam: ' . $exam['title'],
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);
            
            setFlash('success', 'Exam started successfully! Good luck!');
        }
        
        // Redirect to exam interface
        redirect('questions.php?attempt_id=' . $attempt_id);
        
    } catch(PDOException $e) {
        error_log("Error starting exam: " . $e->getMessage());
        setFlash('error', 'Error starting exam: ' . $e->getMessage());
    }
}
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header bg-primary text-white text-center py-4">
                <h1 class="h3 mb-2">
                    <i class="fas fa-file-alt me-2"></i>
                    Exam Instructions
                </h1>
                <p class="mb-0">Please read all instructions carefully before starting</p>
            </div>
            
            <div class="card-body">
                <!-- Debug info (remove in production) -->
                <?php if(false): // Set to true for debugging ?>
                <div class="alert alert-warning">
                    <strong>Debug Info:</strong><br>
                    Exam ID: <?php echo $exam_id; ?><br>
                    Student ID: <?php echo $student_id; ?><br>
                    Question Count: <?php echo $exam['question_count']; ?><br>
                    Previous Attempts: <?php echo $exam['previous_attempts']; ?>
                </div>
                <?php endif; ?>

                <!-- Exam Header -->
                <div class="text-center mb-4">
                    <h2 class="h4 text-primary"><?php echo htmlspecialchars($exam['title']); ?></h2>
                    <p class="text-muted mb-1">
                        <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?>
                    </p>
                    <p class="text-muted mb-0">
                        Instructor: <?php echo htmlspecialchars($exam['instructor_first_name'] . ' ' . $exam['instructor_last_name']); ?>
                    </p>
                </div>

                <!-- Resume Notice -->
                <?php if($in_progress_attempt): ?>
                    <div class="alert alert-warning">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                            <div>
                                <h5 class="alert-heading mb-1">Exam in Progress</h5>
                                <p class="mb-0">
                                    You have an exam in progress that started on 
                                    <strong><?php echo formatDate($in_progress_attempt['started_at']); ?></strong>.
                                    You can resume where you left off.
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Previous Attempts Notice -->
                <?php if($exam['previous_attempts'] > 0): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        You have <?php echo $exam['previous_attempts']; ?> previous attempt(s) for this exam.
                        <?php if($exam['allow_retake']): ?>
                            <strong>Retakes are allowed.</strong>
                        <?php else: ?>
                            <strong>This is your final attempt.</strong>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- Exam Details -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <i class="fas fa-question-circle fa-2x text-primary mb-2"></i>
                                <h5 class="card-title"><?php echo $exam['question_count']; ?></h5>
                                <p class="card-text text-muted mb-0">Total Questions</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <i class="fas fa-clock fa-2x text-warning mb-2"></i>
                                <h5 class="card-title"><?php echo $exam['duration_minutes']; ?> min</h5>
                                <p class="card-text text-muted mb-0">Time Limit</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <i class="fas fa-star fa-2x text-success mb-2"></i>
                                <h5 class="card-title"><?php echo $exam['total_marks']; ?></h5>
                                <p class="card-text text-muted mb-0">Total Marks</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Question Type Breakdown -->
                <?php if(!empty($question_types)): ?>
                <div class="mb-4">
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="fas fa-list-alt me-2 text-info"></i>
                        Question Types
                    </h5>
                    <div class="row">
                        <?php foreach($question_types as $type): 
                            $percentage = round(($type['count'] / $exam['question_count']) * 100, 1);
                        ?>
                            <div class="col-md-6 mb-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">
                                        <?php 
                                        $icon = 'question-circle';
                                        $color = 'primary';
                                        switch($type['question_type']) {
                                            case 'multiple_choice': 
                                                $icon = 'check-circle'; 
                                                $color = 'info';
                                                break;
                                            case 'true_false': 
                                                $icon = 'toggle-on'; 
                                                $color = 'warning';
                                                break;
                                            case 'short_answer': 
                                                $icon = 'pen'; 
                                                $color = 'success';
                                                break;
                                            case 'essay': 
                                                $icon = 'file-alt'; 
                                                $color = 'danger';
                                                break;
                                        }
                                        ?>
                                        <i class="fas fa-<?php echo $icon; ?> text-<?php echo $color; ?> me-2"></i>
                                        <?php echo ucfirst(str_replace('_', ' ', $type['question_type'])); ?>
                                    </span>
                                    <span class="fw-bold">
                                        <?php echo $type['count']; ?> 
                                        <small class="text-muted">(<?php echo $percentage; ?>%)</small>
                                    </span>
                                </div>
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar bg-<?php echo $color; ?>" style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No questions have been added to this exam yet. Please contact your instructor.
                </div>
                <?php endif; ?>

                <!-- Instructions -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="fas fa-info-circle me-2 text-success"></i>
                        Important Instructions
                    </h5>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-flex mb-3">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-clock text-warning fa-lg me-3"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6>Time Management</h6>
                                    <p class="small text-muted mb-0">
                                        The exam must be completed within <strong><?php echo $exam['duration_minutes']; ?> minutes</strong>. 
                                        The timer will start when you begin and cannot be paused.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex mb-3">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-save text-success fa-lg me-3"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6>Auto-Save</h6>
                                    <p class="small text-muted mb-0">
                                        Your answers are automatically saved as you progress. You can navigate between questions freely.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex mb-3">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-ban text-danger fa-lg me-3"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6>Restrictions</h6>
                                    <p class="small text-muted mb-0">
                                        Do not refresh the page or use the browser's back button during the exam. 
                                        This may cause you to lose your progress.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex mb-3">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-flag text-info fa-lg me-3"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h6>Navigation</h6>
                                    <p class="small text-muted mb-0">
                                        Use the navigation panel to move between questions. 
                                        You can flag questions for review and return to them later.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Technical Requirements -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="fas fa-laptop me-2 text-primary"></i>
                        Technical Requirements
                    </h5>
                    <div class="alert alert-info">
                        <ul class="mb-0">
                            <li>Stable internet connection required</li>
                            <li>Use Chrome, Firefox, or Edge browser</li>
                            <li>Ensure JavaScript is enabled</li>
                            <li>Do not close the browser tab during the exam</li>
                            <li>Full-screen mode is recommended for better focus</li>
                        </ul>
                    </div>
                </div>

                <!-- Grading Information -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="fas fa-chart-line me-2 text-warning"></i>
                        Grading Information
                    </h5>
                    <div class="row text-center">
                        <div class="col-md-4">
                            <div class="border rounded p-3">
                                <h4 class="text-primary mb-1"><?php echo $exam['total_marks']; ?></h4>
                                <small class="text-muted">Total Marks</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="border rounded p-3">
                                <h4 class="text-success mb-1"><?php echo $exam['passing_marks']; ?></h4>
                                <small class="text-muted">Passing Marks</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="border rounded p-3">
                                <h4 class="text-info mb-1">
                                    <?php echo round(($exam['passing_marks'] / $exam['total_marks']) * 100); ?>%
                                </h4>
                                <small class="text-muted">Passing Percentage</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Agreement -->
                <div class="mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="agree_terms" required>
                        <label class="form-check-label" for="agree_terms">
                            I understand and agree to the exam rules and instructions. I confirm that:
                            <ul class="small text-muted mt-2 mb-0">
                                <li>I will complete this exam independently without assistance</li>
                                <li>I will not use any unauthorized materials or resources</li>
                                <li>I understand that violations may result in exam disqualification</li>
                            </ul>
                        </label>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                    <a href="take_exam.php" class="btn btn-outline-secondary btn-lg">
                        <i class="fas fa-arrow-left me-2"></i> Back to Exams
                    </a>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="start_exam" id="start_exam_btn" class="btn btn-success btn-lg px-5" 
                                <?php echo ($exam['question_count'] == 0) ? 'disabled' : ''; ?>>
                            <?php if($in_progress_attempt): ?>
                                <i class="fas fa-play-circle me-2"></i> Resume Exam
                            <?php else: ?>
                                <i class="fas fa-play-circle me-2"></i> Start Exam
                            <?php endif; ?>
                        </button>
                        <?php if($exam['question_count'] == 0): ?>
                            <div class="text-danger small mt-1">Cannot start: No questions available</div>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Exam Availability -->
                <div class="text-center mt-4 pt-3 border-top">
                    <small class="text-muted">
                        <i class="fas fa-calendar me-1"></i>
                        Available until: <?php echo formatDate($exam['end_date']); ?>
                        <?php 
                        $now = new DateTime();
                        $end_date = new DateTime($exam['end_date']);
                        $time_remaining = $now->diff($end_date);
                        if ($time_remaining->days == 0 && $time_remaining->h < 24) {
                            echo '<span class="badge bg-warning ms-2">Ending soon</span>';
                        }
                        ?>
                    </small>
                </div>
            </div>
        </div>

        <!-- Quick Tips -->
        <div class="card mt-4">
            <div class="card-header bg-light">
                <h6 class="card-title mb-0">
                    <i class="fas fa-lightbulb me-2 text-warning"></i>
                    Quick Tips for Success
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <i class="fas fa-eye fa-2x text-primary mb-2"></i>
                        <h6>Read Carefully</h6>
                        <p class="small text-muted mb-0">Read each question thoroughly before answering</p>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <i class="fas fa-flag fa-2x text-warning mb-2"></i>
                        <h6>Flag Questions</h6>
                        <p class="small text-muted mb-0">Mark difficult questions to review later</p>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                        <h6>Review Answers</h6>
                        <p class="small text-muted mb-0">Use remaining time to review your answers</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.bg-light {
    background-color: #f8f9fa !important;
}

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

.progress-bar {
    border-radius: 0.375rem;
}

.btn-success {
    font-weight: 600;
    padding: 12px 30px;
}

.form-check-input:checked {
    background-color: #28a745;
    border-color: #28a745;
}

.border-bottom {
    border-color: #dee2e6 !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const agreeCheckbox = document.getElementById('agree_terms');
    const startButton = document.getElementById('start_exam_btn');
    
    // Only enable the agreement functionality if the button isn't already disabled
    if (!startButton.disabled) {
        // Enable start button when terms are agreed
        agreeCheckbox.addEventListener('change', function() {
            startButton.disabled = !this.checked;
        });
        
        // Add confirmation before starting exam
        startButton.addEventListener('click', function(e) {
            if (!confirm('Are you ready to start the exam? The timer will begin immediately and cannot be paused.')) {
                e.preventDefault();
            }
        });
    }
    
    // Auto-scroll to top
    window.scrollTo(0, 0);
    
    // Add countdown for exam ending soon
    const endDate = new Date('<?php echo $exam['end_date']; ?>');
    const now = new Date();
    const timeDiff = endDate.getTime() - now.getTime();
    const hoursRemaining = Math.floor(timeDiff / (1000 * 60 * 60));
    
    if (hoursRemaining < 6) {
        // Add urgent styling if exam is ending soon
        const availabilityNotice = document.querySelector('.text-muted .badge');
        if (availabilityNotice) {
            availabilityNotice.classList.remove('bg-warning');
            availabilityNotice.classList.add('bg-danger');
            availabilityNotice.innerHTML = '<i class="fas fa-exclamation-triangle me-1"></i> Ending very soon';
        }
        
        // Pulse animation for urgency
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse-urgent {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            .btn-success:not(:disabled) {
                animation: pulse-urgent 2s infinite;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Keyboard shortcut - Space to check agreement
    document.addEventListener('keydown', function(e) {
        if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            if (agreeCheckbox) {
                agreeCheckbox.checked = !agreeCheckbox.checked;
                agreeCheckbox.dispatchEvent(new Event('change'));
            }
        }
    });
});

// Prevent accidental navigation
window.addEventListener('beforeunload', function(e) {
    // Only show warning if the exam hasn't been started yet
    const startButton = document.getElementById('start_exam_btn');
    if (startButton && !startButton.disabled) {
        e.preventDefault();
        e.returnValue = 'Are you sure you want to leave? Your exam progress may be lost.';
        return e.returnValue;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>