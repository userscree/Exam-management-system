<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Notifications';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];

// Handle mark as read actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['mark_as_read'])) {
        $notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
        
        if ($notification_id > 0) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE user_notifications 
                    SET is_read = 1, read_at = NOW() 
                    WHERE user_id = ? AND notification_id = ?
                ");
                $stmt->execute([$student_id, $notification_id]);
                
                setFlash('success', 'Notification marked as read.');
            } catch(PDOException $e) {
                setFlash('error', 'Error marking notification as read: ' . $e->getMessage());
            }
        }
    } elseif (isset($_POST['mark_all_read'])) {
        try {
            $stmt = $pdo->prepare("
                UPDATE user_notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE user_id = ? AND is_read = 0
            ");
            $stmt->execute([$student_id]);
            
            setFlash('success', 'All notifications marked as read.');
        } catch(PDOException $e) {
            setFlash('error', 'Error marking notifications as read: ' . $e->getMessage());
        }
    } elseif (isset($_POST['clear_all'])) {
        try {
            $stmt = $pdo->prepare("
                DELETE FROM user_notifications 
                WHERE user_id = ? AND is_read = 1
            ");
            $stmt->execute([$student_id]);
            
            setFlash('success', 'Read notifications cleared.');
        } catch(PDOException $e) {
            setFlash('error', 'Error clearing notifications: ' . $e->getMessage());
        }
    }
    
    // Redirect to avoid form resubmission
    redirect('notifications.php');
}

// Get filter parameters
$filter = $_GET['filter'] ?? 'all';
$type = $_GET['type'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query for notifications
$query = "
    SELECT 
        n.*,
        un.is_read,
        un.read_at,
        un.created_at as received_at,
        creator.first_name as creator_first_name,
        creator.last_name as creator_last_name,
        creator.username as creator_username,
        c.course_code,
        c.course_name
    FROM notifications n
    INNER JOIN user_notifications un ON n.id = un.notification_id
    LEFT JOIN users creator ON n.created_by = creator.id
    LEFT JOIN courses c ON n.course_id = c.id
    WHERE un.user_id = ?
    AND n.is_active = 1
    AND (n.expires_at IS NULL OR n.expires_at > NOW())
";

$params = [$student_id];

// Apply filters
if ($filter === 'unread') {
    $query .= " AND un.is_read = 0";
} elseif ($filter === 'read') {
    $query .= " AND un.is_read = 1";
}

if ($type !== 'all') {
    $query .= " AND n.target_audience = ?";
    $params[] = $type;
}

if (!empty($search)) {
    $query .= " AND (n.title LIKE ? OR n.message LIKE ? OR c.course_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY n.created_at DESC, n.id DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get counts for different types
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN un.is_read = 0 THEN 1 ELSE 0 END) as unread,
            SUM(CASE WHEN un.is_read = 1 THEN 1 ELSE 0 END) as read_count
        FROM notifications n
        INNER JOIN user_notifications un ON n.id = un.notification_id
        WHERE un.user_id = ?
        AND n.is_active = 1
        AND (n.expires_at IS NULL OR n.expires_at > NOW())
    ");
    $stmt->execute([$student_id]);
    $counts = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get notification types distribution
    $stmt = $pdo->prepare("
        SELECT 
            n.target_audience,
            COUNT(*) as count
        FROM notifications n
        INNER JOIN user_notifications un ON n.id = un.notification_id
        WHERE un.user_id = ?
        AND n.is_active = 1
        AND (n.expires_at IS NULL OR n.expires_at > NOW())
        GROUP BY n.target_audience
    ");
    $stmt->execute([$student_id]);
    $type_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching notifications: ' . $e->getMessage());
    $notifications = [];
    $counts = ['total' => 0, 'unread' => 0, 'read_count' => 0];
    $type_counts = [];
}

// Get important announcements (system-wide, not expired)
try {
    $stmt = $pdo->prepare("
        SELECT n.*, creator.first_name, creator.last_name
        FROM notifications n
        LEFT JOIN users creator ON n.created_by = creator.id
        WHERE n.target_audience IN ('all', 'students')
        AND n.is_active = 1
        AND (n.expires_at IS NULL OR n.expires_at > NOW())
        AND n.id NOT IN (
            SELECT notification_id FROM user_notifications WHERE user_id = ?
        )
        ORDER BY n.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $new_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    $new_announcements = [];
}
?>

<div class="row">
    <div class="col-lg-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1">Notifications</h1>
                <p class="text-muted mb-0">Stay updated with important announcements and alerts</p>
            </div>
            <div class="btn-group">
                <?php if($counts['unread'] > 0): ?>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="mark_all_read" class="btn btn-success">
                            <i class="fas fa-check-double me-2"></i> Mark All as Read
                        </button>
                    </form>
                <?php endif; ?>
                <?php if($counts['read_count'] > 0): ?>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="clear_all" class="btn btn-outline-danger" 
                                onclick="return confirm('Are you sure you want to clear all read notifications?')">
                            <i class="fas fa-trash me-2"></i> Clear Read
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Notifications
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $counts['total']; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-bell fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Unread Notifications
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $counts['unread']; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Read Notifications
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $counts['read_count']; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-envelope-open fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    New Announcements
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($new_announcements); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-bullhorn fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- New Announcements -->
        <?php if(!empty($new_announcements)): ?>
            <div class="card border-warning mb-4">
                <div class="card-header bg-warning text-dark">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-bullhorn me-2"></i> New Announcements
                        <span class="badge bg-danger ms-2"><?php echo count($new_announcements); ?> new</span>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <?php foreach($new_announcements as $announcement): ?>
                            <div class="list-group-item border-warning bg-warning bg-opacity-10">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">
                                            <i class="fas fa-exclamation-circle text-warning me-2"></i>
                                            <?php echo htmlspecialchars($announcement['title']); ?>
                                        </h6>
                                        <p class="mb-1"><?php echo htmlspecialchars($announcement['message']); ?></p>
                                        <small class="text-muted">
                                            By: <?php echo htmlspecialchars($announcement['first_name'] . ' ' . $announcement['last_name']); ?>
                                            • <?php echo formatDate($announcement['created_at']); ?>
                                            <?php if($announcement['expires_at']): ?>
                                                • Expires: <?php echo formatDate($announcement['expires_at']); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <div class="flex-shrink-0 ms-3">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="notification_id" value="<?php echo $announcement['id']; ?>">
                                            <button type="submit" name="mark_as_read" class="btn btn-sm btn-success">
                                                <i class="fas fa-check me-1"></i> Mark as Read
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filters and Search -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               placeholder="Search notifications..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="filter" class="form-label">Status</label>
                        <select class="form-select" id="filter" name="filter">
                            <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Notifications</option>
                            <option value="unread" <?php echo $filter === 'unread' ? 'selected' : ''; ?>>Unread Only</option>
                            <option value="read" <?php echo $filter === 'read' ? 'selected' : ''; ?>>Read Only</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="type" class="form-label">Type</label>
                        <select class="form-select" id="type" name="type">
                            <option value="all" <?php echo $type === 'all' ? 'selected' : ''; ?>>All Types</option>
                            <option value="all" <?php echo $type === 'all' ? 'selected' : ''; ?>>System Wide</option>
                            <option value="students" <?php echo $type === 'students' ? 'selected' : ''; ?>>Student Specific</option>
                            <option value="specific_course" <?php echo $type === 'specific_course' ? 'selected' : ''; ?>>Course Specific</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <div class="btn-group w-100">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter me-2"></i> Filter
                            </button>
                            <a href="notifications.php" class="btn btn-outline-secondary">
                                <i class="fas fa-redo me-2"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Notifications List -->
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-list me-2 text-primary"></i> Notifications
                    <span class="badge bg-primary ms-2"><?php echo count($notifications); ?></span>
                </h5>
                <div class="text-muted small">
                    Showing <?php echo $filter === 'all' ? 'all' : $filter; ?> notifications
                    <?php if($type !== 'all'): ?>
                        for <?php echo $type; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if(empty($notifications)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No Notifications Found</h5>
                        <p class="text-muted">
                            <?php 
                            if ($filter === 'unread') {
                                echo 'You have no unread notifications.';
                            } elseif ($filter === 'read') {
                                echo 'You have no read notifications.';
                            } elseif (!empty($search)) {
                                echo 'No notifications match your search criteria.';
                            } else {
                                echo 'You don\'t have any notifications at the moment.';
                            }
                            ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($notifications as $notification): ?>
                            <div class="list-group-item <?php echo !$notification['is_read'] ? 'bg-light' : ''; ?>">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center mb-2">
                                            <?php if(!$notification['is_read']): ?>
                                                <span class="badge bg-success me-2">NEW</span>
                                            <?php endif; ?>
                                            <h6 class="mb-0 <?php echo !$notification['is_read'] ? 'fw-bold' : ''; ?>">
                                                <?php echo htmlspecialchars($notification['title']); ?>
                                            </h6>
                                        </div>
                                        
                                        <p class="mb-2 text-muted"><?php echo htmlspecialchars($notification['message']); ?></p>
                                        
                                        <div class="d-flex flex-wrap gap-3 small text-muted">
                                            <span>
                                                <i class="fas fa-user me-1"></i>
                                                By: <?php echo htmlspecialchars($notification['creator_first_name'] . ' ' . $notification['creator_last_name']); ?>
                                            </span>
                                            <span>
                                                <i class="fas fa-clock me-1"></i>
                                                Received: <?php echo formatDate($notification['received_at']); ?>
                                            </span>
                                            <?php if($notification['course_code']): ?>
                                                <span>
                                                    <i class="fas fa-book me-1"></i>
                                                    Course: <?php echo htmlspecialchars($notification['course_code']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <?php if($notification['expires_at']): ?>
                                                <span>
                                                    <i class="fas fa-calendar-times me-1"></i>
                                                    Expires: <?php echo formatDate($notification['expires_at']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <?php if($notification['is_read'] && $notification['read_at']): ?>
                                                <span>
                                                    <i class="fas fa-check me-1"></i>
                                                    Read: <?php echo formatDate($notification['read_at']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="flex-shrink-0 ms-3">
                                        <div class="btn-group btn-group-sm">
                                            <?php if(!$notification['is_read']): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                                    <button type="submit" name="mark_as_read" class="btn btn-outline-success" 
                                                            title="Mark as Read">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-outline-secondary" disabled title="Read">
                                                    <i class="fas fa-check-double"></i>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if($notification['target_audience'] == 'specific_course' && $notification['course_code']): ?>
                                                <button class="btn btn-outline-info" 
                                                        title="Course: <?php echo htmlspecialchars($notification['course_code']); ?>">
                                                    <i class="fas fa-book"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if(!empty($notifications)): ?>
                <div class="card-footer bg-white">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <small class="text-muted">
                                Showing <?php echo count($notifications); ?> of <?php echo $counts['total']; ?> notifications
                            </small>
                        </div>
                        <div class="col-md-6 text-end">
                            <?php if($counts['unread'] > 0): ?>
                                <form method="POST" class="d-inline">
                                    <button type="submit" name="mark_all_read" class="btn btn-sm btn-success">
                                        <i class="fas fa-check-double me-1"></i> Mark All as Read
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Notification Types Distribution -->
        <?php if(!empty($type_counts)): ?>
            <div class="card mt-4">
                <div class="card-header bg-light">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-chart-pie me-2"></i> Notification Types
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach($type_counts as $type_name => $count): 
                            $percentage = $counts['total'] > 0 ? round(($count / $counts['total']) * 100, 1) : 0;
                            $color = 'primary';
                            $icon = 'bell';
                            
                            switch($type_name) {
                                case 'all': $color = 'primary'; $icon = 'globe'; break;
                                case 'students': $color = 'success'; $icon = 'user-graduate'; break;
                                case 'specific_course': $color = 'info'; $icon = 'book'; break;
                                case 'instructors': $color = 'warning'; $icon = 'chalkboard-teacher'; break;
                                case 'admins': $color = 'danger'; $icon = 'shield-alt'; break;
                            }
                        ?>
                            <div class="col-md-4 col-6 mb-3">
                                <div class="d-flex align-items-center p-2 border rounded">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-<?php echo $icon; ?> fa-2x text-<?php echo $color; ?> me-3"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-bold text-<?php echo $color; ?>"><?php echo $count; ?></div>
                                        <small class="text-muted text-capitalize">
                                            <?php echo str_replace('_', ' ', $type_name); ?>
                                        </small>
                                        <div class="progress mt-1" style="height: 4px;">
                                            <div class="progress-bar bg-<?php echo $color; ?>" style="width: <?php echo $percentage; ?>%"></div>
                                        </div>
                                        <small class="text-muted"><?php echo $percentage; ?>%</small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Notification Settings Modal -->
<div class="modal fade" id="notificationSettingsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Notification Settings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="notificationSettingsForm">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email Notifications</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="emailExamAlerts" checked>
                            <label class="form-check-label" for="emailExamAlerts">
                                Exam schedules and reminders
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="emailResults" checked>
                            <label class="form-check-label" for="emailResults">
                                Exam results and grades
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="emailAnnouncements">
                            <label class="form-check-label" for="emailAnnouncements">
                                System announcements
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Push Notifications</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="pushExamAlerts" checked>
                            <label class="form-check-label" for="pushExamAlerts">
                                Exam alerts
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="pushResults">
                            <label class="form-check-label" for="pushResults">
                                Result notifications
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notificationFrequency" class="form-label fw-bold">Notification Frequency</label>
                        <select class="form-select" id="notificationFrequency">
                            <option value="immediate">Immediate</option>
                            <option value="hourly">Hourly Digest</option>
                            <option value="daily">Daily Digest</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveNotificationSettings()">Save Settings</button>
            </div>
        </div>
    </div>
</div>

<style>
.notification-item {
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
}

.notification-item:hover {
    background-color: #f8f9fa;
    transform: translateX(5px);
}

.notification-item.unread {
    border-left-color: #28a745;
    background-color: #f8fff9;
}

.notification-item.important {
    border-left-color: #dc3545;
    background-color: #fff5f5;
}

.notification-item.course-specific {
    border-left-color: #17a2b8;
    background-color: #f0f9ff;
}

.badge-notification {
    font-size: 0.7rem;
}

.progress {
    background-color: #e9ecef;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-mark as read when notification is viewed for more than 3 seconds
    const unreadNotifications = document.querySelectorAll('.list-group-item.bg-light');
    unreadNotifications.forEach(notification => {
        setTimeout(() => {
            const markAsReadBtn = notification.querySelector('button[title="Mark as Read"]');
            if (markAsReadBtn && isElementInViewport(notification)) {
                // Auto-mark as read after 3 seconds of being in viewport
                setTimeout(() => {
                    if (isElementInViewport(notification)) {
                        markAsReadBtn.click();
                    }
                }, 3000);
            }
        }, 1000);
    });
    
    // Add search functionality with debounce
    const searchInput = document.getElementById('search');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.form.submit();
            }, 500);
        });
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+F to focus search
        if (e.ctrlKey && e.key === 'f') {
            e.preventDefault();
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        }
        
        // Escape to clear search
        if (e.key === 'Escape' && searchInput && searchInput.value) {
            searchInput.value = '';
            searchInput.form.submit();
        }
    });
    
    // Mark all as read with confirmation
    const markAllBtn = document.querySelector('button[name="mark_all_read"]');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to mark all notifications as read?')) {
                e.preventDefault();
            }
        });
    }
    
    // Add notification filtering by clicking on type badges
    document.querySelectorAll('.badge.bg-primary').forEach(badge => {
        badge.style.cursor = 'pointer';
        badge.addEventListener('click', function() {
            const filterSelect = document.getElementById('filter');
            const typeSelect = document.getElementById('type');
            
            if (this.textContent.includes('System')) {
                typeSelect.value = 'all';
            } else if (this.textContent.includes('Student')) {
                typeSelect.value = 'students';
            } else if (this.textContent.includes('Course')) {
                typeSelect.value = 'specific_course';
            }
            
            filterSelect.form.submit();
        });
    });
});

// Helper function to check if element is in viewport
function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Notification settings
function saveNotificationSettings() {
    const form = document.getElementById('notificationSettingsForm');
    const formData = new FormData(form);
    
    // In a real application, you would send this to the server
    console.log('Saving notification settings:', {
        emailExamAlerts: document.getElementById('emailExamAlerts').checked,
        emailResults: document.getElementById('emailResults').checked,
        emailAnnouncements: document.getElementById('emailAnnouncements').checked,
        pushExamAlerts: document.getElementById('pushExamAlerts').checked,
        pushResults: document.getElementById('pushResults').checked,
        frequency: document.getElementById('notificationFrequency').value
    });
    
    // Show success message
    alert('Notification settings saved successfully!');
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('notificationSettingsModal'));
    modal.hide();
}

// Quick actions
function quickMarkAllRead() {
    if (confirm('Mark all notifications as read?')) {
        document.querySelector('button[name="mark_all_read"]').click();
    }
}

function quickSearch() {
    const searchInput = document.getElementById('search');
    if (searchInput) {
        searchInput.focus();
        searchInput.select();
    }
}

// Export function for global access
window.NotificationManager = {
    markAllRead: quickMarkAllRead,
    search: quickSearch,
    openSettings: () => {
        const modal = new bootstrap.Modal(document.getElementById('notificationSettingsModal'));
        modal.show();
    }
};
</script>

<?php require_once '../includes/footer.php'; ?>