<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Exam Instructions';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

if ($exam_id <= 0) {
    setFlash('error', 'Invalid exam selected.');
    redirect('take_exam.php');
}

// Get exam details and check if student can take it
try {
    $stmt = $pdo->prepare("
        SELECT 
            e.*, 
            c.course_code, 
            c.course_name,
            (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
            (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ? AND status IN ('submitted', 'graded')) as previous_attempts
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE e.id = ? 
        AND en.student_id = ?
        AND e.is_active = 1 
        AND e.start_date <= NOW() 
        AND e.end_date >= NOW()
    ");
    $stmt->execute([$student_id, $exam_id, $student_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        setFlash('error', 'Exam not found or you do not have permission to take it.');
        redirect('take_exam.php');
    }
    
    // Check if retake is allowed
    if ($exam['previous_attempts'] > 0 && $exam['allow_retake'] == 0) {
        setFlash('error', 'You have already completed this exam and retakes are not allowed.');
        redirect('take_exam.php');
    }
    
    // Get question type distribution
    $stmt = $pdo->prepare("
        SELECT question_type, COUNT(*) as count, SUM(marks) as total_marks
        FROM questions 
        WHERE exam_id = ? 
        GROUP BY question_type
    ");
    $stmt->execute([$exam_id]);
    $question_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exam details: ' . $e->getMessage());
    redirect('take_exam.php');
}

// Check if there's an existing in-progress attempt
try {
    $stmt = $pdo->prepare("
        SELECT id FROM exam_attempts 
        WHERE exam_id = ? AND student_id = ? AND status = 'in_progress'
    ");
    $stmt->execute([$exam_id, $student_id]);
    $existing_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    $existing_attempt = null;
}
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="card-title mb-0">
                    <i class="fas fa-file-alt me-2"></i> Exam Instructions
                </h4>
            </div>
            <div class="card-body">
                <!-- Exam Header -->
                <div class="text-center mb-4">
                    <h3 class="text-primary"><?php echo htmlspecialchars($exam['title']); ?></h3>
                    <p class="lead text-muted"><?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?></p>
                </div>

                <!-- Exam Overview -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <h5 class="text-primary"><?php echo $exam['question_count']; ?></h5>
                                <p class="mb-0 text-muted">Total Questions</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border-0 bg-light">
                            <div class="card-body text-center">
                                <h5 class="text-primary"><?php echo $exam['duration_minutes']; ?> mins</h5>
                                <p class="mb-0 text-muted">Duration</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Question Type Distribution -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2">Question Distribution</h5>
                    <div class="row">
                        <?php foreach($question_types as $type): 
                            $icon = 'question-circle';
                            $color = 'primary';
                            switch($type['question_type']) {
                                case 'multiple_choice': $icon = 'list-ol'; $color = 'info'; break;
                                case 'true_false': $icon = 'check-circle'; $color = 'success'; break;
                                case 'short_answer': $icon = 'pen'; $color = 'warning'; break;
                                case 'essay': $icon = 'file-alt'; $color = 'danger'; break;
                            }
                        ?>
                            <div class="col-md-3 col-6 mb-2">
                                <div class="text-center p-2 border rounded">
                                    <i class="fas fa-<?php echo $icon; ?> text-<?php echo $color; ?> fa-2x mb-2"></i>
                                    <div class="fw-bold"><?php echo $type['count']; ?></div>
                                    <small class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $type['question_type'])); ?></small>
                                    <div class="small text-primary"><?php echo $type['total_marks']; ?> marks</div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Instructions -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2">Instructions</h5>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Please read the following instructions carefully before starting the exam.
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">General Instructions:</h6>
                            <ul class="small">
                                <li>You have <strong><?php echo $exam['duration_minutes']; ?> minutes</strong> to complete the exam</li>
                                <li>The timer will start when you begin the exam and cannot be paused</li>
                                <li>Do not refresh the page or navigate away during the exam</li>
                                <li>Answers are auto-saved as you progress</li>
                                <li>Review all questions before submitting</li>
                                <li>Ensure you have a stable internet connection</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Navigation & Submission:</h6>
                            <ul class="small">
                                <li>Use "Next" and "Previous" buttons to navigate</li>
                                <li>Mark questions for review if unsure</li>
                                <li>Submit only when you're sure you've completed</li>
                                <li>Exam will auto-submit when time expires</li>
                                <li>Results will be shown immediately after submission</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Important Notes -->
                <div class="alert alert-warning">
                    <h6 class="alert-heading">
                        <i class="fas fa-exclamation-triangle me-2"></i>Important Notes
                    </h6>
                    <ul class="mb-0 small">
                        <li>Any attempt to cheat will result in automatic failure</li>
                        <li>Technical issues should be reported immediately</li>
                        <li>Ensure your device is charged or plugged in</li>
                        <li>Close unnecessary applications and browser tabs</li>
                    </ul>
                </div>

                <!-- System Check -->
                <div class="mb-4">
                    <h5 class="border-bottom pb-2">System Check</h5>
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <div id="connectionCheck" class="p-2">
                                <i class="fas fa-wifi fa-2x text-muted mb-2"></i>
                                <div class="small">Internet Connection</div>
                                <span class="badge bg-secondary">Checking...</span>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div id="browserCheck" class="p-2">
                                <i class="fas fa-desktop fa-2x text-muted mb-2"></i>
                                <div class="small">Browser Support</div>
                                <span class="badge bg-secondary">Checking...</span>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div id="timeCheck" class="p-2">
                                <i class="fas fa-clock fa-2x text-muted mb-2"></i>
                                <div class="small">Time Sync</div>
                                <span class="badge bg-secondary">Checking...</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="take_exam.php" class="btn btn-outline-secondary me-md-2">
                        <i class="fas fa-arrow-left me-2"></i> Back to Exams
                    </a>
                    
                    <?php if($existing_attempt): ?>
                        <a href="questions.php?exam_id=<?php echo $exam_id; ?>&attempt_id=<?php echo $existing_attempt['id']; ?>" 
                           class="btn btn-warning">
                            <i class="fas fa-play-circle me-2"></i> Continue Exam
                        </a>
                    <?php else: ?>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#startExamModal">
                            <i class="fas fa-play-circle me-2"></i> Start Exam
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Start Exam Confirmation Modal -->
<div class="modal fade" id="startExamModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Exam Start</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <i class="fas fa-play-circle fa-3x text-success mb-3"></i>
                    <h5>Ready to Start?</h5>
                    <p class="text-muted">You are about to start <strong><?php echo htmlspecialchars($exam['title']); ?></strong></p>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-clock me-2"></i>
                    <strong>Exam Duration:</strong> <?php echo $exam['duration_minutes']; ?> minutes<br>
                    <strong>Total Questions:</strong> <?php echo $exam['question_count']; ?><br>
                    <strong>Total Marks:</strong> <?php echo $exam['total_marks']; ?>
                </div>
                
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="confirmInstructions">
                    <label class="form-check-label" for="confirmInstructions">
                        I have read and understood all the instructions
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="questions.php?exam_id=<?php echo $exam_id; ?>" 
                   class="btn btn-success" id="startExamBtn" disabled>
                    <i class="fas fa-play-circle me-2"></i> Start Exam
                </a>
            </div>
        </div>
    </div>
</div>

<script>
// System check functionality
function runSystemCheck() {
    // Check internet connection
    const connectionCheck = document.getElementById('connectionCheck');
    const connectionBadge = connectionCheck.querySelector('.badge');
    
    // Check browser compatibility
    const browserCheck = document.getElementById('browserCheck');
    const browserBadge = browserCheck.querySelector('.badge');
    const isModernBrowser = typeof Promise !== 'undefined' && typeof fetch !== 'undefined';
    
    // Check time synchronization
    const timeCheck = document.getElementById('timeCheck');
    const timeBadge = timeCheck.querySelector('.badge');

    // Internet connection check
    if (navigator.onLine) {
        connectionBadge.textContent = 'Connected';
        connectionBadge.className = 'badge bg-success';
        connectionCheck.querySelector('i').className = 'fas fa-wifi fa-2x text-success mb-2';
    } else {
        connectionBadge.textContent = 'Offline';
        connectionBadge.className = 'badge bg-danger';
        connectionCheck.querySelector('i').className = 'fas fa-wifi fa-2x text-danger mb-2';
    }
    
    // Browser compatibility
    if (isModernBrowser) {
        browserBadge.textContent = 'Supported';
        browserBadge.className = 'badge bg-success';
        browserCheck.querySelector('i').className = 'fas fa-desktop fa-2x text-success mb-2';
    } else {
        browserBadge.textContent = 'Update Required';
        browserBadge.className = 'badge bg-warning';
        browserCheck.querySelector('i').className = 'fas fa-desktop fa-2x text-warning mb-2';
    }
    
    // Time sync
    timeBadge.textContent = 'Synchronized';
    timeBadge.className = 'badge bg-success';
    timeCheck.querySelector('i').className = 'fas fa-clock fa-2x text-success mb-2';
}

// Modal confirmation
document.addEventListener('DOMContentLoaded', function() {
    // Run system check on page load
    runSystemCheck();
    
    // Enable start button when checkbox is checked
    const confirmCheckbox = document.getElementById('confirmInstructions');
    const startExamBtn = document.getElementById('startExamBtn');
    
    if (confirmCheckbox && startExamBtn) {
        confirmCheckbox.addEventListener('change', function() {
            startExamBtn.disabled = !this.checked;
        });
    }
    
    // Add page load animation
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Keyboard shortcut for starting exam
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !document.getElementById('startExamModal').classList.contains('show')) {
            const startBtn = document.querySelector('[data-bs-target="#startExamModal"]');
            if (startBtn) {
                startBtn.click();
            }
        }
    });
});
</script>

<style>
.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
}

.card-header {
    border-bottom: 1px solid #e3e6f0;
}

.border-bottom {
    border-color: #e3e6f0 !important;
}

.alert {
    border: none;
    border-radius: 0.5rem;
}

.btn {
    border-radius: 0.375rem;
    font-weight: 500;
}

.modal-content {
    border: none;
    border-radius: 0.5rem;
    box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175);
}
</style>

<?php require_once '../includes/footer.php'; ?>