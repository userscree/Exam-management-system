<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Available Exams';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];

// Get filter parameters
$course_filter = $_GET['course'] ?? '';
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? 'available'; // Default to available exams
$search = $_GET['search'] ?? '';

try {
    // Get available exams (exams from enrolled courses that are active and within date range)
    $query = "
        SELECT e.*, c.course_code, c.course_name, c.department,
               (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ?) as attempt_count,
               (SELECT status FROM exam_attempts WHERE exam_id = e.id AND student_id = ? ORDER BY started_at DESC LIMIT 1) as attempt_status,
               (SELECT id FROM exam_attempts WHERE exam_id = e.id AND student_id = ? ORDER BY started_at DESC LIMIT 1) as attempt_id
        FROM exams e 
        INNER JOIN enrollments en ON e.course_id = en.course_id 
        INNER JOIN courses c ON e.course_id = c.id 
        WHERE en.student_id = ? 
        AND e.is_active = 1
    ";
    
    $params = [$student_id, $student_id, $student_id, $student_id];
    
    // Apply status filter
    if ($status_filter === 'available') {
        $query .= " AND e.start_date <= NOW() AND e.end_date >= NOW()";
        $query .= " AND ((SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ? AND status IN ('submitted', 'graded')) = 0 OR e.allow_retake = 1)";
        $params[] = $student_id;
    } elseif ($status_filter === 'upcoming') {
        $query .= " AND e.start_date > NOW()";
    } elseif ($status_filter === 'completed') {
        $query .= " AND (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ? AND status IN ('submitted', 'graded')) > 0";
        $params[] = $student_id;
    } elseif ($status_filter === 'expired') {
        $query .= " AND e.end_date < NOW()";
    }
    
    // Apply course filter
    if (!empty($course_filter)) {
        $query .= " AND e.course_id = ?";
        $params[] = $course_filter;
    }
    
    // Apply type filter
    if (!empty($type_filter)) {
        $query .= " AND e.exam_type = ?";
        $params[] = $type_filter;
    }
    
    // Apply search filter
    if (!empty($search)) {
        $query .= " AND (e.title LIKE ? OR e.description LIKE ? OR c.course_name LIKE ? OR c.course_code LIKE ?)";
        $search_term = "%$search%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    // Enhanced ordering - prioritize untaken exams first, then by status and date
    $query .= " ORDER BY 
        CASE 
            WHEN (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ?) = 0 THEN 1
            WHEN (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND student_id = ? AND status IN ('submitted', 'graded')) = 0 THEN 2
            ELSE 3
        END,
        CASE 
            WHEN e.start_date <= NOW() AND e.end_date >= NOW() THEN 1
            WHEN e.start_date > NOW() THEN 2
            ELSE 3
        END,
        e.start_date ASC";
    
    $params[] = $student_id;
    $params[] = $student_id;
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get enrolled courses for filter
    $stmt = $pdo->prepare("
        SELECT c.id, c.course_code, c.course_name 
        FROM courses c
        INNER JOIN enrollments en ON c.id = en.course_id
        WHERE en.student_id = ? AND en.status = 'active'
        ORDER BY c.course_code
    ");
    $stmt->execute([$student_id]);
    $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get exam statistics with better categorization
    $untaken_count = 0;
    $in_progress_count = 0;
    $completed_count = 0;
    $upcoming_count = 0;
    $expired_count = 0;
    
    foreach($exams as $exam) {
        $now = new DateTime();
        $start_date = new DateTime($exam['start_date']);
        $end_date = new DateTime($exam['end_date']);
        
        if ($exam['attempt_count'] == 0) {
            $untaken_count++;
        } elseif ($exam['attempt_status'] && in_array($exam['attempt_status'], ['submitted', 'graded'])) {
            $completed_count++;
        } elseif ($exam['attempt_status'] == 'in_progress') {
            $in_progress_count++;
        } elseif ($end_date < $now) {
            $expired_count++;
        } elseif ($start_date > $now) {
            $upcoming_count++;
        }
    }
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exams: ' . $e->getMessage());
    $exams = [];
    $enrolled_courses = [];
    $untaken_count = $in_progress_count = $completed_count = $upcoming_count = $expired_count = 0;
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1 fw-bold text-primary">Available Exams</h1>
                <p class="text-muted mb-0">Take exams for your enrolled courses</p>
            </div>
            <div class="btn-group">
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-primary shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-primary bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-play-circle fa-lg text-primary"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo $untaken_count; ?></h4>
                <small class="text-muted">New Exams</small>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-warning shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-warning bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-sync-alt fa-lg text-warning"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo $in_progress_count; ?></h4>
                <small class="text-muted">In Progress</small>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-success shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-success bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-check-circle fa-lg text-success"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo $completed_count; ?></h4>
                <small class="text-muted">Completed</small>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-info shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-info bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-clock fa-lg text-info"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo $upcoming_count; ?></h4>
                <small class="text-muted">Upcoming</small>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-secondary shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-secondary bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-hourglass-end fa-lg text-secondary"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo $expired_count; ?></h4>
                <small class="text-muted">Expired</small>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-3">
        <div class="card border-dark shadow-sm h-100 hover-card">
            <div class="card-body text-center p-3">
                <div class="bg-dark bg-opacity-10 p-3 rounded-circle d-inline-flex mb-2">
                    <i class="fas fa-file-alt fa-lg text-dark"></i>
                </div>
                <h4 class="fw-bold text-dark mb-1"><?php echo count($exams); ?></h4>
                <small class="text-muted">Total</small>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Filters Card -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white py-3 border-bottom">
        <div class="d-flex justify-content-between align-items-center">
            <h6 class="card-title mb-0 fw-bold">
                <i class="fas fa-filter me-2 text-primary"></i> Filter Exams
            </h6>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-sm btn-outline-primary" onclick="showAllExams()">
                    <i class="fas fa-eye me-1"></i> Show All
                </button>
                <button type="button" class="btn btn-sm btn-outline-success" onclick="showUntakenExams()">
                    <i class="fas fa-play me-1"></i> New Exams
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="search" class="form-label fw-semibold">Search Exams</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="fas fa-search text-muted"></i>
                    </span>
                    <input type="text" class="form-control border-start-0" id="search" name="search" 
                           placeholder="Search by title, course..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label fw-semibold">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="available" <?php echo $status_filter == 'available' ? 'selected' : ''; ?>>Available Now</option>
                    <option value="upcoming" <?php echo $status_filter == 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                    <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                    <option value="expired" <?php echo $status_filter == 'expired' ? 'selected' : ''; ?>>Expired</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="course" class="form-label fw-semibold">Course</label>
                <select class="form-select" id="course" name="course">
                    <option value="">All Courses</option>
                    <?php foreach($enrolled_courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['course_code']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="type" class="form-label fw-semibold">Type</label>
                <select class="form-select" id="type" name="type">
                    <option value="">All Types</option>
                    <option value="quiz" <?php echo $type_filter == 'quiz' ? 'selected' : ''; ?>>Quiz</option>
                    <option value="midterm" <?php echo $type_filter == 'midterm' ? 'selected' : ''; ?>>Midterm</option>
                    <option value="final" <?php echo $type_filter == 'final' ? 'selected' : ''; ?>>Final</option>
                    <option value="assignment" <?php echo $type_filter == 'assignment' ? 'selected' : ''; ?>>Assignment</option>
                </select>
            </div>
            <div class="col-md-3">
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="fas fa-filter me-2"></i> Apply Filters
                    </button>
                    <a href="take_exam.php" class="btn btn-outline-secondary" title="Reset Filters">
                        <i class="fas fa-redo"></i>
                    </a>
                </div>
            </div>
        </form>
        
        <!-- Quick Status Filters -->
        <div class="row mt-3 pt-3 border-top">
            <div class="col-12">
                <div class="d-flex align-items-center flex-wrap gap-2">
                    <small class="text-muted me-2 fw-semibold">Quick filters:</small>
                    <a href="take_exam.php?status=available" class="btn btn-sm btn-outline-primary <?php echo $status_filter == 'available' ? 'active' : ''; ?>">
                        <i class="fas fa-play-circle me-1"></i> Available
                    </a>
                    <a href="take_exam.php?status=upcoming" class="btn btn-sm btn-outline-info <?php echo $status_filter == 'upcoming' ? 'active' : ''; ?>">
                        <i class="fas fa-clock me-1"></i> Upcoming
                    </a>
                    <a href="take_exam.php?status=completed" class="btn btn-sm btn-outline-success <?php echo $status_filter == 'completed' ? 'active' : ''; ?>">
                        <i class="fas fa-check-circle me-1"></i> Completed
                    </a>
                    <a href="take_exam.php?status=expired" class="btn btn-sm btn-outline-secondary <?php echo $status_filter == 'expired' ? 'active' : ''; ?>">
                        <i class="fas fa-hourglass-end me-1"></i> Expired
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Exams Grid -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 border-bottom">
        <div class="d-flex justify-content-between align-items-center">
            <h6 class="card-title mb-0 fw-bold">
                <i class="fas fa-list me-2 text-primary"></i> 
                <?php 
                $status_titles = [
                    'available' => 'Available Exams',
                    'upcoming' => 'Upcoming Exams', 
                    'completed' => 'Completed Exams',
                    'expired' => 'Expired Exams'
                ];
                echo $status_titles[$status_filter] ?? 'All Exams';
                ?>
                <span class="badge bg-primary ms-2"><?php echo count($exams); ?> exams</span>
            </h6>
            <div class="d-flex align-items-center gap-2">
                <small class="text-muted">Sorted by:</small>
                <select class="form-select form-select-sm w-auto" onchange="sortExams(this.value)">
                    <option value="priority">Priority (New First)</option>
                    <option value="date">Date</option>
                    <option value="course">Course</option>
                    <option value="type">Type</option>
                </select>
            </div>
        </div>
    </div>
    
    <div class="card-body p-0">
        <?php if(empty($exams)): ?>
            <div class="text-center py-5">
                <div class="mb-4">
                    <i class="fas fa-file-alt fa-4x text-muted opacity-50"></i>
                </div>
                <h5 class="text-muted mb-3">No Exams Found</h5>
                <p class="text-muted mb-4">
                    <?php 
                    $no_results_messages = [
                        'available' => 'No exams are currently available. Check back later or view upcoming exams.',
                        'upcoming' => 'No upcoming exams scheduled for your courses.',
                        'completed' => 'You haven\'t completed any exams yet.',
                        'expired' => 'No expired exams found in your courses.'
                    ];
                    echo $no_results_messages[$status_filter] ?? 'No exams found matching your criteria.';
                    ?>
                </p>
                <?php if($status_filter != 'available'): ?>
                    <a href="take_exam.php?status=available" class="btn btn-primary">
                        <i class="fas fa-play-circle me-2"></i> View Available Exams
                    </a>
                <?php else: ?>
                    <div class="d-flex gap-2 justify-content-center">
                        <a href="take_exam.php?status=upcoming" class="btn btn-outline-primary">
                            <i class="fas fa-clock me-2"></i> View Upcoming
                        </a>
                        <a href="take_exam.php?status=completed" class="btn btn-outline-success">
                            <i class="fas fa-check-circle me-2"></i> View Completed
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="exams-container" id="examsContainer">
                <?php foreach($exams as $exam): 
                    $now = new DateTime();
                    $start_date = new DateTime($exam['start_date']);
                    $end_date = new DateTime($exam['end_date']);
                    $is_available = $exam['is_active'] && $now >= $start_date && $now <= $end_date;
                    $is_upcoming = $exam['is_active'] && $now < $start_date;
                    $is_expired = $now > $end_date;
                    $is_completed = $exam['attempt_status'] && in_array($exam['attempt_status'], ['submitted', 'graded']);
                    $is_untaken = $exam['attempt_count'] == 0;
                    $is_in_progress = $exam['attempt_status'] == 'in_progress';
                    $can_retake = $exam['allow_retake'] && $is_completed && $is_available;
                    
                    // Calculate time display
                    $time_display = '';
                    $time_class = 'text-muted';
                    $urgency_level = 'normal';
                    
                    if ($is_available) {
                        $time_remaining = $now->diff($end_date);
                        if ($time_remaining->d > 0) {
                            $time_display = $time_remaining->d . ' days left';
                            $urgency_level = 'low';
                        } elseif ($time_remaining->h > 0) {
                            $time_display = $time_remaining->h . ' hours left';
                            $urgency_level = $time_remaining->h <= 6 ? 'medium' : 'low';
                        } else {
                            $time_display = $time_remaining->i . ' minutes left';
                            $time_class = 'text-danger fw-bold';
                            $urgency_level = 'high';
                        }
                    } elseif ($is_upcoming) {
                        $time_until = $now->diff($start_date);
                        if ($time_until->d > 0) {
                            $time_display = 'Starts in ' . $time_until->d . ' days';
                        } elseif ($time_until->h > 0) {
                            $time_display = 'Starts in ' . $time_until->h . ' hours';
                        } else {
                            $time_display = 'Starts in ' . $time_until->i . ' minutes';
                        }
                    }
                    
                    // Determine card type and priority
                    $card_type = 'default';
                    $priority_badge = '';
                    
                    if ($is_untaken) {
                        $card_type = 'untaken';
                        $priority_badge = '<span class="badge bg-primary priority-badge"><i class="fas fa-star me-1"></i>New</span>';
                    } elseif ($is_in_progress) {
                        $card_type = 'in-progress';
                        $priority_badge = '<span class="badge bg-warning priority-badge"><i class="fas fa-sync-alt me-1"></i>In Progress</span>';
                    } elseif ($is_completed) {
                        $card_type = 'completed';
                    }
                ?>
                    <div class="exam-card-wrapper" data-exam-id="<?php echo $exam['id']; ?>" 
                         data-priority="<?php echo $is_untaken ? '1' : ($is_in_progress ? '2' : '3'); ?>"
                         data-date="<?php echo $exam['start_date']; ?>"
                         data-course="<?php echo htmlspecialchars($exam['course_code']); ?>"
                         data-type="<?php echo $exam['exam_type']; ?>"
                         data-urgency="<?php echo $urgency_level; ?>">
                        <div class="card exam-card h-100 border-0 shadow-sm exam-card-<?php echo $card_type; ?>">
                            <div class="card-body position-relative">
                                <!-- Priority Badge -->
                                <?php if($priority_badge): ?>
                                    <div class="position-absolute top-0 end-0 m-2">
                                        <?php echo $priority_badge; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Header -->
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="flex-grow-1 pe-3">
                                        <h6 class="card-title fw-bold text-dark mb-1 exam-title">
                                            <?php echo htmlspecialchars($exam['title']); ?>
                                        </h6>
                                        <p class="text-muted small mb-2">
                                            <i class="fas fa-book me-1"></i>
                                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['course_name']); ?>
                                        </p>
                                    </div>
                                </div>
                                
                                <!-- Exam Info Grid -->
                                <div class="row g-2 mb-3">
                                    <div class="col-6">
                                        <small class="text-muted d-block">Type</small>
                                        <span class="badge exam-type-<?php echo $exam['exam_type']; ?>">
                                            <i class="fas fa-<?php 
                                                switch($exam['exam_type']) {
                                                    case 'quiz': echo 'bolt'; break;
                                                    case 'midterm': echo 'file-medical'; break;
                                                    case 'final': echo 'file-contract'; break;
                                                    case 'assignment': echo 'tasks'; break;
                                                    default: echo 'file-alt';
                                                }
                                            ?> me-1"></i>
                                            <?php echo ucfirst($exam['exam_type']); ?>
                                        </span>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted d-block">Questions</small>
                                        <span class="fw-semibold"><?php echo $exam['question_count']; ?></span>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted d-block">Duration</small>
                                        <span class="fw-semibold"><?php echo $exam['duration_minutes']; ?> min</span>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted d-block">Total Marks</small>
                                        <span class="fw-semibold"><?php echo $exam['total_marks']; ?></span>
                                    </div>
                                </div>
                                
                                <!-- Time Info with Urgency Indicator -->
                                <?php if($time_display): ?>
                                    <div class="mb-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-clock me-2 <?php echo $time_class; ?>"></i>
                                            <span class="<?php echo $time_class; ?> fw-semibold"><?php echo $time_display; ?></span>
                                            <?php if($urgency_level == 'high'): ?>
                                                <span class="badge bg-danger ms-2 blink">
                                                    <i class="fas fa-exclamation-triangle me-1"></i> Urgent
                                                </span>
                                            <?php elseif($urgency_level == 'medium'): ?>
                                                <span class="badge bg-warning ms-2">
                                                    <i class="fas fa-exclamation-circle me-1"></i> Soon
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Dates -->
                                <div class="small text-muted mb-3">
                                    <div class="mb-1">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        <strong>Starts:</strong> <?php echo formatDate($exam['start_date']); ?>
                                    </div>
                                    <div>
                                        <i class="fas fa-calendar-times me-1"></i>
                                        <strong>Ends:</strong> <?php echo formatDate($exam['end_date']); ?>
                                    </div>
                                </div>
                                
                                <!-- Attempt Info -->
                                <?php if($exam['attempt_count'] > 0): ?>
                                    <div class="alert alert-light border small mb-3">
                                        <i class="fas fa-history me-1 text-primary"></i>
                                        Attempted <?php echo $exam['attempt_count']; ?> time(s)
                                        <?php if($exam['attempt_status']): ?>
                                            • Status: <span class="badge bg-<?php 
                                                echo $exam['attempt_status'] == 'graded' ? 'success' : 
                                                     ($exam['attempt_status'] == 'submitted' ? 'warning' : 
                                                     ($exam['attempt_status'] == 'in_progress' ? 'info' : 'secondary')); 
                                            ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $exam['attempt_status'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Action Button -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="flex-grow-1">
                                        <?php if($is_available && (!$is_completed || $can_retake)): ?>
                                            <a href="exam_instructions.php?exam_id=<?php echo $exam['id']; ?>" 
                                               class="btn btn-success btn-sm w-100 action-btn">
                                                <i class="fas fa-<?php echo $is_untaken ? 'play' : ($is_in_progress ? 'sync-alt' : 'redo'); ?> me-1"></i>
                                                <?php echo $is_untaken ? 'Start Exam' : ($is_in_progress ? 'Continue Exam' : 'Retake Exam'); ?>
                                            </a>
                                        <?php elseif($is_completed): ?>
                                            <a href="my_results.php?exam_id=<?php echo $exam['id']; ?>" 
                                               class="btn btn-outline-primary btn-sm w-100 action-btn">
                                                <i class="fas fa-chart-line me-1"></i> View Results
                                            </a>
                                        <?php elseif($is_upcoming): ?>
                                            <button class="btn btn-outline-secondary btn-sm w-100" disabled>
                                                <i class="fas fa-clock me-1"></i> Coming Soon
                                            </button>
                                        <?php elseif($is_expired): ?>
                                            <button class="btn btn-outline-secondary btn-sm w-100" disabled>
                                                <i class="fas fa-times me-1"></i> Expired
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Exam Settings -->
                                <div class="mt-2 d-flex gap-3 small text-muted">
                                    <?php if($exam['allow_retake']): ?>
                                        <span class="text-success">
                                            <i class="fas fa-redo me-1"></i> Retakes allowed
                                        </span>
                                    <?php endif; ?>
                                    <?php if($exam['show_results_immediately']): ?>
                                        <span class="text-info">
                                            <i class="fas fa-bolt me-1"></i> Instant results
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Stats Footer -->
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card border-0 bg-light">
            <div class="card-body py-3">
                <h6 class="card-title mb-2">
                    <i class="fas fa-info-circle me-2 text-primary"></i> Exam Priority
                </h6>
                <p class="small text-muted mb-0">
                    Exams are sorted with <span class="badge bg-primary">New</span> exams first, followed by <span class="badge bg-warning">In Progress</span>, then completed exams.
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 bg-primary bg-opacity-5">
            <div class="card-body py-3">
                <h6 class="card-title mb-2">
                    <i class="fas fa-lightbulb me-2 text-warning"></i> Pro Tip
                </h6>
                <p class="small text-muted mb-0">
                    Start with untaken exams first. Use the priority badges to identify which exams need your immediate attention.
                </p>
            </div>
        </div>
    </div>
</div>

<style>
/* Enhanced Card Styles */
.hover-card {
    transition: all 0.3s ease;
    cursor: pointer;
}

.hover-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
}

.exam-card {
    transition: all 0.3s ease;
    border: 1px solid #e9ecef;
    margin-bottom: 1rem;
}

.exam-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
    border-color: #4e73df;
}

/* Priority Card Styles */
.exam-card-untaken {
    border-left: 4px solid #4e73df;
    background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
}

.exam-card-in-progress {
    border-left: 4px solid #ffc107;
    background: linear-gradient(135deg, #ffffff 0%, #fffbf0 100%);
}

.exam-card-completed {
    border-left: 4px solid #28a745;
    background: linear-gradient(135deg, #ffffff 0%, #f0fff4 100%);
}

/* Priority Badges */
.priority-badge {
    font-size: 0.65em;
    font-weight: 600;
}

/* Exam type specific badges */
.exam-type-quiz {
    background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
    color: white;
}

.exam-type-midterm {
    background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
    color: white;
}

.exam-type-final {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    color: white;
}

.exam-type-assignment {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
}

/* Status badges */
.bg-success {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
}

.bg-warning {
    background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%) !important;
}

.bg-info {
    background: linear-gradient(135deg, #17a2b8 0%, #138496 100%) !important;
}

.bg-secondary {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%) !important;
}

.bg-primary {
    background: linear-gradient(135deg, #4e73df 0%, #224abe 100%) !important;
}

/* Blinking animation for urgent items */
@keyframes blink {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

.blink {
    animation: blink 1s infinite;
}

/* Exams Grid Layout */
.exams-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
    padding: 1.5rem;
}

/* Action Buttons */
.action-btn {
    transition: all 0.3s ease;
    font-weight: 600;
}

.action-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}

/* Quick Filter Buttons */
.btn-outline-primary.active {
    background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
    color: white;
    border-color: #4e73df;
}

/* Responsive Design */
@media (max-width: 768px) {
    .exams-container {
        grid-template-columns: 1fr;
        gap: 1rem;
        padding: 1rem;
    }
    
    .exam-card-wrapper {
        margin-bottom: 1rem;
    }
    
    .row.g-2 {
        margin: 0 -0.25rem;
    }
    
    .row.g-2 > [class*="col-"] {
        padding: 0 0.25rem;
    }
}

/* Sort and Filter Controls */
.form-select-sm {
    font-size: 0.875rem;
}

/* Card Header Enhancements */
.card-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-bottom: 2px solid #e9ecef;
}

/* Statistics Cards Enhancements */
.card-body.text-center {
    padding: 1rem !important;
}

/* Loading States */
.loading {
    opacity: 0.7;
    pointer-events: none;
}

/* Focus States */
.btn:focus, .form-select:focus, .form-control:focus {
    box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    border-color: #4e73df;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize exam cards with priority highlighting
    initializeExamCards();
    
    // Auto-submit form when filters change
    const filters = ['status', 'course', 'type'];
    filters.forEach(filterId => {
        const element = document.getElementById(filterId);
        if (element) {
            element.addEventListener('change', function() {
                showLoadingState();
                setTimeout(() => this.form.submit(), 300);
            });
        }
    });
    
    // Enhanced search with debouncing
    const searchInput = document.getElementById('search');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 2 || this.value.length === 0) {
                    showLoadingState();
                    this.form.submit();
                }
            }, 800);
        });
    });
    
    // Add hover effects to all cards
    document.querySelectorAll('.exam-card, .hover-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Urgent exam notifications
    highlightUrgentExams();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 'f':
                    e.preventDefault();
                    document.getElementById('search')?.focus();
                    break;
                case 'n':
                    e.preventDefault();
                    showUntakenExams();
                    break;
                case 'a':
                    e.preventDefault();
                    showAllExams();
                    break;
            }
        }
    });
});

function initializeExamCards() {
    // Add visual indicators for different priority levels
    const examCards = document.querySelectorAll('.exam-card-wrapper');
    
    examCards.forEach((card, index) => {
        const priority = card.getAttribute('data-priority');
        const urgency = card.getAttribute('data-urgency');
        
        // Add subtle animation for high priority cards
        if (priority === '1') {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('fade-in');
        }
        
        // Add urgency indicators
        if (urgency === 'high') {
            card.classList.add('urgent-exam');
        }
    });
}

function showLoadingState() {
    const submitBtn = document.querySelector('button[type="submit"]');
    if (submitBtn) {
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
        submitBtn.disabled = true;
        
        // Revert after 5 seconds (safety)
        setTimeout(() => {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }, 5000);
    }
}

function highlightUrgentExams() {
    const urgentExams = document.querySelectorAll('[data-urgency="high"]');
    
    urgentExams.forEach(exam => {
        // Add pulsing effect for very urgent exams
        const timeElement = exam.querySelector('.text-danger');
        if (timeElement) {
            setInterval(() => {
                timeElement.classList.toggle('text-danger');
                timeElement.classList.toggle('text-warning');
            }, 1000);
        }
    });
    
    // Show notification if there are urgent exams
    if (urgentExams.length > 0) {
        showUrgentNotification(urgentExams.length);
    }
}

function showUrgentNotification(count) {
    const existingNotification = document.getElementById('urgentNotification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.id = 'urgentNotification';
    notification.className = 'alert alert-warning alert-dismissible fade show position-fixed top-0 end-0 m-3';
    notification.style.zIndex = '1060';
    notification.innerHTML = `
        <i class="fas fa-exclamation-triangle me-2"></i>
        <strong>${count} urgent exam(s)</strong> need your attention!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 10 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 10000);
}

function showUntakenExams() {
    const url = new URL(window.location.href);
    url.searchParams.set('status', 'available');
    window.location.href = url.toString();
}

function showAllExams() {
    window.location.href = 'take_exam.php';
}

function sortExams(sortBy) {
    const container = document.getElementById('examsContainer');
    const examWrappers = Array.from(container.getElementsByClassName('exam-card-wrapper'));
    
    examWrappers.sort((a, b) => {
        switch(sortBy) {
            case 'priority':
                return parseInt(a.getAttribute('data-priority')) - parseInt(b.getAttribute('data-priority'));
            case 'date':
                return new Date(a.getAttribute('data-date')) - new Date(b.getAttribute('data-date'));
            case 'course':
                return a.getAttribute('data-course').localeCompare(b.getAttribute('data-course'));
            case 'type':
                return a.getAttribute('data-type').localeCompare(b.getAttribute('data-type'));
            default:
                return 0;
        }
    });
    
    // Clear container and re-append sorted items
    container.innerHTML = '';
    examWrappers.forEach(wrapper => {
        container.appendChild(wrapper);
    });
    
    // Show sort confirmation
    showSortFeedback(sortBy);
}

function showSortFeedback(sortBy) {
    const sortNames = {
        'priority': 'Priority',
        'date': 'Date',
        'course': 'Course',
        'type': 'Type'
    };
    
    // Create temporary feedback
    const feedback = document.createElement('div');
    feedback.className = 'alert alert-info alert-dismissible fade show position-fixed bottom-0 start-0 m-3';
    feedback.style.zIndex = '1050';
    feedback.innerHTML = `
        <i class="fas fa-sort me-2"></i>
        Sorted by <strong>${sortNames[sortBy]}</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(feedback);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        if (feedback.parentNode) {
            feedback.remove();
        }
    }, 3000);
}

// Enhanced filter removal
function removeFilter(element) {
    const filterText = element.closest('.badge').textContent.trim();
    const filterType = filterText.split(':')[0].toLowerCase();
    
    const url = new URL(window.location.href);
    
    switch(filterType) {
        case 'search':
            url.searchParams.delete('search');
            break;
        case 'status':
            url.searchParams.set('status', 'available');
            break;
        case 'course':
            url.searchParams.delete('course');
            break;
        case 'type':
            url.searchParams.delete('type');
            break;
    }
    
    window.location.href = url.toString();
}

// Add fade-in animation for new content
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-out;
    }
    
    .exam-card-wrapper {
        opacity: 0;
        animation: fadeIn 0.5s ease-out forwards;
    }
`;
document.head.appendChild(style);
</script>

<?php require_once '../includes/footer.php'; ?>