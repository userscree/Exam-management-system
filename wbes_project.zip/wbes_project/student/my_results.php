<?php
require_once '../includes/auth_check.php';
if (!hasRole('student')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'My Results';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];

// Get filter parameters
$exam_filter = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';

// Get student's exam results
try {
    $query = "
        SELECT 
            r.*,
            ea.started_at,
            ea.submitted_at,
            ea.time_spent_seconds,
            e.title as exam_title,
            e.exam_type,
            e.total_marks,
            e.passing_marks,
            c.course_code,
            c.course_name,
            u.first_name as instructor_first_name,
            u.last_name as instructor_last_name
        FROM results r
        JOIN exam_attempts ea ON r.attempt_id = ea.id
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        JOIN users u ON e.instructor_id = u.id
        WHERE r.student_id = ?
    ";
    
    $params = [$student_id];
    
    // Apply filters
    if (!empty($exam_filter)) {
        $query .= " AND e.id = ?";
        $params[] = $exam_filter;
    }
    
    if (!empty($status_filter)) {
        $query .= " AND r.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($date_from)) {
        $query .= " AND DATE(ea.submitted_at) >= ?";
        $params[] = $date_from;
    }
    
    if (!empty($date_to)) {
        $query .= " AND DATE(ea.submitted_at) <= ?";
        $params[] = $date_to;
    }
    
    if (!empty($search)) {
        $query .= " AND (e.title LIKE ? OR c.course_name LIKE ?)";
        $search_term = "%$search%";
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    $query .= " ORDER BY ea.submitted_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get statistics
    $total_results = count($results);
    $passed_count = 0;
    $failed_count = 0;
    $average_percentage = 0;
    $total_marks_obtained = 0;
    $total_possible_marks = 0;
    
    foreach($results as $result) {
        if ($result['status'] == 'pass') {
            $passed_count++;
        } else {
            $failed_count++;
        }
        $average_percentage += $result['percentage'];
        $total_marks_obtained += $result['obtained_marks'];
        $total_possible_marks += $result['total_marks'];
    }
    
    if ($total_results > 0) {
        $average_percentage = round($average_percentage / $total_results, 2);
        $overall_percentage = round(($total_marks_obtained / $total_possible_marks) * 100, 2);
    }
    
    // Get available exams for filter dropdown
    $stmt = $pdo->prepare("
        SELECT DISTINCT e.id, e.title, c.course_code
        FROM results r
        JOIN exam_attempts ea ON r.attempt_id = ea.id
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY e.title
    ");
    $stmt->execute([$student_id]);
    $available_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent activities
    $stmt = $pdo->prepare("
        SELECT al.* 
        FROM audit_logs al
        WHERE al.user_id = ? 
        AND al.action IN ('exam_started', 'exam_submitted')
        ORDER BY al.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $recent_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    error_log("Database error in my_results.php: " . $e->getMessage());
    setFlash('error', 'Error loading results. Please try again.');
    $results = [];
    $total_results = $passed_count = $failed_count = $average_percentage = $overall_percentage = 0;
    $available_exams = $recent_activities = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">My Exam Results</h1>
                <p class="text-muted mb-0">View your performance across all exams</p>
            </div>
            <a href="take_exam.php" class="btn btn-primary">
                <i class="fas fa-play-circle me-2"></i> Take New Exam
            </a>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Exams Taken
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_results; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-chart-line me-1"></i>
                                <?php echo $passed_count; ?> passed
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Success Rate
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo $total_results > 0 ? round(($passed_count / $total_results) * 100, 1) : 0; ?>%
                        </div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-trophy me-1"></i>
                                Overall performance
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-trophy fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Average Score
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $average_percentage; ?>%</div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-star me-1"></i>
                                Across all exams
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Overall Percentage
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overall_percentage; ?>%</div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-percentage me-1"></i>
                                Total marks obtained
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calculator fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Main Content -->
    <div class="col-lg-8">
        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               placeholder="Search exams..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="exam_id" class="form-label">Exam</label>
                        <select class="form-select" id="exam_id" name="exam_id">
                            <option value="">All Exams</option>
                            <?php foreach($available_exams as $exam): ?>
                                <option value="<?php echo $exam['id']; ?>" 
                                    <?php echo $exam_filter == $exam['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="">All Status</option>
                            <option value="pass" <?php echo $status_filter == 'pass' ? 'selected' : ''; ?>>Passed</option>
                            <option value="fail" <?php echo $status_filter == 'fail' ? 'selected' : ''; ?>>Failed</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="date_from" class="form-label">From Date</label>
                        <input type="date" class="form-control" id="date_from" name="date_from" 
                               value="<?php echo htmlspecialchars($date_from); ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="date_to" class="form-label">To Date</label>
                        <input type="date" class="form-control" id="date_to" name="date_to" 
                               value="<?php echo htmlspecialchars($date_to); ?>">
                    </div>
                    <div class="col-md-1 d-flex align-items-end">
                        <div class="btn-group w-100">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter me-2"></i> Filter
                            </button>
                            <a href="my_results.php" class="btn btn-outline-secondary">
                                <i class="fas fa-redo me-2"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Results Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-list me-2"></i> Exam Results
                    <span class="badge bg-primary ms-2"><?php echo $total_results; ?> results</span>
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($results)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No Results Found</h5>
                        <p class="text-muted">
                            <?php 
                            if (!empty($search) || !empty($exam_filter) || !empty($status_filter)) {
                                echo 'Try adjusting your filters to see more results.';
                            } else {
                                echo 'You haven\'t taken any exams yet.';
                            }
                            ?>
                        </p>
                        <a href="take_exam.php" class="btn btn-primary mt-3">
                            <i class="fas fa-play-circle me-2"></i> Take Your First Exam
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Exam</th>
                                    <th>Course</th>
                                    <th>Score</th>
                                    <th>Grade</th>
                                    <th>Status</th>
                                    <th>Time Spent</th>
                                    <th>Submitted</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($results as $result): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($result['exam_title']); ?></div>
                                            <small class="text-muted"><?php echo ucfirst($result['exam_type']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($result['course_code']); ?></span>
                                            <div class="small text-muted"><?php echo htmlspecialchars($result['course_name']); ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-primary">
                                                <?php echo $result['obtained_marks']; ?>/<?php echo $result['total_marks']; ?>
                                            </div>
                                            <div class="progress" style="height: 6px; width: 100px;">
                                                <div class="progress-bar bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>" 
                                                     style="width: <?php echo $result['percentage']; ?>%"></div>
                                            </div>
                                            <small class="text-muted"><?php echo $result['percentage']; ?>%</small>
                                        </td>
                                        <td>
                                            <span class="badge grade-<?php echo strtolower($result['grade']); ?>">
                                                <?php echo $result['grade']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                <i class="fas fa-<?php echo $result['status'] == 'pass' ? 'check' : 'times'; ?> me-1"></i>
                                                <?php echo ucfirst($result['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php
                                            $hours = floor($result['time_spent_seconds'] / 3600);
                                            $minutes = floor(($result['time_spent_seconds'] % 3600) / 60);
                                            $seconds = $result['time_spent_seconds'] % 60;
                                            
                                            if ($hours > 0) {
                                                echo sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                                            } else {
                                                echo sprintf('%02d:%02d', $minutes, $seconds);
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo formatDate($result['submitted_at']); ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-outline-primary view-details" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#resultDetailsModal"
                                                        data-result='<?php echo json_encode($result); ?>'>
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <a href="result_details.php?attempt_id=<?php echo $result['attempt_id']; ?>" 
                                                   class="btn btn-outline-info" title="View Details">
                                                    <i class="fas fa-info-circle"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Performance Summary -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-pie me-2 text-primary"></i>
                    Performance Summary
                </h5>
            </div>
            <div class="card-body">
                <?php if($total_results > 0): ?>
                    <div class="text-center mb-4">
                        <div class="position-relative d-inline-block">
                            <canvas id="performanceChart" width="150" height="150"></canvas>
                            <div class="position-absolute top-50 start-50 translate-middle">
                                <div class="h4 mb-0 text-primary"><?php echo round(($passed_count / $total_results) * 100); ?>%</div>
                                <small class="text-muted">Success</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="h5 text-success"><?php echo $passed_count; ?></div>
                            <small class="text-muted">Passed</small>
                        </div>
                        <div class="col-6">
                            <div class="h5 text-danger"><?php echo $failed_count; ?></div>
                            <small class="text-muted">Failed</small>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span>Overall Progress</span>
                            <span><?php echo $overall_percentage; ?>%</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: <?php echo $overall_percentage; ?>%"></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-chart-pie fa-2x mb-2"></i>
                        <p>Complete your first exam to see performance data.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Activities -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-history me-2 text-info"></i>
                    Recent Activities
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_activities)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-history fa-2x text-muted mb-3"></i>
                        <p class="text-muted mb-0">No recent activities</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($recent_activities as $activity): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-<?php echo $activity['action'] == 'exam_submitted' ? 'check-circle text-success' : 'play-circle text-primary'; ?> mt-1"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1">
                                            <?php echo $activity['action'] == 'exam_submitted' ? 'Exam Submitted' : 'Exam Started'; ?>
                                        </h6>
                                        <p class="mb-1 small text-muted"><?php echo $activity['description']; ?></p>
                                        <small class="text-muted">
                                            <?php echo formatDate($activity['created_at']); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-tachometer-alt me-2 text-warning"></i>
                    Quick Stats
                </h5>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Best Score</span>
                        <span class="fw-bold text-success">
                            <?php 
                            $best_score = 0;
                            foreach($results as $result) {
                                if ($result['percentage'] > $best_score) {
                                    $best_score = $result['percentage'];
                                }
                            }
                            echo $best_score > 0 ? $best_score . '%' : 'N/A';
                            ?>
                        </span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Average Time</span>
                        <span class="fw-bold text-info">
                            <?php 
                            if ($total_results > 0) {
                                $avg_time = array_sum(array_column($results, 'time_spent_seconds')) / $total_results;
                                $minutes = floor($avg_time / 60);
                                echo $minutes . ' min';
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Exams This Month</span>
                        <span class="fw-bold text-primary">
                            <?php
                            $current_month = date('Y-m');
                            $month_count = 0;
                            foreach($results as $result) {
                                if (date('Y-m', strtotime($result['submitted_at'])) == $current_month) {
                                    $month_count++;
                                }
                            }
                            echo $month_count;
                            ?>
                        </span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span class="text-muted">Improvement Trend</span>
                        <span class="fw-bold text-success">
                            <?php
                            if ($total_results >= 2) {
                                $first_score = $results[count($results)-1]['percentage'];
                                $last_score = $results[0]['percentage'];
                                $trend = $last_score - $first_score;
                                echo ($trend > 0 ? '+' : '') . round($trend, 1) . '%';
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Result Details Modal -->
<div class="modal fade" id="resultDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Result Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="resultDetailsContent">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.grade-a+ { background-color: #28a745; color: white; }
.grade-a { background-color: #28a745; color: white; }
.grade-b { background-color: #17a2b8; color: white; }
.grade-c { background-color: #ffc107; color: #212529; }
.grade-d { background-color: #fd7e14; color: white; }
.grade-f { background-color: #dc3545; color: white; }

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

.view-details:hover {
    background-color: #0d6efd;
    color: white;
}

.card {
    border: none;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Initialize performance chart
document.addEventListener('DOMContentLoaded', function() {
    const passedCount = <?php echo $passed_count; ?>;
    const failedCount = <?php echo $failed_count; ?>;
    
    if (passedCount + failedCount > 0) {
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Passed', 'Failed'],
                datasets: [{
                    data: [passedCount, failedCount],
                    backgroundColor: ['#28a745', '#dc3545'],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Result details modal
    const viewButtons = document.querySelectorAll('.view-details');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const result = JSON.parse(this.getAttribute('data-result'));
            showResultDetails(result);
        });
    });
    
    // Auto-focus search field
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
});

function showResultDetails(result) {
    const content = document.getElementById('resultDetailsContent');
    
    const details = `
        <div class="row">
            <div class="col-md-6">
                <h6>Exam Information</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="40%">Exam:</td>
                        <td><strong>${result.exam_title}</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Course:</td>
                        <td>${result.course_code} - ${result.course_name}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Type:</td>
                        <td>${result.exam_type.charAt(0).toUpperCase() + result.exam_type.slice(1)}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Instructor:</td>
                        <td>${result.instructor_first_name} ${result.instructor_last_name}</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Performance</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="50%">Marks Obtained:</td>
                        <td><strong>${result.obtained_marks}/${result.total_marks}</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Percentage:</td>
                        <td><strong>${result.percentage}%</strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Grade:</td>
                        <td><span class="badge grade-${result.grade.toLowerCase()}">${result.grade}</span></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Status:</td>
                        <td><span class="badge bg-${result.status === 'pass' ? 'success' : 'danger'}">${result.status.charAt(0).toUpperCase() + result.status.slice(1)}</span></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="row mt-3">
            <div class="col-md-6">
                <h6>Timing</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="50%">Started:</td>
                        <td>${new Date(result.started_at).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Submitted:</td>
                        <td>${new Date(result.submitted_at).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Time Spent:</td>
                        <td>
                            ${Math.floor(result.time_spent_seconds / 3600).toString().padStart(2, '0')}:
                            ${Math.floor((result.time_spent_seconds % 3600) / 60).toString().padStart(2, '0')}:
                            ${(result.time_spent_seconds % 60).toString().padStart(2, '0')}
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6>Grading</h6>
                <table class="table table-sm table-borderless">
                    <tr>
                        <td class="text-muted" width="60%">Passing Marks:</td>
                        <td>${result.passing_marks}</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Passing Percentage:</td>
                        <td>${Math.round((result.passing_marks / result.total_marks) * 100)}%</td>
                    </tr>
                    <tr>
                        <td class="text-muted">Margin:</td>
                        <td class="${result.obtained_marks >= result.passing_marks ? 'text-success' : 'text-danger'}">
                            ${result.obtained_marks >= result.passing_marks ? '+' : ''}${result.obtained_marks - result.passing_marks} marks
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="alert alert-${result.status === 'pass' ? 'success' : 'danger'} mt-3">
            <i class="fas fa-${result.status === 'pass' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
            <strong>${result.status === 'pass' ? 'Congratulations!' : 'Keep Practicing!'}</strong>
            ${result.status === 'pass' ? 
                'You passed this exam successfully.' : 
                'You need more practice to pass this exam.'}
        </div>
    `;
    
    content.innerHTML = details;
}

// Export results functionality
function exportResults() {
    // This would typically generate a CSV or PDF export
    alert('Export feature would be implemented here. This could generate a PDF or CSV report of your results.');
}

// Print results
function printResults() {
    window.print();
}
</script>

<?php require_once '../includes/footer.php'; ?>