<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = getUserRole();
    redirect($role . '/dashboard.php');
}

// Check maintenance mode
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'maintenance_mode'");
    $stmt->execute();
    $maintenance_mode = $stmt->fetchColumn();
} catch(PDOException $e) {
    $maintenance_mode = 0;
}

// Check if registration is allowed
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'allow_registration'");
    $stmt->execute();
    $allow_registration = $stmt->fetchColumn();
} catch(PDOException $e) {
    $allow_registration = 1;
}

// Get system name
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'system_name'");
    $stmt->execute();
    $system_name = $stmt->fetchColumn();
} catch(PDOException $e) {
    $system_name = 'Web-Based Examination System';
}

// Get institution name
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'institution_name'");
    $stmt->execute();
    $institution_name = $stmt->fetchColumn();
} catch(PDOException $e) {
    $institution_name = 'WBES University';
}

// Process login form
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember_me']) ? 1 : 0;
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        setFlash('error', 'Please enter both username and password.');
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && verifyPassword($password, $user['password_hash'])) {
                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['user'] = $user;
                $_SESSION['logged_in_at'] = time();
                
                // Set remember me cookie if requested
                if ($remember_me) {
                    $token = bin2hex(random_bytes(32));
                    $expiry = time() + (30 * 24 * 60 * 60); // 30 days
                    
                    setcookie('remember_me', $token, $expiry, '/');
                    
                    // Store token in database
                    $stmt = $pdo->prepare("UPDATE users SET remember_token = ?, token_expiry = ? WHERE id = ?");
                    $stmt->execute([$token, date('Y-m-d H:i:s', $expiry), $user['id']]);
                }
                
                // Log login activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $user['id'],
                    'login',
                    'User logged in successfully',
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Welcome back, ' . $user['first_name'] . '!');
                redirect($user['role'] . '/dashboard.php');
            } else {
                // Log failed login attempt
                $stmt = $pdo->prepare("INSERT INTO audit_logs (action, description, ip_address, user_agent) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    'failed_login',
                    'Failed login attempt for username: ' . $username,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('error', 'Invalid username or password.');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Login failed. Please try again.');
        }
    }
}

// Process forgot password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['forgot_password'])) {
    $email = sanitize($_POST['email']);
    
    if (empty($email)) {
        setFlash('error', 'Please enter your email address.');
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, first_name, username FROM users WHERE email = ? AND is_active = 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Generate reset token (in a real application, you'd send an email)
                $reset_token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', time() + (60 * 60)); // 1 hour
                
                $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?");
                $stmt->execute([$reset_token, $expiry, $user['id']]);
                
                setFlash('success', 'Password reset instructions have been sent to your email.');
            } else {
                setFlash('error', 'No account found with that email address.');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Unable to process password reset. Please try again.');
        }
    }
}

// Set page title for header
$page_title = 'Login - ' . $system_name;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        .login-page {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            
        }
        
        .login-page::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><polygon fill="%23ffffff" fill-opacity="0.05" points="0,1000 1000,0 1000,1000"/></svg>');
            background-size: cover;
        }
        
        .login-container {
            position: relative;
            z-index: 2;
        }
        
        .login-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            overflow: hidden;
            border: 1px solid #e3e6f0;
        }
        
        .login-header {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            color: white;
            padding: 2rem 2rem;
            text-align: center;
            position: relative;
        }
        
        .login-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="white" fill-opacity="0.1"/></svg>');
        }
        
        .institution-logo {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
        }
        
        .login-body {
            padding: 2rem 2rem;
        }
        
        .form-control {
            border-radius: 10px;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d3e2;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            border: none;
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        
        .login-features {
            background: #f8f9fc;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 2rem;
            border: 1px solid #e3e6f0;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.75rem;
            color: #6c757d;
        }
        
        .feature-item i {
            color: #4e73df;
            margin-right: 0.75rem;
            font-size: 1.1rem;
        }
        
        .maintenance-alert {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        
        .floating-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 1;
        }
        
        .shape {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .shape-1 {
            width: 100px;
            height: 100px;
            top: 10%;
            left: 10%;
            animation: float 6s ease-in-out infinite;
        }
        
        .shape-2 {
            width: 150px;
            height: 150px;
            bottom: 20%;
            right: 10%;
            animation: float 8s ease-in-out infinite;
        }
        
        .shape-3 {
            width: 80px;
            height: 80px;
            top: 50%;
            left: 5%;
            animation: float 7s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        .language-switcher {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 3;
        }
        
        .form-check-input:checked {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
        }
        
        .btn-outline-primary {
            color: #4e73df;
            border-color: #4e73df;
        }
        
        .btn-outline-primary:hover {
            background-color: #4e73df;
            border-color: #4e73df;
        }
    </style>
</head>
<body class="login-page">
    <!-- Floating Shapes -->
    <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
    </div>
    
    <!-- Language Switcher -->
    <div class="language-switcher">
        <select class="form-select form-select-sm" style="width: auto; border-radius: 5px;">
            <option value="en">English</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
        </select>
    </div>

    <div class="container login-container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <?php if ($maintenance_mode): ?>
                <div class="maintenance-alert">
                    <i class="fas fa-tools me-2"></i>
                    <strong>System Maintenance</strong>
                    <p class="mb-0 mt-1">The system is currently under maintenance. Please try again later.</p>
                </div>
                <?php endif; ?>
                
                <div class="login-card">
                    <div class="login-header">
                        <div class="institution-logo">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h2 class="mb-2"><?php echo $system_name; ?></h2>
                        <p class="mb-0 opacity-75"><?php echo $institution_name; ?></p>
                    </div>
                    
                    <div class="login-body">
                        <?php if ($maintenance_mode): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-tools fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">System Maintenance</h4>
                                <p class="text-muted">We're currently performing scheduled maintenance. Please check back later.</p>
                            </div>
                        <?php else: ?>
                            <!-- Login Form -->
                            <div id="loginForm">
                                <h4 class="text-center mb-4">Sign In to Your Account</h4>
                                
                                <?php
                                $flash = getFlash();
                                if ($flash): 
                                    $alert_class = $flash['type'] == 'error' ? 'danger' : 'success';
                                ?>
                                    <div class="alert alert-<?php echo $alert_class; ?> alert-dismissible fade show">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-<?php echo $flash['type'] == 'error' ? 'exclamation-triangle' : 'check-circle'; ?> me-2"></i>
                                            <div><?php echo $flash['message']; ?></div>
                                        </div>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST" id="loginFormElement">
                                    <input type="hidden" name="login" value="1">
                                    
                                    <div class="mb-3">
                                        <label for="username" class="form-label">
                                            <i class="fas fa-user me-1"></i> Username
                                        </label>
                                        <input type="text" class="form-control" id="username" name="username" 
                                               placeholder="Enter your username" required
                                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                                        <div class="invalid-feedback">Please enter your username.</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="password" class="form-label">
                                            <i class="fas fa-lock me-1"></i> Password
                                        </label>
                                        <div class="input-group">
                                            <input type="password" class="form-control" id="password" name="password" 
                                                   placeholder="Enter your password" required>
                                            <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                        <div class="invalid-feedback">Please enter your password.</div>
                                    </div>
                                    
                                    <div class="mb-3 form-check">
                                        <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me">
                                        <label class="form-check-label" for="remember_me">Remember me</label>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-login w-100 mb-3">
                                        <i class="fas fa-sign-in-alt me-2"></i> Sign In
                                    </button>
                                    
                                    <div class="text-center">
                                        <a href="#" class="text-decoration-none" onclick="showForgotPassword()">
                                            Forgot your password?
                                        </a>
                                    </div>
                                </form>
                                
                                <?php if ($allow_registration): ?>
                                <div class="text-center mt-4 pt-3 border-top">
                                    <p class="mb-2">Don't have an account?</p>
                                    <a href="register.php" class="btn btn-outline-primary">
                                        <i class="fas fa-user-plus me-2"></i> Create Account
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Forgot Password Form -->
                            <div id="forgotPasswordForm" style="display: none;">
                                <h4 class="text-center mb-4">Reset Your Password</h4>
                                
                                <form method="POST" id="forgotPasswordFormElement">
                                    <input type="hidden" name="forgot_password" value="1">
                                    
                                    <div class="mb-3">
                                        <label for="email" class="form-label">
                                            <i class="fas fa-envelope me-1"></i> Email Address
                                        </label>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               placeholder="Enter your email address" required>
                                        <div class="form-text">We'll send reset instructions to your email.</div>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-paper-plane me-2"></i> Send Reset Instructions
                                        </button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="showLogin()">
                                            <i class="fas fa-arrow-left me-2"></i> Back to Login
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- System Features -->
                            <div class="login-features">
                                <h6 class="text-center mb-3">
                                    <i class="fas fa-star me-2"></i>System Features
                                </h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="feature-item">
                                            <i class="fas fa-shield-alt"></i>
                                            <span>Secure Online Exams</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-clock"></i>
                                            <span>Real-time Timer</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-chart-bar"></i>
                                            <span>Instant Results</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="feature-item">
                                            <i class="fas fa-file-alt"></i>
                                            <span>Multiple Question Types</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-bell"></i>
                                            <span>Notifications</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-mobile-alt"></i>
                                            <span>Mobile Friendly</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Footer -->
                <div class="text-center mt-4">
                    <p class="text-white mb-1">
                        &copy; <?php echo date('Y'); ?> <?php echo $institution_name; ?>. All rights reserved.
                    </p>
                    <div class="text-white opacity-75">
                        <small>
                            <i class="fas fa-shield-alt me-1"></i>Secure Login 
                            <span class="mx-2">•</span>
                            <i class="fas fa-clock me-1"></i>24/7 Access
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        // Toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('#password + .btn i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                toggleIcon.className = 'fas fa-eye';
            }
        }
        
        // Show forgot password form
        function showForgotPassword() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('forgotPasswordForm').style.display = 'block';
        }
        
        // Show login form
        function showLogin() {
            document.getElementById('forgotPasswordForm').style.display = 'none';
            document.getElementById('loginForm').style.display = 'block';
        }
        
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('loginFormElement');
            const forgotForm = document.getElementById('forgotPasswordFormElement');
            
            if (loginForm) {
                loginForm.addEventListener('submit', function(e) {
                    if (!this.checkValidity()) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    this.classList.add('was-validated');
                });
            }
            
            if (forgotForm) {
                forgotForm.addEventListener('submit', function(e) {
                    if (!this.checkValidity()) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    this.classList.add('was-validated');
                });
            }
            
            // Auto-focus username field
            const usernameField = document.getElementById('username');
            if (usernameField) {
                usernameField.focus();
            }
            
            // Add loading state to buttons
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function() {
                    const submitBtn = this.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
                        submitBtn.disabled = true;
                    }
                });
            });
            
            // Check for URL parameters
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('expired')) {
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-warning alert-dismissible fade show';
                alertDiv.innerHTML = `
                    <div class="d-flex align-items-center">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <div>Your session has expired. Please login again.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.getElementById('loginForm').insertBefore(alertDiv, document.getElementById('loginForm').firstChild);
            }
            if (urlParams.has('registered')) {
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-success alert-dismissible fade show';
                alertDiv.innerHTML = `
                    <div class="d-flex align-items-center">
                        <i class="fas fa-check-circle me-2"></i>
                        <div>Registration successful! Please login with your credentials.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.getElementById('loginForm').insertBefore(alertDiv, document.getElementById('loginForm').firstChild);
            }
        });
        
        // Detect browser compatibility
        function checkBrowserCompatibility() {
            const isIE = /*@cc_on!@*/false || !!document.documentMode;
            if (isIE) {
                alert('This system works best with modern browsers like Chrome, Firefox, or Edge.');
            }
        }
        
        // Run compatibility check
        checkBrowserCompatibility();
        
        // Add input animations
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
    </script>
</body>
</html>