class ExamTimer {
    constructor(duration, display, submitForm) {
        this.duration = duration * 60; // Convert to seconds
        this.display = display;
        this.submitForm = submitForm;
        this.timer = null;
        this.startTime = Date.now();
        this.initialize();
    }

    initialize() {
        this.updateDisplay();
        this.start();
    }

    start() {
        this.timer = setInterval(() => {
            this.duration--;
            this.updateDisplay();

            if (this.duration <= 0) {
                this.end();
            } else if (this.duration <= 300) { // 5 minutes warning
                this.display.classList.add('timer-warning');
            }
        }, 1000);
    }

    updateDisplay() {
        const minutes = Math.floor(this.duration / 60);
        const seconds = this.duration % 60;
        
        this.display.textContent = 
            minutes.toString().padStart(2, '0') + ':' + 
            seconds.toString().padStart(2, '0');
    }

    end() {
        clearInterval(this.timer);
        this.display.textContent = '00:00';
        
        // Auto-submit the form
        if (this.submitForm) {
            // Add a hidden field to indicate auto-submit
            const autoSubmitInput = document.createElement('input');
            autoSubmitInput.type = 'hidden';
            autoSubmitInput.name = 'auto_submit';
            autoSubmitInput.value = '1';
            this.submitForm.appendChild(autoSubmitInput);
            
            this.submitForm.submit();
        }
    }

    stop() {
        clearInterval(this.timer);
    }

    getTimeSpent() {
        return Math.floor((Date.now() - this.startTime) / 1000);
    }
}

// Initialize timer if on exam page
document.addEventListener('DOMContentLoaded', function() {
    const timerDisplay = document.getElementById('exam-timer');
    const submitForm = document.getElementById('exam-form');
    
    if (timerDisplay && submitForm) {
        const duration = parseInt(timerDisplay.dataset.duration);
        window.examTimer = new ExamTimer(duration, timerDisplay, submitForm);
    }

    // Auto-save progress every 30 seconds
    if (submitForm) {
        setInterval(() => {
            saveProgress();
        }, 30000);
    }
});

function saveProgress() {
    const form = document.getElementById('exam-form');
    const formData = new FormData(form);
    
    fetch('../process/auto_save.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Progress saved:', new Date().toLocaleTimeString());
        }
    })
    .catch(error => console.error('Auto-save failed:', error));
}