<?php
require_once '../config.php';

if (!isLoggedIn() || !hasRole('admin')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['clear_logs'])) {
    $days_old = intval($_POST['days_old']);
    
    if ($days_old < 1) {
        setFlash('error', 'Invalid number of days specified.');
        redirect('../admin/audit_logs.php');
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->execute([$days_old]);
        $deleted_rows = $stmt->rowCount();
        
        // Log the action
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            'logs_cleared',
            'Cleared ' . $deleted_rows . ' audit logs older than ' . $days_old . ' days',
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
        
        setFlash('success', 'Successfully cleared ' . $deleted_rows . ' audit logs older than ' . $days_old . ' days.');
        
    } catch(PDOException $e) {
        setFlash('error', 'Error clearing audit logs: ' . $e->getMessage());
    }
    
    redirect('../admin/audit_logs.php');
}

// Handle CSV export
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="audit_logs_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV header
    fputcsv($output, ['Timestamp', 'User', 'Action', 'Description', 'IP Address', 'User Agent']);
    
    // Build query based on filters (similar to audit_logs.php)
    $action_filter = $_GET['action'] ?? '';
    $user_filter = $_GET['user'] ?? '';
    $date_from = $_GET['date_from'] ?? '';
    $date_to = $_GET['date_to'] ?? '';
    $search = $_GET['search'] ?? '';
    
    $query = "
        SELECT al.created_at, u.username, u.first_name, u.last_name, al.action, al.description, al.ip_address, al.user_agent
        FROM audit_logs al 
        LEFT JOIN users u ON al.user_id = u.id 
        WHERE 1=1
    ";
    $params = [];
    
    if (!empty($action_filter)) {
        $query .= " AND al.action = ?";
        $params[] = $action_filter;
    }
    
    if (!empty($user_filter)) {
        $query .= " AND al.user_id = ?";
        $params[] = $user_filter;
    }
    
    if (!empty($date_from)) {
        $query .= " AND DATE(al.created_at) >= ?";
        $params[] = $date_from;
    }
    
    if (!empty($date_to)) {
        $query .= " AND DATE(al.created_at) <= ?";
        $params[] = $date_to;
    }
    
    if (!empty($search)) {
        $query .= " AND (al.description LIKE ? OR al.ip_address LIKE ? OR u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
        $search_term = "%$search%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    $query .= " ORDER BY al.created_at DESC";
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $user_display = $row['username'] ? $row['first_name'] . ' ' . $row['last_name'] . ' (@' . $row['username'] . ')' : 'System';
            fputcsv($output, [
                $row['created_at'],
                $user_display,
                $row['action'],
                $row['description'],
                $row['ip_address'],
                $row['user_agent']
            ]);
        }
        
    } catch(PDOException $e) {
        // Handle error - could output error to CSV
        fputcsv($output, ['Error', 'Failed to export logs: ' . $e->getMessage()]);
    }
    
    fclose($output);
    exit;
}
?>