<?php
require_once '../config.php';

// Check if user is logged in and is a student
if (!isLoggedIn() || !hasRole('student')) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$student_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['save_progress'])) {
        // Handle auto-save progress
        $attempt_id = isset($_POST['attempt_id']) ? intval($_POST['attempt_id']) : 0;
        $exam_id = isset($_POST['exam_id']) ? intval($_POST['exam_id']) : 0;
        $answers = isset($_POST['answers']) ? json_decode($_POST['answers'], true) : [];
        
        if ($attempt_id <= 0 || $exam_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid attempt data']);
            exit;
        }
        
        // Verify the attempt belongs to the student
        try {
            $stmt = $pdo->prepare("
                SELECT id FROM exam_attempts 
                WHERE id = ? AND student_id = ? AND exam_id = ? AND status = 'in_progress'
            ");
            $stmt->execute([$attempt_id, $student_id, $exam_id]);
            $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$attempt) {
                echo json_encode(['success' => false, 'message' => 'Invalid exam attempt']);
                exit;
            }
            
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Error verifying attempt: ' . $e->getMessage()]);
            exit;
        }
        
        // Save answers
        try {
            $pdo->beginTransaction();
            
            $saved_count = 0;
            foreach ($answers as $question_id => $answer) {
                $question_id = intval($question_id);
                $student_answer = sanitize($answer);
                
                // Verify the question belongs to the exam
                $stmt = $pdo->prepare("SELECT id FROM questions WHERE id = ? AND exam_id = ?");
                $stmt->execute([$question_id, $exam_id]);
                $question = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($question) {
                    // Check if answer already exists
                    $stmt = $pdo->prepare("SELECT id FROM student_answers WHERE attempt_id = ? AND question_id = ?");
                    $stmt->execute([$attempt_id, $question_id]);
                    $existing_answer = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($existing_answer) {
                        // Update existing answer - reset grading since answer changed
                        $stmt = $pdo->prepare("
                            UPDATE student_answers 
                            SET student_answer = ?, awarded_marks = NULL, is_correct = NULL, 
                                graded_by = NULL, graded_at = NULL, updated_at = NOW() 
                            WHERE attempt_id = ? AND question_id = ?
                        ");
                        $stmt->execute([$student_answer, $attempt_id, $question_id]);
                    } else {
                        // Insert new answer
                        $stmt = $pdo->prepare("
                            INSERT INTO student_answers (attempt_id, question_id, student_answer, created_at, updated_at) 
                            VALUES (?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->execute([$attempt_id, $question_id, $student_answer]);
                    }
                    $saved_count++;
                }
            }
            
            // Update attempted questions count
            $stmt = $pdo->prepare("
                UPDATE exam_attempts 
                SET attempted_questions = (
                    SELECT COUNT(DISTINCT question_id) 
                    FROM student_answers 
                    WHERE attempt_id = ? AND student_answer IS NOT NULL AND student_answer != ''
                )
                WHERE id = ?
            ");
            $stmt->execute([$attempt_id, $attempt_id]);
            
            $pdo->commit();
            
            echo json_encode([
                'success' => true, 
                'message' => 'Progress saved successfully',
                'saved_count' => $saved_count
            ]);
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            error_log("Auto-save error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Error saving progress: ' . $e->getMessage()]);
        }
        
    } elseif (isset($_POST['submit_exam'])) {
        // Handle exam submission
        $attempt_id = isset($_POST['attempt_id']) ? intval($_POST['attempt_id']) : 0;
        $exam_id = isset($_POST['exam_id']) ? intval($_POST['exam_id']) : 0;
        
        if ($attempt_id <= 0 || $exam_id <= 0) {
            setFlash('error', 'Invalid exam submission data.');
            header('Location: ../student/take_exam.php');
            exit;
        }
        
        // Verify the attempt belongs to the student and get exam details
        try {
            $stmt = $pdo->prepare("
                SELECT ea.*, e.title, e.show_results_immediately
                FROM exam_attempts ea
                JOIN exams e ON ea.exam_id = e.id
                WHERE ea.id = ? AND ea.student_id = ? AND ea.exam_id = ?
            ");
            $stmt->execute([$attempt_id, $student_id, $exam_id]);
            $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$attempt) {
                setFlash('error', 'Invalid exam attempt.');
                header('Location: ../student/take_exam.php');
                exit;
            }
            
            // Check if already submitted
            if ($attempt['status'] != 'in_progress') {
                setFlash('error', 'Exam already submitted.');
                header('Location: ../student/my_results.php');
                exit;
            }
            
        } catch(PDOException $e) {
            setFlash('error', 'Error verifying exam attempt: ' . $e->getMessage());
            header('Location: ../student/take_exam.php');
            exit;
        }
        
        // Process submission
        try {
            $pdo->beginTransaction();
            
            // Update ALL answers from the form submission
            if (isset($_POST['answer']) && is_array($_POST['answer'])) {
                foreach ($_POST['answer'] as $question_id => $answer) {
                    $question_id = intval($question_id);
                    $student_answer = sanitize($answer);
                    
                    // Check if answer already exists
                    $stmt = $pdo->prepare("SELECT id FROM student_answers WHERE attempt_id = ? AND question_id = ?");
                    $stmt->execute([$attempt_id, $question_id]);
                    $existing_answer = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($existing_answer) {
                        // Update existing answer and reset grading
                        $stmt = $pdo->prepare("
                            UPDATE student_answers 
                            SET student_answer = ?, awarded_marks = NULL, is_correct = NULL, 
                                graded_by = NULL, graded_at = NULL, updated_at = NOW() 
                            WHERE attempt_id = ? AND question_id = ?
                        ");
                        $stmt->execute([$student_answer, $attempt_id, $question_id]);
                    } else {
                        // Insert new answer
                        $stmt = $pdo->prepare("
                            INSERT INTO student_answers (attempt_id, question_id, student_answer, created_at, updated_at) 
                            VALUES (?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->execute([$attempt_id, $question_id, $student_answer]);
                    }
                }
            }
            
            // Update attempt status
            $stmt = $pdo->prepare("
                UPDATE exam_attempts 
                SET status = 'submitted', submitted_at = NOW(),
                    attempted_questions = (
                        SELECT COUNT(DISTINCT question_id) 
                        FROM student_answers 
                        WHERE attempt_id = ? AND student_answer IS NOT NULL AND student_answer != ''
                    )
                WHERE id = ?
            ");
            $stmt->execute([$attempt_id, $attempt_id]);
            
            // Calculate results
            $result = calculateExamResults($pdo, $attempt_id, $exam_id, $student_id);
            
            if ($result) {
                $pdo->commit();
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $student_id,
                    'exam_submitted',
                    'Submitted exam: ' . $attempt['title'],
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Exam submitted successfully! Results have been calculated.');
                
                // Redirect based on results visibility setting
                if ($attempt['show_results_immediately']) {
                    header('Location: ../student/submit_exam.php?attempt_id=' . $attempt_id);
                } else {
                    header('Location: ../student/my_results.php');
                }
                
            } else {
                $pdo->rollBack();
                setFlash('error', 'Error calculating exam results.');
                header('Location: ../student/take_exam.php');
            }
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            setFlash('error', 'Error submitting exam: ' . $e->getMessage());
            header('Location: ../student/take_exam.php');
        }
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

// Function to calculate exam results

// Function to calculate grade based on percentage
function calculateGrade($percentage) {
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B';
    if ($percentage >= 60) return 'C';
    if ($percentage >= 50) return 'D';
    return 'F';
}

// Function to handle time-up auto submission
function handleTimeUpSubmission($pdo, $attempt_id, $student_id) {
    try {
        $pdo->beginTransaction();
        
        // Get attempt details
        $stmt = $pdo->prepare("
            SELECT ea.*, e.title, e.show_results_immediately 
            FROM exam_attempts ea 
            JOIN exams e ON ea.exam_id = e.id 
            WHERE ea.id = ? AND ea.student_id = ?
        ");
        $stmt->execute([$attempt_id, $student_id]);
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attempt || $attempt['status'] != 'in_progress') {
            return false;
        }
        
        // Update attempt status to time_up
        $stmt = $pdo->prepare("
            UPDATE exam_attempts 
            SET status = 'time_up', submitted_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$attempt_id]);
        
        // Calculate results
        $result = calculateExamResults($pdo, $attempt_id, $attempt['exam_id'], $student_id);
        
        if ($result) {
            $pdo->commit();
            
            // Log activity
            $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $student_id,
                'exam_submitted',
                'Auto-submitted exam (time up): ' . $attempt['title'],
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);
            
            return true;
        } else {
            $pdo->rollBack();
            return false;
        }
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        error_log("Error in time-up submission: " . $e->getMessage());
        return false;
    }
}
function calculateExamResults($pdo, $attempt_id, $exam_id, $student_id) {
    try {
        // Get exam details
        $stmt = $pdo->prepare("SELECT total_marks, passing_marks FROM exams WHERE id = ?");
        $stmt->execute([$exam_id]);
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$exam) {
            error_log("Exam not found: " . $exam_id);
            return false;
        }
        
        // Get all questions for the exam
        $stmt = $pdo->prepare("
            SELECT id, question_type, correct_answer, marks 
            FROM questions 
            WHERE exam_id = ?
        ");
        $stmt->execute([$exam_id]);
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get current student answers
        $stmt = $pdo->prepare("
            SELECT question_id, student_answer 
            FROM student_answers 
            WHERE attempt_id = ?
        ");
        $stmt->execute([$attempt_id]);
        $student_answers = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        $total_obtained = 0;
        $total_marks = $exam['total_marks'];
        
        // Calculate marks for each question
        foreach ($questions as $question) {
            $student_answer = $student_answers[$question['id']] ?? '';
            
            // Reset previous grading for this question
            $stmt = $pdo->prepare("
                UPDATE student_answers 
                SET is_correct = NULL, awarded_marks = NULL, graded_by = NULL, graded_at = NULL
                WHERE attempt_id = ? AND question_id = ?
            ");
            $stmt->execute([$attempt_id, $question['id']]);
            
            if (!empty($student_answer)) {
                $is_correct = false;
                $awarded_marks = 0;
                
                switch ($question['question_type']) {
                    case 'multiple_choice':
                    case 'true_false':
                        if (strtoupper(trim($student_answer)) == strtoupper(trim($question['correct_answer']))) {
                            $is_correct = true;
                            $awarded_marks = $question['marks'];
                            error_log("Question {$question['id']}: Correct - Student: {$student_answer}, Correct: {$question['correct_answer']}");
                        } else {
                            error_log("Question {$question['id']}: Incorrect - Student: {$student_answer}, Correct: {$question['correct_answer']}");
                        }
                        break;
                        
                    case 'short_answer':
                        // For short answer, do basic comparison
                        if (strtolower(trim($student_answer)) == strtolower(trim($question['correct_answer']))) {
                            $is_correct = true;
                            $awarded_marks = $question['marks'];
                        }
                        break;
                        
                    case 'essay':
                        // Essay questions need manual grading
                        $is_correct = null;
                        $awarded_marks = 0;
                        break;
                }
                
                // Update student answer with calculated marks
                $stmt = $pdo->prepare("
                    UPDATE student_answers 
                    SET is_correct = ?, awarded_marks = ?, updated_at = NOW()
                    WHERE attempt_id = ? AND question_id = ?
                ");
                $stmt->execute([$is_correct, $awarded_marks, $attempt_id, $question['id']]);
                
                $total_obtained += $awarded_marks;
            }
        }
        
        // Calculate percentage and grade
        $percentage = $total_marks > 0 ? round(($total_obtained / $total_marks) * 100, 2) : 0;
        $grade = calculateGrade($percentage);
        $status = $total_obtained >= $exam['passing_marks'] ? 'pass' : 'fail';
        
        // Delete existing result and insert new one
        $stmt = $pdo->prepare("DELETE FROM results WHERE attempt_id = ?");
        $stmt->execute([$attempt_id]);
        
        // Insert new result
        $stmt = $pdo->prepare("
            INSERT INTO results (attempt_id, student_id, exam_id, total_marks, obtained_marks, percentage, grade, status, finalized_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $attempt_id, $student_id, $exam_id, $total_marks, $total_obtained, $percentage, $grade, $status
        ]);
        
        error_log("Results calculated - Attempt: $attempt_id, Marks: $total_obtained/$total_marks, Percentage: $percentage%");
        
        return true;
        
    } catch(PDOException $e) {
        error_log("Error calculating exam results: " . $e->getMessage());
        return false;
    }
}
?>