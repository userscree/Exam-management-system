<?php
require_once '../config.php';

// Check if user is logged in and is a student
if (!isLoggedIn() || !hasRole('student')) {
    setFlash('error', 'Unauthorized access.');
    redirect('../index.php');
}

$student_id = $_SESSION['user_id'];
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

if ($exam_id <= 0) {
    setFlash('error', 'Invalid exam selected.');
    redirect('../student/take_exam.php');
}

try {
    // Verify exam exists and retake is allowed
    $stmt = $pdo->prepare("
        SELECT e.*, 
               COUNT(ea.id) as attempt_count
        FROM exams e 
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id AND ea.student_id = ? AND ea.status IN ('submitted', 'graded', 'time_up')
        WHERE e.id = ? AND e.is_active = 1 
        AND e.start_date <= NOW() AND e.end_date >= NOW()
        GROUP BY e.id
    ");
    $stmt->execute([$student_id, $exam_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        setFlash('error', 'Exam not found or not available for retake.');
        redirect('../student/take_exam.php');
    }
    
    // Check retake eligibility
    if ($exam['attempt_count'] > 0 && $exam['allow_retake'] == 0) {
        setFlash('error', 'Retakes are not allowed for this exam.');
        redirect('../student/take_exam.php');
    }
    
    // Check if there's already an in-progress attempt
    $stmt = $pdo->prepare("
        SELECT id FROM exam_attempts 
        WHERE exam_id = ? AND student_id = ? AND status = 'in_progress'
    ");
    $stmt->execute([$exam_id, $student_id]);
    $existing_attempt = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_attempt) {
        // Redirect to existing attempt
        redirect('../student/questions.php?exam_id=' . $exam_id . '&attempt_id=' . $existing_attempt['id']);
    }
    
    // Create new attempt for retake
    $stmt = $pdo->prepare("
        INSERT INTO exam_attempts (student_id, exam_id, started_at, total_questions, status) 
        VALUES (?, ?, NOW(), (SELECT COUNT(*) FROM questions WHERE exam_id = ?), 'in_progress')
    ");
    $stmt->execute([$student_id, $exam_id, $exam_id]);
    $attempt_id = $pdo->lastInsertId();
    
    // Log activity
    $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        $student_id,
        'exam_retake',
        'Started retake for exam: ' . $exam['title'],
        $_SERVER['REMOTE_ADDR'],
        $_SERVER['HTTP_USER_AGENT']
    ]);
    
    setFlash('success', 'Retake started successfully! Good luck!');
    redirect('../student/questions.php?exam_id=' . $exam_id . '&attempt_id=' . $attempt_id);
    
} catch(PDOException $e) {
    setFlash('error', 'Error starting retake: ' . $e->getMessage());
    redirect('../student/take_exam.php');
}
?>