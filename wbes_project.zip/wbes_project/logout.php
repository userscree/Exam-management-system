<?php
require_once 'config.php';

// Destroy session
session_destroy();

// Redirect to login page
setFlash('success', 'You have been logged out successfully.');
redirect('index.php');
?>