<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'My Profile';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$user = getUserData();

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        $file_type = $_FILES['profile_picture']['type'];
        $file_size = $_FILES['profile_picture']['size'];
        
        if (in_array($file_type, $allowed_types) && $file_size <= $max_size) {
            // Generate unique filename
            $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
            $filename = 'profile_' . $student_id . '_' . time() . '.' . $file_extension;
            $upload_path = '../assets/uploads/profiles/' . $filename;
            
            // Create upload directory if it doesn't exist
            if (!is_dir('../assets/uploads/profiles/')) {
                mkdir('../assets/uploads/profiles/', 0755, true);
            }
            
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                // Update database
                try {
                    $stmt = $pdo->prepare("UPDATE users SET profile_picture = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$filename, $student_id]);
                    
                    // Update session
                    $_SESSION['user']['profile_picture'] = $filename;
                    
                    setFlash('success', 'Profile picture updated successfully!');
                    redirect('profile.php');
                } catch(PDOException $e) {
                    setFlash('error', 'Error updating profile picture: ' . $e->getMessage());
                }
            } else {
                setFlash('error', 'Error uploading file. Please try again.');
            }
        } else {
            setFlash('error', 'Invalid file type or size. Please upload JPEG, PNG, or GIF files under 2MB.');
        }
    } else {
        setFlash('error', 'File upload error: ' . $_FILES['profile_picture']['error']);
    }
}

// Handle profile information update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $department = sanitize($_POST['department']);
    $academic_year = sanitize($_POST['academic_year']);
    
    try {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET first_name = ?, last_name = ?, email = ?, phone = ?, department = ?, academic_year = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$first_name, $last_name, $email, $phone, $department, $academic_year, $student_id]);
        
        // Update session data
        $_SESSION['user']['first_name'] = $first_name;
        $_SESSION['user']['last_name'] = $last_name;
        $_SESSION['user']['email'] = $email;
        $_SESSION['user']['phone'] = $phone;
        $_SESSION['user']['department'] = $department;
        $_SESSION['user']['academic_year'] = $academic_year;
        
        setFlash('success', 'Profile updated successfully!');
        redirect('profile.php');
        
    } catch(PDOException $e) {
        setFlash('error', 'Error updating profile: ' . $e->getMessage());
    }
}

// Get departments for dropdown
try {
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_code");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $departments = [];
}

// Get user's enrolled courses with details
try {
    $stmt = $pdo->prepare("
        SELECT c.*, u.first_name as instructor_first_name, u.last_name as instructor_last_name
        FROM courses c 
        INNER JOIN enrollments e ON c.id = e.course_id 
        LEFT JOIN users u ON c.instructor_id = u.id
        WHERE e.student_id = ? AND e.status = 'active'
        ORDER BY c.course_code
    ");
    $stmt->execute([$student_id]);
    $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $enrolled_courses = [];
}

// Get user's exam statistics
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_exams,
            AVG(r.percentage) as average_score,
            MAX(r.percentage) as highest_score,
            MIN(r.percentage) as lowest_score,
            SUM(CASE WHEN r.status = 'pass' THEN 1 ELSE 0 END) as passed_exams,
            SUM(CASE WHEN r.status = 'fail' THEN 1 ELSE 0 END) as failed_exams
        FROM results r
        WHERE r.student_id = ?
    ");
    $stmt->execute([$student_id]);
    $exam_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Format scores
    if ($exam_stats) {
        $exam_stats['average_score'] = round($exam_stats['average_score'] ?? 0, 1);
        $exam_stats['highest_score'] = round($exam_stats['highest_score'] ?? 0, 1);
        $exam_stats['lowest_score'] = round($exam_stats['lowest_score'] ?? 0, 1);
    }
} catch(PDOException $e) {
    $exam_stats = [
        'total_exams' => 0,
        'average_score' => 0,
        'highest_score' => 0,
        'lowest_score' => 0,
        'passed_exams' => 0,
        'failed_exams' => 0
    ];
}

// Get recent exam results
try {
    $stmt = $pdo->prepare("
        SELECT r.*, e.title as exam_title, e.exam_type, c.course_code, c.course_name,
               ea.submitted_at
        FROM results r
        JOIN exam_attempts ea ON r.attempt_id = ea.id
        JOIN exams e ON ea.exam_id = e.id
        JOIN courses c ON e.course_id = c.id
        WHERE r.student_id = ?
        ORDER BY ea.submitted_at DESC
        LIMIT 5
    ");
    $stmt->execute([$student_id]);
    $recent_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $recent_results = [];
}

// Get activity statistics
try {
    // Total login count
    $stmt = $pdo->prepare("SELECT COUNT(*) as login_count FROM audit_logs WHERE user_id = ? AND action = 'login'");
    $stmt->execute([$student_id]);
    $login_count = $stmt->fetchColumn();
    
    // Last login
    $stmt = $pdo->prepare("SELECT created_at FROM audit_logs WHERE user_id = ? AND action = 'login' ORDER BY created_at DESC LIMIT 1,1");
    $stmt->execute([$student_id]);
    $last_login = $stmt->fetchColumn();
    
    // Total exam attempts
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_attempts FROM exam_attempts WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $total_attempts = $stmt->fetchColumn();
    
} catch(PDOException $e) {
    $login_count = 0;
    $last_login = null;
    $total_attempts = 0;
}
?>

<div class="row">
    <!-- Left Column - Profile Information -->
    <div class="col-lg-4">
        <!-- Profile Card -->
        <div class="card mb-4">
            <div class="card-body text-center">
                <!-- Profile Picture -->
                <div class="position-relative d-inline-block mb-3">
                    <div class="profile-picture-container">
                        <?php if(!empty($user['profile_picture'])): ?>
                            <img src="../assets/uploads/profiles/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                 alt="Profile Picture" class="profile-picture rounded-circle" id="profileImage">
                        <?php else: ?>
                            <div class="profile-picture-placeholder rounded-circle d-flex align-items-center justify-content-center bg-primary text-white" id="profileImage">
                                <i class="fas fa-user fa-2x"></i>
                            </div>
                        <?php endif; ?>
                        <button type="button" class="btn btn-primary btn-sm rounded-circle position-absolute bottom-0 end-0" 
                                data-bs-toggle="modal" data-bs-target="#profilePictureModal"
                                style="width: 36px; height: 36px;">
                            <i class="fas fa-camera"></i>
                        </button>
                    </div>
                </div>
                
                <!-- User Information -->
                <h4 class="card-title mb-1"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h4>
                <p class="text-muted mb-2">@<?php echo htmlspecialchars($user['username']); ?></p>
                
                <div class="badge bg-primary mb-3">
                    <i class="fas fa-user-graduate me-1"></i> Student
                </div>
                
                <!-- Quick Stats -->
                <div class="row text-center mt-4">
                    <div class="col-4">
                        <div class="h5 text-primary mb-1"><?php echo $exam_stats['total_exams']; ?></div>
                        <small class="text-muted">Exams</small>
                    </div>
                    <div class="col-4">
                        <div class="h5 text-success mb-1"><?php echo $exam_stats['passed_exams']; ?></div>
                        <small class="text-muted">Passed</small>
                    </div>
                    <div class="col-4">
                        <div class="h5 text-info mb-1"><?php echo $login_count; ?></div>
                        <small class="text-muted">Logins</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic Information -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-graduation-cap me-2 text-success"></i> Academic Info
                </h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Student ID:</strong>
                    <span class="float-end text-muted"><?php echo !empty($user['student_id']) ? htmlspecialchars($user['student_id']) : 'Not assigned'; ?></span>
                </div>
                <div class="mb-3">
                    <strong>University ID:</strong>
                    <span class="float-end text-muted"><?php echo !empty($user['university_id']) ? htmlspecialchars($user['university_id']) : 'Not assigned'; ?></span>
                </div>
                <div class="mb-3">
                    <strong>Department:</strong>
                    <span class="float-end text-muted"><?php echo !empty($user['department']) ? htmlspecialchars($user['department']) : 'Not assigned'; ?></span>
                </div>
                <div class="mb-3">
                    <strong>Academic Year:</strong>
                    <span class="float-end text-muted"><?php echo !empty($user['academic_year']) ? htmlspecialchars($user['academic_year']) : 'Not specified'; ?></span>
                </div>
                <div class="mb-0">
                    <strong>Member Since:</strong>
                    <span class="float-end text-muted"><?php echo formatDate($user['created_at']); ?></span>
                </div>
            </div>
        </div>

        <!-- Performance Summary -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-line me-2 text-warning"></i> Performance
                </h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="h3 text-primary"><?php echo $exam_stats['average_score']; ?>%</div>
                    <small class="text-muted">Average Score</small>
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Highest Score</span>
                        <span class="text-success"><?php echo $exam_stats['highest_score']; ?>%</span>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-success" style="width: <?php echo min($exam_stats['highest_score'], 100); ?>%"></div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Lowest Score</span>
                        <span class="text-danger"><?php echo $exam_stats['lowest_score']; ?>%</span>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-danger" style="width: <?php echo min($exam_stats['lowest_score'], 100); ?>%"></div>
                    </div>
                </div>
                
                <div class="row text-center">
                    <div class="col-6">
                        <div class="h5 text-success"><?php echo $exam_stats['passed_exams']; ?></div>
                        <small class="text-muted">Passed</small>
                    </div>
                    <div class="col-6">
                        <div class="h5 text-danger"><?php echo $exam_stats['failed_exams']; ?></div>
                        <small class="text-muted">Failed</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column - Detailed Information -->
    <div class="col-lg-8">
        <!-- Profile Edit Form -->
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-edit me-2 text-primary"></i> Edit Profile
                </h5>
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#profileForm">
                    <i class="fas fa-chevron-down"></i>
                </button>
            </div>
            <div class="card-body collapse show" id="profileForm">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="first_name" class="form-label">First Name *</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" 
                                       value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="last_name" class="form-label">Last Name *</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" 
                                       value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address *</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="department" class="form-label">Department</label>
                                <select class="form-select" id="department" name="department">
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" 
                                            <?php echo ($user['department'] ?? '') == $dept['department_code'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="academic_year" class="form-label">Academic Year</label>
                                <select class="form-select" id="academic_year" name="academic_year">
                                    <option value="">Select Year</option>
                                    <option value="2023-2024" <?php echo ($user['academic_year'] ?? '') == '2023-2024' ? 'selected' : ''; ?>>2023-2024</option>
                                    <option value="2024-2025" <?php echo ($user['academic_year'] ?? '') == '2024-2025' ? 'selected' : ''; ?>>2024-2025</option>
                                    <option value="2025-2026" <?php echo ($user['academic_year'] ?? '') == '2025-2026' ? 'selected' : ''; ?>>2025-2026</option>
                                    <option value="2026-2027" <?php echo ($user['academic_year'] ?? '') == '2026-2027' ? 'selected' : ''; ?>>2026-2027</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                        <div class="form-text">Username cannot be changed.</div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">Last updated: <?php echo formatDate($user['updated_at'] ?? $user['created_at']); ?></small>
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Enrolled Courses -->
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-book me-2 text-success"></i> Enrolled Courses
                    <span class="badge bg-primary ms-2"><?php echo count($enrolled_courses); ?></span>
                </h5>
                <a href="dashboard.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body">
                <?php if(empty($enrolled_courses)): ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-book-open fa-2x mb-3"></i>
                        <p>No courses enrolled yet.</p>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach($enrolled_courses as $course): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card border h-100">
                                    <div class="card-body">
                                        <h6 class="card-title text-primary"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                        <p class="card-text text-muted small"><?php echo htmlspecialchars($course['course_name']); ?></p>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <i class="fas fa-user-tie me-1"></i>
                                                <?php echo htmlspecialchars($course['instructor_first_name'] . ' ' . $course['instructor_last_name']); ?>
                                            </small>
                                            <span class="badge bg-light text-dark">
                                                <?php echo $course['credits'] ?? 3; ?> credits
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Exam Results -->
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-info"></i> Recent Exam Results
                </h5>
                <a href="my_results.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if(empty($recent_results)): ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-chart-line fa-2x mb-3"></i>
                        <p>No exam results yet.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Exam</th>
                                    <th>Course</th>
                                    <th>Score</th>
                                    <th>Grade</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_results as $result): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($result['exam_title']); ?></div>
                                            <small class="text-muted"><?php echo ucfirst($result['exam_type']); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($result['course_code']); ?></span>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-primary"><?php echo $result['obtained_marks']; ?>/<?php echo $result['total_marks']; ?></div>
                                            <div class="progress" style="height: 6px; width: 80px;">
                                                <div class="progress-bar bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>" 
                                                     style="width: <?php echo $result['percentage']; ?>%"></div>
                                            </div>
                                            <small class="text-muted"><?php echo $result['percentage']; ?>%</small>
                                        </td>
                                        <td>
                                            <span class="badge grade-<?php echo strtolower($result['grade']); ?>">
                                                <?php echo $result['grade']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                <i class="fas fa-<?php echo $result['status'] == 'pass' ? 'check' : 'times'; ?> me-1"></i>
                                                <?php echo ucfirst($result['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted"><?php echo formatDate($result['submitted_at']); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Profile Picture Modal -->
<div class="modal fade" id="profilePictureModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Update Profile Picture</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <!-- Current Profile Picture Preview -->
                    <div class="mb-3">
                        <?php if(!empty($user['profile_picture'])): ?>
                            <img src="../assets/uploads/profiles/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                 alt="Current Profile Picture" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;" id="currentProfilePic">
                        <?php else: ?>
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto" 
                                 style="width: 100px; height: 100px;">
                                <i class="fas fa-user fa-2x"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- File Upload -->
                    <div class="mb-3">
                        <label for="profile_picture" class="form-label">Choose New Picture</label>
                        <input type="file" class="form-control" id="profile_picture" name="profile_picture" accept="image/*">
                        <div class="form-text">
                            Supported formats: JPG, PNG, GIF<br>
                            Max size: 2MB
                        </div>
                    </div>
                    
                    <!-- Preview -->
                    <div id="imagePreview" class="mb-3" style="display: none;">
                        <p class="small text-muted mb-1">Preview:</p>
                        <img id="previewImage" class="rounded-circle" style="width: 80px; height: 80px; object-fit: cover;">
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if(!empty($user['profile_picture'])): ?>
                        <button type="button" class="btn btn-outline-danger me-auto" onclick="removeProfilePicture()">
                            <i class="fas fa-trash me-1"></i> Remove
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Picture</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Remove Profile Picture Confirmation Modal -->
<div class="modal fade" id="removePictureModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">Remove Profile Picture</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <i class="fas fa-exclamation-triangle fa-2x text-warning mb-3"></i>
                <p>Are you sure you want to remove your profile picture?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmRemove">Remove Picture</button>
            </div>
        </div>
    </div>
</div>

<script>
// Profile picture preview
document.getElementById('profile_picture').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('imagePreview');
    const previewImage = document.getElementById('previewImage');
    
    if (file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            preview.style.display = 'block';
        }
        
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
});

// Remove profile picture
function removeProfilePicture() {
    // Close the current modal
    const profileModal = bootstrap.Modal.getInstance(document.getElementById('profilePictureModal'));
    profileModal.hide();
    
    // Show confirmation modal
    const removeModal = new bootstrap.Modal(document.getElementById('removePictureModal'));
    removeModal.show();
}

// Confirm remove profile picture
document.getElementById('confirmRemove').addEventListener('click', function() {
    // In a real application, you would make an AJAX call to remove the profile picture
    // For now, we'll just show a message
    alert('Profile picture removal feature would be implemented here with AJAX.');
    
    // Close the modal
    const removeModal = bootstrap.Modal.getInstance(document.getElementById('removePictureModal'));
    removeModal.hide();
});

// Print profile
function printProfile() {
    window.print();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Add animation to profile picture
    const profileImage = document.getElementById('profileImage');
    if (profileImage) {
        profileImage.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
        });
        
        profileImage.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    }
    
    // Auto-focus first input field
    const firstInput = document.querySelector('input[type="text"], input[type="email"]');
    if (firstInput) {
        firstInput.focus();
    }
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});

// Print styles
const style = document.createElement('style');
style.textContent = `
    @media print {
        .btn, .modal, .collapse, .card-header .btn {
            display: none !important;
        }
        .card {
            border: 1px solid #000 !important;
            break-inside: avoid;
        }
        .card-header {
            background: #f8f9fa !important;
            color: #000 !important;
        }
        .profile-picture-container .btn {
            display: none !important;
        }
    }
`;
document.head.appendChild(style);
</script>

<style>
.profile-picture-container {
    position: relative;
    display: inline-block;
}

.profile-picture {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border: 4px solid #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.profile-picture-placeholder {
    width: 120px;
    height: 120px;
    border: 4px solid #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.profile-picture-container .btn {
    width: 36px;
    height: 36px;
    border: 2px solid #fff;
}

.grade-a+ { background-color: #28a745; color: white; }
.grade-a { background-color: #28a745; color: white; }
.grade-b { background-color: #17a2b8; color: white; }
.grade-c { background-color: #ffc107; color: #212529; }
.grade-d { background-color: #fd7e14; color: white; }
.grade-f { background-color: #dc3545; color: white; }

.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
}

.progress {
    background-color: #e9ecef;
}

.progress-bar {
    transition: width 0.3s ease;
}

.btn {
    border-radius: 0.375rem;
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-1px);
}

.table th {
    border-top: none;
    font-weight: 600;
}

.badge {
    font-size: 0.75em;
}

@media (max-width: 768px) {
    .profile-picture {
        width: 100px;
        height: 100px;
    }
    
    .profile-picture-placeholder {
        width: 100px;
        height: 100px;
    }
    
    .card-body .row {
        margin-left: -0.5rem;
        margin-right: -0.5rem;
    }
    
    .card-body .col-md-6 {
        padding-left: 0.5rem;
        padding-right: 0.5rem;
    }
}

/* Animation for profile updates */
@keyframes highlight {
    0% { background-color: transparent; }
    50% { background-color: #e3f2fd; }
    100% { background-color: transparent; }
}

.highlight-update {
    animation: highlight 2s ease;
}
</style>

<?php require_once '../includes/footer.php'; ?>