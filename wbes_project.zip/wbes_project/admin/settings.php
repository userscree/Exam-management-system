<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'System Settings';
require_once '../includes/header.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_general_settings'])) {
        // Update general settings
        $system_name = sanitize($_POST['system_name']);
        $institution_name = sanitize($_POST['institution_name']);
        $institution_logo = $_POST['institution_logo'];
        $contact_email = sanitize($_POST['contact_email']);
        $timezone = sanitize($_POST['timezone']);
        $date_format = sanitize($_POST['date_format']);
        $items_per_page = intval($_POST['items_per_page']);
        
        try {
            $settings = [
                'system_name' => $system_name,
                'institution_name' => $institution_name,
                'institution_logo' => $institution_logo,
                'contact_email' => $contact_email,
                'timezone' => $timezone,
                'date_format' => $date_format,
                'items_per_page' => $items_per_page
            ];
            
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            
            setFlash('success', 'General settings updated successfully!');
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating settings: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_security_settings'])) {
        // Update security settings
        $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
        $allow_registration = isset($_POST['allow_registration']) ? 1 : 0;
        $require_email_verification = isset($_POST['require_email_verification']) ? 1 : 0;
        $max_login_attempts = intval($_POST['max_login_attempts']);
        $session_timeout = intval($_POST['session_timeout']);
        $password_min_length = intval($_POST['password_min_length']);
        $password_require_special = isset($_POST['password_require_special']) ? 1 : 0;
        $password_require_numbers = isset($_POST['password_require_numbers']) ? 1 : 0;
        $password_require_uppercase = isset($_POST['password_require_uppercase']) ? 1 : 0;
        
        try {
            $settings = [
                'maintenance_mode' => $maintenance_mode,
                'allow_registration' => $allow_registration,
                'require_email_verification' => $require_email_verification,
                'max_login_attempts' => $max_login_attempts,
                'session_timeout' => $session_timeout,
                'password_min_length' => $password_min_length,
                'password_require_special' => $password_require_special,
                'password_require_numbers' => $password_require_numbers,
                'password_require_uppercase' => $password_require_uppercase
            ];
            
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            
            setFlash('success', 'Security settings updated successfully!');
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating security settings: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_exam_settings'])) {
        // Update exam settings
        $default_exam_duration = intval($_POST['default_exam_duration']);
        $default_total_marks = intval($_POST['default_total_marks']);
        $default_passing_percentage = intval($_POST['default_passing_percentage']);
        $allow_retake_default = isset($_POST['allow_retake_default']) ? 1 : 0;
        $show_results_default = isset($_POST['show_results_default']) ? 1 : 0;
        $max_attempts = intval($_POST['max_attempts']);
        $auto_submit = isset($_POST['auto_submit']) ? 1 : 0;
        $shuffle_questions = isset($_POST['shuffle_questions']) ? 1 : 0;
        $shuffle_options = isset($_POST['shuffle_options']) ? 1 : 0;
        
        try {
            $settings = [
                'default_exam_duration' => $default_exam_duration,
                'default_total_marks' => $default_total_marks,
                'default_passing_percentage' => $default_passing_percentage,
                'allow_retake_default' => $allow_retake_default,
                'show_results_default' => $show_results_default,
                'max_attempts' => $max_attempts,
                'auto_submit' => $auto_submit,
                'shuffle_questions' => $shuffle_questions,
                'shuffle_options' => $shuffle_options
            ];
            
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            
            setFlash('success', 'Exam settings updated successfully!');
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam settings: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_notification_settings'])) {
        // Update notification settings
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        $exam_reminder = isset($_POST['exam_reminder']) ? 1 : 0;
        $exam_reminder_hours = intval($_POST['exam_reminder_hours']);
        $result_notification = isset($_POST['result_notification']) ? 1 : 0;
        $system_announcements = isset($_POST['system_announcements']) ? 1 : 0;
        $new_user_notification = isset($_POST['new_user_notification']) ? 1 : 0;
        
        try {
            $settings = [
                'email_notifications' => $email_notifications,
                'exam_reminder' => $exam_reminder,
                'exam_reminder_hours' => $exam_reminder_hours,
                'result_notification' => $result_notification,
                'system_announcements' => $system_announcements,
                'new_user_notification' => $new_user_notification
            ];
            
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$key, $value, $value]);
            }
            
            setFlash('success', 'Notification settings updated successfully!');
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating notification settings: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['clear_cache'])) {
        // Clear system cache
        try {
            // Clear session data (except current session)
            $stmt = $pdo->prepare("DELETE FROM sessions WHERE last_activity < ?");
            $stmt->execute([time() - 3600]); // Delete sessions older than 1 hour
            
            // Clear temporary files
            $temp_dir = '../assets/temp/';
            if (is_dir($temp_dir)) {
                $files = glob($temp_dir . '*');
                foreach ($files as $file) {
                    if (is_file($file)) {
                        unlink($file);
                    }
                }
            }
            
            setFlash('success', 'System cache cleared successfully!');
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error clearing cache: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['backup_database'])) {
        // Backup database
        try {
            $backup_file = '../backups/db_backup_' . date('Y-m-d_H-i-s') . '.sql';
            $backup_dir = dirname($backup_file);
            
            if (!is_dir($backup_dir)) {
                mkdir($backup_dir, 0755, true);
            }
            
            // Simple backup - in production, use mysqldump command
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            $backup_content = "";
            
            foreach ($tables as $table) {
                $backup_content .= "-- Table: $table\n";
                $backup_content .= "DROP TABLE IF EXISTS `$table`;\n";
                
                $create_table = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
                $backup_content .= $create_table['Create Table'] . ";\n\n";
                
                $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
                if (count($rows) ){
                    $columns = array_keys($rows[0]);
                    $backup_content .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES \n";
                    
                    $values = [];
                    foreach ($rows as $row) {
                        $row_values = array_map(function($value) {
                            if ($value === null) return 'NULL';
                            return "'" . addslashes($value) . "'";
                        }, $row);
                        $values[] = "(" . implode(', ', $row_values) . ")";
                    }
                    $backup_content .= implode(",\n", $values) . ";\n\n";
                }
            }
            
            file_put_contents($backup_file, $backup_content);
            
            setFlash('success', 'Database backup created successfully! File: ' . basename($backup_file));
            redirect('settings.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error creating database backup: ' . $e->getMessage());
        }
    }
}

// Load current settings
try {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings");
    $stmt->execute();
    $settings_result = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Set default values if settings don't exist
    $settings = array_merge([
        'system_name' => 'Web-Based Examination System',
        'institution_name' => 'WBES University',
        'institution_logo' => 'assets/images/logo.png',
        'contact_email' => 'admin@wbes.edu',
        'timezone' => 'UTC',
        'date_format' => 'Y-m-d H:i:s',
        'items_per_page' => '20',
        'maintenance_mode' => '0',
        'allow_registration' => '1',
        'require_email_verification' => '0',
        'max_login_attempts' => '5',
        'session_timeout' => '3600',
        'password_min_length' => '8',
        'password_require_special' => '1',
        'password_require_numbers' => '1',
        'password_require_uppercase' => '1',
        'default_exam_duration' => '60',
        'default_total_marks' => '100',
        'default_passing_percentage' => '50',
        'allow_retake_default' => '0',
        'show_results_default' => '1',
        'max_attempts' => '3',
        'auto_submit' => '1',
        'shuffle_questions' => '0',
        'shuffle_options' => '0',
        'email_notifications' => '1',
        'exam_reminder' => '1',
        'exam_reminder_hours' => '24',
        'result_notification' => '1',
        'system_announcements' => '1',
        'new_user_notification' => '1'
    ], $settings_result);
    
} catch(PDOException $e) {
    setFlash('error', 'Error loading settings: ' . $e->getMessage());
    $settings = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">System Settings</h1>
                <p class="text-muted mb-0">Configure system-wide settings and preferences</p>
            </div>
            <div class="btn-group">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#backupModal">
                    <i class="fas fa-database me-2"></i> Backup Database
                </button>
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#cacheModal">
                    <i class="fas fa-broom me-2"></i> Clear Cache
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Settings Navigation -->
<div class="card mb-4">
    <div class="card-body">
        <ul class="nav nav-pills nav-fill" id="settingsTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button" role="tab">
                    <i class="fas fa-cog me-2"></i> General
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button" role="tab">
                    <i class="fas fa-shield-alt me-2"></i> Security
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="exam-tab" data-bs-toggle="tab" data-bs-target="#exam" type="button" role="tab">
                    <i class="fas fa-file-alt me-2"></i> Exam Settings
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="notifications-tab" data-bs-toggle="tab" data-bs-target="#notifications" type="button" role="tab">
                    <i class="fas fa-bell me-2"></i> Notifications
                </button>
            </li>
        </ul>
    </div>
</div>

<div class="tab-content" id="settingsTabContent">
    <!-- General Settings Tab -->
    <div class="tab-pane fade show active" id="general" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-cog me-2 text-primary"></i> General Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="system_name" class="form-label">System Name *</label>
                                <input type="text" class="form-control" id="system_name" name="system_name" 
                                       value="<?php echo htmlspecialchars($settings['system_name']); ?>" required>
                                <div class="form-text">The name displayed throughout the system</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="institution_name" class="form-label">Institution Name *</label>
                                <input type="text" class="form-control" id="institution_name" name="institution_name" 
                                       value="<?php echo htmlspecialchars($settings['institution_name']); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="contact_email" class="form-label">Contact Email *</label>
                                <input type="email" class="form-control" id="contact_email" name="contact_email" 
                                       value="<?php echo htmlspecialchars($settings['contact_email']); ?>" required>
                                <div class="form-text">Primary contact email for system notifications</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="timezone" class="form-label">Timezone *</label>
                                <select class="form-select" id="timezone" name="timezone" required>
                                    <option value="UTC" <?php echo $settings['timezone'] == 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                    <option value="America/New_York" <?php echo $settings['timezone'] == 'America/New_York' ? 'selected' : ''; ?>>Eastern Time (ET)</option>
                                    <option value="America/Chicago" <?php echo $settings['timezone'] == 'America/Chicago' ? 'selected' : ''; ?>>Central Time (CT)</option>
                                    <option value="America/Denver" <?php echo $settings['timezone'] == 'America/Denver' ? 'selected' : ''; ?>>Mountain Time (MT)</option>
                                    <option value="America/Los_Angeles" <?php echo $settings['timezone'] == 'America/Los_Angeles' ? 'selected' : ''; ?>>Pacific Time (PT)</option>
                                    <option value="Europe/London" <?php echo $settings['timezone'] == 'Europe/London' ? 'selected' : ''; ?>>London</option>
                                    <option value="Europe/Paris" <?php echo $settings['timezone'] == 'Europe/Paris' ? 'selected' : ''; ?>>Paris</option>
                                    <option value="Asia/Tokyo" <?php echo $settings['timezone'] == 'Asia/Tokyo' ? 'selected' : ''; ?>>Tokyo</option>
                                    <option value="Asia/Kolkata" <?php echo $settings['timezone'] == 'Asia/Kolkata' ? 'selected' : ''; ?>>India</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="date_format" class="form-label">Date Format *</label>
                                <select class="form-select" id="date_format" name="date_format" required>
                                    <option value="Y-m-d" <?php echo $settings['date_format'] == 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD (2023-12-25)</option>
                                    <option value="d/m/Y" <?php echo $settings['date_format'] == 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY (25/12/2023)</option>
                                    <option value="m/d/Y" <?php echo $settings['date_format'] == 'm/d/Y' ? 'selected' : ''; ?>>MM/DD/YYYY (12/25/2023)</option>
                                    <option value="d M Y" <?php echo $settings['date_format'] == 'd M Y' ? 'selected' : ''; ?>>DD Mon YYYY (25 Dec 2023)</option>
                                    <option value="M d, Y" <?php echo $settings['date_format'] == 'M d, Y' ? 'selected' : ''; ?>>Mon DD, YYYY (Dec 25, 2023)</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="items_per_page" class="form-label">Items Per Page *</label>
                                <select class="form-select" id="items_per_page" name="items_per_page" required>
                                    <option value="10" <?php echo $settings['items_per_page'] == '10' ? 'selected' : ''; ?>>10 items</option>
                                    <option value="20" <?php echo $settings['items_per_page'] == '20' ? 'selected' : ''; ?>>20 items</option>
                                    <option value="50" <?php echo $settings['items_per_page'] == '50' ? 'selected' : ''; ?>>50 items</option>
                                    <option value="100" <?php echo $settings['items_per_page'] == '100' ? 'selected' : ''; ?>>100 items</option>
                                </select>
                                <div class="form-text">Number of items to display per page in lists</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="institution_logo" class="form-label">Institution Logo URL</label>
                        <input type="text" class="form-control" id="institution_logo" name="institution_logo" 
                               value="<?php echo htmlspecialchars($settings['institution_logo']); ?>">
                        <div class="form-text">Path to institution logo image file</div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_general_settings" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Save General Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Security Settings Tab -->
    <div class="tab-pane fade" id="security" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-shield-alt me-2 text-success"></i> Security Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" value="1" 
                                           <?php echo $settings['maintenance_mode'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="maintenance_mode">
                                        <strong>Maintenance Mode</strong>
                                    </label>
                                    <div class="form-text">When enabled, only administrators can access the system</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allow_registration" name="allow_registration" value="1" 
                                           <?php echo $settings['allow_registration'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="allow_registration">
                                        <strong>Allow User Registration</strong>
                                    </label>
                                    <div class="form-text">Allow new users to register accounts</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="require_email_verification" name="require_email_verification" value="1" 
                                           <?php echo $settings['require_email_verification'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="require_email_verification">
                                        <strong>Require Email Verification</strong>
                                    </label>
                                    <div class="form-text">Require users to verify their email address</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="max_login_attempts" class="form-label">Maximum Login Attempts *</label>
                                <input type="number" class="form-control" id="max_login_attempts" name="max_login_attempts" 
                                       value="<?php echo $settings['max_login_attempts']; ?>" min="1" max="10" required>
                                <div class="form-text">Number of failed login attempts before account lockout</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="session_timeout" class="form-label">Session Timeout (seconds) *</label>
                                <input type="number" class="form-control" id="session_timeout" name="session_timeout" 
                                       value="<?php echo $settings['session_timeout']; ?>" min="300" max="86400" required>
                                <div class="form-text">Time before automatic logout due to inactivity</div>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    <h6 class="text-primary mb-3">
                        <i class="fas fa-key me-2"></i> Password Requirements
                    </h6>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="password_min_length" class="form-label">Minimum Password Length *</label>
                                <input type="number" class="form-control" id="password_min_length" name="password_min_length" 
                                       value="<?php echo $settings['password_min_length']; ?>" min="6" max="20" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Password Complexity</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="password_require_uppercase" name="password_require_uppercase" value="1" 
                                           <?php echo $settings['password_require_uppercase'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="password_require_uppercase">
                                        Require uppercase letters (A-Z)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="password_require_numbers" name="password_require_numbers" value="1" 
                                           <?php echo $settings['password_require_numbers'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="password_require_numbers">
                                        Require numbers (0-9)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="password_require_special" name="password_require_special" value="1" 
                                           <?php echo $settings['password_require_special'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="password_require_special">
                                        Require special characters (!@#$%^&*)
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_security_settings" class="btn btn-success">
                            <i class="fas fa-save me-2"></i> Save Security Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Exam Settings Tab -->
    <div class="tab-pane fade" id="exam" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-file-alt me-2 text-info"></i> Exam Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="default_exam_duration" class="form-label">Default Exam Duration (minutes) *</label>
                                <input type="number" class="form-control" id="default_exam_duration" name="default_exam_duration" 
                                       value="<?php echo $settings['default_exam_duration']; ?>" min="5" max="480" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="default_total_marks" class="form-label">Default Total Marks *</label>
                                <input type="number" class="form-control" id="default_total_marks" name="default_total_marks" 
                                       value="<?php echo $settings['default_total_marks']; ?>" min="10" max="500" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="default_passing_percentage" class="form-label">Default Passing Percentage *</label>
                                <input type="number" class="form-control" id="default_passing_percentage" name="default_passing_percentage" 
                                       value="<?php echo $settings['default_passing_percentage']; ?>" min="0" max="100" required>
                                <div class="form-text">Minimum percentage required to pass an exam</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="max_attempts" class="form-label">Maximum Attempts *</label>
                                <input type="number" class="form-control" id="max_attempts" name="max_attempts" 
                                       value="<?php echo $settings['max_attempts']; ?>" min="1" max="10" required>
                                <div class="form-text">Maximum number of attempts allowed per exam</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allow_retake_default" name="allow_retake_default" value="1" 
                                           <?php echo $settings['allow_retake_default'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="allow_retake_default">
                                        <strong>Allow Retake by Default</strong>
                                    </label>
                                    <div class="form-text">Allow students to retake exams (subject to maximum attempts)</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="show_results_default" name="show_results_default" value="1" 
                                           <?php echo $settings['show_results_default'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="show_results_default">
                                        <strong>Show Results Immediately</strong>
                                    </label>
                                    <div class="form-text">Show results to students immediately after submission</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="auto_submit" name="auto_submit" value="1" 
                                           <?php echo $settings['auto_submit'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="auto_submit">
                                        <strong>Auto-Submit on Timeout</strong>
                                    </label>
                                    <div class="form-text">Automatically submit exam when time expires</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="shuffle_questions" name="shuffle_questions" value="1" 
                                           <?php echo $settings['shuffle_questions'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="shuffle_questions">
                                        <strong>Shuffle Questions</strong>
                                    </label>
                                    <div class="form-text">Display questions in random order</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="shuffle_options" name="shuffle_options" value="1" 
                                           <?php echo $settings['shuffle_options'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="shuffle_options">
                                        <strong>Shuffle Options</strong>
                                    </label>
                                    <div class="form-text">Display multiple choice options in random order</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_exam_settings" class="btn btn-info">
                            <i class="fas fa-save me-2"></i> Save Exam Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Notification Settings Tab -->
    <div class="tab-pane fade" id="notifications" role="tabpanel">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-bell me-2 text-warning"></i> Notification Settings
                </h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" value="1" 
                                   <?php echo $settings['email_notifications'] == '1' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="email_notifications">
                                <strong>Enable Email Notifications</strong>
                            </label>
                            <div class="form-text">Send notifications via email when enabled</div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="exam_reminder" name="exam_reminder" value="1" 
                                           <?php echo $settings['exam_reminder'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="exam_reminder">
                                        <strong>Exam Reminder Notifications</strong>
                                    </label>
                                    <div class="form-text">Send reminders for upcoming exams</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="exam_reminder_hours" class="form-label">Reminder Hours Before Exam</label>
                                <input type="number" class="form-control" id="exam_reminder_hours" name="exam_reminder_hours" 
                                       value="<?php echo $settings['exam_reminder_hours']; ?>" min="1" max="168">
                                <div class="form-text">Send reminder this many hours before exam starts</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="result_notification" name="result_notification" value="1" 
                                           <?php echo $settings['result_notification'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="result_notification">
                                        <strong>Result Notifications</strong>
                                    </label>
                                    <div class="form-text">Notify students when results are available</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="system_announcements" name="system_announcements" value="1" 
                                           <?php echo $settings['system_announcements'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="system_announcements">
                                        <strong>System Announcements</strong>
                                    </label>
                                    <div class="form-text">Send system-wide announcements and updates</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="new_user_notification" name="new_user_notification" value="1" 
                                           <?php echo $settings['new_user_notification'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="new_user_notification">
                                        <strong>New User Notifications</strong>
                                    </label>
                                    <div class="form-text">Notify administrators when new users register</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-end">
                        <button type="submit" name="update_notification_settings" class="btn btn-warning">
                            <i class="fas fa-save me-2"></i> Save Notification Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Backup Database Modal -->
<div class="modal fade" id="backupModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Backup Database</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-database fa-3x text-primary mb-3"></i>
                        <h5>Create Database Backup</h5>
                        <p class="text-muted">This will create a complete backup of your database.</p>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        The backup file will be saved in the <code>backups/</code> directory with timestamp.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="backup_database" class="btn btn-primary">
                        <i class="fas fa-download me-2"></i> Create Backup
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Clear Cache Modal -->
<div class="modal fade" id="cacheModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Clear System Cache</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-broom fa-3x text-warning mb-3"></i>
                        <h5>Clear System Cache</h5>
                        <p class="text-muted">This will clear temporary files and expired sessions.</p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This action will remove temporary session data and cache files.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="clear_cache" class="btn btn-warning">
                        <i class="fas fa-broom me-2"></i> Clear Cache
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tab functionality
    const settingsTabs = document.getElementById('settingsTabs');
    if (settingsTabs) {
        const tab = new bootstrap.Tab(settingsTabs.querySelector('.nav-link.active'));
    }
    
    // Password requirements validation
    const passwordMinLength = document.getElementById('password_min_length');
    if (passwordMinLength) {
        passwordMinLength.addEventListener('change', function() {
            if (this.value < 6) {
                alert('Minimum password length should be at least 6 characters for security.');
                this.value = 6;
            }
        });
    }
    
    // Session timeout validation
    const sessionTimeout = document.getElementById('session_timeout');
    if (sessionTimeout) {
        sessionTimeout.addEventListener('change', function() {
            if (this.value < 300) {
                alert('Session timeout should be at least 5 minutes (300 seconds).');
                this.value = 300;
            }
        });
    }
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });
    
    // Settings preview
    const systemName = document.getElementById('system_name');
    const pageTitle = document.querySelector('title');
    
    if (systemName && pageTitle) {
        systemName.addEventListener('input', function() {
            const baseTitle = pageTitle.textContent.replace(/^[^-]* - /, '');
            pageTitle.textContent = this.value + ' - ' + baseTitle;
        });
    }
});
</script>

<style>
.nav-pills .nav-link {
    color: #6c757d;
    font-weight: 500;
    border-radius: 0.5rem;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
}

.nav-pills .nav-link.active {
    background-color: #4e73df;
    color: white;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.nav-pills .nav-link:hover:not(.active) {
    background-color: #f8f9fa;
    color: #4e73df;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.form-switch .form-check-input {
    width: 3em;
    height: 1.5em;
}

.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
}

.card-header {
    border-bottom: 2px solid #e3e6f0;
    background-color: #f8f9fc;
}

.tab-pane {
    animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.form-text {
    font-size: 0.875rem;
}

hr {
    border-top: 2px solid #e3e6f0;
    opacity: 1;
}

.text-primary {
    color: #4e73df !important;
}

.text-success {
    color: #1cc88a !important;
}

.text-info {
    color: #36b9cc !important;
}

.text-warning {
    color: #f6c23e !important;
}
</style>

<?php require_once '../includes/footer.php'; ?>