<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Audit Logs';
require_once '../includes/header.php';

// Handle filter parameters
$action_filter = $_GET['action'] ?? '';
$user_filter = $_GET['user'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 50;
$offset = ($page - 1) * $limit;

// Build query for audit logs - FIXED VERSION
$query = "
    SELECT al.*, u.username, u.first_name, u.last_name, u.role
    FROM audit_logs al 
    LEFT JOIN users u ON al.user_id = u.id 
    WHERE 1=1
";
$params = [];
$count_params = [];

if (!empty($action_filter)) {
    $query .= " AND al.action = ?";
    $params[] = $action_filter;
    $count_params[] = $action_filter;
}

if (!empty($user_filter)) {
    $query .= " AND al.user_id = ?";
    $params[] = $user_filter;
    $count_params[] = $user_filter;
}

if (!empty($date_from)) {
    $query .= " AND DATE(al.created_at) >= ?";
    $params[] = $date_from;
    $count_params[] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND DATE(al.created_at) <= ?";
    $params[] = $date_to;
    $count_params[] = $date_to;
}

if (!empty($search)) {
    $query .= " AND (al.description LIKE ? OR al.ip_address LIKE ? OR u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
}

// FIXED: Append LIMIT and OFFSET without parameter binding
$query .= " ORDER BY al.created_at DESC LIMIT $limit OFFSET $offset";

try {
    // Get audit logs
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $audit_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $count_query = "SELECT COUNT(*) FROM audit_logs al LEFT JOIN users u ON al.user_id = u.id WHERE 1=1";
    if (!empty($action_filter)) $count_query .= " AND al.action = ?";
    if (!empty($user_filter)) $count_query .= " AND al.user_id = ?";
    if (!empty($date_from)) $count_query .= " AND DATE(al.created_at) >= ?";
    if (!empty($date_to)) $count_query .= " AND DATE(al.created_at) <= ?";
    if (!empty($search)) $count_query .= " AND (al.description LIKE ? OR al.ip_address LIKE ? OR u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($count_params);
    $total_logs = $stmt->fetchColumn();
    $total_pages = ceil($total_logs / $limit);
    
    // Get distinct actions for filter dropdown
    $stmt = $pdo->prepare("SELECT DISTINCT action FROM audit_logs ORDER BY action");
    $stmt->execute();
    $actions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get users for filter dropdown
    $stmt = $pdo->prepare("SELECT id, username, first_name, last_name FROM users ORDER BY username");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM audit_logs");
    $stmt->execute();
    $total_audit_logs = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as today FROM audit_logs WHERE DATE(created_at) = CURDATE()");
    $stmt->execute();
    $today_logs = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as failed_logins FROM audit_logs WHERE action = 'failed_login' AND DATE(created_at) = CURDATE()");
    $stmt->execute();
    $failed_logins_today = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) as active_users FROM audit_logs WHERE DATE(created_at) = CURDATE() AND user_id IS NOT NULL");
    $stmt->execute();
    $active_users_today = $stmt->fetchColumn();
    
    // Get top actions
    $stmt = $pdo->prepare("SELECT action, COUNT(*) as count FROM audit_logs GROUP BY action ORDER BY count DESC LIMIT 10");
    $stmt->execute();
    $top_actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching audit logs: ' . $e->getMessage());
    $audit_logs = [];
    $actions = [];
    $users = [];
    $total_audit_logs = $today_logs = $failed_logins_today = $active_users_today = 0;
    $top_actions = [];
    $total_pages = 1;
}
?>

<!-- The rest of your HTML/PHP code remains the same -->
<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Audit Logs</h1>
                <p class="text-muted mb-0">Monitor system activities and user actions</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-outline-primary" id="exportLogs">
                    <i class="fas fa-download me-2"></i> Export Logs
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#clearLogsModal">
                    <i class="fas fa-trash me-2"></i> Clear Old Logs
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Logs
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($total_audit_logs); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-history fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Today's Activities
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($today_logs); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar-day fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Failed Logins (Today)
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($failed_logins_today); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Active Users (Today)
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($active_users_today); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Top Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-primary"></i>
                    Top Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php if(empty($top_actions)): ?>
                        <div class="col-12 text-center text-muted py-3">
                            <i class="fas fa-chart-bar fa-2x mb-2"></i>
                            <p>No action data available</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($top_actions as $action): ?>
                            <div class="col-md-4 col-6 mb-3">
                                <div class="d-flex align-items-center p-3 border rounded">
                                    <div class="flex-shrink-0">
                                        <?php 
                                        $icon = 'info-circle';
                                        $color = 'primary';
                                        switch($action['action']) {
                                            case 'login': $icon = 'sign-in-alt'; $color = 'success'; break;
                                            case 'failed_login': $icon = 'exclamation-triangle'; $color = 'danger'; break;
                                            case 'registration': $icon = 'user-plus'; $color = 'info'; break;
                                            case 'exam_created': $icon = 'file-plus'; $color = 'warning'; break;
                                            case 'exam_submitted': $icon = 'check-circle'; $color = 'success'; break;
                                            case 'question_added': $icon = 'question-circle'; $color = 'info'; break;
                                        }
                                        ?>
                                        <i class="fas fa-<?php echo $icon; ?> fa-2x text-<?php echo $color; ?> me-3"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-bold text-<?php echo $color; ?>"><?php echo number_format($action['count']); ?></div>
                                        <small class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $action['action'])); ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search logs..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="action" class="form-label">Action Type</label>
                <select class="form-select" id="action" name="action">
                    <option value="">All Actions</option>
                    <?php foreach($actions as $action): ?>
                        <option value="<?php echo htmlspecialchars($action); ?>" <?php echo $action_filter == $action ? 'selected' : ''; ?>>
                            <?php echo ucfirst(str_replace('_', ' ', $action)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="user" class="form-label">User</label>
                <select class="form-select" id="user" name="user">
                    <option value="">All Users</option>
                    <?php foreach($users as $user): ?>
                        <option value="<?php echo $user['id']; ?>" <?php echo $user_filter == $user['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="date_from" class="form-label">Date From</label>
                <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            <div class="col-md-2">
                <label for="date_to" class="form-label">Date To</label>
                <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="audit_logs.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Audit Logs Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Audit Logs
            <span class="badge bg-primary ms-2"><?php echo number_format($total_logs); ?> logs</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>IP Address</th>
                        <th>User Agent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($audit_logs)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-history fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No audit logs found</h5>
                                <p class="text-muted">Try adjusting your filters or check back later.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($audit_logs as $log): ?>
                            <tr>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($log['created_at']); ?></small>
                                </td>
                                <td>
                                    <?php if($log['user_id']): ?>
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0">
                                                <div class="bg-<?php 
                                                    switch($log['role']) {
                                                        case 'admin': echo 'danger'; break;
                                                        case 'instructor': echo 'warning'; break;
                                                        case 'student': echo 'info'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?> text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                    <i class="fas fa-<?php 
                                                        switch($log['role']) {
                                                            case 'admin': echo 'shield-alt'; break;
                                                            case 'instructor': echo 'chalkboard-teacher'; break;
                                                            case 'student': echo 'user-graduate'; break;
                                                            default: echo 'user';
                                                        }
                                                    ?>"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <div class="fw-semibold"><?php echo htmlspecialchars($log['first_name'] . ' ' . $log['last_name']); ?></div>
                                                <small class="text-muted">@<?php echo htmlspecialchars($log['username']); ?></small>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">System</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge 
                                        <?php 
                                        switch($log['action']) {
                                            case 'login': echo 'bg-success'; break;
                                            case 'failed_login': echo 'bg-danger'; break;
                                            case 'registration': echo 'bg-info'; break;
                                            case 'exam_created': echo 'bg-warning'; break;
                                            case 'exam_submitted': echo 'bg-primary'; break;
                                            case 'question_added': echo 'bg-secondary'; break;
                                            default: echo 'bg-dark';
                                        }
                                        ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $log['action'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="text-break" style="max-width: 300px;">
                                        <?php echo htmlspecialchars($log['description']); ?>
                                    </div>
                                </td>
                                <td>
                                    <code class="text-muted"><?php echo htmlspecialchars($log['ip_address']); ?></code>
                                </td>
                                <td>
                                    <div class="text-break small text-muted" style="max-width: 200px;">
                                        <?php echo htmlspecialchars(substr($log['user_agent'], 0, 50)); ?>...
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Pagination -->
    <?php if($total_pages > 1): ?>
    <div class="card-footer bg-white">
        <nav aria-label="Audit logs pagination">
            <ul class="pagination justify-content-center mb-0">
                <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                            <i class="fas fa-chevron-left me-1"></i> Previous
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                            Next <i class="fas fa-chevron-right ms-1"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="text-center text-muted mt-2">
            <small>Page <?php echo $page; ?> of <?php echo $total_pages; ?> • <?php echo number_format($total_logs); ?> total logs</small>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Clear Logs Modal -->
<div class="modal fade" id="clearLogsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="../process/process_audit_logs.php">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Clear Old Audit Logs</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Clear audit logs older than specified days?</h6>
                    
                    <div class="mb-3">
                        <label for="days_old" class="form-label">Delete logs older than (days):</label>
                        <select class="form-select" id="days_old" name="days_old" required>
                            <option value="30">30 days</option>
                            <option value="60">60 days</option>
                            <option value="90">90 days</option>
                            <option value="180">180 days</option>
                            <option value="365">1 year</option>
                        </select>
                        <div class="form-text">This action cannot be undone. Logs will be permanently deleted.</div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <strong>Warning:</strong> This will permanently delete audit logs. Make sure you have backups if needed.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="clear_logs" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i> Clear Logs
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Export logs functionality
    document.getElementById('exportLogs').addEventListener('click', function() {
        const params = new URLSearchParams(window.location.search);
        params.append('export', '1');
        
        // Show loading state
        const originalText = this.innerHTML;
        this.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Exporting...';
        this.disabled = true;
        
        // Create download link
        const downloadUrl = `../process/process_audit_logs.php?${params.toString()}`;
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = `audit_logs_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Reset button
        setTimeout(() => {
            this.innerHTML = originalText;
            this.disabled = false;
        }, 2000);
    });
    
    // Date validation
    const dateFrom = document.getElementById('date_from');
    const dateTo = document.getElementById('date_to');
    
    if (dateFrom && dateTo) {
        dateFrom.addEventListener('change', function() {
            if (dateTo.value && this.value > dateTo.value) {
                alert('Start date cannot be after end date!');
                this.value = '';
            }
        });
        
        dateTo.addEventListener('change', function() {
            if (dateFrom.value && this.value < dateFrom.value) {
                alert('End date cannot be before start date!');
                this.value = '';
            }
        });
    }
    
    // Auto-focus search field
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Show user agent details on click
    document.querySelectorAll('td .text-break').forEach(cell => {
        cell.addEventListener('click', function() {
            const fullText = this.getAttribute('title') || this.textContent;
            if (fullText.length > 50) {
                alert(fullText);
            }
        });
    });
});

// Real-time updates (optional)
function refreshLogs() {
    // You can implement AJAX refresh here if needed
    console.log('Refreshing audit logs...');
}

// Auto-refresh every 60 seconds if on first page
<?php if($page === 1): ?>
setInterval(refreshLogs, 60000);
<?php endif; ?>
</script>

<style>
.table td {
    vertical-align: middle;
}

.text-break {
    word-break: break-word;
}

.badge {
    font-size: 0.75em;
}

.pagination {
    margin-bottom: 0;
}

.progress {
    height: 8px;
}

/* Responsive table */
@media (max-width: 768px) {
    .table-responsive {
        font-size: 0.875rem;
    }
    
    .badge {
        font-size: 0.7em;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?>