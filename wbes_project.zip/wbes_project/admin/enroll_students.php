<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Enroll Students';
require_once '../includes/header.php';

// Handle enrollment actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_id = $_POST['course_id'] ?? '';
    
    if (empty($course_id)) {
        setFlash('error', 'Please select a course.');
    } else {
        // Individual enrollment
        if (isset($_POST['enroll_students'])) {
            $student_ids = $_POST['student_ids'] ?? [];
            
            if (empty($student_ids)) {
                setFlash('error', 'Please select at least one student.');
            } else {
                enrollStudents($student_ids, $course_id);
            }
        }
        
        // Bulk enrollment by criteria
        if (isset($_POST['bulk_enroll'])) {
            $bulk_criteria = $_POST['bulk_criteria'] ?? '';
            $bulk_value = $_POST['bulk_value'] ?? '';
            
            if (empty($bulk_criteria) || empty($bulk_value)) {
                setFlash('error', 'Please select bulk enrollment criteria.');
            } else {
                bulkEnrollStudents($bulk_criteria, $bulk_value, $course_id);
            }
        }
    }
}

// Function to enroll individual students
function enrollStudents($student_ids, $course_id) {
    global $pdo;
    
    $enrolled_count = 0;
    $already_enrolled = 0;
    $errors = [];
    
    foreach ($student_ids as $student_id) {
        try {
            // Check if already enrolled
            $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
            $stmt->execute([$student_id, $course_id]);
            
            if (!$stmt->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, status, enrolled_at) VALUES (?, ?, 'active', NOW())");
                $stmt->execute([$student_id, $course_id]);
                $enrolled_count++;
                
                // Log activity
                logEnrollmentActivity($student_id, $course_id, 'manual');
            } else {
                $already_enrolled++;
            }
        } catch(PDOException $e) {
            $errors[] = "Error enrolling student ID: $student_id - " . $e->getMessage();
        }
    }
    
    // Prepare response message
    if ($enrolled_count > 0) {
        setFlash('success', "✅ Successfully enrolled $enrolled_count student(s)." . 
                 ($already_enrolled > 0 ? " $already_enrolled student(s) were already enrolled." : ""));
    } elseif ($already_enrolled > 0) {
        setFlash('info', "ℹ️ All selected students ($already_enrolled) are already enrolled in this course.");
    }
    
    if (!empty($errors)) {
        setFlash('error', implode('<br>', $errors));
    }
}

// Function for bulk enrollment
function bulkEnrollStudents($criteria, $value, $course_id) {
    global $pdo;
    
    try {
        $query = "SELECT id FROM users WHERE role = 'student' AND is_active = 1";
        $params = [];
        
        switch($criteria) {
            case 'department':
                $query .= " AND department = ?";
                $params[] = $value;
                $criteria_text = "department $value";
                break;
                
            case 'year':
                $query .= " AND academic_year = ?";
                $params[] = $value;
                $criteria_text = "academic year $value";
                break;
                
            case 'all':
                $criteria_text = "all students";
                break;
                
            case 'unenrolled':
                $query .= " AND id NOT IN (SELECT student_id FROM enrollments WHERE course_id = ?)";
                $params[] = $course_id;
                $criteria_text = "unenrolled students";
                break;
        }
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $student_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $enrolled_count = 0;
        $already_enrolled = 0;
        
        foreach ($student_ids as $student_id) {
            // Check if already enrolled
            $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
            $stmt->execute([$student_id, $course_id]);
            
            if (!$stmt->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, status, enrolled_at) VALUES (?, ?, 'active', NOW())");
                $stmt->execute([$student_id, $course_id]);
                $enrolled_count++;
                
                // Log activity
                logEnrollmentActivity($student_id, $course_id, 'bulk_' . $criteria);
            } else {
                $already_enrolled++;
            }
        }
        
        if ($enrolled_count > 0) {
            setFlash('success', "✅ Bulk enrollment completed! Enrolled $enrolled_count student(s) from $criteria_text." . 
                     ($already_enrolled > 0 ? " $already_enrolled student(s) were already enrolled." : ""));
        } else {
            setFlash('info', "ℹ️ No new students to enroll from $criteria_text. All students are already enrolled.");
        }
        
    } catch(PDOException $e) {
        setFlash('error', '❌ Error in bulk enrollment: ' . $e->getMessage());
    }
}

// Function to log enrollment activity
function logEnrollmentActivity($student_id, $course_id, $enrollment_type) {
    global $pdo, $_SESSION;
    
    try {
        // Get student and course details
        $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
        
        $stmt = $pdo->prepare("SELECT course_code, course_name FROM courses WHERE id = ?");
        $stmt->execute([$course_id]);
        $course = $stmt->fetch();
        
        $description = "Enrolled student @" . $student['username'] . " in course " . $course['course_code'];
        if ($enrollment_type !== 'manual') {
            $description .= " (via " . str_replace('_', ' ', $enrollment_type) . " enrollment)";
        }
        
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            'student_enrolled',
            $description,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);
    } catch(PDOException $e) {
        // Silently fail logging
    }
}

// Get all data
try {
    // First check if department column exists in courses table
    $stmt = $pdo->query("SHOW COLUMNS FROM courses LIKE 'department'");
    $department_column_exists = $stmt->fetch();
    
    // Get search parameter
    $course_search = isset($_GET['course_search']) ? trim($_GET['course_search']) : '';
    
    // Build query dynamically based on column existence
    $course_query = "
        SELECT c.*, 
               CONCAT(u.first_name, ' ', u.last_name) as instructor_name,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id AND status = 'active') as enrolled_count,
               (SELECT COUNT(*) FROM users WHERE role = 'student' AND is_active = 1) as total_students
        FROM courses c 
        LEFT JOIN users u ON c.instructor_id = u.id 
        WHERE c.is_active = 1
    ";
    
    $course_params = [];
    
    // Add search condition if provided
    if (!empty($course_search)) {
        $course_query .= " AND (c.course_code LIKE ? OR c.course_name LIKE ? OR c.description LIKE ?)";
        $search_term = "%$course_search%";
        $course_params[] = $search_term;
        $course_params[] = $search_term;
        $course_params[] = $search_term;
    }
    
    $course_query .= " ORDER BY c.course_code";
    
    $stmt = $pdo->prepare($course_query);
    $stmt->execute($course_params);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all active students
    $student_query = "
        SELECT u.*,
               (SELECT COUNT(*) FROM enrollments WHERE student_id = u.id) as enrolled_courses
        FROM users u 
        WHERE u.role = 'student' AND u.is_active = 1 
        ORDER BY u.first_name, u.last_name
    ";
    
    $stmt = $pdo->prepare($student_query);
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get unique departments (check if column exists in users table first)
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'department'");
    $user_dept_column_exists = $stmt->fetch();
    
    $departments = [];
    if ($user_dept_column_exists) {
        $stmt = $pdo->prepare("
            SELECT DISTINCT u.department
            FROM users u 
            WHERE u.role = 'student' AND u.department IS NOT NULL AND u.is_active = 1
            ORDER BY u.department
        ");
        $stmt->execute();
        $departments = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    // Get unique academic years (check if column exists)
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'academic_year'");
    $academic_year_exists = $stmt->fetch();
    
    $academic_years = [];
    if ($academic_year_exists) {
        $stmt = $pdo->prepare("
            SELECT DISTINCT academic_year 
            FROM users 
            WHERE role = 'student' AND is_active = 1 AND academic_year IS NOT NULL
            ORDER BY academic_year DESC
        ");
        $stmt->execute();
        $academic_years = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    // Get enrollment statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM enrollments WHERE status = 'active'");
    $stmt->execute();
    $total_enrollments = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT student_id) as unique_students 
        FROM enrollments 
        WHERE status = 'active'
    ");
    $stmt->execute();
    $unique_students = $stmt->fetchColumn();
    
} catch(PDOException $e) {
    setFlash('error', 'Database error: ' . $e->getMessage());
    $courses = [];
    $students = [];
    $departments = [];
    $academic_years = [];
    $total_enrollments = $unique_students = 0;
}
?>

<div class="container-fluid px-4">
    <!-- Header Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-lg" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <div class="card-body py-4">
                    <div class="row align-items-center">
                        <div class="col-lg-8">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-white bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="fas fa-user-graduate fa-2x text-white"></i>
                                </div>
                                <div>
                                    <h1 class="h2 mb-1 text-white fw-bold">Student Enrollment System</h1>
                                    <p class="text-white-50 mb-0">Easily enroll students in courses with advanced filtering and bulk operations</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="d-flex flex-wrap gap-2">
                                <span class="badge  bg-opacity-20 text-white px-3 py-2">
                                    <i class="fas fa-users me-1"></i>
                                    <?php echo count($students); ?> Active Students
                                </span>
                                <span class="badge  bg-opacity-20 text-white px-3 py-2">
                                    <i class="fas fa-book me-1"></i>
                                    <?php echo $total_enrollments; ?> Enrollments
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="row">
        <!-- Left Column - Course Selection -->
        <div class="col-lg-4 mb-4">
            <!-- Course Search Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="card-title mb-0 d-flex align-items-center">
                        <i class="fas fa-search me-2"></i>Course Search
                    </h5>
                </div>
                <div class="card-body">
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control border-primary" 
                                   name="course_search" 
                                   placeholder="Search courses by code, name, or description..."
                                   value="<?php echo htmlspecialchars($course_search); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if(!empty($course_search)): ?>
                            <a href="enroll_students.php" class="btn btn-outline-secondary">
                                <i class="fas fa-times"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php if(!empty($course_search)): ?>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                Found <?php echo count($courses); ?> courses matching "<?php echo htmlspecialchars($course_search); ?>"
                            </small>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- Course Selection Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-success text-white py-3">
                    <h5 class="card-title mb-0 d-flex align-items-center">
                        <i class="fas fa-book-open me-2"></i>Select Course
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-dark">Choose a Course</label>
                        <select class="form-select form-select-lg border-success" 
                                id="course_id" 
                                name="course_id" 
                                required
                                style="border-width: 2px;">
                            <option value="">-- Select Course --</option>
                            <?php foreach($courses as $course): ?>
                                <option value="<?php echo $course['id']; ?>" 
                                        data-enrolled="<?php echo $course['enrolled_count']; ?>"
                                        data-instructor="<?php echo htmlspecialchars($course['instructor_name'] ?? 'Not assigned'); ?>"
                                        data-description="<?php echo htmlspecialchars($course['description'] ?? 'No description available'); ?>"
                                        data-duration="<?php echo $course['duration_minutes'] ?? 'N/A'; ?>"
                                        data-marks="<?php echo $course['total_marks'] ?? 'N/A'; ?>">
                                    <?php echo htmlspecialchars($course['course_code']); ?> - 
                                    <?php echo htmlspecialchars($course['course_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Course Details Preview -->
                    <div id="coursePreview" class="border border-success rounded p-3 bg-light" style="display: none; border-width: 2px;">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h6 id="courseTitle" class="mb-1 fw-bold text-success"></h6>
                                <small id="courseInstructor" class="text-muted">
                                    <i class="fas fa-chalkboard-teacher me-1"></i>
                                    <span id="instructorName"></span>
                                </small>
                            </div>
                            <div class="text-end">
                                <div class="badge bg-success-subtle text-success border border-success px-3 py-2" id="enrollmentCount"></div>
                            </div>
                        </div>
                        <div id="courseDescription" class="small text-muted mb-3"></div>
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="bg-info-subtle rounded-circle p-2 me-2">
                                        <i class="fas fa-clock text-info"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Duration</small>
                                        <span class="fw-bold" id="courseDuration"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="bg-warning-subtle rounded-circle p-2 me-2">
                                        <i class="fas fa-star text-warning"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Total Marks</small>
                                        <span class="fw-bold" id="courseMarks"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- No Courses Message -->
                    <?php if(empty($courses)): ?>
                    <div class="alert alert-warning mt-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        No courses found. <?php echo !empty($course_search) ? 'Try a different search term.' : 'Please create courses first.'; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-warning text-dark py-3">
                    <h5 class="card-title mb-0 d-flex align-items-center">
                        <i class="fas fa-bolt me-2"></i>Quick Actions
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-3">
                        <button type="button" 
                                class="btn btn-primary btn-lg d-flex align-items-center justify-content-center"
                                onclick="selectAllStudents()"
                                id="selectAllBtn">
                            <i class="fas fa-check-circle me-2"></i>
                            <span>Select All Students</span>
                        </button>
                        
                        <button type="button" 
                                class="btn btn-outline-secondary btn-lg d-flex align-items-center justify-content-center"
                                onclick="deselectAllStudents()"
                                id="deselectAllBtn">
                            <i class="fas fa-times-circle me-2"></i>
                            <span>Deselect All</span>
                        </button>
                        
                        <button type="button" 
                                class="btn btn-success btn-lg d-flex align-items-center justify-content-center"
                                id="enrollBtn"
                                disabled
                                onclick="showConfirmationModal()">
                            <i class="fas fa-save me-2"></i>
                            <span>Enroll Selected</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Bulk Enrollment Card -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-info text-white py-3">
                    <h5 class="card-title mb-0 d-flex align-items-center">
                        <i class="fas fa-users me-2"></i>Bulk Enrollment
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" id="bulkForm">
                        <input type="hidden" name="course_id" id="bulk_course_id">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-dark">Enroll By Criteria</label>
                            <select class="form-select border-info" 
                                    id="bulk_criteria" 
                                    name="bulk_criteria" 
                                    onchange="toggleBulkValue()"
                                    style="border-width: 2px;">
                                <option value="">-- Select Criteria --</option>
                                <option value="all">All Students</option>
                                <option value="unenrolled">Unenrolled Only</option>
                                <?php if(!empty($departments)): ?>
                                <option value="department">Department</option>
                                <?php endif; ?>
                                <?php if(!empty($academic_years)): ?>
                                <option value="year">Academic Year</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="bulkValueContainer" style="display: none;">
                            <label class="form-label fw-bold text-dark" id="bulkValueLabel"></label>
                            <select class="form-select border-info" 
                                    id="bulk_value" 
                                    name="bulk_value"
                                    style="border-width: 2px;">
                                <!-- Options will be populated dynamically -->
                            </select>
                        </div>
                        
                        <button type="submit" 
                                name="bulk_enroll" 
                                class="btn btn-info w-100 d-flex align-items-center justify-content-center py-2"
                                id="bulkEnrollBtn"
                                disabled>
                            <i class="fas fa-users me-2"></i>
                            <span>Bulk Enroll</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Column - Student Management -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-gradient-dark text-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0 d-flex align-items-center">
                            <i class="fas fa-user-friends me-2"></i>Student Management
                        </h5>
                        <div class="d-flex align-items-center">
                            <div class="bg-white bg-opacity-10 rounded px-3 py-1 me-3">
                                <span class="text-white" id="selectedCount">0 selected</span>
                            </div>
                            <div class="input-group input-group-sm" style="width: 250px;">
                                <span class="input-group-text bg-white border-0">
                                    <i class="fas fa-search text-muted"></i>
                                </span>
                                <input type="text" 
                                       class="form-control border-0" 
                                       id="studentSearch" 
                                       placeholder="Search students by name or ID...">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card-body p-0">
                    <!-- Student Filters -->
                    <div class="p-3 border-bottom bg-light">
                        <div class="row g-3">
                            <?php if(!empty($departments)): ?>
                            <div class="col-md-<?php echo !empty($academic_years) ? '4' : '6'; ?>">
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-primary">
                                        <i class="fas fa-building text-primary"></i>
                                    </span>
                                    <select class="form-select border-primary" 
                                            id="filterDepartment" 
                                            onchange="applyFilters()"
                                            style="border-width: 2px;">
                                        <option value="">All Departments</option>
                                        <?php foreach($departments as $dept): ?>
                                            <option value="<?php echo htmlspecialchars($dept); ?>">
                                                <?php echo htmlspecialchars($dept); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if(!empty($academic_years)): ?>
                            <div class="col-md-<?php echo !empty($departments) ? '4' : '6'; ?>">
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-info">
                                        <i class="fas fa-calendar text-info"></i>
                                    </span>
                                    <select class="form-select border-info" 
                                            id="filterYear" 
                                            onchange="applyFilters()"
                                            style="border-width: 2px;">
                                        <option value="">All Years</option>
                                        <?php foreach($academic_years as $year): ?>
                                            <option value="<?php echo htmlspecialchars($year); ?>">
                                                <?php echo htmlspecialchars($year); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <div class="col-md-<?php echo (!empty($departments) && !empty($academic_years)) ? '4' : '6'; ?>">
                                <button type="button" 
                                        class="btn btn-outline-primary w-100 h-100 d-flex align-items-center justify-content-center"
                                        onclick="resetFilters()">
                                    <i class="fas fa-redo me-2"></i>
                                    Reset Filters
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Students List -->
                    <div class="student-list-container" style="max-height: 700px; overflow-y: auto; padding: 1rem;">
                        <form method="POST" id="enrollmentForm">
                            <input type="hidden" name="course_id" id="form_course_id">
                            
                            <div class="row g-3" id="studentList">
                                <?php foreach($students as $student): ?>
                                    <div class="col-lg-6 student-item"
                                         data-id="<?php echo $student['id']; ?>"
                                         data-department="<?php echo htmlspecialchars($student['department'] ?? ''); ?>"
                                         data-year="<?php echo htmlspecialchars($student['academic_year'] ?? ''); ?>"
                                         data-name="<?php echo htmlspecialchars(strtolower($student['first_name'] . ' ' . $student['last_name'])); ?>"
                                         data-username="<?php echo htmlspecialchars(strtolower($student['username'])); ?>"
                                         data-email="<?php echo htmlspecialchars(strtolower($student['email'] ?? '')); ?>">
                                        <div class="card border-0 shadow-sm h-100 student-card">
                                            <div class="card-body">
                                                <div class="d-flex align-items-start">
                                                    <div class="form-check me-3 mt-1">
                                                        <input class="form-check-input student-checkbox" 
                                                               type="checkbox" 
                                                               name="student_ids[]" 
                                                               value="<?php echo $student['id']; ?>"
                                                               id="student_<?php echo $student['id']; ?>">
                                                    </div>
                                                    <div class="flex-shrink-0">
                                                        <div class="avatar bg-primary bg-gradient text-white rounded-circle d-flex align-items-center justify-content-center" 
                                                             style="width: 48px; height: 48px; font-size: 1.2rem;">
                                                            <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                                        </div>
                                                    </div>
                                                    <div class="flex-grow-1 ms-3">
                                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                                            <div>
                                                                <h6 class="mb-1 fw-bold text-dark">
                                                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                                                </h6>
                                                                <small class="text-muted">
                                                                    <i class="fas fa-at me-1"></i>
                                                                    <?php echo htmlspecialchars($student['username']); ?>
                                                                    <?php if(isset($student['university_id']) && !empty($student['university_id'])): ?>
                                                                        <span class="mx-2">•</span>
                                                                        <i class="fas fa-id-card me-1"></i>
                                                                        <?php echo htmlspecialchars($student['university_id']); ?>
                                                                    <?php endif; ?>
                                                                </small>
                                                            </div>
                                                            <div class="badge bg-light text-dark px-2 py-1">
                                                                <i class="fas fa-book me-1"></i>
                                                                <?php echo $student['enrolled_courses']; ?> courses
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="d-flex flex-wrap gap-1 mb-2">
                                                            <?php if(isset($student['department']) && !empty($student['department'])): ?>
                                                                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary px-2 py-1">
                                                                    <i class="fas fa-building me-1"></i>
                                                                    <?php echo htmlspecialchars($student['department']); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if(isset($student['academic_year']) && !empty($student['academic_year'])): ?>
                                                                <span class="badge bg-info bg-opacity-10 text-info border border-info px-2 py-1">
                                                                    <i class="fas fa-calendar me-1"></i>
                                                                    <?php echo htmlspecialchars($student['academic_year']); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        
                                                        <?php if(isset($student['email']) && !empty($student['email'])): ?>
                                                        <div class="small">
                                                            <i class="fas fa-envelope text-muted me-1"></i>
                                                            <span class="text-muted"><?php echo htmlspecialchars($student['email']); ?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <!-- No Results Message -->
                            <div id="noResults" class="text-center py-5" style="display: none;">
                                <div class="py-5">
                                    <div class="display-1 text-muted opacity-25 mb-4">
                                        <i class="fas fa-search"></i>
                                    </div>
                                    <h3 class="text-muted mb-3">No Students Found</h3>
                                    <p class="text-muted mb-4">Try adjusting your search or filters</p>
                                    <button type="button" class="btn btn-outline-primary" onclick="resetFilters()">
                                        <i class="fas fa-redo me-2"></i>Reset All Filters
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Footer Actions -->
                <div class="card-footer bg-light py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted" id="filterInfo">
                                <i class="fas fa-info-circle me-1"></i>
                                Showing <?php echo count($students); ?> students
                            </small>
                        </div>
                        <div class="d-flex gap-2">
                            <?php if(!empty($departments)): ?>
                            <button type="button" 
                                    class="btn btn-outline-primary btn-sm d-flex align-items-center"
                                    onclick="selectByFilter('department')">
                                <i class="fas fa-building me-1"></i>
                                Select Department
                            </button>
                            <?php endif; ?>
                            <?php if(!empty($academic_years)): ?>
                            <button type="button" 
                                    class="btn btn-outline-info btn-sm d-flex align-items-center"
                                    onclick="selectByFilter('year')">
                                <i class="fas fa-calendar me-1"></i>
                                Select Year
                            </button>
                            <?php endif; ?>
                            <button type="submit" 
                                    form="enrollmentForm" 
                                    name="enroll_students" 
                                    class="btn btn-primary btn-sm d-flex align-items-center"
                                    id="confirmEnrollBtn"
                                    disabled>
                                <i class="fas fa-check me-1"></i>
                                Confirm Enrollment
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Section -->
    <div class="row mt-4">
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm bg-gradient-primary  overflow-hidden">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-users fa-2x opacity-50"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h3 class="mb-0 fw-bold"><?php echo count($students); ?></h3>
                            <small>Active Students</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm bg-gradient-success  overflow-hidden">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-book fa-2x opacity-50"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h3 class="mb-0 fw-bold"><?php echo count($courses); ?></h3>
                            <small>Active Courses</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm bg-gradient-info  overflow-hidden">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-graduation-cap fa-2x opacity-50"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h3 class="mb-0 fw-bold"><?php echo $unique_students; ?></h3>
                            <small>Enrolled Students</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm bg-gradient-warning  overflow-hidden">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-chart-line fa-2x opacity-50"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h3 class="mb-0 fw-bold"><?php echo $total_enrollments; ?></h3>
                            <small>Total Enrollments</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-gradient-success text-white border-0">
                <h5 class="modal-title">
                    <i class="fas fa-check-circle me-2"></i>Confirm Enrollment
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-4">
                <div class="text-center mb-4">
                    <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center p-3 mb-3">
                        <i class="fas fa-user-graduate fa-2x text-success"></i>
                    </div>
                    <h4 class="fw-bold">Ready to Enroll Students?</h4>
                    <p class="text-muted" id="confirmationText"></p>
                </div>
                <div class="alert alert-success bg-opacity-10 border-success">
                    <div class="d-flex">
                        <i class="fas fa-info-circle text-success mt-1 me-3"></i>
                        <div>
                            <strong id="confirmationDetails"></strong>
                            <div class="mt-2 small" id="enrollmentStats"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
                    <i class="fas fa-times me-2"></i>Cancel
                </button>
                <button type="button" class="btn btn-success px-4" onclick="submitEnrollment()">
                    <i class="fas fa-check me-2"></i>Confirm & Enroll
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Success Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="successToast" class="toast" role="alert" data-bs-delay="5000">
        <div class="toast-header bg-success text-white">
            <i class="fas fa-check-circle me-2"></i>
            <strong class="me-auto">Success!</strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            Enrollment completed successfully!
        </div>
    </div>
</div>

<script>
// Global variables
let selectedCourseId = '';
let selectedCourseName = '';

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Course selection handler
    const courseSelect = document.getElementById('course_id');
    courseSelect.addEventListener('change', function() {
        const courseId = this.value;
        const selectedOption = this.options[this.selectedIndex];
        
        selectedCourseId = courseId;
        selectedCourseName = selectedOption.text;
        
        // Update forms
        document.getElementById('form_course_id').value = courseId;
        document.getElementById('bulk_course_id').value = courseId;
        
        // Show/hide preview
        const preview = document.getElementById('coursePreview');
        if (courseId) {
            preview.style.display = 'block';
            // Update preview details
            const enrolled = selectedOption.getAttribute('data-enrolled') || '0';
            document.getElementById('enrollmentCount').textContent = enrolled + ' enrolled';
            document.getElementById('courseTitle').textContent = selectedOption.text;
            document.getElementById('instructorName').textContent = selectedOption.getAttribute('data-instructor');
            document.getElementById('courseDescription').textContent = selectedOption.getAttribute('data-description');
            document.getElementById('courseDuration').textContent = selectedOption.getAttribute('data-duration');
            document.getElementById('courseMarks').textContent = selectedOption.getAttribute('data-marks');
            
            // Add pulse animation
            preview.classList.add('animate__animated', 'animate__pulse');
            setTimeout(() => {
                preview.classList.remove('animate__animated', 'animate__pulse');
            }, 1000);
        } else {
            preview.style.display = 'none';
        }
        
        // Enable/disable buttons
        const enrollBtn = document.getElementById('enrollBtn');
        const bulkBtn = document.getElementById('bulkEnrollBtn');
        enrollBtn.disabled = !courseId;
        bulkBtn.disabled = !courseId;
        
        // Update button states
        updateButtonStates();
    });
    
    // Student checkbox handler
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const card = this.closest('.student-card');
            if (this.checked) {
                card.classList.add('border-primary', 'shadow');
                card.style.transform = 'translateY(-2px)';
            } else {
                card.classList.remove('border-primary', 'shadow');
                card.style.transform = 'translateY(0)';
            }
            updateSelectionCount();
        });
    });
    
    // Search handler with debounce
    let searchTimeout;
    document.getElementById('studentSearch').addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(filterStudents, 300);
    });
    
    // Enrollment form submission
    document.getElementById('enrollmentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        showConfirmationModal();
    });
    
    // Bulk form submission
    document.getElementById('bulkForm').addEventListener('submit', function(e) {
        if (!selectedCourseId) {
            e.preventDefault();
            showToast('Please select a course first.', 'warning');
            return;
        }
        
        const criteria = document.getElementById('bulk_criteria').value;
        if (!criteria) {
            e.preventDefault();
            showToast('Please select bulk enrollment criteria.', 'warning');
            return;
        }
        
        if (criteria !== 'all' && criteria !== 'unenrolled') {
            const value = document.getElementById('bulk_value').value;
            if (!value) {
                e.preventDefault();
                showToast('Please select a value for the criteria.', 'warning');
                return;
            }
        }
    });
    
    // Initialize filters
    filterStudents();
    
    // Add hover effects to student cards
    document.querySelectorAll('.student-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (!this.classList.contains('border-primary')) {
                this.classList.add('shadow-sm');
            }
        });
        
        card.addEventListener('mouseleave', function() {
            if (!this.classList.contains('border-primary')) {
                this.classList.remove('shadow-sm');
            }
        });
    });
    
    // Initialize
    updateSelectionCount();
});

// Update selection count
function updateSelectionCount() {
    const selected = document.querySelectorAll('.student-checkbox:checked').length;
    const selectedCount = document.getElementById('selectedCount');
    
    // Update badge with animation
    selectedCount.textContent = selected + ' selected';
    selectedCount.classList.add('animate__animated', 'animate__headShake');
    setTimeout(() => {
        selectedCount.classList.remove('animate__animated', 'animate__headShake');
    }, 500);
    
    document.getElementById('confirmEnrollBtn').disabled = selected === 0;
    document.getElementById('enrollBtn').disabled = selected === 0 || !selectedCourseId;
    
    // Update filter info
    const visible = document.querySelectorAll('.student-item:not([style*="display: none"])').length;
    const filterInfo = document.getElementById('filterInfo');
    filterInfo.textContent = `Showing ${visible} students (${selected} selected)`;
    filterInfo.innerHTML = `<i class="fas fa-info-circle me-1"></i> ${visible} students visible, ${selected} selected`;
    
    updateButtonStates();
}

// Update button states with visual feedback
function updateButtonStates() {
    const selected = document.querySelectorAll('.student-checkbox:checked').length;
    const selectAllBtn = document.getElementById('selectAllBtn');
    const deselectAllBtn = document.getElementById('deselectAllBtn');
    const enrollBtn = document.getElementById('enrollBtn');
    
    // Visual feedback for buttons
    if (selected > 0) {
        enrollBtn.classList.add('shadow');
        selectAllBtn.classList.remove('shadow');
    } else {
        enrollBtn.classList.remove('shadow');
        selectAllBtn.classList.add('shadow');
    }
    
    if (selected === document.querySelectorAll('.student-checkbox').length) {
        selectAllBtn.disabled = true;
        selectAllBtn.classList.remove('shadow');
        deselectAllBtn.classList.add('shadow');
    } else {
        selectAllBtn.disabled = false;
        deselectAllBtn.classList.remove('shadow');
    }
}

// Select all students
function selectAllStudents() {
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.checked = true;
        const card = checkbox.closest('.student-card');
        card.classList.add('border-primary', 'shadow');
        card.style.transform = 'translateY(-2px)';
    });
    updateSelectionCount();
    
    // Visual feedback
    const btn = document.getElementById('selectAllBtn');
    btn.classList.add('animate__animated', 'animate__pulse');
    setTimeout(() => {
        btn.classList.remove('animate__animated', 'animate__pulse');
    }, 1000);
}

// Deselect all students
function deselectAllStudents() {
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.checked = false;
        const card = checkbox.closest('.student-card');
        card.classList.remove('border-primary', 'shadow');
        card.style.transform = 'translateY(0)';
    });
    updateSelectionCount();
    
    // Visual feedback
    const btn = document.getElementById('deselectAllBtn');
    btn.classList.add('animate__animated', 'animate__pulse');
    setTimeout(() => {
        btn.classList.remove('animate__animated', 'animate__pulse');
    }, 1000);
}

// Filter students
function filterStudents() {
    const searchTerm = document.getElementById('studentSearch').value.toLowerCase();
    const departmentFilter = document.getElementById('filterDepartment')?.value || '';
    const yearFilter = document.getElementById('filterYear')?.value || '';
    
    let visibleCount = 0;
    
    document.querySelectorAll('.student-item').forEach(item => {
        const name = item.getAttribute('data-name');
        const username = item.getAttribute('data-username');
        const email = item.getAttribute('data-email');
        const department = item.getAttribute('data-department');
        const year = item.getAttribute('data-year');
        
        const matchesSearch = !searchTerm || 
            name.includes(searchTerm) || 
            username.includes(searchTerm) || 
            email.includes(searchTerm);
        const matchesDepartment = !departmentFilter || department === departmentFilter;
        const matchesYear = !yearFilter || year === yearFilter;
        
        if (matchesSearch && matchesDepartment && matchesYear) {
            item.style.display = '';
            visibleCount++;
        } else {
            item.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noResults = document.getElementById('noResults');
    const studentList = document.getElementById('studentList');
    if (visibleCount === 0) {
        noResults.style.display = 'block';
        studentList.style.display = 'none';
    } else {
        noResults.style.display = 'none';
        studentList.style.display = 'flex';
    }
    
    updateSelectionCount();
    
    // Add animation to results
    if (visibleCount > 0) {
        studentList.classList.add('animate__animated', 'animate__fadeIn');
        setTimeout(() => {
            studentList.classList.remove('animate__animated', 'animate__fadeIn');
        }, 500);
    }
}

// Apply filters
function applyFilters() {
    filterStudents();
    
    // Visual feedback
    const filterSection = document.querySelector('.bg-light');
    filterSection.classList.add('animate__animated', 'animate__pulse');
    setTimeout(() => {
        filterSection.classList.remove('animate__animated', 'animate__pulse');
    }, 300);
}

// Reset filters
function resetFilters() {
    document.getElementById('studentSearch').value = '';
    if (document.getElementById('filterDepartment')) {
        document.getElementById('filterDepartment').value = '';
    }
    if (document.getElementById('filterYear')) {
        document.getElementById('filterYear').value = '';
    }
    filterStudents();
    
    // Visual feedback
    const resetBtn = document.querySelector('.btn-outline-primary');
    resetBtn.classList.add('animate__animated', 'animate__rotateIn');
    setTimeout(() => {
        resetBtn.classList.remove('animate__animated', 'animate__rotateIn');
    }, 500);
}

// Select by filter
function selectByFilter(type) {
    let selector = '';
    
    if (type === 'department' && document.getElementById('filterDepartment')) {
        const department = document.getElementById('filterDepartment').value;
        if (!department) {
            showToast('Please select a department first.', 'warning');
            return;
        }
        selector = `.student-item[data-department="${department}"] .student-checkbox`;
    } else if (type === 'year' && document.getElementById('filterYear')) {
        const year = document.getElementById('filterYear').value;
        if (!year) {
            showToast('Please select a year first.', 'warning');
            return;
        }
        selector = `.student-item[data-year="${year}"] .student-checkbox`;
    } else {
        showToast('This filter is not available.', 'warning');
        return;
    }
    
    if (selector) {
        let selectedCount = 0;
        document.querySelectorAll(selector).forEach(checkbox => {
            if (!checkbox.disabled) {
                checkbox.checked = true;
                selectedCount++;
                const card = checkbox.closest('.student-card');
                card.classList.add('border-primary', 'shadow');
                card.style.transform = 'translateY(-2px)';
            }
        });
        
        updateSelectionCount();
        
        // Show success message
        showToast(`Selected ${selectedCount} students from ${type === 'department' ? 'department' : 'academic year'} filter.`, 'success');
    }
}

// Toggle bulk value field
function toggleBulkValue() {
    const criteria = document.getElementById('bulk_criteria').value;
    const container = document.getElementById('bulkValueContainer');
    const label = document.getElementById('bulkValueLabel');
    const select = document.getElementById('bulk_value');
    
    if (criteria === 'department') {
        container.style.display = 'block';
        label.textContent = 'Select Department';
        // Add department options dynamically
        select.innerHTML = `
            <option value="">-- Select Department --</option>
            <?php foreach($departments as $dept): ?>
                <option value="<?php echo htmlspecialchars($dept); ?>">
                    <?php echo htmlspecialchars($dept); ?>
                </option>
            <?php endforeach; ?>
        `;
    } else if (criteria === 'year') {
        container.style.display = 'block';
        label.textContent = 'Select Academic Year';
        // Add year options dynamically
        select.innerHTML = `
            <option value="">-- Select Year --</option>
            <?php foreach($academic_years as $year): ?>
                <option value="<?php echo htmlspecialchars($year); ?>">
                    <?php echo htmlspecialchars($year); ?>
                </option>
            <?php endforeach; ?>
        `;
    } else if (criteria === 'all' || criteria === 'unenrolled') {
        container.style.display = 'none';
    } else {
        container.style.display = 'none';
    }
    
    // Animation for bulk form
    container.classList.add('animate__animated', 'animate__fadeIn');
    setTimeout(() => {
        container.classList.remove('animate__animated', 'animate__fadeIn');
    }, 300);
}

// Show confirmation modal
function showConfirmationModal() {
    if (!selectedCourseId) {
        showToast('Please select a course first.', 'warning');
        return;
    }
    
    const selected = document.querySelectorAll('.student-checkbox:checked').length;
    if (selected === 0) {
        showToast('Please select at least one student.', 'warning');
        return;
    }
    
    // Get selected student details
    const selectedStudents = [];
    document.querySelectorAll('.student-checkbox:checked').forEach(checkbox => {
        const card = checkbox.closest('.student-card');
        const name = card.querySelector('.fw-bold').textContent;
        const username = card.querySelector('.text-muted').textContent.split('@')[1]?.split('•')[0]?.trim();
        selectedStudents.push({ name, username });
    });
    
    // Update modal text
    document.getElementById('confirmationText').textContent = 
        `You are about to enroll ${selected} student(s) in the following course:`;
    
    document.getElementById('confirmationDetails').innerHTML = `
        <strong>${selectedCourseName}</strong>
    `;
    
    // Show selected students preview (first 3)
    let previewHtml = '<div class="mt-2 small">';
    selectedStudents.slice(0, 3).forEach(student => {
        previewHtml += `<div class="d-flex align-items-center mb-1">
            <i class="fas fa-user text-success me-2"></i>
            <span>${student.name} (@${student.username})</span>
        </div>`;
    });
    if (selected > 3) {
        previewHtml += `<div class="text-muted">and ${selected - 3} more students...</div>`;
    }
    previewHtml += '</div>';
    
    document.getElementById('enrollmentStats').innerHTML = previewHtml;
    
    // Show modal with animation
    const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    modal.show();
    
    // Add animation to modal
    const modalElement = document.getElementById('confirmationModal');
    modalElement.classList.add('animate__animated', 'animate__zoomIn');
}

// Submit enrollment
function submitEnrollment() {
    // Show loading state
    const confirmBtn = document.querySelector('#confirmationModal .btn-success');
    const originalText = confirmBtn.innerHTML;
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
    confirmBtn.disabled = true;
    
    // Submit form after delay for visual feedback
    setTimeout(() => {
        document.getElementById('enrollmentForm').submit();
    }, 1500);
}

// Show toast notification
function showToast(message, type = 'success') {
    const toastEl = document.getElementById('successToast');
    const toastBody = toastEl.querySelector('.toast-body');
    const toastHeader = toastEl.querySelector('.toast-header');
    
    // Update toast content
    toastBody.textContent = message;
    
    // Update toast color based on type
    if (type === 'success') {
        toastHeader.className = 'toast-header bg-success text-white';
    } else if (type === 'warning') {
        toastHeader.className = 'toast-header bg-warning text-dark';
    } else if (type === 'error') {
        toastHeader.className = 'toast-header bg-danger text-white';
    }
    
    // Show toast
    const toast = new bootstrap.Toast(toastEl);
    toast.show();
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + A to select all
    if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        selectAllStudents();
    }
    // Ctrl + D to deselect all
    if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        deselectAllStudents();
    }
    // Ctrl + F to focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        document.getElementById('studentSearch').focus();
    }
    // Escape to clear search
    if (e.key === 'Escape') {
        document.getElementById('studentSearch').value = '';
        filterStudents();
    }
});

// Auto-update course statistics
setInterval(() => {
    if (selectedCourseId) {
        // In a real application, you might want to fetch updated statistics via AJAX
        console.log('Auto-refreshing course statistics...');
    }
}, 30000); // Every 30 seconds
</script>

<style>
/* Custom Styles with Modern Design */
:root {
    --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --success-gradient: linear-gradient(135deg, #38ef7d 0%, #11998e 100%);
    --info-gradient: linear-gradient(135deg, #36d1dc 0%, #5b86e5 100%);
    --warning-gradient: linear-gradient(135deg, #f7971e 0%, #ffd200 100%);
}

body {
    background-color: #f8f9fa;
}

/* Card hover effects */
.card {
    transition: all 0.3s ease;
    border-radius: 12px;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1) !important;
}

/* Student card animation */
.student-card {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border: 2px solid transparent;
}

.student-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
}

/* Avatar styling */
.avatar {
    font-weight: 600;
    background: var(--primary-gradient);
    box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
}

/* Badge styling */
.badge {
    font-weight: 500;
    transition: all 0.2s ease;
}

/* Input focus effects */
.form-control:focus, .form-select:focus {
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    border-color: #667eea;
}

/* Button styling */
.btn {
    font-weight: 500;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 5px;
    height: 5px;
    background: rgba(255, 255, 255, 0.5);
    opacity: 0;
    border-radius: 100%;
    transform: scale(1, 1) translate(-50%);
    transform-origin: 50% 50%;
}

.btn:focus:not(:active)::after {
    animation: ripple 1s ease-out;
}

@keyframes ripple {
    0% {
        transform: scale(0, 0);
        opacity: 0.5;
    }
    100% {
        transform: scale(20, 20);
        opacity: 0;
    }
}

/* Custom scrollbar */
.student-list-container::-webkit-scrollbar {
    width: 8px;
}

.student-list-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.student-list-container::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 4px;
}

.student-list-container::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}

/* Animation classes */
.animate__animated {
    animation-duration: 0.5s;
}

/* Gradient text */
.gradient-text {
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Loading animation */
.loading-spinner {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid rgba(255,255,255,.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Card header gradient */
.card-header.bg-gradient-dark {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
}

/* Toast styling */
.toast {
    border-radius: 10px;
    border: none;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

/* Checkbox styling */
.form-check-input:checked {
    background-color: #28a745;
    border-color: #28a745;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3e%3cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10l3 3l6-6'/%3e%3c/svg%3e");
}

.form-check-input:focus {
    border-color: #28a745;
    box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
}

/* Stats card hover */
.card.bg-gradient-primary:hover,
.card.bg-gradient-success:hover,
.card.bg-gradient-info:hover,
.card.bg-gradient-warning:hover {
    transform: translateY(-5px) scale(1.02);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .card-header .input-group {
        width: 100% !important;
        margin-top: 10px;
    }
    
    .student-list-container {
        max-height: 400px !important;
    }
}
</style>

<!-- Animate.css for animations -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

<?php require_once '../includes/footer.php'; ?>