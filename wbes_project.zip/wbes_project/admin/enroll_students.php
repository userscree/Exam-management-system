<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Enroll Students';
require_once '../includes/header.php';

// Handle enrollment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['enroll_students'])) {
        $course_id = $_POST['course_id'];
        $student_ids = $_POST['student_ids'] ?? [];
        
        if (empty($course_id) || empty($student_ids)) {
            setFlash('error', 'Please select a course and at least one student.');
        } else {
            $enrolled_count = 0;
            $already_enrolled = 0;
            $errors = [];
            
            foreach ($student_ids as $student_id) {
                try {
                    // Check if already enrolled
                    $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
                    $stmt->execute([$student_id, $course_id]);
                    
                    if (!$stmt->fetch()) {
                        $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, 'active')");
                        $stmt->execute([$student_id, $course_id]);
                        $enrolled_count++;
                    } else {
                        $already_enrolled++;
                    }
                } catch(PDOException $e) {
                    $errors[] = "Error enrolling student ID: $student_id - " . $e->getMessage();
                }
            }
            
            if ($enrolled_count > 0) {
                setFlash('success', "Successfully enrolled $enrolled_count students in the course." . ($already_enrolled > 0 ? " $already_enrolled students were already enrolled." : ""));
            } elseif ($already_enrolled > 0) {
                setFlash('info', "All selected students ($already_enrolled) are already enrolled in this course.");
            }
            if (!empty($errors)) {
                setFlash('error', implode('<br>', $errors));
            }
        }
    }
    
    if (isset($_POST['bulk_enroll_by_department'])) {
        $course_id = $_POST['course_id'];
        $department = $_POST['department'];
        
        if (empty($course_id) || empty($department)) {
            setFlash('error', 'Please select a course and department.');
        } else {
            try {
                // Get all students from the selected department
                $stmt = $pdo->prepare("
                    SELECT id FROM users 
                    WHERE role = 'student' AND is_active = 1 AND department = ?
                ");
                $stmt->execute([$department]);
                $department_students = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                $enrolled_count = 0;
                $already_enrolled = 0;
                
                foreach ($department_students as $student_id) {
                    // Check if already enrolled
                    $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
                    $stmt->execute([$student_id, $course_id]);
                    
                    if (!$stmt->fetch()) {
                        $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, 'active')");
                        $stmt->execute([$student_id, $course_id]);
                        $enrolled_count++;
                    } else {
                        $already_enrolled++;
                    }
                }
                
                if ($enrolled_count > 0) {
                    setFlash('success', "Successfully enrolled $enrolled_count students from $department department." . ($already_enrolled > 0 ? " $already_enrolled students were already enrolled." : ""));
                } else {
                    setFlash('info', "All students from $department department are already enrolled in this course.");
                }
                
            } catch(PDOException $e) {
                setFlash('error', 'Error in bulk enrollment: ' . $e->getMessage());
            }
        }
    }
    
    if (isset($_POST['bulk_enroll_by_year'])) {
        $course_id = $_POST['course_id'];
        $academic_year = $_POST['academic_year'];
        
        if (empty($course_id) || empty($academic_year)) {
            setFlash('error', 'Please select a course and academic year.');
        } else {
            try {
                // Get all students from the selected academic year
                $stmt = $pdo->prepare("
                    SELECT id FROM users 
                    WHERE role = 'student' AND is_active = 1 AND academic_year = ?
                ");
                $stmt->execute([$academic_year]);
                $year_students = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                $enrolled_count = 0;
                $already_enrolled = 0;
                
                foreach ($year_students as $student_id) {
                    // Check if already enrolled
                    $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
                    $stmt->execute([$student_id, $course_id]);
                    
                    if (!$stmt->fetch()) {
                        $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, 'active')");
                        $stmt->execute([$student_id, $course_id]);
                        $enrolled_count++;
                    } else {
                        $already_enrolled++;
                    }
                }
                
                if ($enrolled_count > 0) {
                    setFlash('success', "Successfully enrolled $enrolled_count students from academic year $academic_year." . ($already_enrolled > 0 ? " $already_enrolled students were already enrolled." : ""));
                } else {
                    setFlash('info', "All students from academic year $academic_year are already enrolled in this course.");
                }
                
            } catch(PDOException $e) {
                setFlash('error', 'Error in bulk enrollment: ' . $e->getMessage());
            }
        }
    }
}

// Get all courses
try {
    $stmt = $pdo->prepare("
        SELECT c.*, d.department_name, u.first_name, u.last_name,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id AND status = 'active') as enrolled_count
        FROM courses c 
        LEFT JOIN departments d ON c.department = d.department_code 
        LEFT JOIN users u ON c.instructor_id = u.id 
        WHERE c.is_active = 1 
        ORDER BY c.course_code
    ");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all students with additional filters
    $stmt = $pdo->prepare("
        SELECT u.*, d.department_name,
               (SELECT COUNT(*) FROM enrollments WHERE student_id = u.id) as course_count
        FROM users u 
        LEFT JOIN departments d ON u.department = d.department_code 
        WHERE u.role = 'student' AND u.is_active = 1 
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get departments for bulk enrollment
    $stmt = $pdo->prepare("
        SELECT DISTINCT department, department_name 
        FROM users u 
        LEFT JOIN departments d ON u.department = d.department_code 
        WHERE u.role = 'student' AND u.is_active = 1 AND u.department IS NOT NULL
        ORDER BY department_name
    ");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get academic years
    $stmt = $pdo->prepare("
        SELECT DISTINCT academic_year 
        FROM users 
        WHERE role = 'student' AND is_active = 1 AND academic_year IS NOT NULL
        ORDER BY academic_year DESC
    ");
    $stmt->execute();
    $academic_years = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get enrollment statistics
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_students FROM users WHERE role = 'student' AND is_active = 1
    ");
    $stmt->execute();
    $total_students = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT student_id) as total_enrolled FROM enrollments WHERE status = 'active'
    ");
    $stmt->execute();
    $total_enrolled = $stmt->fetchColumn();
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching data: ' . $e->getMessage());
    $courses = [];
    $students = [];
    $departments = [];
    $academic_years = [];
    $total_students = 0;
    $total_enrolled = 0;
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Enroll Students</h1>
                <p class="text-muted mb-0">Manage student enrollments in courses</p>
            </div>
            <div class="text-end">
                <div class="row">
                    <div class="col-auto">
                        <div class="card bg-light">
                            <div class="card-body py-2">
                                <small class="text-muted">Total Students:</small>
                                <div class="fw-bold text-primary"><?php echo $total_students; ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="card bg-light">
                            <div class="card-body py-2">
                                <small class="text-muted">Total Enrollments:</small>
                                <div class="fw-bold text-success"><?php echo $total_enrolled; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-user-plus me-2"></i> Enroll Students in Courses
                </h5>
            </div>
            <div class="card-body">
                <!-- Course Selection -->
                <div class="row mb-4">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label for="course_id" class="form-label">Select Course *</label>
                            <select class="form-select" id="course_id" name="course_id" required>
                                <option value="">Choose a course...</option>
                                <?php foreach($courses as $course): ?>
                                    <option value="<?php echo $course['id']; ?>" data-department="<?php echo htmlspecialchars($course['department']); ?>">
                                        <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        (<?php echo htmlspecialchars($course['department_name']); ?>)
                                        - <?php echo $course['enrolled_count']; ?> enrolled
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">Quick Actions</label>
                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-outline-primary" onclick="selectAllStudents()">
                                    <i class="fas fa-check-square me-2"></i> Select All
                                </button>
                                <button type="button" class="btn btn-outline-secondary" onclick="deselectAllStudents()">
                                    <i class="fas fa-times-circle me-2"></i> Deselect All
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bulk Enrollment Options -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-users me-2 text-primary"></i> Bulk Enrollment Options
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <form method="POST" class="bulk-form">
                                    <input type="hidden" name="course_id" id="bulk_course_id_department">
                                    <div class="mb-3">
                                        <label for="department" class="form-label">Enroll by Department</label>
                                        <select class="form-select" id="department" name="department">
                                            <option value="">Select Department</option>
                                            <?php foreach($departments as $dept): ?>
                                                <option value="<?php echo htmlspecialchars($dept['department']); ?>">
                                                    <?php echo htmlspecialchars($dept['department_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <button type="submit" name="bulk_enroll_by_department" class="btn btn-outline-primary w-100">
                                        <i class="fas fa-building me-2"></i> Enroll Department
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <form method="POST" class="bulk-form">
                                    <input type="hidden" name="course_id" id="bulk_course_id_year">
                                    <div class="mb-3">
                                        <label for="academic_year" class="form-label">Enroll by Academic Year</label>
                                        <select class="form-select" id="academic_year" name="academic_year">
                                            <option value="">Select Year</option>
                                            <?php foreach($academic_years as $year): ?>
                                                <option value="<?php echo htmlspecialchars($year); ?>">
                                                    <?php echo htmlspecialchars($year); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <button type="submit" name="bulk_enroll_by_year" class="btn btn-outline-success w-100">
                                        <i class="fas fa-calendar me-2"></i> Enroll Year
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3 border rounded h-100 d-flex flex-column justify-content-center">
                                    <i class="fas fa-info-circle fa-2x text-info mb-2"></i>
                                    <h6>Quick Tips</h6>
                                    <small class="text-muted">
                                        • Use bulk enrollment for large groups<br>
                                        • Filter students using search<br>
                                        • Check enrollment status before submitting
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Student Selection -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <label class="form-label mb-0">
                            Select Individual Students * 
                            <span class="badge bg-primary" id="selectedCount">0 selected</span>
                        </label>
                        <div class="d-flex gap-2">
                            <input type="text" class="form-control form-control-sm" id="studentSearch" placeholder="Search students..." style="width: 200px;">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="filterByDepartment()">
                                <i class="fas fa-filter me-1"></i> Filter
                            </button>
                        </div>
                    </div>
                    
                    <div class="border rounded p-3" style="max-height: 400px; overflow-y: auto;">
                        <div class="row" id="studentList">
                            <?php foreach($students as $student): ?>
                                <div class="col-md-6 col-lg-4 mb-2 student-item" 
                                     data-department="<?php echo htmlspecialchars($student['department']); ?>"
                                     data-year="<?php echo htmlspecialchars($student['academic_year']); ?>"
                                     data-name="<?php echo htmlspecialchars(strtolower($student['first_name'] . ' ' . $student['last_name'])); ?>">
                                    <div class="form-check">
                                        <input class="form-check-input student-checkbox" type="checkbox" name="student_ids[]" 
                                               value="<?php echo $student['id']; ?>" id="student_<?php echo $student['id']; ?>">
                                        <label class="form-check-label w-100" for="student_<?php echo $student['id']; ?>">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div class="flex-grow-1">
                                                    <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        @<?php echo htmlspecialchars($student['username']); ?> 
                                                        | ID: <?php echo htmlspecialchars($student['university_id']); ?>
                                                    </small>
                                                    <br>
                                                    <small>
                                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($student['department_name']); ?></span>
                                                        <span class="badge bg-info"><?php echo htmlspecialchars($student['academic_year']); ?></span>
                                                        <span class="badge bg-light text-dark"><?php echo $student['course_count']; ?> courses</span>
                                                    </small>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="mt-2 d-flex justify-content-between align-items-center">
                        <small class="text-muted" id="filterInfo">Showing all <?php echo count($students); ?> students</small>
                        <div>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="selectByDepartment()">
                                <i class="fas fa-users me-1"></i> Select by Department
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success" onclick="selectByYear()">
                                <i class="fas fa-calendar me-1"></i> Select by Year
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Enrollment Actions -->
                <div class="d-flex justify-content-between align-items-center border-top pt-3">
                    <a href="manage_courses.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Back to Courses
                    </a>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-info" onclick="previewEnrollment()">
                            <i class="fas fa-eye me-2"></i> Preview
                        </button>
                        <button type="submit" name="enroll_students" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Enroll Selected Students
                        </button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Enrollment Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" form="enrollmentForm" name="enroll_students" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i> Confirm Enrollment
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Update selected count
function updateSelectedCount() {
    const selected = document.querySelectorAll('.student-checkbox:checked').length;
    document.getElementById('selectedCount').textContent = selected + ' selected';
}

// Select all students
function selectAllStudents() {
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.checked = true;
    });
    updateSelectedCount();
}

// Deselect all students
function deselectAllStudents() {
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.checked = false;
    });
    updateSelectedCount();
}

// Filter students by search
function filterStudents() {
    const searchTerm = document.getElementById('studentSearch').value.toLowerCase();
    const studentItems = document.querySelectorAll('.student-item');
    let visibleCount = 0;
    
    studentItems.forEach(item => {
        const studentName = item.getAttribute('data-name');
        if (studentName.includes(searchTerm)) {
            item.style.display = 'block';
            visibleCount++;
        } else {
            item.style.display = 'none';
        }
    });
    
    document.getElementById('filterInfo').textContent = `Showing ${visibleCount} students`;
}

// Filter by department
function filterByDepartment() {
    const courseSelect = document.getElementById('course_id');
    const courseDepartment = courseSelect.options[courseSelect.selectedIndex]?.getAttribute('data-department');
    
    if (courseDepartment) {
        const studentItems = document.querySelectorAll('.student-item');
        let visibleCount = 0;
        
        studentItems.forEach(item => {
            const studentDepartment = item.getAttribute('data-department');
            if (studentDepartment === courseDepartment) {
                item.style.display = 'block';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
        
        document.getElementById('filterInfo').textContent = `Showing ${visibleCount} students from ${courseDepartment} department`;
    } else {
        alert('Please select a course first to filter by department.');
    }
}

// Select students by department
function selectByDepartment() {
    const courseSelect = document.getElementById('course_id');
    const courseDepartment = courseSelect.options[courseSelect.selectedIndex]?.getAttribute('data-department');
    
    if (courseDepartment) {
        document.querySelectorAll('.student-item').forEach(item => {
            const studentDepartment = item.getAttribute('data-department');
            if (studentDepartment === courseDepartment) {
                item.querySelector('.student-checkbox').checked = true;
            }
        });
        updateSelectedCount();
    } else {
        alert('Please select a course first.');
    }
}

// Select students by year
function selectByYear() {
    const year = prompt('Enter academic year (e.g., 2023-2024):');
    if (year) {
        document.querySelectorAll('.student-item').forEach(item => {
            const studentYear = item.getAttribute('data-year');
            if (studentYear === year) {
                item.querySelector('.student-checkbox').checked = true;
            }
        });
        updateSelectedCount();
    }
}

// Preview enrollment
function previewEnrollment() {
    const courseSelect = document.getElementById('course_id');
    const courseText = courseSelect.options[courseSelect.selectedIndex]?.text || 'No course selected';
    const selectedStudents = document.querySelectorAll('.student-checkbox:checked');
    
    if (selectedStudents.length === 0) {
        alert('Please select at least one student.');
        return;
    }
    
    let previewContent = `
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            You are about to enroll <strong>${selectedStudents.length} students</strong> in:
            <strong>${courseText}</strong>
        </div>
        <h6>Selected Students:</h6>
        <div class="table-responsive">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Department</th>
                        <th>Year</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    selectedStudents.forEach(checkbox => {
        const item = checkbox.closest('.student-item');
        const name = item.querySelector('strong').textContent;
        const username = item.querySelector('small.text-muted').textContent.split('|')[0].replace('@', '').trim();
        const department = item.querySelector('.badge.bg-secondary').textContent;
        const year = item.querySelector('.badge.bg-info').textContent;
        
        previewContent += `
            <tr>
                <td>${name}</td>
                <td>@${username}</td>
                <td>${department}</td>
                <td>${year}</td>
            </tr>
        `;
    });
    
    previewContent += `
                </tbody>
            </table>
        </div>
    `;
    
    document.getElementById('previewContent').innerHTML = previewContent;
    const previewModal = new bootstrap.Modal(document.getElementById('previewModal'));
    previewModal.show();
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Update selected count when checkboxes change
    document.querySelectorAll('.student-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectedCount);
    });
    
    // Search functionality
    document.getElementById('studentSearch').addEventListener('input', filterStudents);
    
    // Update bulk form course IDs when course selection changes
    document.getElementById('course_id').addEventListener('change', function() {
        const courseId = this.value;
        document.getElementById('bulk_course_id_department').value = courseId;
        document.getElementById('bulk_course_id_year').value = courseId;
    });
    
    // Update bulk forms when course is selected
    document.querySelectorAll('.bulk-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            const courseId = document.getElementById('course_id').value;
            if (!courseId) {
                e.preventDefault();
                alert('Please select a course first.');
                return;
            }
            this.querySelector('input[name="course_id"]').value = courseId;
        });
    });
    
    // Initialize selected count
    updateSelectedCount();
});
</script>

<style>
.student-item {
    transition: all 0.3s ease;
}

.student-item:hover {
    background-color: #f8f9fa;
    border-radius: 5px;
}

.student-checkbox:checked + label {
    background-color: #e7f3ff;
    border-radius: 5px;
    padding: 5px;
}

.bulk-form {
    margin-bottom: 0;
}

#selectedCount {
    font-size: 0.8em;
}

.form-check-label {
    cursor: pointer;
    padding: 5px;
    border-radius: 5px;
    transition: background-color 0.2s ease;
}

.form-check-label:hover {
    background-color: #f8f9fa;
}

.card-header.bg-primary {
    background: linear-gradient(135deg, #007bff 0%, #0056b3 100%) !important;
}
</style>

<?php require_once '../includes/footer.php'; ?>