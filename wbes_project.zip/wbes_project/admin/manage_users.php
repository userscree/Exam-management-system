<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Users';
require_once '../includes/header.php';

// Function to generate unique student ID
function generateStudentId($pdo, $department = '') {
    $prefix = 'STU';
    
    // If department is provided, use department code as prefix
    if (!empty($department)) {
        $prefix = strtoupper(substr($department, 0, 3));
    }
    
    // Get current year
    $current_year = date('y');
    
    // Try to generate unique ID
    $max_attempts = 10;
    $attempt = 0;
    
    while ($attempt < $max_attempts) {
        // Generate random 4-digit number
        $random_number = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        // Create student ID format: DEP23-1234 or STU23-1234
        $student_id = $prefix . $current_year . '-' . $random_number;
        
        // Check if this ID already exists
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE student_id = ?");
            $stmt->execute([$student_id]);
            
            if (!$stmt->fetch()) {
                return $student_id; // Unique ID found
            }
        } catch(PDOException $e) {
            // If there's an error, fall back to a simpler format
            $student_id = $prefix . $current_year . $random_number;
            return $student_id;
        }
        
        $attempt++;
    }
    
    // If all attempts fail, use timestamp-based ID
    return $prefix . $current_year . time();
}

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_user'])) {
        // Add new user
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $first_name = sanitize($_POST['first_name']);
        $last_name = sanitize($_POST['last_name']);
        $role = sanitize($_POST['role']);
        $department = sanitize($_POST['department'] ?? '');
        $student_id = sanitize($_POST['student_id'] ?? '');
        $university_id = sanitize($_POST['university_id'] ?? '');
        $academic_year = sanitize($_POST['academic_year'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        
        try {
            // Check if username or email exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Username or email already exists.');
            } else {
                // Validate university ID for students
                if ($role == 'student') {
                    if (empty($university_id)) {
                        setFlash('error', 'University ID is required for students.');
                    } else {
                        // Check if university ID already exists
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE university_id = ?");
                        $stmt->execute([$university_id]);
                        if ($stmt->fetch()) {
                            setFlash('error', 'University ID already exists.');
                        }
                    }
                    
                    // Auto-generate student ID if not provided
                    if (empty($student_id)) {
                        $student_id = generateStudentId($pdo, $department);
                    }
                }
                
                if (!isset($_SESSION['flash'])) {
                    $hashed_password = hashPassword($password);
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role, first_name, last_name, department, student_id, university_id, academic_year, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$username, $email, $hashed_password, $role, $first_name, $last_name, $department, $student_id, $university_id, $academic_year, $phone]);
                    
                    setFlash('success', 'User added successfully! Student ID: ' . $student_id);
                    redirect('manage_users.php');
                }
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error adding user: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_user'])) {
        // Update user
        $user_id = $_POST['user_id'];
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $first_name = sanitize($_POST['first_name']);
        $last_name = sanitize($_POST['last_name']);
        $role = sanitize($_POST['role']);
        $department = sanitize($_POST['department'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $student_id = sanitize($_POST['student_id'] ?? '');
        $university_id = sanitize($_POST['university_id'] ?? '');
        $academic_year = sanitize($_POST['academic_year'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        
        try {
            // Check if username or email exists for other users
            $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $user_id]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Username or email already exists for another user.');
            } else {
                // Validate university ID for students
                if ($role == 'student') {
                    if (empty($university_id)) {
                        setFlash('error', 'University ID is required for students.');
                    } else {
                        // Check if university ID already exists for other users
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE university_id = ? AND id != ?");
                        $stmt->execute([$university_id, $user_id]);
                        if ($stmt->fetch()) {
                            setFlash('error', 'University ID already exists for another user.');
                        }
                    }
                    
                    // Auto-generate student ID if not provided and user is being converted to student
                    $current_user_stmt = $pdo->prepare("SELECT role, student_id FROM users WHERE id = ?");
                    $current_user_stmt->execute([$user_id]);
                    $current_user = $current_user_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (empty($student_id) && ($current_user['role'] != 'student' || empty($current_user['student_id']))) {
                        $student_id = generateStudentId($pdo, $department);
                    }
                }
                
                if (!isset($_SESSION['flash'])) {
                    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, first_name = ?, last_name = ?, role = ?, department = ?, is_active = ?, student_id = ?, university_id = ?, academic_year = ?, phone = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$username, $email, $first_name, $last_name, $role, $department, $is_active, $student_id, $university_id, $academic_year, $phone, $user_id]);
                    
                    setFlash('success', 'User updated successfully!' . ($student_id ? ' Student ID: ' . $student_id : ''));
                    redirect('manage_users.php');
                }
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error updating user: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_user'])) {
        // Delete user
        $user_id = $_POST['user_id'];
        
        try {
            // Prevent deleting own account
            if ($user_id == $_SESSION['user_id']) {
                setFlash('error', 'You cannot delete your own account.');
            } else {
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                
                setFlash('success', 'User deleted successfully!');
                redirect('manage_users.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting user: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['reset_password'])) {
        // Reset user password
        $user_id = $_POST['user_id'];
        $new_password = $_POST['new_password'];
        
        try {
            $hashed_password = hashPassword($new_password);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$hashed_password, $user_id]);
            
            setFlash('success', 'Password reset successfully!');
            redirect('manage_users.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error resetting password: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['generate_student_id'])) {
        // Generate student ID for existing student
        $user_id = $_POST['user_id'];
        
        try {
            // Get user details
            $stmt = $pdo->prepare("SELECT role, department FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && $user['role'] == 'student') {
                $student_id = generateStudentId($pdo, $user['department']);
                
                $stmt = $pdo->prepare("UPDATE users SET student_id = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$student_id, $user_id]);
                
                setFlash('success', 'Student ID generated successfully: ' . $student_id);
            } else {
                setFlash('error', 'Can only generate student IDs for students.');
            }
            
            redirect('manage_users.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error generating student ID: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$role_filter = $_GET['role'] ?? '';
$status_filter = $_GET['status'] ?? '';
$department_filter = $_GET['department'] ?? '';
$academic_year_filter = $_GET['academic_year'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for users
$query = "SELECT * FROM users WHERE 1=1";
$params = [];

if (!empty($role_filter)) {
    $query .= " AND role = ?";
    $params[] = $role_filter;
}

if ($status_filter === 'active') {
    $query .= " AND is_active = 1";
} elseif ($status_filter === 'inactive') {
    $query .= " AND is_active = 0";
}

if (!empty($department_filter)) {
    $query .= " AND department = ?";
    $params[] = $department_filter;
}

if (!empty($academic_year_filter)) {
    $query .= " AND academic_year = ?";
    $params[] = $academic_year_filter;
}

if (!empty($search)) {
    $query .= " AND (username LIKE ? OR email LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR university_id LIKE ? OR student_id LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get departments
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_code");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get user counts for statistics
    $stmt = $pdo->prepare("SELECT role, COUNT(*) as count FROM users GROUP BY role");
    $stmt->execute();
    $role_counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM users");
    $stmt->execute();
    $total_users = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM users WHERE is_active = 1");
    $stmt->execute();
    $active_users = $stmt->fetchColumn();
    
    // Get department statistics
    $stmt = $pdo->prepare("SELECT department, COUNT(*) as count FROM users WHERE department IS NOT NULL GROUP BY department");
    $stmt->execute();
    $department_counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get academic years
    $stmt = $pdo->prepare("SELECT DISTINCT academic_year FROM users WHERE academic_year IS NOT NULL ORDER BY academic_year DESC");
    $stmt->execute();
    $academic_years = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching users: ' . $e->getMessage());
    $users = [];
    $departments = [];
    $role_counts = [];
    $total_users = 0;
    $active_users = 0;
    $department_counts = [];
    $academic_years = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Users</h1>
                <p class="text-muted mb-0">Create, edit, and manage system users</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                    <i class="fas fa-user-plus me-2"></i> Add New User
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addUserModal"><i class="fas fa-user-plus me-2"></i>Add User</a></li>
                    <li><a class="dropdown-item" href="manage_departments.php"><i class="fas fa-building me-2"></i>Manage Departments</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Users
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_users; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Users
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_users; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Students
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php 
                            $student_count = 0;
                            foreach($role_counts as $count) {
                                if ($count['role'] == 'student') {
                                    $student_count = $count['count'];
                                    break;
                                }
                            }
                            echo $student_count;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Instructors
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php 
                            $instructor_count = 0;
                            foreach($role_counts as $count) {
                                if ($count['role'] == 'instructor') {
                                    $instructor_count = $count['count'];
                                    break;
                                }
                            }
                            echo $instructor_count;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chalkboard-teacher fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Admins
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php 
                            $admin_count = 0;
                            foreach($role_counts as $count) {
                                if ($count['role'] == 'admin') {
                                    $admin_count = $count['count'];
                                    break;
                                }
                            }
                            echo $admin_count;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-shield-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                            Departments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($departments); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-building fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Department Distribution -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-primary"></i>
                    Department Distribution
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php if(empty($department_counts)): ?>
                        <div class="col-12 text-center text-muted py-3">
                            <i class="fas fa-building fa-2x mb-2"></i>
                            <p>No department data available</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($department_counts as $dept): ?>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="d-flex align-items-center p-3 border rounded">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-university fa-2x text-primary me-3"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-bold text-primary"><?php echo $dept['count']; ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($dept['department']); ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-2">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="role" class="form-label">Role</label>
                <select class="form-select" id="role" name="role">
                    <option value="">All Roles</option>
                    <option value="admin" <?php echo $role_filter == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="instructor" <?php echo $role_filter == 'instructor' ? 'selected' : ''; ?>>Instructor</option>
                    <option value="student" <?php echo $role_filter == 'student' ? 'selected' : ''; ?>>Student</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="department" class="form-label">Department</label>
                <select class="form-select" id="department" name="department">
                    <option value="">All Departments</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" <?php echo $department_filter == $dept['department_code'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department_code']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="academic_year" class="form-label">Academic Year</label>
                <select class="form-select" id="academic_year" name="academic_year">
                    <option value="">All Years</option>
                    <?php foreach($academic_years as $year): ?>
                        <option value="<?php echo htmlspecialchars($year); ?>" <?php echo $academic_year_filter == $year ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($year); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="manage_users.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Users Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Users List
            <span class="badge bg-primary ms-2"><?php echo count($users); ?> users</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>User Information</th>
                        <th>Academic Details</th>
                        <th>Role & Status</th>
                        <th>Contact</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($users)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No users found</h5>
                                <p class="text-muted">Try adjusting your filters or add a new user.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($users as $user): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h6>
                                            <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                                            <?php if(!empty($user['student_id'])): ?>
                                                <div class="mt-1">
                                                    <small class="text-muted">Student ID:</small>
                                                    <span class="badge bg-success"><?php echo htmlspecialchars($user['student_id']); ?></span>
                                                </div>
                                            <?php elseif($user['role'] == 'student'): ?>
                                                <div class="mt-1">
                                                    <small class="text-muted">Student ID:</small>
                                                    <span class="badge bg-warning">Not Assigned</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if($user['role'] == 'student'): ?>
                                        <?php if(!empty($user['university_id'])): ?>
                                            <div class="mb-1">
                                                <small class="text-muted">University ID:</small>
                                                <div class="fw-bold text-primary"><?php echo htmlspecialchars($user['university_id']); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(!empty($user['academic_year'])): ?>
                                            <div class="mb-1">
                                                <small class="text-muted">Academic Year:</small>
                                                <span class="badge bg-info"><?php echo htmlspecialchars($user['academic_year']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(!empty($user['department'])): ?>
                                        <div>
                                            <small class="text-muted">Department:</small>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($user['department']); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge 
                                        <?php 
                                        switch($user['role']) {
                                            case 'admin': echo 'bg-danger'; break;
                                            case 'instructor': echo 'bg-warning'; break;
                                            case 'student': echo 'bg-info'; break;
                                            default: echo 'bg-secondary';
                                        }
                                        ?> mb-2">
                                        <i class="fas fa-<?php 
                                        switch($user['role']) {
                                            case 'admin': echo 'shield-alt'; break;
                                            case 'instructor': echo 'chalkboard-teacher'; break;
                                            case 'student': echo 'user-graduate'; break;
                                            default: echo 'user';
                                        }
                                        ?> me-1"></i>
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                    <br>
                                    <span class="badge bg-<?php echo $user['is_active'] ? 'success' : 'secondary'; ?>">
                                        <i class="fas fa-<?php echo $user['is_active'] ? 'check-circle' : 'times-circle'; ?> me-1"></i>
                                        <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div>
                                        <small class="text-muted">Email:</small>
                                        <div><?php echo htmlspecialchars($user['email']); ?></div>
                                    </div>
                                    <?php if(!empty($user['phone'])): ?>
                                        <div class="mt-1">
                                            <small class="text-muted">Phone:</small>
                                            <div><?php echo htmlspecialchars($user['phone']); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($user['created_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editUserModal" 
                                                data-user-id="<?php echo $user['id']; ?>"
                                                data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                                data-email="<?php echo htmlspecialchars($user['email']); ?>"
                                                data-first-name="<?php echo htmlspecialchars($user['first_name']); ?>"
                                                data-last-name="<?php echo htmlspecialchars($user['last_name']); ?>"
                                                data-role="<?php echo $user['role']; ?>"
                                                data-department="<?php echo htmlspecialchars($user['department'] ?? ''); ?>"
                                                data-student-id="<?php echo htmlspecialchars($user['student_id'] ?? ''); ?>"
                                                data-university-id="<?php echo htmlspecialchars($user['university_id'] ?? ''); ?>"
                                                data-academic-year="<?php echo htmlspecialchars($user['academic_year'] ?? ''); ?>"
                                                data-phone="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                                data-is-active="<?php echo $user['is_active']; ?>"
                                                onclick="editUser(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-outline-warning" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#resetPasswordModal"
                                                data-user-id="<?php echo $user['id']; ?>"
                                                data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                                onclick="resetPassword(this)">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <?php if($user['role'] == 'student' && empty($user['student_id'])): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" name="generate_student_id" class="btn btn-outline-success" title="Generate Student ID">
                                                    <i class="fas fa-id-card"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <?php if($user['id'] != $_SESSION['user_id']): ?>
                                            <button class="btn btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteUserModal"
                                                    data-user-id="<?php echo $user['id']; ?>"
                                                    data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                                    onclick="deleteUser(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="Cannot delete your own account">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="addUserForm">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_first_name" class="form-label">First Name *</label>
                                <input type="text" class="form-control" id="add_first_name" name="first_name" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_last_name" class="form-label">Last Name *</label>
                                <input type="text" class="form-control" id="add_last_name" name="last_name" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_username" class="form-label">Username *</label>
                                <input type="text" class="form-control" id="add_username" name="username" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="add_email" name="email" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_password" class="form-label">Password *</label>
                                <input type="password" class="form-control" id="add_password" name="password" required minlength="8">
                                <div class="form-text">Minimum 8 characters</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_role" class="form-label">Role *</label>
                                <select class="form-select" id="add_role" name="role" required onchange="toggleStudentFields()">
                                    <option value="">Select Role</option>
                                    <option value="admin">Admin</option>
                                    <option value="instructor">Instructor</option>
                                    <option value="student">Student</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_department" class="form-label">Department</label>
                                <select class="form-select" id="add_department" name="department">
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_phone" class="form-label">Phone</label>
                                <input type="tel" class="form-control" id="add_phone" name="phone">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Student Specific Fields -->
                    <div id="studentFields" style="display: none;">
                        <hr>
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-graduation-cap me-2"></i>Student Information
                        </h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="add_university_id" class="form-label">University ID *</label>
                                    <input type="text" class="form-control" id="add_university_id" name="university_id">
                                    <div class="form-text">Unique university identification number</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="add_academic_year" class="form-label">Academic Year</label>
                                    <select class="form-select" id="add_academic_year" name="academic_year">
                                        <option value="">Select Year</option>
                                        <option value="2023-2024">2023-2024</option>
                                        <option value="2024-2025">2024-2025</option>
                                        <option value="2025-2026">2025-2026</option>
                                        <option value="2026-2027">2026-2027</option>
                                        <option value="2027-2028">2027-2028</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="add_student_id" class="form-label">Student ID (Internal)</label>
                                    <input type="text" class="form-control" id="add_student_id" name="student_id" placeholder="Auto-generated if left empty">
                                    <div class="form-text">Internal student identification number - will be auto-generated if left empty</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="editUserForm">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_first_name" class="form-label">First Name *</label>
                                <input type="text" class="form-control" id="edit_first_name" name="first_name" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_last_name" class="form-label">Last Name *</label>
                                <input type="text" class="form-control" id="edit_last_name" name="last_name" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_username" class="form-label">Username *</label>
                                <input type="text" class="form-control" id="edit_username" name="username" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_role" class="form-label">Role *</label>
                                <select class="form-select" id="edit_role" name="role" required onchange="toggleEditStudentFields()">
                                    <option value="">Select Role</option>
                                    <option value="admin">Admin</option>
                                    <option value="instructor">Instructor</option>
                                    <option value="student">Student</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                                    <label class="form-check-label" for="edit_is_active">Active User</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_department" class="form-label">Department</label>
                                <select class="form-select" id="edit_department" name="department">
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_phone" class="form-label">Phone</label>
                                <input type="tel" class="form-control" id="edit_phone" name="phone">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Student Specific Fields -->
                    <div id="editStudentFields" style="display: none;">
                        <hr>
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-graduation-cap me-2"></i>Student Information
                        </h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_university_id" class="form-label">University ID *</label>
                                    <input type="text" class="form-control" id="edit_university_id" name="university_id">
                                    <div class="form-text">Unique university identification number</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_academic_year" class="form-label">Academic Year</label>
                                    <select class="form-select" id="edit_academic_year" name="academic_year">
                                        <option value="">Select Year</option>
                                        <option value="2023-2024">2023-2024</option>
                                        <option value="2024-2025">2024-2025</option>
                                        <option value="2025-2026">2025-2026</option>
                                        <option value="2026-2027">2026-2027</option>
                                        <option value="2027-2028">2027-2028</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_student_id" class="form-label">Student ID (Internal)</label>
                                    <input type="text" class="form-control" id="edit_student_id" name="student_id" placeholder="Auto-generated if left empty">
                                    <div class="form-text">Internal student identification number - will be auto-generated if left empty</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_user" class="btn btn-primary">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="user_id" id="reset_user_id">
                <div class="modal-header">
                    <h5 class="modal-title">Reset Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Reset password for user: <strong id="reset_username"></strong></p>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password *</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                        <div class="form-text">Minimum 8 characters</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="reset_password" class="btn btn-warning">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="user_id" id="delete_user_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this user?</h6>
                    <p class="text-center text-muted">User: <strong id="delete_username"></strong></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. All user data will be permanently deleted.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_user" class="btn btn-danger">Delete User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleStudentFields() {
    const role = document.getElementById('add_role').value;
    const studentFields = document.getElementById('studentFields');
    
    if (role === 'student') {
        studentFields.style.display = 'block';
        document.getElementById('add_university_id').required = true;
    } else {
        studentFields.style.display = 'none';
        document.getElementById('add_university_id').required = false;
    }
}

function toggleEditStudentFields() {
    const role = document.getElementById('edit_role').value;
    const studentFields = document.getElementById('editStudentFields');
    
    if (role === 'student') {
        studentFields.style.display = 'block';
        document.getElementById('edit_university_id').required = true;
    } else {
        studentFields.style.display = 'none';
        document.getElementById('edit_university_id').required = false;
    }
}

function editUser(button) {
    const userId = button.getAttribute('data-user-id');
    const username = button.getAttribute('data-username');
    const email = button.getAttribute('data-email');
    const firstName = button.getAttribute('data-first-name');
    const lastName = button.getAttribute('data-last-name');
    const role = button.getAttribute('data-role');
    const department = button.getAttribute('data-department');
    const studentId = button.getAttribute('data-student-id');
    const universityId = button.getAttribute('data-university-id');
    const academicYear = button.getAttribute('data-academic-year');
    const phone = button.getAttribute('data-phone');
    const isActive = button.getAttribute('data-is-active');
    
    document.getElementById('edit_user_id').value = userId;
    document.getElementById('edit_username').value = username;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_first_name').value = firstName;
    document.getElementById('edit_last_name').value = lastName;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_department').value = department;
    document.getElementById('edit_student_id').value = studentId;
    document.getElementById('edit_university_id').value = universityId;
    document.getElementById('edit_academic_year').value = academicYear;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_is_active').checked = isActive === '1';
    
    // Toggle student fields based on role
    toggleEditStudentFields();
}

function resetPassword(button) {
    const userId = button.getAttribute('data-user-id');
    const username = button.getAttribute('data-username');
    
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_username').textContent = username;
    document.getElementById('new_password').value = '';
}

function deleteUser(button) {
    const userId = button.getAttribute('data-user-id');
    const username = button.getAttribute('data-username');
    
    document.getElementById('delete_user_id').value = userId;
    document.getElementById('delete_username').textContent = username;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Form validation
    const addUserForm = document.getElementById('addUserForm');
    if (addUserForm) {
        addUserForm.addEventListener('submit', function(e) {
            const role = document.getElementById('add_role').value;
            const universityId = document.getElementById('add_university_id');
            
            if (role === 'student' && (!universityId.value || universityId.value.trim() === '')) {
                e.preventDefault();
                alert('University ID is required for students.');
                universityId.focus();
            }
        });
    }
    
    const editUserForm = document.getElementById('editUserForm');
    if (editUserForm) {
        editUserForm.addEventListener('submit', function(e) {
            const role = document.getElementById('edit_role').value;
            const universityId = document.getElementById('edit_university_id');
            
            if (role === 'student' && (!universityId.value || universityId.value.trim() === '')) {
                e.preventDefault();
                alert('University ID is required for students.');
                universityId.focus();
            }
        });
    }
});
</script>

<style>
.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
}

.modal-header {
    border-bottom: 2px solid #dee2e6;
}

.modal-footer {
    border-top: 2px solid #dee2e6;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}
</style>

<?php require_once '../includes/footer.php'; ?>