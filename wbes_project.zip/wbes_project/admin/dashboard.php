<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access the admin dashboard.');
    redirect('../index.php');
}

$page_title = 'Admin Dashboard';
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];

// Get dashboard statistics
try {
    // Total Users
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users");
    $stmt->execute();
    $total_users = $stmt->fetchColumn();
    
    // Total Students
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'student'");
    $stmt->execute();
    $total_students = $stmt->fetchColumn();
    
    // Total Instructors
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'instructor'");
    $stmt->execute();
    $total_instructors = $stmt->fetchColumn();
    
    // Total Courses
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE is_active = 1");
    $stmt->execute();
    $total_courses = $stmt->fetchColumn();
    
    // Total Exams
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE is_active = 1");
    $stmt->execute();
    $total_exams = $stmt->fetchColumn();
    
    // Active Exams (currently running)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE is_active = 1 AND start_date <= NOW() AND end_date >= NOW()");
    $stmt->execute();
    $active_exams = $stmt->fetchColumn();
    
    // Total Exam Attempts
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM exam_attempts");
    $stmt->execute();
    $total_attempts = $stmt->fetchColumn();
    
    // Recent Registrations (last 7 days)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $stmt->execute();
    $recent_registrations = $stmt->fetchColumn();
    
    // System Status
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'maintenance_mode'");
    $stmt->execute();
    $maintenance_mode = $stmt->fetchColumn();
    
    // Recent Activities from Audit Logs
    $stmt = $pdo->prepare("
        SELECT al.*, u.username, u.first_name, u.last_name 
        FROM audit_logs al 
        LEFT JOIN users u ON al.user_id = u.id 
        ORDER BY al.created_at DESC 
        LIMIT 10
    ");
    $stmt->execute();
    $recent_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Recent Notifications
    $stmt = $pdo->prepare("
        SELECT n.*, u.username as created_by_name 
        FROM notifications n 
        LEFT JOIN users u ON n.created_by = u.id 
        WHERE n.is_active = 1 AND (n.expires_at IS NULL OR n.expires_at > NOW())
        ORDER BY n.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $recent_notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Exam Statistics by Type
    $stmt = $pdo->prepare("
        SELECT exam_type, COUNT(*) as count 
        FROM exams 
        WHERE is_active = 1 
        GROUP BY exam_type
    ");
    $stmt->execute();
    $exam_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // User Activity (last 30 days)
    $stmt = $pdo->prepare("
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as registrations
        FROM users 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date DESC
        LIMIT 15
    ");
    $stmt->execute();
    $user_activity = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Database error: ' . $e->getMessage());
}
?>

<div class="row">
    <!-- Welcome Card -->
    <div class="col-12 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="card-title mb-2">Welcome back, <?php echo $_SESSION['user']['first_name']; ?>! 👋</h4>
                        <p class="card-text mb-0">Here's what's happening with your system today.</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="d-flex align-items-center justify-content-md-end">
                            <div class="me-3">
                                <i class="fas fa-shield-alt fa-3x opacity-50"></i>
                            </div>
                            <div>
                                <h5 class="mb-0">Administrator</h5>
                                <small>System Management</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Users
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_users; ?></div>
                        <div class="mt-2">
                            <small class="text-success">
                                <i class="fas fa-user-plus me-1"></i>
                                <?php echo $recent_registrations; ?> new this week
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Students
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_students; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-graduation-cap me-1"></i>
                                Active learners
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_courses; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <i class="fas fa-book me-1"></i>
                                Available courses
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book-open fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Active Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_exams; ?></div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        Currently running
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- System Overview -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar me-2 text-primary"></i>
                        System Overview
                    </h5>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-calendar me-1"></i> Last 30 days
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Last 7 days</a></li>
                            <li><a class="dropdown-item" href="#">Last 30 days</a></li>
                            <li><a class="dropdown-item" href="#">Last 90 days</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <i class="fas fa-chalkboard-teacher fa-2x text-info mb-2"></i>
                            <h4><?php echo $total_instructors; ?></h4>
                            <small class="text-muted">Instructors</small>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <i class="fas fa-file-signature fa-2x text-success mb-2"></i>
                            <h4><?php echo $total_exams; ?></h4>
                            <small class="text-muted">Total Exams</small>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <i class="fas fa-check-circle fa-2x text-warning mb-2"></i>
                            <h4><?php echo $total_attempts; ?></h4>
                            <small class="text-muted">Exam Attempts</small>
                        </div>
                    </div>
                </div>
                
                <!-- Exam Type Distribution -->
                <div class="mt-4">
                    <h6 class="text-muted mb-3">Exam Type Distribution</h6>
                    <div class="row">
                        <?php foreach($exam_types as $type): ?>
                            <div class="col-md-3 col-6 mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <?php 
                                        $icon = 'file-alt';
                                        $color = 'primary';
                                        switch($type['exam_type']) {
                                            case 'quiz': $icon = 'bolt'; $color = 'warning'; break;
                                            case 'midterm': $icon = 'file-medical'; $color = 'info'; break;
                                            case 'final': $icon = 'file-contract'; $color = 'danger'; break;
                                            case 'assignment': $icon = 'tasks'; $color = 'success'; break;
                                        }
                                        ?>
                                        <i class="fas fa-<?php echo $icon; ?> text-<?php echo $color; ?> me-2"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-2">
                                        <small class="text-muted"><?php echo ucfirst($type['exam_type']); ?></small>
                                        <div class="fw-bold"><?php echo $type['count']; ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activities -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2 text-primary"></i>
                    Recent Activities
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if($recent_activities): ?>
                        <?php foreach($recent_activities as $activity): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <?php 
                                        $icon = 'info-circle';
                                        $color = 'primary';
                                        switch($activity['action']) {
                                            case 'login': $icon = 'sign-in-alt'; $color = 'success'; break;
                                            case 'registration': $icon = 'user-plus'; $color = 'info'; break;
                                            case 'exam_created': $icon = 'file-plus'; $color = 'warning'; break;
                                            case 'exam_completed': $icon = 'check-circle'; $color = 'success'; break;
                                            case 'failed_login': $icon = 'exclamation-triangle'; $color = 'danger'; break;
                                        }
                                        ?>
                                        <i class="fas fa-<?php echo $icon; ?> text-<?php echo $color; ?>"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h6 class="mb-1"><?php echo ucfirst(str_replace('_', ' ', $activity['action'])); ?></h6>
                                            <small class="text-muted"><?php echo formatDate($activity['created_at']); ?></small>
                                        </div>
                                        <p class="mb-1 small text-muted">
                                            <?php if($activity['user_id']): ?>
                                                <strong><?php echo $activity['first_name'] . ' ' . $activity['last_name']; ?></strong> 
                                                (<?php echo $activity['username']; ?>)
                                            <?php else: ?>
                                                System Activity
                                            <?php endif; ?>
                                            - <?php echo $activity['description']; ?>
                                        </p>
                                        <?php if($activity['ip_address']): ?>
                                            <small class="text-muted">
                                                <i class="fas fa-globe me-1"></i>
                                                <?php echo $activity['ip_address']; ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="list-group-item text-center text-muted py-4">
                            <i class="fas fa-inbox fa-2x mb-2"></i>
                            <p class="mb-0">No recent activities found.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-footer bg-white">
                <a href="audit_logs.php" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-list me-1"></i> View All Activities
                </a>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Quick Actions -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2 text-warning"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="manage_users.php" class="btn btn-outline-primary text-start">
                        <i class="fas fa-user-plus me-2"></i> Add New User
                    </a>
                    <a href="manage_courses.php" class="btn btn-outline-success text-start">
                        <i class="fas fa-book me-2"></i> Manage Courses
                    </a>
                    <a href="manage_exams.php" class="btn btn-outline-info text-start">
                        <i class="fas fa-file-alt me-2"></i> Manage Exams
                    </a>
                    <a href="view_reports.php" class="btn btn-outline-warning text-start">
                        <i class="fas fa-chart-pie me-2"></i> View Reports
                    </a>
                    <a href="settings.php" class="btn btn-outline-secondary text-start">
                        <i class="fas fa-cog me-2"></i> System Settings
                    </a>
                </div>
            </div>
        </div>

        <!-- System Status -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="fas fa-server me-2 text-info"></i>
                    System Status
                </h5>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span>
                            <i class="fas fa-database me-2 text-primary"></i>
                            Database
                        </span>
                        <span class="badge bg-success">Online</span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span>
                            <i class="fas fa-shield-alt me-2 text-primary"></i>
                            Security
                        </span>
                        <span class="badge bg-success">Active</span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span>
                            <i class="fas fa-bell me-2 text-primary"></i>
                            Notifications
                        </span>
                        <span class="badge bg-success">Enabled</span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span>
                            <i class="fas fa-tools me-2 text-primary"></i>
                            Maintenance Mode
                        </span>
                        <span class="badge bg-<?php echo $maintenance_mode ? 'warning' : 'success'; ?>">
                            <?php echo $maintenance_mode ? 'Enabled' : 'Disabled'; ?>
                        </span>
                    </div>
                    <div class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                        <span>
                            <i class="fas fa-user-plus me-2 text-primary"></i>
                            Registration
                        </span>
                        <span class="badge bg-<?php echo $allow_registration ? 'success' : 'secondary'; ?>">
                            <?php echo $allow_registration ? 'Open' : 'Closed'; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Notifications -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="fas fa-bell me-2 text-warning"></i>
                    Recent Notifications
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if($recent_notifications): ?>
                        <?php foreach($recent_notifications as $notification): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-bell text-warning mt-1"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1"><?php echo $notification['title']; ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo substr($notification['message'], 0, 80) . '...'; ?></p>
                                        <small class="text-muted">
                                            By: <?php echo $notification['created_by_name']; ?> 
                                            • <?php echo formatDate($notification['created_at']); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="list-group-item text-center text-muted py-4">
                            <i class="fas fa-bell-slash fa-2x mb-2"></i>
                            <p class="mb-0">No recent notifications.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-footer bg-white">
                <a href="notifications.php" class="btn btn-sm btn-outline-warning">
                    <i class="fas fa-eye me-1"></i> View All Notifications
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats Row 2 -->
<div class="row mt-4">
    <div class="col-md-3">
        <div class="card bg-gradient-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-0"><?php echo $total_instructors; ?></h4>
                        <p class="mb-0">Instructors</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-chalkboard-teacher fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-gradient-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-0"><?php echo $total_exams; ?></h4>
                        <p class="mb-0">Total Exams</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-file-alt fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-gradient-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-0"><?php echo $total_attempts; ?></h4>
                        <p class="mb-0">Exam Attempts</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-check-circle fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-gradient-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-0"><?php echo $recent_registrations; ?></h4>
                        <p class="mb-0">New Users (7d)</p>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-user-plus fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$additional_scripts = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Auto-refresh dashboard every 60 seconds
    setInterval(function() {
        // You can add AJAX refresh here if needed
        console.log("Dashboard auto-refresh check");
    }, 60000);
    
    // Add click animation to quick action buttons
    const quickActions = document.querySelectorAll(".btn-outline-primary, .btn-outline-success, .btn-outline-info, .btn-outline-warning");
    quickActions.forEach(btn => {
        btn.addEventListener("click", function() {
            this.style.transform = "scale(0.98)";
            setTimeout(() => {
                this.style.transform = "scale(1)";
            }, 150);
        });
    });
});
</script>
';
require_once '../includes/footer.php'; 
?>