<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Courses';
require_once '../includes/header.php';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_course'])) {
        // Add new course
        $course_code = sanitize($_POST['course_code']);
        $course_name = sanitize($_POST['course_name']);
        $description = sanitize($_POST['description']);
        $instructor_id = $_POST['instructor_id'];
        $department = sanitize($_POST['department']);
        $credits = $_POST['credits'];
        $academic_year = sanitize($_POST['academic_year']);
        $semester = sanitize($_POST['semester']);
        $max_students = $_POST['max_students'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        try {
            // Check if course code already exists for the same academic year and semester
            $stmt = $pdo->prepare("SELECT id FROM courses WHERE course_code = ? AND academic_year = ? AND semester = ?");
            $stmt->execute([$course_code, $academic_year, $semester]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Course code already exists for this academic year and semester. Please use a unique course code or change academic year/semester.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO courses (course_code, course_name, description, instructor_id, department, credits, academic_year, semester, max_students, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$course_code, $course_name, $description, $instructor_id, $department, $credits, $academic_year, $semester, $max_students, $is_active]);
                
                $course_id = $pdo->lastInsertId();
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_SESSION['user_id'],
                    'course_added',
                    'Added new course: ' . $course_code . ' - ' . $course_name,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                setFlash('success', 'Course added successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error adding course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_course'])) {
        // Update course
        $course_id = $_POST['course_id'];
        $course_code = sanitize($_POST['course_code']);
        $course_name = sanitize($_POST['course_name']);
        $description = sanitize($_POST['description']);
        $instructor_id = $_POST['instructor_id'];
        $department = sanitize($_POST['department']);
        $credits = $_POST['credits'];
        $academic_year = sanitize($_POST['academic_year']);
        $semester = sanitize($_POST['semester']);
        $max_students = $_POST['max_students'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        try {
            // Check if course code already exists for other courses in same academic year/semester
            $stmt = $pdo->prepare("SELECT id FROM courses WHERE course_code = ? AND academic_year = ? AND semester = ? AND id != ?");
            $stmt->execute([$course_code, $academic_year, $semester, $course_id]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Course code already exists for another course in this academic year and semester.');
            } else {
                $stmt = $pdo->prepare("UPDATE courses SET course_code = ?, course_name = ?, description = ?, instructor_id = ?, department = ?, credits = ?, academic_year = ?, semester = ?, max_students = ?, is_active = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$course_code, $course_name, $description, $instructor_id, $department, $credits, $academic_year, $semester, $max_students, $is_active, $course_id]);
                
                setFlash('success', 'Course updated successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error updating course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_course'])) {
        // Delete course
        $course_id = $_POST['course_id'];
        
        try {
            // Check if course has exams
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE course_id = ?");
            $stmt->execute([$course_id]);
            $exam_count = $stmt->fetchColumn();
            
            if ($exam_count > 0) {
                setFlash('error', 'Cannot delete course. There are exams associated with this course. Please delete the exams first.');
            } else {
                // Delete enrollments first
                $stmt = $pdo->prepare("DELETE FROM enrollments WHERE course_id = ?");
                $stmt->execute([$course_id]);
                
                // Then delete course
                $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
                $stmt->execute([$course_id]);
                
                setFlash('success', 'Course deleted successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['toggle_course_status'])) {
        // Toggle course active status
        $course_id = $_POST['course_id'];
        $current_status = $_POST['current_status'];
        $new_status = $current_status ? 0 : 1;
        
        try {
            $stmt = $pdo->prepare("UPDATE courses SET is_active = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_status, $course_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            setFlash('success', "Course {$status_text} successfully!");
            redirect('manage_courses.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating course status: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['bulk_action'])) {
        $bulk_action = $_POST['bulk_action'];
        $selected_courses = isset($_POST['selected_courses']) ? $_POST['selected_courses'] : [];
        
        if (empty($selected_courses)) {
            setFlash('error', 'Please select at least one course.');
        } else {
            try {
                $pdo->beginTransaction();
                $updated_count = 0;
                
                switch($bulk_action) {
                    case 'activate':
                        $placeholders = str_repeat('?,', count($selected_courses) - 1) . '?';
                        $stmt = $pdo->prepare("UPDATE courses SET is_active = 1, updated_at = NOW() WHERE id IN ($placeholders)");
                        $stmt->execute($selected_courses);
                        $updated_count = $stmt->rowCount();
                        break;
                        
                    case 'deactivate':
                        $placeholders = str_repeat('?,', count($selected_courses) - 1) . '?';
                        $stmt = $pdo->prepare("UPDATE courses SET is_active = 0, updated_at = NOW() WHERE id IN ($placeholders)");
                        $stmt->execute($selected_courses);
                        $updated_count = $stmt->rowCount();
                        break;
                }
                
                $pdo->commit();
                setFlash('success', "Bulk action completed. {$updated_count} courses updated.");
                redirect('manage_courses.php');
                
            } catch(PDOException $e) {
                $pdo->rollBack();
                setFlash('error', 'Error performing bulk action: ' . $e->getMessage());
            }
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$department_filter = $_GET['department'] ?? '';
$instructor_filter = $_GET['instructor'] ?? '';
$academic_year_filter = $_GET['academic_year'] ?? '';
$semester_filter = $_GET['semester'] ?? '';
$search_course = $_GET['search_course'] ?? '';
$search_instructor = $_GET['search_instructor'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 25;

// Build query for courses
$query = "
    SELECT c.*, 
           u.first_name as instructor_first_name, u.last_name as instructor_last_name, u.username as instructor_username, u.email as instructor_email,
           d.department_name,
           (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id AND status = 'active') as student_count,
           (SELECT COUNT(*) FROM exams WHERE course_id = c.id) as exam_count,
           (SELECT COUNT(*) FROM questions q JOIN exams e ON q.exam_id = e.id WHERE e.course_id = c.id) as total_questions
    FROM courses c 
    LEFT JOIN users u ON c.instructor_id = u.id 
    LEFT JOIN departments d ON c.department = d.department_code 
    WHERE 1=1
";
$count_query = "SELECT COUNT(*) FROM courses c LEFT JOIN users u ON c.instructor_id = u.id WHERE 1=1";
$params = [];
$count_params = [];

if (!empty($status_filter)) {
    if ($status_filter === 'active') {
        $query .= " AND c.is_active = 1";
        $count_query .= " AND c.is_active = 1";
    } elseif ($status_filter === 'inactive') {
        $query .= " AND c.is_active = 0";
        $count_query .= " AND c.is_active = 0";
    }
}

if (!empty($department_filter)) {
    $query .= " AND c.department = ?";
    $count_query .= " AND c.department = ?";
    $params[] = $department_filter;
    $count_params[] = $department_filter;
}

if (!empty($instructor_filter)) {
    $query .= " AND c.instructor_id = ?";
    $count_query .= " AND c.instructor_id = ?";
    $params[] = $instructor_filter;
    $count_params[] = $instructor_filter;
}

if (!empty($academic_year_filter)) {
    $query .= " AND c.academic_year = ?";
    $count_query .= " AND c.academic_year = ?";
    $params[] = $academic_year_filter;
    $count_params[] = $academic_year_filter;
}

if (!empty($semester_filter)) {
    $query .= " AND c.semester = ?";
    $count_query .= " AND c.semester = ?";
    $params[] = $semester_filter;
    $count_params[] = $semester_filter;
}

if (!empty($search_course)) {
    $query .= " AND (c.course_code LIKE ? OR c.course_name LIKE ? OR c.description LIKE ?)";
    $count_query .= " AND (c.course_code LIKE ? OR c.course_name LIKE ? OR c.description LIKE ?)";
    $search_term = "%$search_course%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
}

if (!empty($search_instructor)) {
    $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
    $count_query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
    $search_term = "%$search_instructor%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
}

// For pagination
$offset = ($page - 1) * $per_page;
$query .= " ORDER BY c.academic_year DESC, c.semester DESC, c.course_code ASC LIMIT {$offset}, {$per_page}";

try {
    // Get courses
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($count_params);
    $total_courses = $stmt->fetchColumn();
    $total_pages = ceil($total_courses / $per_page);
    
    // Get instructors for filter dropdown
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, username, email FROM users WHERE role = 'instructor' AND is_active = 1 ORDER BY first_name, last_name");
    $stmt->execute();
    $instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get departments for filter dropdown
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_name");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get unique academic years and semesters
    $stmt = $pdo->prepare("SELECT DISTINCT academic_year FROM courses ORDER BY academic_year DESC");
    $stmt->execute();
    $academic_years = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $stmt = $pdo->prepare("SELECT DISTINCT semester FROM courses ORDER BY semester DESC");
    $stmt->execute();
    $semesters = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get course statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM courses");
    $stmt->execute();
    $total_courses_count = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM courses WHERE is_active = 1");
    $stmt->execute();
    $active_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as inactive FROM courses WHERE is_active = 0");
    $stmt->execute();
    $inactive_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT SUM(student_count) as total_students FROM (SELECT COUNT(*) as student_count FROM enrollments WHERE status = 'active' GROUP BY course_id) as subquery");
    $stmt->execute();
    $total_students = $stmt->fetchColumn() ?: 0;
    
    // Get department-wise course count
    $stmt = $pdo->prepare("
        SELECT d.department_code, d.department_name, COUNT(c.id) as course_count 
        FROM departments d 
        LEFT JOIN courses c ON d.department_code = c.department AND c.is_active = 1 
        WHERE d.is_active = 1 
        GROUP BY d.department_code, d.department_name 
        ORDER BY course_count DESC
        LIMIT 5
    ");
    $stmt->execute();
    $top_departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get instructor-wise course count
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.username,
            COUNT(c.id) as course_count
        FROM users u 
        LEFT JOIN courses c ON u.id = c.instructor_id AND c.is_active = 1 
        WHERE u.role = 'instructor' AND u.is_active = 1
        GROUP BY u.id, u.first_name, u.last_name, u.username 
        ORDER BY course_count DESC
        LIMIT 5
    ");
    $stmt->execute();
    $top_instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching courses: ' . $e->getMessage());
    $courses = [];
    $instructors = [];
    $departments = [];
    $academic_years = [];
    $semesters = [];
    $total_courses_count = 0;
    $active_courses = 0;
    $inactive_courses = 0;
    $total_students = 0;
    $top_departments = [];
    $top_instructors = [];
    $total_courses = 0;
    $total_pages = 1;
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Courses</h1>
                <p class="text-muted mb-0">Comprehensive course management system</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                    <i class="fas fa-plus-circle me-2"></i> Add New Course
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addCourseModal"><i class="fas fa-plus-circle me-2"></i>Add Course</a></li>
                    <li><a class="dropdown-item" href="manage_departments.php"><i class="fas fa-building me-2"></i>Manage Departments</a></li>
                    <li><a class="dropdown-item" href="enroll_students.php"><i class="fas fa-user-plus me-2"></i>Enroll Students</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Advanced Statistics Dashboard -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($total_courses_count); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($active_courses); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Total Students
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($total_students); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Instructors
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(count($instructors)); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chalkboard-teacher fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                            Departments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(count($departments)); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-building fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
    </div>
</div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Academic Years
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format(count($academic_years)); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Analytics Row -->
<div class="row mb-4">
    <!-- Top Departments -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-primary"></i>
                    Top Departments
                </h5>
                <a href="manage_departments.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body">
                <?php if(empty($top_departments)): ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-building fa-2x mb-2"></i>
                        <p>No department data available</p>
                    </div>
                <?php else: ?>
                    <?php foreach($top_departments as $dept): 
                        $percentage = $total_courses_count > 0 ? round(($dept['course_count'] / $total_courses_count) * 100) : 0;
                    ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span class="fw-bold">
                                    <i class="fas fa-university me-2 text-primary"></i>
                                    <?php echo htmlspecialchars($dept['department_name']); ?>
                                </span>
                                <span class="text-primary fw-bold"><?php echo $dept['course_count']; ?> courses</span>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-primary" style="width: <?php echo $percentage; ?>%"></div>
                            </div>
                            <div class="text-end small text-muted"><?php echo $percentage; ?>% of total</div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Top Instructors -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-trophy me-2 text-warning"></i>
                    Top Instructors
                </h5>
                <button class="btn btn-sm btn-outline-primary" onclick="resetInstructorFilter()">Reset Filter</button>
            </div>
            <div class="card-body">
                <?php if(empty($top_instructors)): ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-chalkboard-teacher fa-2x mb-2"></i>
                        <p>No instructor data available</p>
                    </div>
                <?php else: ?>
                    <?php foreach($top_instructors as $instructor): ?>
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="fw-bold"><?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?></div>
                                    <small class="text-muted">@<?php echo htmlspecialchars($instructor['username']); ?></small>
                                </div>
                                <div class="flex-shrink-0">
                                    <span class="badge bg-primary p-2"><?php echo $instructor['course_count']; ?> courses</span>
                                </div>
                            </div>
                            <div class="mt-2 text-end">
                                <button class="btn btn-sm btn-outline-primary" onclick="filterByInstructor(<?php echo $instructor['id']; ?>)">
                                    <i class="fas fa-filter me-1"></i> Filter
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Advanced Search & Filters -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-search me-2 text-primary"></i>
            Advanced Search & Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3" id="searchForm">
            <!-- Course Search -->
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="fas fa-book text-primary"></i>
                    </span>
                    <input type="text" class="form-control border-start-0" id="search_course" name="search_course" 
                           placeholder="Search courses by code, name, or description..." 
                           value="<?php echo htmlspecialchars($search_course); ?>">
                    <button class="btn btn-outline-secondary" type="button" onclick="clearCourseSearch()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            
            <!-- Instructor Search -->
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="fas fa-chalkboard-teacher text-warning"></i>
                    </span>
                    <input type="text" class="form-control border-start-0" id="search_instructor" name="search_instructor" 
                           placeholder="Search instructors by name, username, or email..." 
                           value="<?php echo htmlspecialchars($search_instructor); ?>">
                    <button class="btn btn-outline-secondary" type="button" onclick="clearInstructorSearch()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            
            <!-- Quick Filters -->
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text bg-light">
                        <i class="fas fa-filter text-info"></i>
                    </span>
                    <select class="form-select" id="status" name="status" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active Only</option>
                        <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive Only</option>
                    </select>
                </div>
            </div>
            
            <!-- Advanced Filters -->
            <div class="col-md-3">
                <label class="form-label small text-muted">Department</label>
                <select class="form-select" id="department" name="department">
                    <option value="">All Departments</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" <?php echo $department_filter == $dept['department_code'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-3">
                <label class="form-label small text-muted">Instructor</label>
                <select class="form-select" id="instructor" name="instructor">
                    <option value="">All Instructors</option>
                    <?php foreach($instructors as $instructor): ?>
                        <option value="<?php echo $instructor['id']; ?>" <?php echo $instructor_filter == $instructor['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label class="form-label small text-muted">Academic Year</label>
                <select class="form-select" id="academic_year" name="academic_year">
                    <option value="">All Years</option>
                    <?php foreach($academic_years as $year): ?>
                        <option value="<?php echo htmlspecialchars($year); ?>" <?php echo $academic_year_filter == $year ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($year); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label class="form-label small text-muted">Semester</label>
                <select class="form-select" id="semester" name="semester">
                    <option value="">All Semesters</option>
                    <?php foreach($semesters as $sem): ?>
                        <option value="<?php echo htmlspecialchars($sem); ?>" <?php echo $semester_filter == $sem ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($sem); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Apply Filters
                    </button>
                    <button type="button" class="btn btn-outline-secondary" onclick="resetFilters()">
                        <i class="fas fa-redo me-2"></i> Reset
                    </button>
                </div>
            </div>
        </form>
        
        <!-- Active Filters Display -->
        <?php if($status_filter || $department_filter || $instructor_filter || $academic_year_filter || $semester_filter || $search_course || $search_instructor): ?>
        <div class="mt-3 pt-3 border-top">
            <div class="d-flex align-items-center">
                <span class="me-2 text-muted">Active Filters:</span>
                <div class="d-flex flex-wrap gap-2">
                    <?php if($status_filter): ?>
                        <span class="badge bg-primary">
                            Status: <?php echo ucfirst($status_filter); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('status')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($department_filter): ?>
                        <span class="badge bg-info">
                            Department: <?php echo htmlspecialchars($department_filter); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('department')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($instructor_filter): ?>
                        <span class="badge bg-warning">
                            Instructor: <?php echo htmlspecialchars($instructor_filter); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('instructor')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($academic_year_filter): ?>
                        <span class="badge bg-success">
                            Year: <?php echo htmlspecialchars($academic_year_filter); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('academic_year')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($semester_filter): ?>
                        <span class="badge bg-secondary">
                            Semester: <?php echo htmlspecialchars($semester_filter); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('semester')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($search_course): ?>
                        <span class="badge bg-dark">
                            Course Search: <?php echo htmlspecialchars($search_course); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('search_course')"></button>
                        </span>
                    <?php endif; ?>
                    <?php if($search_instructor): ?>
                        <span class="badge bg-dark">
                            Instructor Search: <?php echo htmlspecialchars($search_instructor); ?>
                            <button type="button" class="btn-close btn-close-white ms-1" style="font-size: 0.5rem;" onclick="removeFilter('search_instructor')"></button>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Courses Table with Bulk Actions -->
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <div>
            <h5 class="card-title mb-0">
                <i class="fas fa-list me-2"></i> Courses List
                <span class="badge bg-primary ms-2"><?php echo number_format($total_courses); ?> courses</span>
            </h5>
            <small class="text-muted">Page <?php echo $page; ?> of <?php echo $total_pages; ?></small>
        </div>
        <div class="d-flex align-items-center">
            <div class="form-check me-3">
                <input class="form-check-input" type="checkbox" id="selectAllCourses">
                <label class="form-check-label small" for="selectAllCourses">Select All</label>
            </div>
            <form method="POST" class="d-flex gap-2" id="bulkActionForm">
                <select class="form-select form-select-sm" name="bulk_action" id="bulkActionSelect" style="width: auto;">
                    <option value="">Bulk Actions</option>
                    <option value="activate">Activate Selected</option>
                    <option value="deactivate">Deactivate Selected</option>
                </select>
                <button type="submit" class="btn btn-sm btn-primary" id="applyBulkAction" disabled>
                    <i class="fas fa-play me-1"></i> Apply
                </button>
            </form>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="40">
                            <input type="checkbox" id="selectAllCheckbox">
                        </th>
                        <th>Course Details</th>
                        <th>Instructor & Department</th>
                        <th>Academic Info</th>
                        <th>Statistics</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($courses)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="fas fa-book fa-3x mb-3"></i>
                                    <h4>No courses found</h4>
                                    <p>Try adjusting your search filters or add a new course.</p>
                                    <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                                        <i class="fas fa-plus-circle me-2"></i> Add Your First Course
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($courses as $course): ?>
                            <tr class="<?php echo $course['is_active'] ? '' : 'table-light'; ?>">
                                <td>
                                    <input type="checkbox" class="course-checkbox" name="selected_courses[]" value="<?php echo $course['id']; ?>">
                                </td>
                                <td>
                                    <div class="d-flex align-items-start">
                                        <div class="flex-shrink-0">
                                            <div class="bg-primary text-white rounded d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-book"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1 fw-bold text-primary"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($course['course_name']); ?></div>
                                            <?php if(!empty($course['description'])): ?>
                                                <small class="text-muted d-block mt-1"><?php echo htmlspecialchars(substr($course['description'], 0, 80)); ?>...</small>
                                            <?php endif; ?>
                                            <div class="mt-1">
                                                <span class="badge bg-light text-dark">
                                                    <i class="fas fa-star text-warning me-1"></i>
                                                    <?php echo $course['credits']; ?> credits
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if($course['instructor_first_name']): ?>
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="flex-shrink-0">
                                                <div class="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <div class="fw-semibold"><?php echo htmlspecialchars($course['instructor_first_name'] . ' ' . $course['instructor_last_name']); ?></div>
                                                <small class="text-muted">@<?php echo htmlspecialchars($course['instructor_username']); ?></small>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-exclamation-triangle me-1"></i> No Instructor
                                        </span>
                                    <?php endif; ?>
                                    
                                    <?php if($course['department_name']): ?>
                                        <div class="mt-2">
                                            <span class="badge bg-info">
                                                <i class="fas fa-university me-1"></i>
                                                <?php echo htmlspecialchars($course['department']); ?>
                                            </span>
                                            <small class="text-muted d-block"><?php echo htmlspecialchars($course['department_name']); ?></small>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="small">
                                        <div class="mb-1">
                                            <strong>Academic Year:</strong>
                                            <span class="badge bg-success"><?php echo htmlspecialchars($course['academic_year']); ?></span>
                                        </div>
                                        <div class="mb-1">
                                            <strong>Semester:</strong>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($course['semester']); ?></span>
                                        </div>
                                        <div>
                                            <strong>Capacity:</strong>
                                            <span class="text-muted"><?php echo $course['student_count']; ?>/<?php echo $course['max_students']; ?> students</span>
                                            <?php 
                                            $capacity_percentage = $course['max_students'] > 0 ? round(($course['student_count'] / $course['max_students']) * 100) : 0;
                                            $capacity_color = $capacity_percentage >= 90 ? 'danger' : ($capacity_percentage >= 70 ? 'warning' : 'success');
                                            ?>
                                            <div class="progress mt-1" style="height: 5px; width: 80px;">
                                                <div class="progress-bar bg-<?php echo $capacity_color; ?>" style="width: <?php echo $capacity_percentage; ?>%"></div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="text-muted">Students:</span>
                                            <span class="fw-bold text-primary"><?php echo $course['student_count']; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="text-muted">Exams:</span>
                                            <span class="fw-bold text-info"><?php echo $course['exam_count']; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span class="text-muted">Questions:</span>
                                            <span class="fw-bold text-success"><?php echo $course['total_questions']; ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $course['is_active'] ? 'success' : 'secondary'; ?>">
                                        <i class="fas fa-<?php echo $course['is_active'] ? 'check-circle' : 'pause-circle'; ?> me-1"></i>
                                        <?php echo $course['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                    <div class="mt-2">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                            <input type="hidden" name="current_status" value="<?php echo $course['is_active']; ?>">
                                            <button type="submit" name="toggle_course_status" class="btn btn-sm btn-<?php echo $course['is_active'] ? 'warning' : 'success'; ?>">
                                                <i class="fas fa-<?php echo $course['is_active'] ? 'pause' : 'play'; ?> me-1"></i>
                                                <?php echo $course['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editCourseModal" 
                                                data-course-id="<?php echo $course['id']; ?>"
                                                data-course-code="<?php echo htmlspecialchars($course['course_code']); ?>"
                                                data-course-name="<?php echo htmlspecialchars($course['course_name']); ?>"
                                                data-description="<?php echo htmlspecialchars($course['description'] ?? ''); ?>"
                                                data-instructor-id="<?php echo $course['instructor_id']; ?>"
                                                data-department="<?php echo htmlspecialchars($course['department'] ?? ''); ?>"
                                                data-credits="<?php echo $course['credits']; ?>"
                                                data-academic-year="<?php echo htmlspecialchars($course['academic_year']); ?>"
                                                data-semester="<?php echo htmlspecialchars($course['semester']); ?>"
                                                data-max-students="<?php echo $course['max_students']; ?>"
                                                data-is-active="<?php echo $course['is_active']; ?>"
                                                onclick="editCourse(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="enroll_students.php?course_id=<?php echo $course['id']; ?>" class="btn btn-outline-success" title="Manage Enrollments">
                                            <i class="fas fa-user-plus"></i>
                                        </a>
                                        <button class="btn btn-outline-info" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#viewCourseModal"
                                                data-course-id="<?php echo $course['id']; ?>"
                                                data-course-code="<?php echo htmlspecialchars($course['course_code']); ?>"
                                                data-course-name="<?php echo htmlspecialchars($course['course_name']); ?>"
                                                data-description="<?php echo htmlspecialchars($course['description'] ?? ''); ?>"
                                                data-instructor="<?php echo htmlspecialchars($course['instructor_first_name'] . ' ' . $course['instructor_last_name']); ?>"
                                                data-instructor-email="<?php echo htmlspecialchars($course['instructor_email'] ?? ''); ?>"
                                                data-department="<?php echo htmlspecialchars($course['department_name'] ?? ''); ?>"
                                                data-credits="<?php echo $course['credits']; ?>"
                                                data-academic-year="<?php echo htmlspecialchars($course['academic_year']); ?>"
                                                data-semester="<?php echo htmlspecialchars($course['semester']); ?>"
                                                data-max-students="<?php echo $course['max_students']; ?>"
                                                data-student-count="<?php echo $course['student_count']; ?>"
                                                data-exam-count="<?php echo $course['exam_count']; ?>"
                                                data-total-questions="<?php echo $course['total_questions']; ?>"
                                                data-is-active="<?php echo $course['is_active']; ?>"
                                                data-created-at="<?php echo $course['created_at']; ?>"
                                                onclick="viewCourse(this)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if($course['exam_count'] == 0): ?>
                                            <button class="btn btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteCourseModal"
                                                    data-course-id="<?php echo $course['id']; ?>"
                                                    data-course-code="<?php echo htmlspecialchars($course['course_code']); ?>"
                                                    data-course-name="<?php echo htmlspecialchars($course['course_name']); ?>"
                                                    onclick="deleteCourse(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="Cannot delete course with exams">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Pagination -->
    <!-- Pagination -->
<?php if($total_pages > 1): ?>
<div class="card-footer bg-white">
    <div class="d-flex justify-content-between align-items-center">
        <div class="text-muted small">
            Showing <?php echo (($page - 1) * $per_page) + 1; ?> to <?php echo min($page * $per_page, $total_courses); ?> of <?php echo number_format($total_courses); ?> courses
        </div>
        <nav>
            <ul class="pagination mb-0">
                <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">
                            <i class="fas fa-angle-double-left"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                            <i class="fas fa-angle-left"></i>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php 
                $start_page = max(1, $page - 2);
                $end_page = min($total_pages, $page + 2);
                
                for($i = $start_page; $i <= $end_page; $i++): 
                ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                            <i class="fas fa-angle-right"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>">
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>
<?php endif; ?>
</div>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="addCourseForm" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title">Add New Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_course_code" class="form-label">Course Code *</label>
                                <input type="text" class="form-control" id="add_course_code" name="course_code" 
                                       placeholder="e.g., CS101" required>
                                <div class="form-text">Unique identifier for the course</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_credits" class="form-label">Credits *</label>
                                <input type="number" class="form-control" id="add_credits" name="credits" 
                                       min="1" max="10" value="3" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_course_name" class="form-label">Course Name *</label>
                        <input type="text" class="form-control" id="add_course_name" name="course_name" 
                               placeholder="e.g., Introduction to Computer Science" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_description" class="form-label">Description</label>
                        <textarea class="form-control" id="add_description" name="description" 
                                  rows="3" placeholder="Brief description of the course..."></textarea>
                        <div class="form-text">You can use HTML tags for formatting</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_department" class="form-label">Department *</label>
                                <select class="form-select" id="add_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_instructor_id" class="form-label">Instructor *</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="add_instructor_search" 
                                           placeholder="Search instructors by name or email..." 
                                           onkeyup="searchInstructors()">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-search text-primary"></i>
                                    </span>
                                </div>
                                <select class="form-select mt-2" id="add_instructor_id" name="instructor_id" required>
                                    <option value="">Select Instructor</option>
                                    <?php foreach($instructors as $instructor): ?>
                                        <option value="<?php echo $instructor['id']; ?>" data-search="<?php echo htmlspecialchars(strtolower($instructor['first_name'] . ' ' . $instructor['last_name'] . ' ' . $instructor['username'] . ' ' . $instructor['email'])); ?>">
                                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name'] . ' (@' . $instructor['username'] . ' - ' . $instructor['email'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">Type to search instructors</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="add_academic_year" class="form-label">Academic Year *</label>
                                <select class="form-select" id="add_academic_year" name="academic_year" required>
                                    <option value="">Select Year</option>
                                    <option value="2023-2024">2023-2024</option>
                                    <option value="2024-2025" selected>2024-2025</option>
                                    <option value="2025-2026">2025-2026</option>
                                    <option value="2026-2027">2026-2027</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="add_semester" class="form-label">Semester *</label>
                                <select class="form-select" id="add_semester" name="semester" required>
                                    <option value="">Select Semester</option>
                                    <option value="Fall">Fall</option>
                                    <option value="Spring" selected>Spring</option>
                                    <option value="Summer">Summer</option>
                                    <option value="Winter">Winter</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="add_max_students" class="form-label">Max Students</label>
                                <input type="number" class="form-control" id="add_max_students" name="max_students" 
                                       min="1" max="500" value="50">
                                <div class="form-text">Maximum number of enrolled students</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="add_is_active" name="is_active" value="1" checked>
                            <label class="form-check-label" for="add_is_active">
                                <strong>Activate this course immediately</strong>
                            </label>
                        </div>
                        <div class="form-text">
                            If unchecked, the course will be created but won't be visible to students until activated.
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_course" class="btn btn-primary">Add Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Course Modal -->
<div class="modal fade" id="editCourseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="editCourseForm">
                <input type="hidden" name="course_id" id="edit_course_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_course_code" class="form-label">Course Code *</label>
                                <input type="text" class="form-control" id="edit_course_code" name="course_code" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_credits" class="form-label">Credits *</label>
                                <input type="number" class="form-control" id="edit_credits" name="credits" 
                                       min="1" max="10" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_course_name" class="form-label">Course Name *</label>
                        <input type="text" class="form-control" id="edit_course_name" name="course_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_department" class="form-label">Department *</label>
                                <select class="form-select" id="edit_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_instructor_id" class="form-label">Instructor *</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="edit_instructor_search" 
                                           placeholder="Search instructors by name or email..." 
                                           onkeyup="searchEditInstructors()">
                                    <span class="input-group-text bg-light">
                                        <i class="fas fa-search text-primary"></i>
                                    </span>
                                </div>
                                <select class="form-select mt-2" id="edit_instructor_id" name="instructor_id" required>
                                    <option value="">Select Instructor</option>
                                    <?php foreach($instructors as $instructor): ?>
                                        <option value="<?php echo $instructor['id']; ?>" data-search="<?php echo htmlspecialchars(strtolower($instructor['first_name'] . ' ' . $instructor['last_name'] . ' ' . $instructor['username'] . ' ' . $instructor['email'])); ?>">
                                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name'] . ' (@' . $instructor['username'] . ' - ' . $instructor['email'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">Type to search instructors</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_academic_year" class="form-label">Academic Year *</label>
                                <select class="form-select" id="edit_academic_year" name="academic_year" required>
                                    <option value="">Select Year</option>
                                    <?php foreach($academic_years as $year): ?>
                                        <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_semester" class="form-label">Semester *</label>
                                <select class="form-select" id="edit_semester" name="semester" required>
                                    <option value="">Select Semester</option>
                                    <?php foreach($semesters as $sem): ?>
                                        <option value="<?php echo htmlspecialchars($sem); ?>"><?php echo htmlspecialchars($sem); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_max_students" class="form-label">Max Students</label>
                                <input type="number" class="form-control" id="edit_max_students" name="max_students" 
                                       min="1" max="500">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                            <label class="form-check-label" for="edit_is_active">
                                <strong>Activate this course</strong>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_course" class="btn btn-primary">Update Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Course Modal -->
<div class="modal fade" id="viewCourseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Course Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-4">
                    <div class="col-md-8">
                        <h3 id="view_course_code" class="text-primary mb-2"></h3>
                        <h4 id="view_course_name" class="mb-3"></h4>
                        <div id="view_description" class="text-muted"></div>
                    </div>
                    <div class="col-md-4 text-end">
                        <span id="view_status_badge" class="badge fs-6 mb-2"></span>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark fs-6">
                                <i class="fas fa-star text-warning me-1"></i>
                                <span id="view_credits"></span> credits
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-header bg-light">
                                <h6 class="mb-0">
                                    <i class="fas fa-info-circle me-2 text-primary"></i>
                                    Course Information
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <strong>Academic Year:</strong>
                                    <span id="view_academic_year" class="badge bg-success ms-2"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Semester:</strong>
                                    <span id="view_semester" class="badge bg-secondary ms-2"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Department:</strong>
                                    <span id="view_department"></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Capacity:</strong>
                                    <span id="view_capacity"></span>
                                </div>
                                <div>
                                    <strong>Created:</strong>
                                    <span id="view_created_at" class="text-muted"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-header bg-light">
                                <h6 class="mb-0">
                                    <i class="fas fa-chalkboard-teacher me-2 text-warning"></i>
                                    Instructor Information
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <strong>Instructor:</strong>
                                    <div id="view_instructor" class="fw-bold"></div>
                                </div>
                                <div class="mb-2">
                                    <strong>Email:</strong>
                                    <div id="view_instructor_email"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">
                            <i class="fas fa-chart-bar me-2 text-success"></i>
                            Course Statistics
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-4">
                                <div class="display-6 text-primary" id="view_student_count"></div>
                                <div class="text-muted">Enrolled Students</div>
                            </div>
                            <div class="col-4">
                                <div class="display-6 text-info" id="view_exam_count"></div>
                                <div class="text-muted">Total Exams</div>
                            </div>
                            <div class="col-4">
                                <div class="display-6 text-success" id="view_total_questions"></div>
                                <div class="text-muted">Total Questions</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Course Modal -->
<div class="modal fade" id="deleteCourseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="course_id" id="delete_course_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this course?</h6>
                    <p class="text-center text-muted">Course: <strong id="delete_course_code"></strong> - <span id="delete_course_name"></span></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. All course data and student enrollments will be permanently deleted.
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Note: Courses with existing exams cannot be deleted. Please delete the exams first.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_course" class="btn btn-danger">Delete Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Search functionality for add course modal instructor search
function searchInstructors() {
    const searchTerm = document.getElementById('add_instructor_search').value.toLowerCase();
    const instructorSelect = document.getElementById('add_instructor_id');
    const options = instructorSelect.getElementsByTagName('option');
    
    // First option is "Select Instructor"
    for (let i = 1; i < options.length; i++) {
        const option = options[i];
        const searchText = option.getAttribute('data-search') || '';
        
        if (searchText.includes(searchTerm)) {
            option.style.display = '';
        } else {
            option.style.display = 'none';
        }
    }
}

// Search functionality for edit course modal instructor search
function searchEditInstructors() {
    const searchTerm = document.getElementById('edit_instructor_search').value.toLowerCase();
    const instructorSelect = document.getElementById('edit_instructor_id');
    const options = instructorSelect.getElementsByTagName('option');
    
    // First option is "Select Instructor"
    for (let i = 1; i < options.length; i++) {
        const option = options[i];
        const searchText = option.getAttribute('data-search') || '';
        
        if (searchText.includes(searchTerm)) {
            option.style.display = '';
        } else {
            option.style.display = 'none';
        }
    }
}

// Selection management for bulk actions
document.addEventListener('DOMContentLoaded', function() {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const courseCheckboxes = document.querySelectorAll('.course-checkbox');
    const bulkActionSelect = document.getElementById('bulkActionSelect');
    const applyBulkAction = document.getElementById('applyBulkAction');
    const bulkActionForm = document.getElementById('bulkActionForm');
    
    function updateSelection() {
        const selected = document.querySelectorAll('.course-checkbox:checked').length;
        applyBulkAction.disabled = selected === 0 || !bulkActionSelect.value;
    }
    
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            courseCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelection();
        });
    }
    
    courseCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelection);
    });
    
    if (bulkActionSelect) {
        bulkActionSelect.addEventListener('change', updateSelection);
    }
    
    // Bulk action form submission
    if (bulkActionForm) {
        bulkActionForm.addEventListener('submit', function(e) {
            const selected = document.querySelectorAll('.course-checkbox:checked').length;
            const action = bulkActionSelect.value;
            
            if (selected === 0) {
                e.preventDefault();
                alert('Please select at least one course.');
                return;
            }
            
            if (!action) {
                e.preventDefault();
                alert('Please select a bulk action.');
                return;
            }
            
            if (!confirm(`Are you sure you want to ${action} ${selected} course(s)?`)) {
                e.preventDefault();
            }
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-focus search fields
    const searchCourseField = document.getElementById('search_course');
    const searchInstructorField = document.getElementById('search_instructor');
    
    if (searchCourseField) {
        searchCourseField.focus();
    }
    
    // Initialize search with debounce
    let searchTimeout;
    [searchCourseField, searchInstructorField].forEach(field => {
        if (field) {
            field.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.form.submit();
                }, 500);
            });
        }
    });
    
    // Focus instructor search when add modal opens
    const addCourseModal = document.getElementById('addCourseModal');
    if (addCourseModal) {
        addCourseModal.addEventListener('shown.bs.modal', function() {
            setTimeout(() => {
                const instructorSearch = document.getElementById('add_instructor_search');
                if (instructorSearch) {
                    instructorSearch.focus();
                }
            }, 500);
        });
    }
});

// Edit course function
function editCourse(button) {
    const courseId = button.getAttribute('data-course-id');
    const courseCode = button.getAttribute('data-course-code');
    const courseName = button.getAttribute('data-course-name');
    const description = button.getAttribute('data-description');
    const instructorId = button.getAttribute('data-instructor-id');
    const department = button.getAttribute('data-department');
    const credits = button.getAttribute('data-credits');
    const academicYear = button.getAttribute('data-academic-year');
    const semester = button.getAttribute('data-semester');
    const maxStudents = button.getAttribute('data-max-students');
    const isActive = button.getAttribute('data-is-active');
    
    document.getElementById('edit_course_id').value = courseId;
    document.getElementById('edit_course_code').value = courseCode;
    document.getElementById('edit_course_name').value = courseName;
    document.getElementById('edit_description').value = description;
    document.getElementById('edit_instructor_id').value = instructorId;
    document.getElementById('edit_department').value = department;
    document.getElementById('edit_credits').value = credits;
    document.getElementById('edit_academic_year').value = academicYear;
    document.getElementById('edit_semester').value = semester;
    document.getElementById('edit_max_students').value = maxStudents;
    document.getElementById('edit_is_active').checked = isActive === '1';
    
    // Clear edit instructor search
    document.getElementById('edit_instructor_search').value = '';
    searchEditInstructors();
}

// View course function
function viewCourse(button) {
    const courseId = button.getAttribute('data-course-id');
    const courseCode = button.getAttribute('data-course-code');
    const courseName = button.getAttribute('data-course-name');
    const description = button.getAttribute('data-description');
    const instructor = button.getAttribute('data-instructor');
    const instructorEmail = button.getAttribute('data-instructor-email');
    const department = button.getAttribute('data-department');
    const credits = button.getAttribute('data-credits');
    const academicYear = button.getAttribute('data-academic-year');
    const semester = button.getAttribute('data-semester');
    const maxStudents = button.getAttribute('data-max-students');
    const studentCount = button.getAttribute('data-student-count');
    const examCount = button.getAttribute('data-exam-count');
    const totalQuestions = button.getAttribute('data-total-questions');
    const isActive = button.getAttribute('data-is-active');
    const createdAt = button.getAttribute('data-created-at');
    
    document.getElementById('view_course_code').textContent = courseCode;
    document.getElementById('view_course_name').textContent = courseName;
    document.getElementById('view_description').textContent = description || 'No description available.';
    document.getElementById('view_instructor').textContent = instructor || 'Not assigned';
    document.getElementById('view_instructor_email').textContent = instructorEmail || 'N/A';
    document.getElementById('view_department').textContent = department || 'Not assigned';
    document.getElementById('view_credits').textContent = credits;
    document.getElementById('view_academic_year').textContent = academicYear;
    document.getElementById('view_semester').textContent = semester;
    document.getElementById('view_capacity').textContent = studentCount + '/' + maxStudents + ' students';
    document.getElementById('view_student_count').textContent = studentCount;
    document.getElementById('view_exam_count').textContent = examCount;
    document.getElementById('view_total_questions').textContent = totalQuestions;
    document.getElementById('view_created_at').textContent = new Date(createdAt).toLocaleString();
    
    const statusBadge = document.getElementById('view_status_badge');
    if (isActive === '1') {
        statusBadge.className = 'badge bg-success fs-6 mb-2';
        statusBadge.innerHTML = '<i class="fas fa-check-circle me-1"></i> Active';
    } else {
        statusBadge.className = 'badge bg-secondary fs-6 mb-2';
        statusBadge.innerHTML = '<i class="fas fa-pause-circle me-1"></i> Inactive';
    }
}

// Delete course function
function deleteCourse(button) {
    const courseId = button.getAttribute('data-course-id');
    const courseCode = button.getAttribute('data-course-code');
    const courseName = button.getAttribute('data-course-name');
    
    document.getElementById('delete_course_id').value = courseId;
    document.getElementById('delete_course_code').textContent = courseCode;
    document.getElementById('delete_course_name').textContent = courseName;
}

// Filter functions
function filterByInstructor(instructorId) {
    document.getElementById('instructor').value = instructorId;
    document.getElementById('searchForm').submit();
}

function resetInstructorFilter() {
    document.getElementById('instructor').value = '';
    document.getElementById('searchForm').submit();
}

function clearCourseSearch() {
    document.getElementById('search_course').value = '';
    document.getElementById('searchForm').submit();
}

function clearInstructorSearch() {
    document.getElementById('search_instructor').value = '';
    document.getElementById('searchForm').submit();
}

function removeFilter(filterName) {
    const form = document.getElementById('searchForm');
    const input = form.querySelector('[name="' + filterName + '"]');
    if (input) {
        input.value = '';
    }
    form.submit();
}

function resetFilters() {
    window.location.href = 'manage_courses.php';
}

// Course name suggestions based on course code
document.addEventListener('DOMContentLoaded', function() {
    const courseCodeInput = document.getElementById('add_course_code');
    const courseNameInput = document.getElementById('add_course_name');
    
    if (courseCodeInput && courseNameInput) {
        courseCodeInput.addEventListener('blur', function() {
            if (!courseNameInput.value) {
                const code = this.value.toUpperCase();
                const suggestions = {
                    'CS': 'Computer Science',
                    'MATH': 'Mathematics',
                    'PHY': 'Physics',
                    'CHEM': 'Chemistry',
                    'BIO': 'Biology',
                    'ENG': 'English',
                    'HIST': 'History',
                    'ECON': 'Economics',
                    'BUS': 'Business',
                    'PSY': 'Psychology',
                    'SOC': 'Sociology',
                    'ART': 'Art',
                    'MUS': 'Music'
                };
                
                for (const [prefix, subject] of Object.entries(suggestions)) {
                    if (code.startsWith(prefix)) {
                        const courseNum = code.replace(prefix, '').trim();
                        const courseNumber = courseNum.match(/\d+/)?.[0] || '';
                        const courseLevel = courseNumber ? parseInt(courseNumber.charAt(0)) * 100 : '';
                        
                        let levelText = '';
                        if (courseLevel) {
                            if (courseLevel >= 400) levelText = 'Advanced ';
                            else if (courseLevel >= 300) levelText = 'Intermediate ';
                            else if (courseLevel >= 200) levelText = 'Intermediate ';
                            else levelText = 'Introduction to ';
                        }
                        
                        courseNameInput.value = levelText + subject + (courseNum ? ' ' + courseNum : '');
                        break;
                    }
                }
            }
        });
    }
});

// Auto-suggest academic year based on current date
document.addEventListener('DOMContentLoaded', function() {
    const academicYearSelect = document.getElementById('add_academic_year');
    if (academicYearSelect) {
        const currentYear = new Date().getFullYear();
        const nextYear = currentYear + 1;
        const currentAcademicYear = currentYear + '-' + nextYear;
        
        // Check if current academic year exists in options
        let exists = false;
        for (let i = 0; i < academicYearSelect.options.length; i++) {
            if (academicYearSelect.options[i].value === currentAcademicYear) {
                exists = true;
                break;
            }
        }
        
        if (!exists) {
            const option = document.createElement('option');
            option.value = currentAcademicYear;
            option.textContent = currentAcademicYear;
            academicYearSelect.appendChild(option);
        }
        
        academicYearSelect.value = currentAcademicYear;
    }
});

// Reset instructor search when modal closes
const addCourseModalElement = document.getElementById('addCourseModal');
if (addCourseModalElement) {
    addCourseModalElement.addEventListener('hidden.bs.modal', function() {
        const instructorSearch = document.getElementById('add_instructor_search');
        const instructorSelect = document.getElementById('add_instructor_id');
        
        if (instructorSearch) {
            instructorSearch.value = '';
        }
        
        if (instructorSelect) {
            // Show all options
            const options = instructorSelect.getElementsByTagName('option');
            for (let i = 0; i < options.length; i++) {
                options[i].style.display = '';
            }
        }
    });
}

const editCourseModalElement = document.getElementById('editCourseModal');
if (editCourseModalElement) {
    editCourseModalElement.addEventListener('hidden.bs.modal', function() {
        const instructorSearch = document.getElementById('edit_instructor_search');
        const instructorSelect = document.getElementById('edit_instructor_id');
        
        if (instructorSearch) {
            instructorSearch.value = '';
        }
        
        if (instructorSelect) {
            // Show all options
            const options = instructorSelect.getElementsByTagName('option');
            for (let i = 0; i < options.length; i++) {
                options[i].style.display = '';
            }
        }
    });
}
</script>

<style>
/* Custom styling for better UI */
.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
    background-color: #f8f9fa;
}

.table-hover tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.05);
}

.table-light {
    background-color: rgba(248, 249, 250, 0.5);
}

.modal-header {
    border-bottom: 2px solid #e9ecef;
    background-color: #f8f9fa;
}

.modal-footer {
    border-top: 2px solid #e9ecef;
    background-color: #f8f9fa;
}

.progress {
    background-color: #e9ecef;
    border-radius: 10px;
}

.progress-bar {
    border-radius: 10px;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
}

.input-group-text {
    background-color: #f8f9fa;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.pagination .page-item.active .page-link {
    background-color: #0d6efd;
    border-color: #0d6efd;
}

.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
}

.display-6 {
    font-size: 2.5rem;
    font-weight: 300;
}

/* Instructor search specific styles */
#add_instructor_id option,
#edit_instructor_id option {
    padding: 8px;
}

#add_instructor_id option:hover,
#edit_instructor_id option:hover {
    background-color: #f8f9fa;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .table-responsive {
        font-size: 0.875rem;
    }
    
    .btn-group-sm .btn {
        padding: 0.125rem 0.25rem;
    }
    
    .display-6 {
        font-size: 1.75rem;
    }
}

/* Hover effects */
.course-checkbox:checked + td {
    background-color: rgba(13, 110, 253, 0.1) !important;
}

/* Animation for modal */
.modal.fade .modal-dialog {
    transform: translate(0, -50px);
    transition: transform 0.3s ease-out;
}

.modal.show .modal-dialog {
    transform: translate(0, 0);
}

/* Highlight selected instructor in dropdown */
#add_instructor_id option:checked,
#edit_instructor_id option:checked {
    background-color: #0d6efd;
    color: white;
}

/* Search input styling */
#add_instructor_search,
#edit_instructor_search {
    transition: all 0.3s ease;
}

#add_instructor_search:focus,
#edit_instructor_search:focus {
    border-color: #86b7fe;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

/* Loading spinner for search */
.search-loading {
    position: absolute;
    right: 40px;
    top: 50%;
    transform: translateY(-50%);
    display: none;
}

.search-loading.active {
    display: block;
}
</style>

<?php require_once '../includes/footer.php'; ?>