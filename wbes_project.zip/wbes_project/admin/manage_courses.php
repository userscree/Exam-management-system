<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Courses';
require_once '../includes/header.php';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_course'])) {
        // Add new course
        $course_code = sanitize($_POST['course_code']);
        $course_name = sanitize($_POST['course_name']);
        $description = sanitize($_POST['description']);
        $instructor_id = $_POST['instructor_id'];
        $department = sanitize($_POST['department']);
        $credits = $_POST['credits'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        try {
            // Check if course code already exists
            $stmt = $pdo->prepare("SELECT id FROM courses WHERE course_code = ?");
            $stmt->execute([$course_code]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Course code already exists. Please use a unique course code.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO courses (course_code, course_name, description, instructor_id, department, credits, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$course_code, $course_name, $description, $instructor_id, $department, $credits, $is_active]);
                
                setFlash('success', 'Course added successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error adding course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_course'])) {
        // Update course
        $course_id = $_POST['course_id'];
        $course_code = sanitize($_POST['course_code']);
        $course_name = sanitize($_POST['course_name']);
        $description = sanitize($_POST['description']);
        $instructor_id = $_POST['instructor_id'];
        $department = sanitize($_POST['department']);
        $credits = $_POST['credits'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        try {
            // Check if course code already exists for other courses
            $stmt = $pdo->prepare("SELECT id FROM courses WHERE course_code = ? AND id != ?");
            $stmt->execute([$course_code, $course_id]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Course code already exists for another course.');
            } else {
                $stmt = $pdo->prepare("UPDATE courses SET course_code = ?, course_name = ?, description = ?, instructor_id = ?, department = ?, credits = ?, is_active = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$course_code, $course_name, $description, $instructor_id, $department, $credits, $is_active, $course_id]);
                
                setFlash('success', 'Course updated successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error updating course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_course'])) {
        // Delete course
        $course_id = $_POST['course_id'];
        
        try {
            // Check if course has exams
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE course_id = ?");
            $stmt->execute([$course_id]);
            $exam_count = $stmt->fetchColumn();
            
            if ($exam_count > 0) {
                setFlash('error', 'Cannot delete course. There are exams associated with this course. Please delete the exams first.');
            } else {
                // Delete enrollments first
                $stmt = $pdo->prepare("DELETE FROM enrollments WHERE course_id = ?");
                $stmt->execute([$course_id]);
                
                // Then delete course
                $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
                $stmt->execute([$course_id]);
                
                setFlash('success', 'Course deleted successfully!');
                redirect('manage_courses.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting course: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['toggle_course_status'])) {
        // Toggle course active status
        $course_id = $_POST['course_id'];
        $current_status = $_POST['current_status'];
        $new_status = $current_status ? 0 : 1;
        
        try {
            $stmt = $pdo->prepare("UPDATE courses SET is_active = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_status, $course_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            setFlash('success', "Course {$status_text} successfully!");
            redirect('manage_courses.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating course status: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$department_filter = $_GET['department'] ?? '';
$instructor_filter = $_GET['instructor'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for courses
$query = "
    SELECT c.*, 
           u.first_name as instructor_first_name, u.last_name as instructor_last_name, u.username as instructor_username,
           d.department_name,
           (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id AND status = 'active') as student_count,
           (SELECT COUNT(*) FROM exams WHERE course_id = c.id) as exam_count
    FROM courses c 
    LEFT JOIN users u ON c.instructor_id = u.id 
    LEFT JOIN departments d ON c.department = d.department_code 
    WHERE 1=1
";
$params = [];

if (!empty($status_filter)) {
    if ($status_filter === 'active') {
        $query .= " AND c.is_active = 1";
    } elseif ($status_filter === 'inactive') {
        $query .= " AND c.is_active = 0";
    }
}

if (!empty($department_filter)) {
    $query .= " AND c.department = ?";
    $params[] = $department_filter;
}

if (!empty($instructor_filter)) {
    $query .= " AND c.instructor_id = ?";
    $params[] = $instructor_filter;
}

if (!empty($search)) {
    $query .= " AND (c.course_code LIKE ? OR c.course_name LIKE ? OR c.description LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY c.course_code ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get instructors for dropdown
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, username FROM users WHERE role = 'instructor' AND is_active = 1 ORDER BY first_name, last_name");
    $stmt->execute();
    $instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get departments for dropdown
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE is_active = 1 ORDER BY department_name");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get course statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM courses");
    $stmt->execute();
    $total_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM courses WHERE is_active = 1");
    $stmt->execute();
    $active_courses = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as inactive FROM courses WHERE is_active = 0");
    $stmt->execute();
    $inactive_courses = $stmt->fetchColumn();
    
    // Get department-wise course count
    $stmt = $pdo->prepare("
        SELECT d.department_code, d.department_name, COUNT(c.id) as course_count 
        FROM departments d 
        LEFT JOIN courses c ON d.department_code = c.department AND c.is_active = 1 
        WHERE d.is_active = 1 
        GROUP BY d.department_code, d.department_name 
        ORDER BY course_count DESC
    ");
    $stmt->execute();
    $department_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching courses: ' . $e->getMessage());
    $courses = [];
    $instructors = [];
    $departments = [];
    $total_courses = 0;
    $active_courses = 0;
    $inactive_courses = 0;
    $department_stats = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Courses</h1>
                <p class="text-muted mb-0">Create, edit, and manage all courses</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                    <i class="fas fa-plus-circle me-2"></i> Add New Course
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addCourseModal"><i class="fas fa-plus-circle me-2"></i>Add Course</a></li>
                    <li><a class="dropdown-item" href="manage_departments.php"><i class="fas fa-building me-2"></i>Manage Departments</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_courses; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_courses; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Inactive Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $inactive_courses; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-pause-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Departments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($departments); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-building fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Department Statistics -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-bar me-2 text-primary"></i>
                    Courses by Department
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php if(empty($department_stats)): ?>
                        <div class="col-12 text-center text-muted py-3">
                            <i class="fas fa-building fa-2x mb-2"></i>
                            <p>No department data available</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($department_stats as $dept): ?>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="d-flex align-items-center p-3 border rounded">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-university fa-2x text-primary me-3"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-bold text-primary"><?php echo $dept['course_count']; ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($dept['department_name']); ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search Courses</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search by code, name..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="department" class="form-label">Department</label>
                <select class="form-select" id="department" name="department">
                    <option value="">All Departments</option>
                    <?php foreach($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>" <?php echo $department_filter == $dept['department_code'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department_code']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="instructor" class="form-label">Instructor</label>
                <select class="form-select" id="instructor" name="instructor">
                    <option value="">All Instructors</option>
                    <?php foreach($instructors as $instructor): ?>
                        <option value="<?php echo $instructor['id']; ?>" <?php echo $instructor_filter == $instructor['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="manage_courses.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Courses Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Courses List
            <span class="badge bg-primary ms-2"><?php echo count($courses); ?> courses</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Course Information</th>
                        <th>Department & Instructor</th>
                        <th>Statistics</th>
                        <th>Credits</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($courses)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-book fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No courses found</h5>
                                <p class="text-muted">Try adjusting your filters or add a new course.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($courses as $course): ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($course['course_name']); ?></div>
                                    <?php if(!empty($course['description'])): ?>
                                        <small class="text-muted"><?php echo htmlspecialchars(substr($course['description'], 0, 100)); ?>...</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($course['department_name']): ?>
                                        <div class="mb-2">
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($course['department']); ?></span>
                                            <small class="text-muted d-block"><?php echo htmlspecialchars($course['department_name']); ?></small>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($course['instructor_first_name']): ?>
                                        <div>
                                            <small class="text-muted">Instructor:</small>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($course['instructor_first_name'] . ' ' . $course['instructor_last_name']); ?></div>
                                            <small class="text-muted">@<?php echo htmlspecialchars($course['instructor_username']); ?></small>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge bg-warning">No Instructor</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex gap-3 text-center">
                                        <div>
                                            <div class="fw-bold text-primary"><?php echo $course['student_count']; ?></div>
                                            <small class="text-muted">Students</small>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-info"><?php echo $course['exam_count']; ?></div>
                                            <small class="text-muted">Exams</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark fs-6"><?php echo $course['credits']; ?> credits</span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $course['is_active'] ? 'success' : 'secondary'; ?>">
                                        <i class="fas fa-<?php echo $course['is_active'] ? 'check-circle' : 'pause-circle'; ?> me-1"></i>
                                        <?php echo $course['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                    <div class="mt-1">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                            <input type="hidden" name="current_status" value="<?php echo $course['is_active']; ?>">
                                            <button type="submit" name="toggle_course_status" class="btn btn-sm btn-<?php echo $course['is_active'] ? 'warning' : 'success'; ?>">
                                                <i class="fas fa-<?php echo $course['is_active'] ? 'pause' : 'play'; ?> me-1"></i>
                                                <?php echo $course['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($course['created_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editCourseModal" 
                                                data-course-id="<?php echo $course['id']; ?>"
                                                data-course-code="<?php echo htmlspecialchars($course['course_code']); ?>"
                                                data-course-name="<?php echo htmlspecialchars($course['course_name']); ?>"
                                                data-description="<?php echo htmlspecialchars($course['description'] ?? ''); ?>"
                                                data-instructor-id="<?php echo $course['instructor_id']; ?>"
                                                data-department="<?php echo htmlspecialchars($course['department'] ?? ''); ?>"
                                                data-credits="<?php echo $course['credits']; ?>"
                                                data-is-active="<?php echo $course['is_active']; ?>"
                                                onclick="editCourse(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <?php if($course['exam_count'] == 0): ?>
                                            <button class="btn btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteCourseModal"
                                                    data-course-id="<?php echo $course['id']; ?>"
                                                    data-course-code="<?php echo htmlspecialchars($course['course_code']); ?>"
                                                    data-course-name="<?php echo htmlspecialchars($course['course_name']); ?>"
                                                    onclick="deleteCourse(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="Cannot delete course with exams">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="addCourseForm">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_course_code" class="form-label">Course Code *</label>
                                <input type="text" class="form-control" id="add_course_code" name="course_code" 
                                       placeholder="e.g., CS101, MATH201" required>
                                <div class="invalid-feedback">Please provide a course code.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_credits" class="form-label">Credits *</label>
                                <input type="number" class="form-control" id="add_credits" name="credits" 
                                       min="1" max="10" value="3" required>
                                <div class="invalid-feedback">Please enter valid credits.</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_course_name" class="form-label">Course Name *</label>
                        <input type="text" class="form-control" id="add_course_name" name="course_name" 
                               placeholder="e.g., Introduction to Computer Science" required>
                        <div class="invalid-feedback">Please provide a course name.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_description" class="form-label">Description</label>
                        <textarea class="form-control" id="add_description" name="description" 
                                  rows="3" placeholder="Brief description of the course..."></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_department" class="form-label">Department *</label>
                                <select class="form-select" id="add_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Please select a department.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_instructor_id" class="form-label">Instructor *</label>
                                <select class="form-select" id="add_instructor_id" name="instructor_id" required>
                                    <option value="">Select Instructor</option>
                                    <?php foreach($instructors as $instructor): ?>
                                        <option value="<?php echo $instructor['id']; ?>">
                                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name'] . ' (@' . $instructor['username'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Please select an instructor.</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="add_is_active" name="is_active" value="1" checked>
                            <label class="form-check-label" for="add_is_active">
                                <strong>Activate this course immediately</strong>
                            </label>
                        </div>
                        <div class="form-text">
                            If unchecked, the course will be created but won't be visible to students until activated.
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_course" class="btn btn-primary">Add Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Course Modal -->
<div class="modal fade" id="editCourseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="editCourseForm">
                <input type="hidden" name="course_id" id="edit_course_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_course_code" class="form-label">Course Code *</label>
                                <input type="text" class="form-control" id="edit_course_code" name="course_code" required>
                                <div class="invalid-feedback">Please provide a course code.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_credits" class="form-label">Credits *</label>
                                <input type="number" class="form-control" id="edit_credits" name="credits" 
                                       min="1" max="10" required>
                                <div class="invalid-feedback">Please enter valid credits.</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_course_name" class="form-label">Course Name *</label>
                        <input type="text" class="form-control" id="edit_course_name" name="course_name" required>
                        <div class="invalid-feedback">Please provide a course name.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_department" class="form-label">Department *</label>
                                <select class="form-select" id="edit_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php foreach($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept['department_code']); ?>">
                                            <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Please select a department.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_instructor_id" class="form-label">Instructor *</label>
                                <select class="form-select" id="edit_instructor_id" name="instructor_id" required>
                                    <option value="">Select Instructor</option>
                                    <?php foreach($instructors as $instructor): ?>
                                        <option value="<?php echo $instructor['id']; ?>">
                                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name'] . ' (@' . $instructor['username'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Please select an instructor.</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                            <label class="form-check-label" for="edit_is_active">
                                <strong>Activate this course</strong>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_course" class="btn btn-primary">Update Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Course Modal -->
<div class="modal fade" id="deleteCourseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="course_id" id="delete_course_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this course?</h6>
                    <p class="text-center text-muted">Course: <strong id="delete_course_code"></strong> - <span id="delete_course_name"></span></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. All course data and student enrollments will be permanently deleted.
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Note: Courses with existing exams cannot be deleted. Please delete the exams first.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_course" class="btn btn-danger">Delete Course</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editCourse(button) {
    const courseId = button.getAttribute('data-course-id');
    const courseCode = button.getAttribute('data-course-code');
    const courseName = button.getAttribute('data-course-name');
    const description = button.getAttribute('data-description');
    const instructorId = button.getAttribute('data-instructor-id');
    const department = button.getAttribute('data-department');
    const credits = button.getAttribute('data-credits');
    const isActive = button.getAttribute('data-is-active');
    
    document.getElementById('edit_course_id').value = courseId;
    document.getElementById('edit_course_code').value = courseCode;
    document.getElementById('edit_course_name').value = courseName;
    document.getElementById('edit_description').value = description;
    document.getElementById('edit_instructor_id').value = instructorId;
    document.getElementById('edit_department').value = department;
    document.getElementById('edit_credits').value = credits;
    document.getElementById('edit_is_active').checked = isActive === '1';
}

function deleteCourse(button) {
    const courseId = button.getAttribute('data-course-id');
    const courseCode = button.getAttribute('data-course-code');
    const courseName = button.getAttribute('data-course-name');
    
    document.getElementById('delete_course_id').value = courseId;
    document.getElementById('delete_course_code').textContent = courseCode;
    document.getElementById('delete_course_name').textContent = courseName;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Form validation
    const addCourseForm = document.getElementById('addCourseForm');
    if (addCourseForm) {
        addCourseForm.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    }
    
    const editCourseForm = document.getElementById('editCourseForm');
    if (editCourseForm) {
        editCourseForm.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    }
    
    // Auto-generate course name suggestions based on course code
    const courseCodeInput = document.getElementById('add_course_code');
    const courseNameInput = document.getElementById('add_course_name');
    
    if (courseCodeInput && courseNameInput) {
        courseCodeInput.addEventListener('blur', function() {
            if (!courseNameInput.value) {
                const code = this.value.toUpperCase();
                const suggestions = {
                    'CS': 'Computer Science',
                    'MATH': 'Mathematics',
                    'PHY': 'Physics',
                    'CHEM': 'Chemistry',
                    'BIO': 'Biology',
                    'ENG': 'English',
                    'HIST': 'History',
                    'ECON': 'Economics'
                };
                
                for (const [prefix, subject] of Object.entries(suggestions)) {
                    if (code.startsWith(prefix)) {
                        const courseNum = code.replace(prefix, '').trim();
                        courseNameInput.value = `${subject} ${courseNum}`;
                        break;
                    }
                }
            }
        });
    }
});
</script>

<style>
.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
}

.modal-header {
    border-bottom: 2px solid #dee2e6;
}

.modal-footer {
    border-top: 2px solid #dee2e6;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.invalid-feedback {
    display: block;
}

.was-validated .form-control:invalid,
.was-validated .form-select:invalid {
    border-color: #dc3545;
}

.was-validated .form-control:valid,
.was-validated .form-select:valid {
    border-color: #198754;
}
</style>

<?php require_once '../includes/footer.php'; ?>