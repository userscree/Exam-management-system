<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Exams';
require_once '../includes/header.php';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_exam'])) {
        // Update exam
        $exam_id = $_POST['exam_id'];
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $exam_type = sanitize($_POST['exam_type']);
        $total_marks = $_POST['total_marks'];
        $passing_marks = $_POST['passing_marks'];
        $duration_minutes = $_POST['duration_minutes'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $allow_retake = isset($_POST['allow_retake']) ? 1 : 0;
        $show_results_immediately = isset($_POST['show_results_immediately']) ? 1 : 0;
        
        try {
            $stmt = $pdo->prepare("UPDATE exams SET title = ?, description = ?, exam_type = ?, total_marks = ?, passing_marks = ?, duration_minutes = ?, start_date = ?, end_date = ?, is_active = ?, allow_retake = ?, show_results_immediately = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$title, $description, $exam_type, $total_marks, $passing_marks, $duration_minutes, $start_date, $end_date, $is_active, $allow_retake, $show_results_immediately, $exam_id]);
            
            setFlash('success', 'Exam updated successfully!');
            redirect('manage_exams.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_exam'])) {
        // Delete exam
        $exam_id = $_POST['exam_id'];
        
        try {
            // Check if exam has attempts
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM exam_attempts WHERE exam_id = ?");
            $stmt->execute([$exam_id]);
            $attempt_count = $stmt->fetchColumn();
            
            if ($attempt_count > 0) {
                setFlash('error', 'Cannot delete exam. There are exam attempts associated with this exam. Please delete the attempts first.');
            } else {
                // Delete questions first (due to foreign key constraint)
                $stmt = $pdo->prepare("DELETE FROM questions WHERE exam_id = ?");
                $stmt->execute([$exam_id]);
                
                // Then delete exam
                $stmt = $pdo->prepare("DELETE FROM exams WHERE id = ?");
                $stmt->execute([$exam_id]);
                
                setFlash('success', 'Exam deleted successfully!');
                redirect('manage_exams.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting exam: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['toggle_exam_status'])) {
        // Toggle exam active status
        $exam_id = $_POST['exam_id'];
        $current_status = $_POST['current_status'];
        $new_status = $current_status ? 0 : 1;
        
        try {
            $stmt = $pdo->prepare("UPDATE exams SET is_active = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_status, $exam_id]);
            
            $status_text = $new_status ? 'activated' : 'deactivated';
            setFlash('success', "Exam {$status_text} successfully!");
            redirect('manage_exams.php');
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam status: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$course_filter = $_GET['course'] ?? '';
$instructor_filter = $_GET['instructor'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for exams
$query = "
    SELECT e.*, 
           c.course_code, c.course_name,
           u.first_name as instructor_first_name, u.last_name as instructor_last_name, u.username as instructor_username,
           (SELECT COUNT(*) FROM questions WHERE exam_id = e.id) as question_count,
           (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id) as attempt_count,
           (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND status = 'graded') as graded_count
    FROM exams e 
    LEFT JOIN courses c ON e.course_id = c.id 
    LEFT JOIN users u ON e.instructor_id = u.id 
    WHERE 1=1
";
$params = [];

if (!empty($status_filter)) {
    if ($status_filter === 'active') {
        $query .= " AND e.is_active = 1 AND e.start_date <= NOW() AND e.end_date >= NOW()";
    } elseif ($status_filter === 'upcoming') {
        $query .= " AND e.is_active = 1 AND e.start_date > NOW()";
    } elseif ($status_filter === 'expired') {
        $query .= " AND e.end_date < NOW()";
    } elseif ($status_filter === 'inactive') {
        $query .= " AND e.is_active = 0";
    }
}

if (!empty($type_filter)) {
    $query .= " AND e.exam_type = ?";
    $params[] = $type_filter;
}

if (!empty($course_filter)) {
    $query .= " AND e.course_id = ?";
    $params[] = $course_filter;
}

if (!empty($instructor_filter)) {
    $query .= " AND e.instructor_id = ?";
    $params[] = $instructor_filter;
}

if (!empty($search)) {
    $query .= " AND (e.title LIKE ? OR e.description LIKE ? OR c.course_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY e.created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get courses for dropdown
    $stmt = $pdo->prepare("SELECT id, course_code, course_name FROM courses WHERE is_active = 1 ORDER BY course_code");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get instructors for dropdown
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, username FROM users WHERE role = 'instructor' AND is_active = 1 ORDER BY first_name, last_name");
    $stmt->execute();
    $instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get exam statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM exams");
    $stmt->execute();
    $total_exams = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM exams WHERE is_active = 1");
    $stmt->execute();
    $active_exams = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as ongoing FROM exams WHERE is_active = 1 AND start_date <= NOW() AND end_date >= NOW()");
    $stmt->execute();
    $ongoing_exams = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as upcoming FROM exams WHERE is_active = 1 AND start_date > NOW()");
    $stmt->execute();
    $upcoming_exams = $stmt->fetchColumn();
    
    // Get exam type distribution
    $stmt = $pdo->prepare("SELECT exam_type, COUNT(*) as count FROM exams GROUP BY exam_type");
    $stmt->execute();
    $exam_types = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exams: ' . $e->getMessage());
    $exams = [];
    $courses = [];
    $instructors = [];
    $total_exams = 0;
    $active_exams = 0;
    $ongoing_exams = 0;
    $upcoming_exams = 0;
    $exam_types = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Exams</h1>
                <p class="text-muted mb-0">View and manage all system exams</p>
            </div>
            <div class="btn-group">
                <a href="../instructor/create_exam.php" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i> Create New Exam
                </a>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="../instructor/create_exam.php"><i class="fas fa-file-alt me-2"></i>Create Exam</a></li>
                    <li><a class="dropdown-item" href="../instructor/add_question.php"><i class="fas fa-question-circle me-2"></i>Add Questions</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_exams; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_exams; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Ongoing Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $ongoing_exams; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-play-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Upcoming Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $upcoming_exams; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Exam Type Distribution -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-pie me-2 text-primary"></i>
                    Exam Type Distribution
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php foreach($exam_types as $type): ?>
                        <div class="col-md-3 col-6 mb-3">
                            <div class="d-flex align-items-center p-3 border rounded">
                                <div class="flex-shrink-0">
                                    <?php 
                                    $icon = 'file-alt';
                                    $color = 'primary';
                                    switch($type['exam_type']) {
                                        case 'quiz': $icon = 'bolt'; $color = 'warning'; break;
                                        case 'midterm': $icon = 'file-medical'; $color = 'info'; break;
                                        case 'final': $icon = 'file-contract'; $color = 'danger'; break;
                                        case 'assignment': $icon = 'tasks'; $color = 'success'; break;
                                    }
                                    ?>
                                    <i class="fas fa-<?php echo $icon; ?> fa-2x text-<?php echo $color; ?> me-3"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="fw-bold text-<?php echo $color; ?>"><?php echo $type['count']; ?></div>
                                    <small class="text-muted"><?php echo ucfirst($type['exam_type']); ?> Exams</small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search Exams</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search by title, description..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="type" class="form-label">Exam Type</label>
                <select class="form-select" id="type" name="type">
                    <option value="">All Types</option>
                    <option value="quiz" <?php echo $type_filter == 'quiz' ? 'selected' : ''; ?>>Quiz</option>
                    <option value="midterm" <?php echo $type_filter == 'midterm' ? 'selected' : ''; ?>>Midterm</option>
                    <option value="final" <?php echo $type_filter == 'final' ? 'selected' : ''; ?>>Final</option>
                    <option value="assignment" <?php echo $type_filter == 'assignment' ? 'selected' : ''; ?>>Assignment</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="course" class="form-label">Course</label>
                <select class="form-select" id="course" name="course">
                    <option value="">All Courses</option>
                    <?php foreach($courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['course_code']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="instructor" class="form-label">Instructor</label>
                <select class="form-select" id="instructor" name="instructor">
                    <option value="">All Instructors</option>
                    <?php foreach($instructors as $instructor): ?>
                        <option value="<?php echo $instructor['id']; ?>" <?php echo $instructor_filter == $instructor['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="upcoming" <?php echo $status_filter == 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                    <option value="expired" <?php echo $status_filter == 'expired' ? 'selected' : ''; ?>>Expired</option>
                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="manage_exams.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Exams Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Exams List
            <span class="badge bg-primary ms-2"><?php echo count($exams); ?> exams</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Exam Details</th>
                        <th>Course & Instructor</th>
                        <th>Timing</th>
                        <th>Statistics</th>
                        <th>Settings</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($exams)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No exams found</h5>
                                <p class="text-muted">Try adjusting your filters or create a new exam.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($exams as $exam): 
                            $now = new DateTime();
                            $start_date = new DateTime($exam['start_date']);
                            $end_date = new DateTime($exam['end_date']);
                            $is_ongoing = $exam['is_active'] && $now >= $start_date && $now <= $end_date;
                            $is_upcoming = $exam['is_active'] && $now < $start_date;
                            $is_expired = $now > $end_date;
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                    <small class="text-muted"><?php echo substr(htmlspecialchars($exam['description']), 0, 100); ?>...</small>
                                    <div class="mt-1">
                                        <span class="badge 
                                            <?php 
                                            switch($exam['exam_type']) {
                                                case 'quiz': echo 'bg-warning'; break;
                                                case 'midterm': echo 'bg-info'; break;
                                                case 'final': echo 'bg-danger'; break;
                                                case 'assignment': echo 'bg-success'; break;
                                                default: echo 'bg-secondary';
                                            }
                                            ?>">
                                            <i class="fas fa-<?php 
                                            switch($exam['exam_type']) {
                                                case 'quiz': echo 'bolt'; break;
                                                case 'midterm': echo 'file-medical'; break;
                                                case 'final': echo 'file-contract'; break;
                                                case 'assignment': echo 'tasks'; break;
                                                default: echo 'file-alt';
                                            }
                                            ?> me-1"></i>
                                            <?php echo ucfirst($exam['exam_type']); ?>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo htmlspecialchars($exam['course_code']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($exam['course_name']); ?></small>
                                    <?php if($exam['instructor_first_name']): ?>
                                        <div class="mt-1">
                                            <small class="text-muted">Instructor:</small>
                                            <div><?php echo htmlspecialchars($exam['instructor_first_name'] . ' ' . $exam['instructor_last_name']); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="small">
                                        <div><strong>Start:</strong> <?php echo formatDate($exam['start_date']); ?></div>
                                        <div><strong>End:</strong> <?php echo formatDate($exam['end_date']); ?></div>
                                        <div><strong>Duration:</strong> <?php echo $exam['duration_minutes']; ?> mins</div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex gap-3 text-center">
                                        <div>
                                            <div class="fw-bold text-primary"><?php echo $exam['question_count']; ?></div>
                                            <small class="text-muted">Questions</small>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-info"><?php echo $exam['attempt_count']; ?></div>
                                            <small class="text-muted">Attempts</small>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-success"><?php echo $exam['graded_count']; ?></div>
                                            <small class="text-muted">Graded</small>
                                        </div>
                                    </div>
                                    <div class="mt-1 small">
                                        <strong>Marks:</strong> <?php echo $exam['passing_marks']; ?>/<?php echo $exam['total_marks']; ?> to pass
                                    </div>
                                </td>
                                <td>
                                    <div class="small">
                                        <div>
                                            <i class="fas fa-<?php echo $exam['allow_retake'] ? 'check text-success' : 'times text-danger'; ?> me-1"></i>
                                            Retake allowed
                                        </div>
                                        <div>
                                            <i class="fas fa-<?php echo $exam['show_results_immediately'] ? 'check text-success' : 'times text-danger'; ?> me-1"></i>
                                            Instant results
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if($is_ongoing): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-play-circle me-1"></i> Ongoing
                                        </span>
                                    <?php elseif($is_upcoming): ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-clock me-1"></i> Upcoming
                                        </span>
                                    <?php elseif($is_expired): ?>
                                        <span class="badge bg-secondary">
                                            <i class="fas fa-hourglass-end me-1"></i> Expired
                                        </span>
                                    <?php elseif(!$exam['is_active']): ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-times-circle me-1"></i> Inactive
                                        </span>
                                    <?php endif; ?>
                                    
                                    <div class="mt-1">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                                            <input type="hidden" name="current_status" value="<?php echo $exam['is_active']; ?>">
                                            <button type="submit" name="toggle_exam_status" class="btn btn-sm btn-<?php echo $exam['is_active'] ? 'warning' : 'success'; ?>">
                                                <i class="fas fa-<?php echo $exam['is_active'] ? 'pause' : 'play'; ?> me-1"></i>
                                                <?php echo $exam['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editExamModal" 
                                                data-exam-id="<?php echo $exam['id']; ?>"
                                                data-title="<?php echo htmlspecialchars($exam['title']); ?>"
                                                data-description="<?php echo htmlspecialchars($exam['description']); ?>"
                                                data-exam-type="<?php echo $exam['exam_type']; ?>"
                                                data-total-marks="<?php echo $exam['total_marks']; ?>"
                                                data-passing-marks="<?php echo $exam['passing_marks']; ?>"
                                                data-duration-minutes="<?php echo $exam['duration_minutes']; ?>"
                                                data-start-date="<?php echo date('Y-m-d\TH:i', strtotime($exam['start_date'])); ?>"
                                                data-end-date="<?php echo date('Y-m-d\TH:i', strtotime($exam['end_date'])); ?>"
                                                data-is-active="<?php echo $exam['is_active']; ?>"
                                                data-allow-retake="<?php echo $exam['allow_retake']; ?>"
                                                data-show-results-immediately="<?php echo $exam['show_results_immediately']; ?>"
                                                onclick="editExam(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="../instructor/view_exams.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-outline-info" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="../instructor/add_question.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-outline-success" title="Manage Questions">
                                            <i class="fas fa-question-circle"></i>
                                        </a>
                                        <?php if($exam['attempt_count'] == 0): ?>
                                            <button class="btn btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteExamModal"
                                                    data-exam-id="<?php echo $exam['id']; ?>"
                                                    data-title="<?php echo htmlspecialchars($exam['title']); ?>"
                                                    onclick="deleteExam(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="Cannot delete exam with attempts">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit Exam Modal -->
<div class="modal fade" id="editExamModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="exam_id" id="edit_exam_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Exam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_title" class="form-label">Exam Title *</label>
                                <input type="text" class="form-control" id="edit_title" name="title" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_exam_type" class="form-label">Exam Type *</label>
                                <select class="form-select" id="edit_exam_type" name="exam_type" required>
                                    <option value="quiz">Quiz</option>
                                    <option value="midterm">Midterm</option>
                                    <option value="final">Final</option>
                                    <option value="assignment">Assignment</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_total_marks" class="form-label">Total Marks *</label>
                                <input type="number" class="form-control" id="edit_total_marks" name="total_marks" min="1" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_passing_marks" class="form-label">Passing Marks *</label>
                                <input type="number" class="form-control" id="edit_passing_marks" name="passing_marks" min="1" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_duration_minutes" class="form-label">Duration (minutes) *</label>
                                <input type="number" class="form-control" id="edit_duration_minutes" name="duration_minutes" min="1" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_start_date" class="form-label">Start Date & Time *</label>
                                <input type="datetime-local" class="form-control" id="edit_start_date" name="start_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_end_date" class="form-label">End Date & Time *</label>
                                <input type="datetime-local" class="form-control" id="edit_end_date" name="end_date" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                                    <label class="form-check-label" for="edit_is_active">Active Exam</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_allow_retake" name="allow_retake" value="1">
                                    <label class="form-check-label" for="edit_allow_retake">Allow Retake</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="edit_show_results_immediately" name="show_results_immediately" value="1">
                                    <label class="form-check-label" for="edit_show_results_immediately">Show Results Immediately</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_exam" class="btn btn-primary">Update Exam</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Exam Modal -->
<div class="modal fade" id="deleteExamModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="exam_id" id="delete_exam_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Exam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this exam?</h6>
                    <p class="text-center text-muted">Exam: <strong id="delete_exam_title"></strong></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. All exam data and questions will be permanently deleted.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_exam" class="btn btn-danger">Delete Exam</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editExam(button) {
    const examId = button.getAttribute('data-exam-id');
    const title = button.getAttribute('data-title');
    const description = button.getAttribute('data-description');
    const examType = button.getAttribute('data-exam-type');
    const totalMarks = button.getAttribute('data-total-marks');
    const passingMarks = button.getAttribute('data-passing-marks');
    const durationMinutes = button.getAttribute('data-duration-minutes');
    const startDate = button.getAttribute('data-start-date');
    const endDate = button.getAttribute('data-end-date');
    const isActive = button.getAttribute('data-is-active');
    const allowRetake = button.getAttribute('data-allow-retake');
    const showResultsImmediately = button.getAttribute('data-show-results-immediately');
    
    document.getElementById('edit_exam_id').value = examId;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_description').value = description;
    document.getElementById('edit_exam_type').value = examType;
    document.getElementById('edit_total_marks').value = totalMarks;
    document.getElementById('edit_passing_marks').value = passingMarks;
    document.getElementById('edit_duration_minutes').value = durationMinutes;
    document.getElementById('edit_start_date').value = startDate;
    document.getElementById('edit_end_date').value = endDate;
    document.getElementById('edit_is_active').checked = isActive === '1';
    document.getElementById('edit_allow_retake').checked = allowRetake === '1';
    document.getElementById('edit_show_results_immediately').checked = showResultsImmediately === '1';
}

function deleteExam(button) {
    const examId = button.getAttribute('data-exam-id');
    const examTitle = button.getAttribute('data-title');
    
    document.getElementById('delete_exam_id').value = examId;
    document.getElementById('delete_exam_title').textContent = examTitle;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Validate dates
    const startDateInput = document.getElementById('edit_start_date');
    const endDateInput = document.getElementById('edit_end_date');
    
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            if (endDateInput.value && this.value > endDateInput.value) {
                alert('Start date cannot be after end date!');
                this.value = '';
            }
        });
        
        endDateInput.addEventListener('change', function() {
            if (startDateInput.value && this.value < startDateInput.value) {
                alert('End date cannot be before start date!');
                this.value = '';
            }
        });
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>