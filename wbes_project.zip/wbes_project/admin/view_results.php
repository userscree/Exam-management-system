<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'View Results';
require_once '../includes/header.php';

// Handle result actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['regrade_exam'])) {
        $exam_id = $_POST['exam_id'];
        
        try {
            // Regrade all attempts for this exam
            $stmt = $pdo->prepare("
                SELECT ea.id as attempt_id 
                FROM exam_attempts ea 
                WHERE ea.exam_id = ? AND ea.status = 'submitted'
            ");
            $stmt->execute([$exam_id]);
            $attempts = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $regraded_count = 0;
            foreach($attempts as $attempt_id) {
                if (regradeAttempt($attempt_id)) {
                    $regraded_count++;
                }
            }
            
            setFlash('success', "Successfully regraded {$regraded_count} exam attempts.");
            redirect('view_results.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error regrading exam: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_attempt'])) {
        $attempt_id = $_POST['attempt_id'];
        
        try {
            // Delete student answers first
            $stmt = $pdo->prepare("DELETE FROM student_answers WHERE attempt_id = ?");
            $stmt->execute([$attempt_id]);
            
            // Delete result
            $stmt = $pdo->prepare("DELETE FROM results WHERE attempt_id = ?");
            $stmt->execute([$attempt_id]);
            
            // Delete attempt
            $stmt = $pdo->prepare("DELETE FROM exam_attempts WHERE id = ?");
            $stmt->execute([$attempt_id]);
            
            setFlash('success', 'Exam attempt deleted successfully!');
            redirect('view_results.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting attempt: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$exam_filter = $_GET['exam'] ?? '';
$course_filter = $_GET['course'] ?? '';
$student_filter = $_GET['student'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for results - FIXED: Use submitted_at from exam_attempts instead of created_at
$query = "
    SELECT r.*, 
           ea.started_at, ea.submitted_at, ea.status as attempt_status,
           e.title as exam_title, e.exam_type, e.total_marks, e.passing_marks,
           c.course_code, c.course_name,
           u.first_name, u.last_name, u.username, u.university_id,
           i.first_name as instructor_first_name, i.last_name as instructor_last_name
    FROM results r
    JOIN exam_attempts ea ON r.attempt_id = ea.id
    JOIN exams e ON ea.exam_id = e.id
    JOIN courses c ON e.course_id = c.id
    JOIN users u ON ea.student_id = u.id
    LEFT JOIN users i ON e.instructor_id = i.id
    WHERE 1=1
";
$params = [];

if (!empty($exam_filter)) {
    $query .= " AND e.id = ?";
    $params[] = $exam_filter;
}

if (!empty($course_filter)) {
    $query .= " AND c.id = ?";
    $params[] = $course_filter;
}

if (!empty($student_filter)) {
    $query .= " AND u.id = ?";
    $params[] = $student_filter;
}

if (!empty($status_filter)) {
    if ($status_filter === 'pass') {
        $query .= " AND r.status = 'pass'";
    } elseif ($status_filter === 'fail') {
        $query .= " AND r.status = 'fail'";
    }
}

if (!empty($date_from)) {
    $query .= " AND DATE(ea.submitted_at) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND DATE(ea.submitted_at) <= ?";
    $params[] = $date_to;
}

if (!empty($search)) {
    $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ? OR e.title LIKE ? OR c.course_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY ea.submitted_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get exams for filter dropdown
    $stmt = $pdo->prepare("SELECT id, title FROM exams WHERE is_active = 1 ORDER BY title");
    $stmt->execute();
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get courses for filter dropdown
    $stmt = $pdo->prepare("SELECT id, course_code, course_name FROM courses WHERE is_active = 1 ORDER BY course_code");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get students for filter dropdown
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, username FROM users WHERE role = 'student' AND is_active = 1 ORDER BY first_name, last_name");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get result statistics - FIXED: Use submitted_at from exam_attempts
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM results");
    $stmt->execute();
    $total_results = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as passed FROM results WHERE status = 'pass'");
    $stmt->execute();
    $passed_results = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as failed FROM results WHERE status = 'fail'");
    $stmt->execute();
    $failed_results = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT AVG(percentage) as avg_percentage FROM results");
    $stmt->execute();
    $avg_percentage = $stmt->fetchColumn();
    $avg_percentage = $avg_percentage ? round($avg_percentage, 2) : 0;
    
    // Get recent results (last 7 days) - FIXED: Use submitted_at from exam_attempts
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as recent 
        FROM results r
        JOIN exam_attempts ea ON r.attempt_id = ea.id
        WHERE DATE(ea.submitted_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $recent_results = $stmt->fetchColumn();
    
    // Get grade distribution
    $stmt = $pdo->prepare("SELECT grade, COUNT(*) as count FROM results GROUP BY grade ORDER BY 
        CASE grade 
            WHEN 'A+' THEN 1
            WHEN 'A' THEN 2
            WHEN 'B' THEN 3
            WHEN 'C' THEN 4
            WHEN 'D' THEN 5
            WHEN 'F' THEN 6
            ELSE 7
        END");
    $stmt->execute();
    $grade_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get exam performance statistics
    $stmt = $pdo->prepare("
        SELECT e.title, 
               COUNT(r.id) as attempt_count,
               AVG(r.percentage) as avg_score,
               SUM(CASE WHEN r.status = 'pass' THEN 1 ELSE 0 END) as pass_count
        FROM exams e
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE ea.status = 'graded'
        GROUP BY e.id
        ORDER BY attempt_count DESC
        LIMIT 10
    ");
    $stmt->execute();
    $exam_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching results: ' . $e->getMessage());
    $results = [];
    $exams = [];
    $courses = [];
    $students = [];
    $total_results = 0;
    $passed_results = 0;
    $failed_results = 0;
    $avg_percentage = 0;
    $recent_results = 0;
    $grade_distribution = [];
    $exam_performance = [];
}

// Function to regrade an attempt
function regradeAttempt($attempt_id) {
    global $pdo;
    
    try {
        // Get attempt details
        $stmt = $pdo->prepare("
            SELECT ea.*, e.total_marks 
            FROM exam_attempts ea 
            JOIN exams e ON ea.exam_id = e.id 
            WHERE ea.id = ?
        ");
        $stmt->execute([$attempt_id]);
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attempt) return false;
        
        // Calculate total obtained marks
        $stmt = $pdo->prepare("
            SELECT SUM(sa.awarded_marks) as total_obtained
            FROM student_answers sa
            JOIN questions q ON sa.question_id = q.id
            WHERE sa.attempt_id = ? AND sa.awarded_marks IS NOT NULL
        ");
        $stmt->execute([$attempt_id]);
        $marks_result = $stmt->fetch(PDO::FETCH_ASSOC);
        $obtained_marks = $marks_result['total_obtained'] ?? 0;
        
        // Calculate percentage
        $percentage = calculatePercentage($obtained_marks, $attempt['total_marks']);
        
        // Determine grade and status
        $grade = getGrade($percentage);
        $status = ($percentage >= ($attempt['passing_marks'] / $attempt['total_marks'] * 100)) ? 'pass' : 'fail';
        
        // Update result
        $stmt = $pdo->prepare("
            UPDATE results 
            SET obtained_marks = ?, percentage = ?, grade = ?, status = ?, updated_at = NOW() 
            WHERE attempt_id = ?
        ");
        $stmt->execute([$obtained_marks, $percentage, $grade, $status, $attempt_id]);
        
        return true;
        
    } catch(PDOException $e) {
        error_log("Regrade error: " . $e->getMessage());
        return false;
    }
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Exam Results</h1>
                <p class="text-muted mb-0">View and manage all exam results</p>
            </div>
            <div class="btn-group">
                <a href="view_reports.php" class="btn btn-outline-primary">
                    <i class="fas fa-chart-bar me-2"></i> View Reports
                </a>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="fas fa-download me-2"></i>Export Results
                    </a></li>
                    <li><a class="dropdown-item" href="view_reports.php">
                        <i class="fas fa-chart-pie me-2"></i>Analytics
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Results
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_results; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Passed
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $passed_results; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <?php echo $total_results > 0 ? round(($passed_results / $total_results) * 100, 1) : 0; ?>% success rate
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Failed
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $failed_results; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                <?php echo $total_results > 0 ? round(($failed_results / $total_results) * 100, 1) : 0; ?>% failure rate
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Average Score
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $avg_percentage; ?>%</div>
                        <div class="mt-2">
                            <small class="text-muted">
                                Overall performance
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Recent (7d)
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $recent_results; ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                New results
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-2 col-md-4 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                            Active Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($exams); ?></div>
                        <div class="mt-2">
                            <small class="text-muted">
                                With results
                            </small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-play-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- Filters and Search -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Search results..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="exam" class="form-label">Exam</label>
                        <select class="form-select" id="exam" name="exam">
                            <option value="">All Exams</option>
                            <?php foreach($exams as $exam_item): ?>
                                <option value="<?php echo $exam_item['id']; ?>" <?php echo $exam_filter == $exam_item['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($exam_item['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="course" class="form-label">Course</label>
                        <select class="form-select" id="course" name="course">
                            <option value="">All Courses</option>
                            <?php foreach($courses as $course): ?>
                                <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($course['course_code']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="student" class="form-label">Student</label>
                        <select class="form-select" id="student" name="student">
                            <option value="">All Students</option>
                            <?php foreach($students as $student): ?>
                                <option value="<?php echo $student['id']; ?>" <?php echo $student_filter == $student['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="">All</option>
                            <option value="pass" <?php echo $status_filter == 'pass' ? 'selected' : ''; ?>>Pass</option>
                            <option value="fail" <?php echo $status_filter == 'fail' ? 'selected' : ''; ?>>Fail</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <div class="btn-group w-100">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter me-2"></i> Filter
                            </button>
                            <a href="view_results.php" class="btn btn-outline-secondary">
                                <i class="fas fa-redo me-2"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
                
                <!-- Date Range Filter -->
                <form method="GET" class="row g-3 mt-2">
                    <input type="hidden" name="exam" value="<?php echo htmlspecialchars($exam_filter); ?>">
                    <input type="hidden" name="course" value="<?php echo htmlspecialchars($course_filter); ?>">
                    <input type="hidden" name="student" value="<?php echo htmlspecialchars($student_filter); ?>">
                    <input type="hidden" name="status" value="<?php echo htmlspecialchars($status_filter); ?>">
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                    
                    <div class="col-md-3">
                        <label for="date_from" class="form-label">Date From</label>
                        <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="date_to" class="form-label">Date To</label>
                        <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-outline-primary">
                            <i class="fas fa-calendar me-2"></i> Apply Date
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Results Table -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-list me-2"></i> Exam Results
                    <span class="badge bg-primary ms-2"><?php echo count($results); ?> results</span>
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Student</th>
                                <th>Exam & Course</th>
                                <th>Score</th>
                                <th>Grade</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($results)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                                        <h5 class="text-muted">No results found</h5>
                                        <p class="text-muted">Try adjusting your filters or check back later.</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($results as $result): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="flex-shrink-0">
                                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                        <i class="fas fa-user"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1 ms-3">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?></h6>
                                                    <small class="text-muted">@<?php echo htmlspecialchars($result['username']); ?></small>
                                                    <?php if(!empty($result['university_id'])): ?>
                                                        <div class="mt-1">
                                                            <small class="text-muted">ID:</small>
                                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($result['university_id']); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <h6 class="mb-1"><?php echo htmlspecialchars($result['exam_title']); ?></h6>
                                            <small class="text-muted"><?php echo htmlspecialchars($result['course_code'] . ' - ' . $result['course_name']); ?></small>
                                            <div class="mt-1">
                                                <span class="badge bg-<?php 
                                                    switch($result['exam_type']) {
                                                        case 'quiz': echo 'warning'; break;
                                                        case 'midterm': echo 'info'; break;
                                                        case 'final': echo 'danger'; break;
                                                        case 'assignment': echo 'success'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?>">
                                                    <?php echo ucfirst($result['exam_type']); ?>
                                                </span>
                                            </div>
                                            <?php if($result['instructor_first_name']): ?>
                                                <div class="mt-1">
                                                    <small class="text-muted">Instructor: <?php echo htmlspecialchars($result['instructor_first_name'] . ' ' . $result['instructor_last_name']); ?></small>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="text-center">
                                                <div class="h5 mb-1 text-primary"><?php echo $result['percentage']; ?>%</div>
                                                <div class="progress" style="height: 6px; width: 80px; margin: 0 auto;">
                                                    <div class="progress-bar bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>" 
                                                         style="width: <?php echo $result['percentage']; ?>%"></div>
                                                </div>
                                                <small class="text-muted">
                                                    <?php echo $result['obtained_marks']; ?>/<?php echo $result['total_marks']; ?>
                                                </small>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge grade-<?php echo strtolower($result['grade']); ?> fs-6">
                                                <?php echo $result['grade']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $result['status'] == 'pass' ? 'success' : 'danger'; ?>">
                                                <i class="fas fa-<?php echo $result['status'] == 'pass' ? 'check' : 'times'; ?> me-1"></i>
                                                <?php echo ucfirst($result['status']); ?>
                                            </span>
                                            <div class="mt-1 small text-muted">
                                                Passing: <?php echo $result['passing_marks']; ?> marks
                                            </div>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo formatDate($result['submitted_at']); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="../student/result_details.php?attempt_id=<?php echo $result['attempt_id']; ?>" 
                                                   class="btn btn-outline-primary" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button class="btn btn-outline-warning" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#regradeModal"
                                                        data-attempt-id="<?php echo $result['attempt_id']; ?>"
                                                        data-student-name="<?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?>"
                                                        data-exam-title="<?php echo htmlspecialchars($result['exam_title']); ?>"
                                                        onclick="regradeAttempt(this)">
                                                    <i class="fas fa-sync-alt"></i>
                                                </button>
                                                <button class="btn btn-outline-danger" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#deleteAttemptModal"
                                                        data-attempt-id="<?php echo $result['attempt_id']; ?>"
                                                        data-student-name="<?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?>"
                                                        data-exam-title="<?php echo htmlspecialchars($result['exam_title']); ?>"
                                                        onclick="deleteAttempt(this)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if(!empty($results)): ?>
            <div class="card-footer bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">
                            Showing <?php echo count($results); ?> results
                        </small>
                    </div>
                    <div>
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exportModal">
                            <i class="fas fa-download me-2"></i> Export Results
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Grade Distribution -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-pie me-2 text-primary"></i>
                    Grade Distribution
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($grade_distribution)): ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-chart-pie fa-2x mb-2"></i>
                        <p>No grade data available</p>
                    </div>
                <?php else: ?>
                    <?php foreach($grade_distribution as $grade): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge grade-<?php echo strtolower($grade['grade']); ?>">
                                <?php echo $grade['grade']; ?>
                            </span>
                            <span class="fw-bold text-primary"><?php echo $grade['count']; ?></span>
                        </div>
                        <div class="progress mb-3" style="height: 8px;">
                            <div class="progress-bar bg-<?php 
                                switch($grade['grade']) {
                                    case 'A+': case 'A': echo 'success'; break;
                                    case 'B': echo 'info'; break;
                                    case 'C': echo 'warning'; break;
                                    case 'D': echo 'orange'; break;
                                    case 'F': echo 'danger'; break;
                                    default: echo 'secondary';
                                }
                            ?>" style="width: <?php echo ($grade['count'] / $total_results) * 100; ?>%"></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Top Performing Exams -->
        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-trophy me-2 text-warning"></i>
                    Top Performing Exams
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($exam_performance)): ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-trophy fa-2x mb-2"></i>
                        <p>No exam performance data</p>
                    </div>
                <?php else: ?>
                    <?php foreach($exam_performance as $exam): ?>
                        <div class="mb-3">
                            <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">Average Score</small>
                                <span class="fw-bold text-primary"><?php echo round($exam['avg_score'], 1); ?>%</span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Pass Rate</small>
                                <span class="fw-bold text-<?php echo ($exam['pass_count'] / $exam['attempt_count'] * 100) >= 70 ? 'success' : 'danger'; ?>">
                                    <?php echo $exam['attempt_count'] > 0 ? round(($exam['pass_count'] / $exam['attempt_count']) * 100, 1) : 0; ?>%
                                </span>
                            </div>
                            <div class="mt-1">
                                <small class="text-muted"><?php echo $exam['attempt_count']; ?> attempts</small>
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-bolt me-2 text-warning"></i>
                    Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <button class="btn btn-outline-primary text-start" data-bs-toggle="modal" data-bs-target="#exportModal">
                        <i class="fas fa-download me-2"></i> Export All Results
                    </button>
                    <button class="btn btn-outline-warning text-start" data-bs-toggle="modal" data-bs-target="#bulkRegradeModal">
                        <i class="fas fa-sync-alt me-2"></i> Bulk Regrade
                    </button>
                    <a href="view_reports.php" class="btn btn-outline-info text-start">
                        <i class="fas fa-chart-bar me-2"></i> View Analytics
                    </a>
                    <a href="manage_exams.php" class="btn btn-outline-success text-start">
                        <i class="fas fa-cog me-2"></i> Manage Exams
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Export Modal -->
<div class="modal fade" id="exportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Export Results</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="../process/export_results.php" id="exportForm">
                    <input type="hidden" name="export_type" value="results">
                    <input type="hidden" name="exam_filter" value="<?php echo htmlspecialchars($exam_filter); ?>">
                    <input type="hidden" name="course_filter" value="<?php echo htmlspecialchars($course_filter); ?>">
                    <input type="hidden" name="student_filter" value="<?php echo htmlspecialchars($student_filter); ?>">
                    <input type="hidden" name="status_filter" value="<?php echo htmlspecialchars($status_filter); ?>">
                    <input type="hidden" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                    <input type="hidden" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Export Format</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="format" id="format_csv" value="csv" checked>
                            <label class="form-check-label" for="format_csv">
                                CSV (Excel compatible)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="format" id="format_pdf" value="pdf">
                            <label class="form-check-label" for="format_pdf">
                                PDF Report
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Data Range</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="range" id="range_current" value="current" checked>
                            <label class="form-check-label" for="range_current">
                                Current filtered results (<?php echo count($results); ?> records)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="range" id="range_all" value="all">
                            <label class="form-check-label" for="range_all">
                                All results (<?php echo $total_results; ?> records)
                            </label>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        The export will include all visible columns from the results table.
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="exportForm" class="btn btn-primary">
                    <i class="fas fa-download me-2"></i> Export
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Regrade Modal -->
<div class="modal fade" id="regradeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="attempt_id" id="regrade_attempt_id">
                <div class="modal-header">
                    <h5 class="modal-title">Regrade Attempt</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to regrade this exam attempt?</p>
                    <div class="alert alert-info">
                        <strong>Student:</strong> <span id="regrade_student_name"></span><br>
                        <strong>Exam:</strong> <span id="regrade_exam_title"></span>
                    </div>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This will recalculate the score based on current answer evaluations.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="regrade_exam" class="btn btn-warning">
                        <i class="fas fa-sync-alt me-2"></i> Regrade
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk Regrade Modal -->
<div class="modal fade" id="bulkRegradeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Bulk Regrade</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="bulk_exam" class="form-label">Select Exam</label>
                        <select class="form-select" id="bulk_exam" name="exam_id">
                            <option value="">Select Exam</option>
                            <?php foreach($exams as $exam_item): ?>
                                <option value="<?php echo $exam_item['id']; ?>">
                                    <?php echo htmlspecialchars($exam_item['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        This will regrade ALL submitted attempts for the selected exam. This action may take several minutes for large datasets.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="regrade_exam" class="btn btn-warning">
                        <i class="fas fa-sync-alt me-2"></i> Bulk Regrade
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Attempt Modal -->
<div class="modal fade" id="deleteAttemptModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="attempt_id" id="delete_attempt_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Exam Attempt</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this exam attempt?</h6>
                    <p class="text-center text-muted">
                        Student: <strong id="delete_student_name"></strong><br>
                        Exam: <strong id="delete_exam_title"></strong>
                    </p>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. All associated data including answers and results will be permanently deleted.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_attempt" class="btn btn-danger">Delete Attempt</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function regradeAttempt(button) {
    const attemptId = button.getAttribute('data-attempt-id');
    const studentName = button.getAttribute('data-student-name');
    const examTitle = button.getAttribute('data-exam-title');
    
    document.getElementById('regrade_attempt_id').value = attemptId;
    document.getElementById('regrade_student_name').textContent = studentName;
    document.getElementById('regrade_exam_title').textContent = examTitle;
}

function deleteAttempt(button) {
    const attemptId = button.getAttribute('data-attempt-id');
    const studentName = button.getAttribute('data-student-name');
    const examTitle = button.getAttribute('data-exam-title');
    
    document.getElementById('delete_attempt_id').value = attemptId;
    document.getElementById('delete_student_name').textContent = studentName;
    document.getElementById('delete_exam_title').textContent = examTitle;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Update export form based on selections
    const exportForm = document.getElementById('exportForm');
    if (exportForm) {
        const rangeCurrent = document.getElementById('range_current');
        const rangeAll = document.getElementById('range_all');
        
        rangeCurrent.addEventListener('change', updateExportForm);
        rangeAll.addEventListener('change', updateExportForm);
        
        function updateExportForm() {
            if (rangeAll.checked) {
                // Clear filter values for "all results"
                exportForm.querySelector('input[name="exam_filter"]').value = '';
                exportForm.querySelector('input[name="course_filter"]').value = '';
                exportForm.querySelector('input[name="student_filter"]').value = '';
                exportForm.querySelector('input[name="status_filter"]').value = '';
                exportForm.querySelector('input[name="date_from"]').value = '';
                exportForm.querySelector('input[name="date_to"]').value = '';
                exportForm.querySelector('input[name="search"]').value = '';
            }
        }
    }
});
</script>

<style>
.grade-a+ { background-color: #28a745; color: white; }
.grade-a { background-color: #28a745; color: white; }
.grade-b { background-color: #17a2b8; color: white; }
.grade-c { background-color: #ffc107; color: #212529; }
.grade-d { background-color: #fd7e14; color: white; }
.grade-f { background-color: #dc3545; color: white; }

.progress {
    background-color: #e9ecef;
    border-radius: 0.375rem;
}

.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
}

.bg-orange {
    background-color: #fd7e14 !important;
}
</style>

<?php require_once '../includes/footer.php'; ?>