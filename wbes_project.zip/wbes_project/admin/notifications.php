<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Notifications';
require_once '../includes/header.php';

$admin_id = $_SESSION['user_id'];

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['send_notification'])) {
        $title = sanitize($_POST['title']);
        $message = sanitize($_POST['message']);
        $notification_type = sanitize($_POST['notification_type']);
        $target_audience = sanitize($_POST['target_audience']);
        $specific_users = isset($_POST['specific_users']) ? $_POST['specific_users'] : [];
        $expires_at = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
        $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;
        $send_email = isset($_POST['send_email']) ? 1 : 0;
        
        // Validation
        $errors = [];
        
        if (empty($title)) {
            $errors[] = 'Notification title is required.';
        }
        
        if (empty($message)) {
            $errors[] = 'Notification message is required.';
        }
        
        if (empty($target_audience)) {
            $errors[] = 'Please select target audience.';
        }
        
        if ($target_audience == 'specific' && empty($specific_users)) {
            $errors[] = 'Please select specific users for the notification.';
        }
        
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();
                
                // Create notification
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (title, message, notification_type, target_audience, is_urgent, expires_at, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$title, $message, $notification_type, $target_audience, $is_urgent, $expires_at, $admin_id]);
                $notification_id = $pdo->lastInsertId();
                
                // Determine target users based on audience
                $target_users = [];
                
                switch($target_audience) {
                    case 'all':
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE is_active = 1");
                        $stmt->execute();
                        $target_users = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        break;
                        
                    case 'students':
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'student' AND is_active = 1");
                        $stmt->execute();
                        $target_users = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        break;
                        
                    case 'instructors':
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'instructor' AND is_active = 1");
                        $stmt->execute();
                        $target_users = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        break;
                        
                    case 'admins':
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'admin' AND is_active = 1");
                        $stmt->execute();
                        $target_users = $stmt->fetchAll(PDO::FETCH_COLUMN);
                        break;
                        
                    case 'specific':
                        $target_users = $specific_users;
                        break;
                }
                
                // Create user notifications
                $user_count = 0;
                foreach($target_users as $user_id) {
                    $stmt = $pdo->prepare("
                        INSERT INTO user_notifications (user_id, notification_id, is_read) 
                        VALUES (?, ?, 0)
                    ");
                    $stmt->execute([$user_id, $notification_id]);
                    $user_count++;
                }
                
                // Log activity
                $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $admin_id,
                    'notification_sent',
                    'Sent notification to ' . $user_count . ' users: ' . $title,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                $pdo->commit();
                
                setFlash('success', 'Notification sent successfully to ' . $user_count . ' users!');
                redirect('notifications.php');
                
            } catch(PDOException $e) {
                $pdo->rollBack();
                setFlash('error', 'Error sending notification: ' . $e->getMessage());
            }
        } else {
            foreach($errors as $error) {
                setFlash('error', $error);
            }
        }
    }
    
    if (isset($_POST['update_notification'])) {
        $notification_id = $_POST['notification_id'];
        $title = sanitize($_POST['title']);
        $message = sanitize($_POST['message']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $expires_at = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
        
        try {
            $stmt = $pdo->prepare("
                UPDATE notifications 
                SET title = ?, message = ?, is_active = ?, expires_at = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$title, $message, $is_active, $expires_at, $notification_id]);
            
            setFlash('success', 'Notification updated successfully!');
            redirect('notifications.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error updating notification: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_notification'])) {
        $notification_id = $_POST['notification_id'];
        
        try {
            // Delete user notifications first
            $stmt = $pdo->prepare("DELETE FROM user_notifications WHERE notification_id = ?");
            $stmt->execute([$notification_id]);
            
            // Delete notification
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ?");
            $stmt->execute([$notification_id]);
            
            setFlash('success', 'Notification deleted successfully!');
            redirect('notifications.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting notification: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';
$audience_filter = $_GET['audience'] ?? '';
$urgent_filter = $_GET['urgent'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for notifications
$query = "
    SELECT n.*, 
           u.first_name as created_by_first_name, u.last_name as created_by_last_name,
           (SELECT COUNT(*) FROM user_notifications WHERE notification_id = n.id) as total_recipients,
           (SELECT COUNT(*) FROM user_notifications WHERE notification_id = n.id AND is_read = 1) as read_count
    FROM notifications n 
    LEFT JOIN users u ON n.created_by = u.id 
    WHERE 1=1
";
$params = [];

if (!empty($type_filter)) {
    $query .= " AND n.notification_type = ?";
    $params[] = $type_filter;
}

if ($status_filter === 'active') {
    $query .= " AND n.is_active = 1 AND (n.expires_at IS NULL OR n.expires_at > NOW())";
} elseif ($status_filter === 'expired') {
    $query .= " AND n.expires_at IS NOT NULL AND n.expires_at <= NOW()";
} elseif ($status_filter === 'inactive') {
    $query .= " AND n.is_active = 0";
}

if (!empty($audience_filter)) {
    $query .= " AND n.target_audience = ?";
    $params[] = $audience_filter;
}

if ($urgent_filter === 'yes') {
    $query .= " AND n.is_urgent = 1";
} elseif ($urgent_filter === 'no') {
    $query .= " AND n.is_urgent = 0";
}

if (!empty($search)) {
    $query .= " AND (n.title LIKE ? OR n.message LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY n.created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get users for specific targeting
    $stmt = $pdo->prepare("
        SELECT id, first_name, last_name, username, role, email 
        FROM users 
        WHERE is_active = 1 
        ORDER BY role, first_name, last_name
    ");
    $stmt->execute();
    $all_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get notification statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM notifications");
    $stmt->execute();
    $total_notifications = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM notifications WHERE is_active = 1 AND (expires_at IS NULL OR expires_at > NOW())");
    $stmt->execute();
    $active_notifications = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as urgent FROM notifications WHERE is_urgent = 1");
    $stmt->execute();
    $urgent_notifications = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as expired FROM notifications WHERE expires_at IS NOT NULL AND expires_at <= NOW()");
    $stmt->execute();
    $expired_notifications = $stmt->fetchColumn();
    
    // Get audience distribution
    $stmt = $pdo->prepare("SELECT target_audience, COUNT(*) as count FROM notifications GROUP BY target_audience");
    $stmt->execute();
    $audience_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get type distribution
    $stmt = $pdo->prepare("SELECT notification_type, COUNT(*) as count FROM notifications GROUP BY notification_type");
    $stmt->execute();
    $type_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching notifications: ' . $e->getMessage());
    $notifications = [];
    $all_users = [];
    $total_notifications = $active_notifications = $urgent_notifications = $expired_notifications = 0;
    $audience_distribution = $type_distribution = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Notifications</h1>
                <p class="text-muted mb-0">Send and manage system notifications</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#sendNotificationModal">
                    <i class="fas fa-bell me-2"></i> Send Notification
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#sendNotificationModal"><i class="fas fa-bell me-2"></i>Send Notification</a></li>
                    <li><a class="dropdown-item" href="notification_templates.php"><i class="fas fa-file-alt me-2"></i>Manage Templates</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Notifications
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_notifications; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-bell fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Notifications
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_notifications; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Urgent Notifications
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $urgent_notifications; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Expired Notifications
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $expired_notifications; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-hourglass-end fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Distribution Cards -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-users me-2 text-primary"></i>
                    Audience Distribution
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($audience_distribution)): ?>
                    <p class="text-muted text-center mb-0">No audience data available</p>
                <?php else: ?>
                    <?php foreach($audience_distribution as $audience): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">
                                <i class="fas fa-<?php 
                                    switch($audience['target_audience']) {
                                        case 'all': echo 'globe'; break;
                                        case 'students': echo 'user-graduate'; break;
                                        case 'instructors': echo 'chalkboard-teacher'; break;
                                        case 'admins': echo 'shield-alt'; break;
                                        case 'specific': echo 'user-friends'; break;
                                        default: echo 'user';
                                    }
                                ?> me-2 text-<?php 
                                    switch($audience['target_audience']) {
                                        case 'all': echo 'primary'; break;
                                        case 'students': echo 'success'; break;
                                        case 'instructors': echo 'warning'; break;
                                        case 'admins': echo 'danger'; break;
                                        case 'specific': echo 'info'; break;
                                        default: echo 'secondary';
                                    }
                                ?>"></i>
                                <?php echo ucfirst($audience['target_audience']); ?>
                            </span>
                            <span class="badge bg-<?php 
                                switch($audience['target_audience']) {
                                    case 'all': echo 'primary'; break;
                                    case 'students': echo 'success'; break;
                                    case 'instructors': echo 'warning'; break;
                                    case 'admins': echo 'danger'; break;
                                    case 'specific': echo 'info'; break;
                                    default: echo 'secondary';
                                }
                            ?>"><?php echo $audience['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">
                    <i class="fas fa-tags me-2 text-primary"></i>
                    Type Distribution
                </h5>
            </div>
            <div class="card-body">
                <?php if(empty($type_distribution)): ?>
                    <p class="text-muted text-center mb-0">No type data available</p>
                <?php else: ?>
                    <?php foreach($type_distribution as $type): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">
                                <i class="fas fa-<?php 
                                    switch($type['notification_type']) {
                                        case 'info': echo 'info-circle'; break;
                                        case 'warning': echo 'exclamation-triangle'; break;
                                        case 'success': echo 'check-circle'; break;
                                        case 'error': echo 'times-circle'; break;
                                        case 'exam': echo 'file-alt'; break;
                                        default: echo 'bell';
                                    }
                                ?> me-2 text-<?php 
                                    switch($type['notification_type']) {
                                        case 'info': echo 'info'; break;
                                        case 'warning': echo 'warning'; break;
                                        case 'success': echo 'success'; break;
                                        case 'error': echo 'danger'; break;
                                        case 'exam': echo 'primary'; break;
                                        default: echo 'secondary';
                                    }
                                ?>"></i>
                                <?php echo ucfirst($type['notification_type']); ?>
                            </span>
                            <span class="badge bg-<?php 
                                switch($type['notification_type']) {
                                    case 'info': echo 'info'; break;
                                    case 'warning': echo 'warning'; break;
                                    case 'success': echo 'success'; break;
                                    case 'error': echo 'danger'; break;
                                    case 'exam': echo 'primary'; break;
                                    default: echo 'secondary';
                                }
                            ?>"><?php echo $type['count']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search notifications..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type">
                    <option value="">All Types</option>
                    <option value="info" <?php echo $type_filter == 'info' ? 'selected' : ''; ?>>Info</option>
                    <option value="warning" <?php echo $type_filter == 'warning' ? 'selected' : ''; ?>>Warning</option>
                    <option value="success" <?php echo $type_filter == 'success' ? 'selected' : ''; ?>>Success</option>
                    <option value="error" <?php echo $type_filter == 'error' ? 'selected' : ''; ?>>Error</option>
                    <option value="exam" <?php echo $type_filter == 'exam' ? 'selected' : ''; ?>>Exam</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="audience" class="form-label">Audience</label>
                <select class="form-select" id="audience" name="audience">
                    <option value="">All Audiences</option>
                    <option value="all" <?php echo $audience_filter == 'all' ? 'selected' : ''; ?>>All Users</option>
                    <option value="students" <?php echo $audience_filter == 'students' ? 'selected' : ''; ?>>Students</option>
                    <option value="instructors" <?php echo $audience_filter == 'instructors' ? 'selected' : ''; ?>>Instructors</option>
                    <option value="admins" <?php echo $audience_filter == 'admins' ? 'selected' : ''; ?>>Admins</option>
                    <option value="specific" <?php echo $audience_filter == 'specific' ? 'selected' : ''; ?>>Specific Users</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="expired" <?php echo $status_filter == 'expired' ? 'selected' : ''; ?>>Expired</option>
                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="urgent" class="form-label">Urgent</label>
                <select class="form-select" id="urgent" name="urgent">
                    <option value="">All</option>
                    <option value="yes" <?php echo $urgent_filter == 'yes' ? 'selected' : ''; ?>>Urgent Only</option>
                    <option value="no" <?php echo $urgent_filter == 'no' ? 'selected' : ''; ?>>Not Urgent</option>
                </select>
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="notifications.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Notifications Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Notifications List
            <span class="badge bg-primary ms-2"><?php echo count($notifications); ?> notifications</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Notification Details</th>
                        <th>Audience & Type</th>
                        <th>Delivery Stats</th>
                        <th>Status & Expiry</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($notifications)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-bell fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No notifications found</h5>
                                <p class="text-muted">Try adjusting your filters or send a new notification.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($notifications as $notification): 
                            $now = new DateTime();
                            $expires_at = $notification['expires_at'] ? new DateTime($notification['expires_at']) : null;
                            $is_expired = $expires_at && $now > $expires_at;
                            $is_active = $notification['is_active'] && !$is_expired;
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($notification['title']); ?></h6>
                                    <p class="mb-1 small text-muted"><?php echo substr(htmlspecialchars($notification['message']), 0, 100); ?>...</p>
                                    <?php if($notification['is_urgent']): ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-exclamation-triangle me-1"></i> Urgent
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="mb-2">
                                        <span class="badge bg-<?php 
                                            switch($notification['target_audience']) {
                                                case 'all': echo 'primary'; break;
                                                case 'students': echo 'success'; break;
                                                case 'instructors': echo 'warning'; break;
                                                case 'admins': echo 'danger'; break;
                                                case 'specific': echo 'info'; break;
                                                default: echo 'secondary';
                                            }
                                        ?>">
                                            <i class="fas fa-<?php 
                                                switch($notification['target_audience']) {
                                                    case 'all': echo 'globe'; break;
                                                    case 'students': echo 'user-graduate'; break;
                                                    case 'instructors': echo 'chalkboard-teacher'; break;
                                                    case 'admins': echo 'shield-alt'; break;
                                                    case 'specific': echo 'user-friends'; break;
                                                    default: echo 'user';
                                                }
                                            ?> me-1"></i>
                                            <?php echo ucfirst($notification['target_audience']); ?>
                                        </span>
                                    </div>
                                    <div>
                                        <span class="badge bg-<?php 
                                            switch($notification['notification_type']) {
                                                case 'info': echo 'info'; break;
                                                case 'warning': echo 'warning'; break;
                                                case 'success': echo 'success'; break;
                                                case 'error': echo 'danger'; break;
                                                case 'exam': echo 'primary'; break;
                                                default: echo 'secondary';
                                            }
                                        ?>">
                                            <?php echo ucfirst($notification['notification_type']); ?>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="mb-1">
                                            <small class="text-muted">Total:</small>
                                            <span class="fw-bold"><?php echo $notification['total_recipients']; ?></span>
                                        </div>
                                        <div class="mb-1">
                                            <small class="text-muted">Read:</small>
                                            <span class="fw-bold text-success"><?php echo $notification['read_count']; ?></span>
                                        </div>
                                        <div>
                                            <small class="text-muted">Unread:</small>
                                            <span class="fw-bold text-warning"><?php echo $notification['total_recipients'] - $notification['read_count']; ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if($is_active): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check-circle me-1"></i> Active
                                        </span>
                                    <?php elseif($is_expired): ?>
                                        <span class="badge bg-secondary">
                                            <i class="fas fa-hourglass-end me-1"></i> Expired
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">
                                            <i class="fas fa-times-circle me-1"></i> Inactive
                                        </span>
                                    <?php endif; ?>
                                    
                                    <?php if($expires_at): ?>
                                        <div class="mt-1 small text-muted">
                                            <i class="fas fa-clock me-1"></i>
                                            <?php echo $is_expired ? 'Expired' : 'Expires'; ?>: 
                                            <?php echo formatDate($notification['expires_at']); ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="mt-1 small text-muted">
                                            <i class="fas fa-infinity me-1"></i> No expiry
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="small">
                                        <div><?php echo formatDate($notification['created_at']); ?></div>
                                        <div class="text-muted">
                                            By: <?php echo htmlspecialchars($notification['created_by_first_name'] . ' ' . $notification['created_by_last_name']); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#viewNotificationModal" 
                                                data-notification-id="<?php echo $notification['id']; ?>"
                                                data-title="<?php echo htmlspecialchars($notification['title']); ?>"
                                                data-message="<?php echo htmlspecialchars($notification['message']); ?>"
                                                data-notification-type="<?php echo $notification['notification_type']; ?>"
                                                data-target-audience="<?php echo $notification['target_audience']; ?>"
                                                data-is-urgent="<?php echo $notification['is_urgent']; ?>"
                                                data-expires-at="<?php echo $notification['expires_at']; ?>"
                                                data-total-recipients="<?php echo $notification['total_recipients']; ?>"
                                                data-read-count="<?php echo $notification['read_count']; ?>"
                                                data-created-at="<?php echo $notification['created_at']; ?>"
                                                data-created-by="<?php echo htmlspecialchars($notification['created_by_first_name'] . ' ' . $notification['created_by_last_name']); ?>"
                                                onclick="viewNotification(this)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-outline-warning" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editNotificationModal"
                                                data-notification-id="<?php echo $notification['id']; ?>"
                                                data-title="<?php echo htmlspecialchars($notification['title']); ?>"
                                                data-message="<?php echo htmlspecialchars($notification['message']); ?>"
                                                data-is-active="<?php echo $notification['is_active']; ?>"
                                                data-expires-at="<?php echo $notification['expires_at']; ?>"
                                                onclick="editNotification(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-outline-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteNotificationModal"
                                                data-notification-id="<?php echo $notification['id']; ?>"
                                                data-title="<?php echo htmlspecialchars($notification['title']); ?>"
                                                onclick="deleteNotification(this)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Send Notification Modal -->
<div class="modal fade" id="sendNotificationModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="sendNotificationForm">
                <div class="modal-header">
                    <h5 class="modal-title">Send New Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="title" class="form-label">Notification Title *</label>
                                <input type="text" class="form-control" id="title" name="title" required 
                                       placeholder="Enter notification title...">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="notification_type" class="form-label">Type *</label>
                                <select class="form-select" id="notification_type" name="notification_type" required>
                                    <option value="info">Info</option>
                                    <option value="warning">Warning</option>
                                    <option value="success">Success</option>
                                    <option value="error">Error</option>
                                    <option value="exam">Exam Related</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="message" class="form-label">Message *</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required 
                                  placeholder="Enter notification message..."></textarea>
                        <div class="form-text">You can use HTML tags for formatting.</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="target_audience" class="form-label">Target Audience *</label>
                                <select class="form-select" id="target_audience" name="target_audience" required onchange="toggleSpecificUsers()">
                                    <option value="">Select Audience</option>
                                    <option value="all">All Users</option>
                                    <option value="students">Students Only</option>
                                    <option value="instructors">Instructors Only</option>
                                    <option value="admins">Admins Only</option>
                                    <option value="specific">Specific Users</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="expires_at" class="form-label">Expiry Date (Optional)</label>
                                <input type="datetime-local" class="form-control" id="expires_at" name="expires_at">
                                <div class="form-text">Leave empty for no expiration</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Specific Users Selection -->
                    <div class="mb-3" id="specificUsersSection" style="display: none;">
                        <label class="form-label">Select Specific Users *</label>
                        <div class="border rounded p-3" style="max-height: 200px; overflow-y: auto;">
                            <div class="row">
                                <?php foreach($all_users as $user): ?>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-check">
                                            <input class="form-check-input specific-user" type="checkbox" 
                                                   name="specific_users[]" value="<?php echo $user['id']; ?>" 
                                                   id="user_<?php echo $user['id']; ?>">
                                            <label class="form-check-label" for="user_<?php echo $user['id']; ?>">
                                                <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                                <small class="text-muted">(<?php echo $user['role']; ?>)</small>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="selectAllUsers()">Select All</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="deselectAllUsers()">Deselect All</button>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="is_urgent" name="is_urgent" value="1">
                                    <label class="form-check-label" for="is_urgent">Mark as Urgent</label>
                                </div>
                                <div class="form-text">Urgent notifications are highlighted</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="send_email" name="send_email" value="1">
                                    <label class="form-check-label" for="send_email">Send Email Notification</label>
                                </div>
                                <div class="form-text">Send email copies to users</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Templates -->
                    <div class="mb-3">
                        <label class="form-label">Quick Templates</label>
                        <div class="btn-group w-100">
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="loadTemplate('exam_reminder')">Exam Reminder</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="loadTemplate('maintenance')">Maintenance</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="loadTemplate('welcome')">Welcome</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="loadTemplate('urgent')">Urgent Alert</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="send_notification" class="btn btn-primary">Send Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Notification Modal -->
<div class="modal fade" id="viewNotificationModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Notification Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <h4 id="view_title" class="text-primary"></h4>
                    </div>
                    <div class="col-md-4 text-end">
                        <span id="view_type_badge" class="badge"></span>
                        <span id="view_urgent_badge" class="badge bg-danger" style="display: none;">
                            <i class="fas fa-exclamation-triangle me-1"></i> Urgent
                        </span>
                    </div>
                </div>
                
                <div class="mb-4">
                    <h6>Message:</h6>
                    <div id="view_message" class="border rounded p-3 bg-light"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Target Audience:</strong>
                            <div id="view_audience" class="text-muted"></div>
                        </div>
                        <div class="mb-3">
                            <strong>Created By:</strong>
                            <div id="view_created_by" class="text-muted"></div>
                        </div>
                        <div class="mb-3">
                            <strong>Created At:</strong>
                            <div id="view_created_at" class="text-muted"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Delivery Statistics:</strong>
                            <div class="mt-2">
                                <div class="d-flex justify-content-between">
                                    <span>Total Recipients:</span>
                                    <strong id="view_total_recipients"></strong>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Read:</span>
                                    <strong class="text-success" id="view_read_count"></strong>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Unread:</span>
                                    <strong class="text-warning" id="view_unread_count"></strong>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <strong>Expires At:</strong>
                            <div id="view_expires_at" class="text-muted"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Notification Modal -->
<div class="modal fade" id="editNotificationModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="editNotificationForm">
                <input type="hidden" name="notification_id" id="edit_notification_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_title" class="form-label">Title *</label>
                        <input type="text" class="form-control" id="edit_title" name="title" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_message" class="form-label">Message *</label>
                        <textarea class="form-control" id="edit_message" name="message" rows="5" required></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_expires_at" class="form-label">Expiry Date</label>
                                <input type="datetime-local" class="form-control" id="edit_expires_at" name="expires_at">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                                    <label class="form-check-label" for="edit_is_active">Active</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_notification" class="btn btn-primary">Update Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Notification Modal -->
<div class="modal fade" id="deleteNotificationModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="notification_id" id="delete_notification_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this notification?</h6>
                    <p class="text-center text-muted">Notification: <strong id="delete_notification_title"></strong></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This will also delete all user notification records associated with this notification.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_notification" class="btn btn-danger">Delete Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleSpecificUsers() {
    const targetAudience = document.getElementById('target_audience').value;
    const specificUsersSection = document.getElementById('specificUsersSection');
    
    if (targetAudience === 'specific') {
        specificUsersSection.style.display = 'block';
        // Make specific users required
        document.querySelectorAll('.specific-user').forEach(checkbox => {
            checkbox.required = true;
        });
    } else {
        specificUsersSection.style.display = 'none';
        // Remove required attribute
        document.querySelectorAll('.specific-user').forEach(checkbox => {
            checkbox.required = false;
        });
    }
}

function selectAllUsers() {
    document.querySelectorAll('.specific-user').forEach(checkbox => {
        checkbox.checked = true;
    });
}

function deselectAllUsers() {
    document.querySelectorAll('.specific-user').forEach(checkbox => {
        checkbox.checked = false;
    });
}

function loadTemplate(templateType) {
    const titleInput = document.getElementById('title');
    const messageInput = document.getElementById('message');
    const typeSelect = document.getElementById('notification_type');
    const urgentCheckbox = document.getElementById('is_urgent');
    
    switch(templateType) {
        case 'exam_reminder':
            titleInput.value = 'Upcoming Exam Reminder';
            messageInput.value = 'This is a reminder about your upcoming exam. Please ensure you are prepared and have stable internet connection. Good luck!';
            typeSelect.value = 'exam';
            urgentCheckbox.checked = false;
            break;
            
        case 'maintenance':
            titleInput.value = 'System Maintenance Notice';
            messageInput.value = 'The system will be undergoing scheduled maintenance. During this time, the system may be unavailable. We apologize for any inconvenience.';
            typeSelect.value = 'warning';
            urgentCheckbox.checked = false;
            break;
            
        case 'welcome':
            titleInput.value = 'Welcome to WBES System';
            messageInput.value = 'Welcome to our Web-Based Examination System! We are excited to have you on board. Feel free to explore the features and contact support if you need assistance.';
            typeSelect.value = 'info';
            urgentCheckbox.checked = false;
            break;
            
        case 'urgent':
            titleInput.value = 'URGENT: System Update Required';
            messageInput.value = 'IMPORTANT: Please complete the required system update immediately to ensure continued access to the examination system.';
            typeSelect.value = 'error';
            urgentCheckbox.checked = true;
            break;
    }
}

function viewNotification(button) {
    const notificationId = button.getAttribute('data-notification-id');
    const title = button.getAttribute('data-title');
    const message = button.getAttribute('data-message');
    const notificationType = button.getAttribute('data-notification-type');
    const targetAudience = button.getAttribute('data-target-audience');
    const isUrgent = button.getAttribute('data-is-urgent');
    const expiresAt = button.getAttribute('data-expires-at');
    const totalRecipients = button.getAttribute('data-total-recipients');
    const readCount = button.getAttribute('data-read-count');
    const createdAt = button.getAttribute('data-created-at');
    const createdBy = button.getAttribute('data-created-by');
    
    document.getElementById('view_title').textContent = title;
    document.getElementById('view_message').textContent = message;
    document.getElementById('view_audience').textContent = targetAudience.charAt(0).toUpperCase() + targetAudience.slice(1);
    document.getElementById('view_created_by').textContent = createdBy;
    document.getElementById('view_created_at').textContent = new Date(createdAt).toLocaleString();
    document.getElementById('view_total_recipients').textContent = totalRecipients;
    document.getElementById('view_read_count').textContent = readCount;
    document.getElementById('view_unread_count').textContent = totalRecipients - readCount;
    
    if (expiresAt) {
        document.getElementById('view_expires_at').textContent = new Date(expiresAt).toLocaleString();
    } else {
        document.getElementById('view_expires_at').textContent = 'No expiry';
    }
    
    // Set type badge
    const typeBadge = document.getElementById('view_type_badge');
    typeBadge.textContent = notificationType.charAt(0).toUpperCase() + notificationType.slice(1);
    typeBadge.className = 'badge bg-' + 
        (notificationType === 'info' ? 'info' : 
         notificationType === 'warning' ? 'warning' : 
         notificationType === 'success' ? 'success' : 
         notificationType === 'error' ? 'danger' : 'primary');
    
    // Show/hide urgent badge
    document.getElementById('view_urgent_badge').style.display = isUrgent === '1' ? 'inline-block' : 'none';
}

function editNotification(button) {
    const notificationId = button.getAttribute('data-notification-id');
    const title = button.getAttribute('data-title');
    const message = button.getAttribute('data-message');
    const isActive = button.getAttribute('data-is-active');
    const expiresAt = button.getAttribute('data-expires-at');
    
    document.getElementById('edit_notification_id').value = notificationId;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_message').value = message;
    document.getElementById('edit_is_active').checked = isActive === '1';
    
    if (expiresAt) {
        // Convert to datetime-local format
        const date = new Date(expiresAt);
        const localDateTime = date.toISOString().slice(0, 16);
        document.getElementById('edit_expires_at').value = localDateTime;
    } else {
        document.getElementById('edit_expires_at').value = '';
    }
}

function deleteNotification(button) {
    const notificationId = button.getAttribute('data-notification-id');
    const title = button.getAttribute('data-title');
    
    document.getElementById('delete_notification_id').value = notificationId;
    document.getElementById('delete_notification_title').textContent = title;
}

// Auto-focus search field
document.addEventListener('DOMContentLoaded', function() {
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Form validation
    const sendForm = document.getElementById('sendNotificationForm');
    if (sendForm) {
        sendForm.addEventListener('submit', function(e) {
            const targetAudience = document.getElementById('target_audience').value;
            
            if (targetAudience === 'specific') {
                const specificUsers = document.querySelectorAll('.specific-user:checked');
                if (specificUsers.length === 0) {
                    e.preventDefault();
                    alert('Please select at least one specific user.');
                    return;
                }
            }
        });
    }
    
    // Character counter for message
    const messageInput = document.getElementById('message');
    if (messageInput) {
        messageInput.addEventListener('input', function() {
            const charCount = this.value.length;
            // You can add character count display if needed
        });
    }
});
</script>

<style>
.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
}

.modal-header {
    border-bottom: 2px solid #dee2e6;
}

.modal-footer {
    border-top: 2px solid #dee2e6;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.specific-user {
    margin-right: 0.5rem;
}

#specificUsersSection {
    transition: all 0.3s ease;
}
</style>

<?php require_once '../includes/footer.php'; ?>