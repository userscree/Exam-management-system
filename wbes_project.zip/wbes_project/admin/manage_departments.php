<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Departments';
require_once '../includes/header.php';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_department'])) {
        $department_code = sanitize($_POST['department_code']);
        $department_name = sanitize($_POST['department_name']);
        $description = sanitize($_POST['description'] ?? '');
        
        try {
            // Check if department code exists
            $stmt = $pdo->prepare("SELECT id FROM departments WHERE department_code = ?");
            $stmt->execute([$department_code]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Department code already exists.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO departments (department_code, department_name, description) VALUES (?, ?, ?)");
                $stmt->execute([$department_code, $department_name, $description]);
                
                setFlash('success', 'Department added successfully!');
                redirect('manage_departments.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error adding department: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_department'])) {
        $department_id = $_POST['department_id'];
        $department_code = sanitize($_POST['department_code']);
        $department_name = sanitize($_POST['department_name']);
        $description = sanitize($_POST['description'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        try {
            // Check if department code exists for other departments
            $stmt = $pdo->prepare("SELECT id FROM departments WHERE department_code = ? AND id != ?");
            $stmt->execute([$department_code, $department_id]);
            
            if ($stmt->fetch()) {
                setFlash('error', 'Department code already exists for another department.');
            } else {
                $stmt = $pdo->prepare("UPDATE departments SET department_code = ?, department_name = ?, description = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$department_code, $department_name, $description, $is_active, $department_id]);
                
                setFlash('success', 'Department updated successfully!');
                redirect('manage_departments.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error updating department: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_department'])) {
        $department_id = $_POST['department_id'];
        
        try {
            // Check if department has users
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE department = (SELECT department_code FROM departments WHERE id = ?)");
            $stmt->execute([$department_id]);
            $user_count = $stmt->fetchColumn();
            
            if ($user_count > 0) {
                setFlash('error', 'Cannot delete department. There are users associated with this department.');
            } else {
                $stmt = $pdo->prepare("DELETE FROM departments WHERE id = ?");
                $stmt->execute([$department_id]);
                
                setFlash('success', 'Department deleted successfully!');
                redirect('manage_departments.php');
            }
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting department: ' . $e->getMessage());
        }
    }
}

// Get all departments
try {
    $stmt = $pdo->prepare("SELECT * FROM departments ORDER BY department_code");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get department statistics
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM departments");
    $stmt->execute();
    $total_departments = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as active FROM departments WHERE is_active = 1");
    $stmt->execute();
    $active_departments = $stmt->fetchColumn();
    
    // Get user counts per department
    $stmt = $pdo->prepare("SELECT department, COUNT(*) as user_count FROM users WHERE department IS NOT NULL GROUP BY department");
    $stmt->execute();
    $department_users = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching departments: ' . $e->getMessage());
    $departments = [];
    $total_departments = 0;
    $active_departments = 0;
    $department_users = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Departments</h1>
                <p class="text-muted mb-0">Create and manage academic departments</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                <i class="fas fa-plus-circle me-2"></i> Add Department
            </button>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Departments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_departments; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-building fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Departments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_departments; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Departments with Users
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($department_users); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Departments Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Departments List
            <span class="badge bg-primary ms-2"><?php echo count($departments); ?> departments</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Department Code</th>
                        <th>Department Name</th>
                        <th>Description</th>
                        <th>Users</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($departments)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-building fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No departments found</h5>
                                <p class="text-muted">Add your first department to get started.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($departments as $dept): ?>
                            <tr>
                                <td>
                                    <strong class="text-primary"><?php echo htmlspecialchars($dept['department_code']); ?></strong>
                                </td>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($dept['department_name']); ?></h6>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo !empty($dept['description']) ? htmlspecialchars($dept['description']) : 'No description'; ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo $department_users[$dept['department_code']] ?? 0; ?> users
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $dept['is_active'] ? 'success' : 'secondary'; ?>">
                                        <i class="fas fa-<?php echo $dept['is_active'] ? 'check-circle' : 'times-circle'; ?> me-1"></i>
                                        <?php echo $dept['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($dept['created_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editDepartmentModal" 
                                                data-department-id="<?php echo $dept['id']; ?>"
                                                data-department-code="<?php echo htmlspecialchars($dept['department_code']); ?>"
                                                data-department-name="<?php echo htmlspecialchars($dept['department_name']); ?>"
                                                data-description="<?php echo htmlspecialchars($dept['description'] ?? ''); ?>"
                                                data-is-active="<?php echo $dept['is_active']; ?>"
                                                onclick="editDepartment(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <?php if(!isset($department_users[$dept['department_code']]) || $department_users[$dept['department_code']] == 0): ?>
                                            <button class="btn btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteDepartmentModal"
                                                    data-department-id="<?php echo $dept['id']; ?>"
                                                    data-department-name="<?php echo htmlspecialchars($dept['department_name']); ?>"
                                                    onclick="deleteDepartment(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-secondary" disabled title="Cannot delete department with users">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Department Modal -->
<div class="modal fade" id="addDepartmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="add_department_code" class="form-label">Department Code *</label>
                        <input type="text" class="form-control" id="add_department_code" name="department_code" required maxlength="10">
                        <div class="form-text">Short code for the department (e.g., CS, MATH)</div>
                    </div>
                    <div class="mb-3">
                        <label for="add_department_name" class="form-label">Department Name *</label>
                        <input type="text" class="form-control" id="add_department_name" name="department_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="add_description" class="form-label">Description</label>
                        <textarea class="form-control" id="add_description" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_department" class="btn btn-primary">Add Department</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="editDepartmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="department_id" id="edit_department_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_department_code" class="form-label">Department Code *</label>
                        <input type="text" class="form-control" id="edit_department_code" name="department_code" required maxlength="10">
                    </div>
                    <div class="mb-3">
                        <label for="edit_department_name" class="form-label">Department Name *</label>
                        <input type="text" class="form-control" id="edit_department_name" name="department_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active" value="1">
                            <label class="form-check-label" for="edit_is_active">Active Department</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_department" class="btn btn-primary">Update Department</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Department Modal -->
<div class="modal fade" id="deleteDepartmentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="department_id" id="delete_department_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Department</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this department?</h6>
                    <p class="text-center text-muted">Department: <strong id="delete_department_name"></strong></p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This action cannot be undone. The department will be permanently removed from the system.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_department" class="btn btn-danger">Delete Department</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editDepartment(button) {
    const departmentId = button.getAttribute('data-department-id');
    const departmentCode = button.getAttribute('data-department-code');
    const departmentName = button.getAttribute('data-department-name');
    const description = button.getAttribute('data-description');
    const isActive = button.getAttribute('data-is-active');
    
    document.getElementById('edit_department_id').value = departmentId;
    document.getElementById('edit_department_code').value = departmentCode;
    document.getElementById('edit_department_name').value = departmentName;
    document.getElementById('edit_description').value = description;
    document.getElementById('edit_is_active').checked = isActive === '1';
}

function deleteDepartment(button) {
    const departmentId = button.getAttribute('data-department-id');
    const departmentName = button.getAttribute('data-department-name');
    
    document.getElementById('delete_department_id').value = departmentId;
    document.getElementById('delete_department_name').textContent = departmentName;
}

// Auto-focus first field in add modal
document.addEventListener('DOMContentLoaded', function() {
    const addModal = document.getElementById('addDepartmentModal');
    if (addModal) {
        addModal.addEventListener('shown.bs.modal', function() {
            document.getElementById('add_department_code').focus();
        });
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>