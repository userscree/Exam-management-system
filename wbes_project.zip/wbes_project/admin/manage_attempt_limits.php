<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'Manage Attempt Limits';
require_once '../includes/header.php';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['save_attempt_limits'])) {
        $exam_id = $_POST['exam_id'];
        $user_id = $_POST['user_id'] ?? null;
        $max_attempts = $_POST['max_attempts'];
        $min_retake_interval = $_POST['min_retake_interval'];
        $allow_concurrent = isset($_POST['allow_concurrent']) ? 1 : 0;
        
        try {
            // Check if limit already exists
            $stmt = $pdo->prepare("SELECT id FROM attempt_limits WHERE exam_id = ? AND (user_id = ? OR user_id IS NULL)");
            $stmt->execute([$exam_id, $user_id]);
            $existing_limit = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing_limit) {
                // Update existing limit
                $stmt = $pdo->prepare("
                    UPDATE attempt_limits 
                    SET max_attempts = ?, min_retake_interval = ?, allow_concurrent = ?, updated_at = NOW() 
                    WHERE id = ?
                ");
                $stmt->execute([$max_attempts, $min_retake_interval, $allow_concurrent, $existing_limit['id']]);
            } else {
                // Insert new limit
                $stmt = $pdo->prepare("
                    INSERT INTO attempt_limits (exam_id, user_id, max_attempts, min_retake_interval, allow_concurrent) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$exam_id, $user_id, $max_attempts, $min_retake_interval, $allow_concurrent]);
            }
            
            setFlash('success', 'Attempt limits saved successfully!');
            redirect('manage_attempt_limits.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error saving attempt limits: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['delete_limit'])) {
        $limit_id = $_POST['limit_id'];
        
        try {
            $stmt = $pdo->prepare("DELETE FROM attempt_limits WHERE id = ?");
            $stmt->execute([$limit_id]);
            
            setFlash('success', 'Attempt limit deleted successfully!');
            redirect('manage_attempt_limits.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error deleting attempt limit: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['update_exam_defaults'])) {
        $exam_id = $_POST['exam_id'];
        $max_attempts = $_POST['max_attempts'];
        $min_retake_interval = $_POST['min_retake_interval'];
        $allow_concurrent = isset($_POST['allow_concurrent']) ? 1 : 0;
        
        try {
            $stmt = $pdo->prepare("
                UPDATE exams 
                SET max_attempts = ?, min_retake_interval = ?, allow_concurrent = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$max_attempts, $min_retake_interval, $allow_concurrent, $exam_id]);
            
            setFlash('success', 'Exam default limits updated successfully!');
            redirect('manage_attempt_limits.php?exam_id=' . $exam_id);
            
        } catch(PDOException $e) {
            setFlash('error', 'Error updating exam defaults: ' . $e->getMessage());
        }
    }
    
    // NEW: Handle reset student attempts
    if (isset($_POST['reset_student_attempts'])) {
        $student_id = $_POST['student_id'];
        $exam_id = $_POST['exam_id'];
        
        try {
            // Delete all attempts for this student and exam
            $stmt = $pdo->prepare("
                DELETE FROM exam_attempts 
                WHERE student_id = ? AND exam_id = ?
            ");
            $stmt->execute([$student_id, $exam_id]);
            
            // Also delete associated student answers
            $stmt = $pdo->prepare("
                DELETE sa FROM student_answers sa
                JOIN exam_attempts ea ON sa.attempt_id = ea.id
                WHERE ea.student_id = ? AND ea.exam_id = ?
            ");
            $stmt->execute([$student_id, $exam_id]);
            
            // Delete results
            $stmt = $pdo->prepare("
                DELETE r FROM results r
                JOIN exam_attempts ea ON r.attempt_id = ea.id
                WHERE ea.student_id = ? AND ea.exam_id = ?
            ");
            $stmt->execute([$student_id, $exam_id]);
            
            setFlash('success', 'Student attempts reset successfully!');
            redirect('manage_attempt_limits.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error resetting student attempts: ' . $e->getMessage());
        }
    }
    
    // NEW: Handle reset all attempts for exam
    if (isset($_POST['reset_all_exam_attempts'])) {
        $exam_id = $_POST['exam_id'];
        
        try {
            // Delete all attempts for this exam
            $stmt = $pdo->prepare("DELETE FROM exam_attempts WHERE exam_id = ?");
            $stmt->execute([$exam_id]);
            
            // Also delete associated student answers
            $stmt = $pdo->prepare("
                DELETE sa FROM student_answers sa
                JOIN exam_attempts ea ON sa.attempt_id = ea.id
                WHERE ea.exam_id = ?
            ");
            $stmt->execute([$exam_id]);
            
            // Delete results
            $stmt = $pdo->prepare("
                DELETE r FROM results r
                JOIN exam_attempts ea ON r.attempt_id = ea.id
                WHERE ea.exam_id = ?
            ");
            $stmt->execute([$exam_id]);
            
            setFlash('success', 'All exam attempts reset successfully!');
            redirect('manage_attempt_limits.php');
            
        } catch(PDOException $e) {
            setFlash('error', 'Error resetting exam attempts: ' . $e->getMessage());
        }
    }
}

// Get filter parameters
$exam_filter = $_GET['exam_id'] ?? '';
$user_filter = $_GET['user_id'] ?? '';
$search = $_GET['search'] ?? '';

// Get all exams for dropdown
try {
    $stmt = $pdo->prepare("
        SELECT e.id, e.title, c.course_code, c.course_name,
               e.max_attempts as exam_max_attempts, 
               e.min_retake_interval as exam_retake_interval,
               e.allow_concurrent as exam_allow_concurrent,
               (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id) as total_attempts
        FROM exams e 
        LEFT JOIN courses c ON e.course_id = c.id 
        ORDER BY c.course_code, e.title
    ");
    $stmt->execute();
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching exams: ' . $e->getMessage());
    $exams = [];
}

// Get all students for dropdown
try {
    $stmt = $pdo->prepare("
        SELECT id, first_name, last_name, username, university_id 
        FROM users 
        WHERE role = 'student' AND is_active = 1 
        ORDER BY first_name, last_name
    ");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching students: ' . $e->getMessage());
    $students = [];
}

// Build query for attempt limits
$query = "
    SELECT al.*, 
           e.title as exam_title, c.course_code, c.course_name,
           u.first_name, u.last_name, u.username, u.university_id,
           (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = al.exam_id AND student_id = al.user_id) as total_attempts,
           (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = al.exam_id AND student_id = al.user_id AND status IN ('submitted', 'graded')) as completed_attempts
    FROM attempt_limits al
    LEFT JOIN exams e ON al.exam_id = e.id
    LEFT JOIN courses c ON e.course_id = c.id
    LEFT JOIN users u ON al.user_id = u.id
    WHERE 1=1
";
$params = [];

if (!empty($exam_filter)) {
    $query .= " AND al.exam_id = ?";
    $params[] = $exam_filter;
}

if (!empty($user_filter)) {
    $query .= " AND al.user_id = ?";
    $params[] = $user_filter;
}

if (!empty($search)) {
    $query .= " AND (e.title LIKE ? OR c.course_name LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.username LIKE ? OR u.university_id LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY al.created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $attempt_limits = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get statistics
    $total_limits = count($attempt_limits);
    $global_limits = 0;
    $user_specific_limits = 0;
    
    foreach($attempt_limits as $limit) {
        if ($limit['user_id'] === null) {
            $global_limits++;
        } else {
            $user_specific_limits++;
        }
    }
    
} catch(PDOException $e) {
    setFlash('error', 'Error fetching attempt limits: ' . $e->getMessage());
    $attempt_limits = [];
    $total_limits = $global_limits = $user_specific_limits = 0;
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">Manage Attempt Limits</h1>
                <p class="text-muted mb-0">Configure exam attempt limits and restrictions</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAttemptLimitModal">
                    <i class="fas fa-plus-circle me-2"></i> Add Attempt Limit
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addAttemptLimitModal">
                        <i class="fas fa-plus-circle me-2"></i>Add Attempt Limit
                    </a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#resetStudentAttemptsModal">
                        <i class="fas fa-redo me-2"></i>Reset Student Attempts
                    </a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#resetExamAttemptsModal">
                        <i class="fas fa-trash-alt me-2"></i>Reset All Exam Attempts
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Limits
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_limits; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-sliders-h fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Global Limits
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $global_limits; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-globe fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            User-Specific Limits
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $user_specific_limits; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-cog fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Active Exams
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($exams); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="exam_id" class="form-label">Filter by Exam</label>
                <select class="form-select" id="exam_id" name="exam_id">
                    <option value="">All Exams</option>
                    <?php foreach($exams as $exam): ?>
                        <option value="<?php echo $exam['id']; ?>" <?php echo $exam_filter == $exam['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="user_id" class="form-label">Filter by Student</label>
                <select class="form-select" id="user_id" name="user_id">
                    <option value="">All Students</option>
                    <?php foreach($students as $student): ?>
                        <option value="<?php echo $student['id']; ?>" <?php echo $user_filter == $student['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['username'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search exams, students..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                    <a href="manage_attempt_limits.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Attempt Limits Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-list me-2"></i> Attempt Limits
            <span class="badge bg-primary ms-2"><?php echo $total_limits; ?> limits</span>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if(empty($attempt_limits)): ?>
            <div class="text-center py-5">
                <i class="fas fa-sliders-h fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No Attempt Limits Found</h5>
                <p class="text-muted">No attempt limits have been configured yet.</p>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAttemptLimitModal">
                    <i class="fas fa-plus-circle me-2"></i> Add Your First Limit
                </button>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Scope</th>
                            <th>Exam & Course</th>
                            <th>Student</th>
                            <th>Attempt Limits</th>
                            <th>Retake Interval</th>
                            <th>Concurrent</th>
                            <th>Usage</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($attempt_limits as $limit): ?>
                            <tr>
                                <td>
                                    <?php if($limit['user_id'] === null): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-globe me-1"></i> Global
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-info">
                                            <i class="fas fa-user me-1"></i> User-Specific
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($limit['exam_title']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($limit['course_code'] . ' - ' . $limit['course_name']); ?></small>
                                </td>
                                <td>
                                    <?php if($limit['user_id']): ?>
                                        <div class="fw-bold"><?php echo htmlspecialchars($limit['first_name'] . ' ' . $limit['last_name']); ?></div>
                                        <small class="text-muted">@<?php echo htmlspecialchars($limit['username']); ?></small>
                                        <?php if($limit['university_id']): ?>
                                            <div class="mt-1">
                                                <small class="text-muted">ID:</small>
                                                <span class="badge bg-light text-dark"><?php echo htmlspecialchars($limit['university_id']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">All Students</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <span class="fw-bold text-primary"><?php echo $limit['max_attempts']; ?></span>
                                        <small class="text-muted ms-1">max attempts</small>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark">
                                        <i class="fas fa-clock me-1 text-warning"></i>
                                        <?php echo $limit['min_retake_interval']; ?> min
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $limit['allow_concurrent'] ? 'success' : 'secondary'; ?>">
                                        <i class="fas fa-<?php echo $limit['allow_concurrent'] ? 'check' : 'times'; ?> me-1"></i>
                                        <?php echo $limit['allow_concurrent'] ? 'Allowed' : 'Not Allowed'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="small">
                                        <div>
                                            <strong>Total:</strong> <?php echo $limit['total_attempts']; ?>
                                        </div>
                                        <div>
                                            <strong>Completed:</strong> <?php echo $limit['completed_attempts']; ?>
                                        </div>
                                        <div class="progress mt-1" style="height: 4px; width: 80px;">
                                            <?php 
                                            $usage_percentage = $limit['max_attempts'] > 0 ? 
                                                min(100, ($limit['completed_attempts'] / $limit['max_attempts']) * 100) : 0;
                                            ?>
                                            <div class="progress-bar bg-<?php echo $usage_percentage >= 80 ? 'danger' : ($usage_percentage >= 50 ? 'warning' : 'success'); ?>" 
                                                 style="width: <?php echo $usage_percentage; ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo formatDate($limit['created_at']); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editAttemptLimitModal"
                                                data-limit-id="<?php echo $limit['id']; ?>"
                                                data-exam-id="<?php echo $limit['exam_id']; ?>"
                                                data-user-id="<?php echo $limit['user_id']; ?>"
                                                data-max-attempts="<?php echo $limit['max_attempts']; ?>"
                                                data-min-retake-interval="<?php echo $limit['min_retake_interval']; ?>"
                                                data-allow-concurrent="<?php echo $limit['allow_concurrent']; ?>"
                                                onclick="editAttemptLimit(this)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-outline-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteLimitModal"
                                                data-limit-id="<?php echo $limit['id']; ?>"
                                                data-exam-title="<?php echo htmlspecialchars($limit['exam_title']); ?>"
                                                data-user-name="<?php echo $limit['user_id'] ? htmlspecialchars($limit['first_name'] . ' ' . $limit['last_name']) : 'All Students'; ?>"
                                                onclick="deleteAttemptLimit(this)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Attempt Limit Modal -->
<div class="modal fade" id="addAttemptLimitModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="addAttemptLimitForm">
                <div class="modal-header">
                    <h5 class="modal-title">Add Attempt Limit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_exam_id" class="form-label">Exam *</label>
                                <select class="form-select" id="add_exam_id" name="exam_id" required>
                                    <option value="">Select Exam</option>
                                    <?php foreach($exams as $exam): ?>
                                        <option value="<?php echo $exam['id']; ?>" 
                                                data-max-attempts="<?php echo $exam['exam_max_attempts']; ?>"
                                                data-retake-interval="<?php echo $exam['exam_retake_interval']; ?>"
                                                data-allow-concurrent="<?php echo $exam['exam_allow_concurrent']; ?>">
                                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="add_user_id" class="form-label">Student (Optional)</label>
                                <select class="form-select" id="add_user_id" name="user_id">
                                    <option value="">All Students (Global Limit)</option>
                                    <?php foreach($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>">
                                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['username'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">Leave empty to apply to all students</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="add_max_attempts" class="form-label">Max Attempts *</label>
                                <input type="number" class="form-control" id="add_max_attempts" name="max_attempts" 
                                       min="1" max="10" value="3" required>
                                <div class="form-text">Maximum number of attempts allowed</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="add_min_retake_interval" class="form-label">Retake Interval (minutes) *</label>
                                <input type="number" class="form-control" id="add_min_retake_interval" name="min_retake_interval" 
                                       min="0" max="1440" value="30" required>
                                <div class="form-text">Minimum minutes between attempts</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Concurrent Attempts</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" id="add_allow_concurrent" name="allow_concurrent" value="1">
                                    <label class="form-check-label" for="add_allow_concurrent">Allow Multiple Concurrent Attempts</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Note:</strong> User-specific limits override global limits for the same exam.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="save_attempt_limits" class="btn btn-primary">Save Limit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Attempt Limit Modal -->
<div class="modal fade" id="editAttemptLimitModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="editAttemptLimitForm">
                <input type="hidden" name="limit_id" id="edit_limit_id">
                <input type="hidden" name="exam_id" id="edit_exam_id">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="modal-header">
                    <h5 class="modal-title">Edit Attempt Limit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_max_attempts" class="form-label">Max Attempts *</label>
                                <input type="number" class="form-control" id="edit_max_attempts" name="max_attempts" 
                                       min="1" max="10" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_min_retake_interval" class="form-label">Retake Interval (minutes) *</label>
                                <input type="number" class="form-control" id="edit_min_retake_interval" name="min_retake_interval" 
                                       min="0" max="1440" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Concurrent Attempts</label>
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" id="edit_allow_concurrent" name="allow_concurrent" value="1">
                                    <label class="form-check-label" for="edit_allow_concurrent">Allow Multiple Concurrent Attempts</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Changing these limits will affect future exam attempts.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="save_attempt_limits" class="btn btn-primary">Update Limit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Limit Modal -->
<div class="modal fade" id="deleteLimitModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="limit_id" id="delete_limit_id">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Delete Attempt Limit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center text-danger mb-3">
                        <i class="fas fa-exclamation-triangle fa-3x"></i>
                    </div>
                    <h6 class="text-center">Are you sure you want to delete this attempt limit?</h6>
                    <p class="text-center text-muted">
                        Exam: <strong id="delete_exam_title"></strong><br>
                        Student: <strong id="delete_user_name"></strong>
                    </p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        This will revert to the exam's default attempt limits.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_limit" class="btn btn-danger">Delete Limit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- NEW: Reset Student Attempts Modal -->
<div class="modal fade" id="resetStudentAttemptsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" id="resetStudentAttemptsForm">
                <div class="modal-header">
                    <h5 class="modal-title">Reset Student Attempts</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="reset_exam_id" class="form-label">Exam *</label>
                                <select class="form-select" id="reset_exam_id" name="exam_id" required>
                                    <option value="">Select Exam</option>
                                    <?php foreach($exams as $exam): ?>
                                        <option value="<?php echo $exam['id']; ?>" data-attempts="<?php echo $exam['total_attempts']; ?>">
                                            <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                                            (<?php echo $exam['total_attempts']; ?> attempts)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="reset_student_search" class="form-label">Search Student</label>
                                <input type="text" class="form-control" id="reset_student_search" placeholder="Search by name, username, or ID...">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="reset_student_id" class="form-label">Select Student *</label>
                        <select class="form-select" id="reset_student_id" name="student_id" required size="8">
                            <option value="">Select a student...</option>
                            <?php foreach($students as $student): ?>
                                <option value="<?php echo $student['id']; ?>" 
                                        data-name="<?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>"
                                        data-username="<?php echo htmlspecialchars($student['username']); ?>"
                                        data-university-id="<?php echo htmlspecialchars($student['university_id']); ?>">
                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> 
                                    (<?php echo htmlspecialchars($student['username']); ?>)
                                    <?php if($student['university_id']): ?>
                                        - <?php echo htmlspecialchars($student['university_id']); ?>
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Use the search box above to filter students</div>
                    </div>
                    
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Warning:</strong> This will permanently delete all exam attempts, answers, and results for the selected student and exam. This action cannot be undone.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="reset_student_attempts" class="btn btn-danger">Reset Student Attempts</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- NEW: Reset All Exam Attempts Modal -->
<div class="modal fade" id="resetExamAttemptsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="resetExamAttemptsForm">
                <div class="modal-header">
                    <h5 class="modal-title">Reset All Exam Attempts</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="reset_all_exam_id" class="form-label">Select Exam *</label>
                        <select class="form-select" id="reset_all_exam_id" name="exam_id" required>
                            <option value="">Select Exam</option>
                            <?php foreach($exams as $exam): ?>
                                <option value="<?php echo $exam['id']; ?>" data-attempts="<?php echo $exam['total_attempts']; ?>">
                                    <?php echo htmlspecialchars($exam['course_code'] . ' - ' . $exam['title']); ?>
                                    (<?php echo $exam['total_attempts']; ?> attempts)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Warning:</strong> This will permanently delete ALL attempts, answers, and results for the selected exam for ALL students. This action cannot be undone.
                    </div>
                    
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="confirm_reset_all" required>
                        <label class="form-check-label" for="confirm_reset_all">
                            I understand this will delete all exam data and cannot be undone
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="reset_all_exam_attempts" class="btn btn-danger" id="resetAllExamBtn" disabled>
                        Reset All Exam Attempts
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Exam Defaults Management -->
<?php if(!empty($exams)): ?>
<div class="card mt-4">
    <div class="card-header bg-light">
        <h5 class="card-title mb-0">
            <i class="fas fa-cog me-2 text-primary"></i>
            Exam Default Attempt Limits
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Exam</th>
                        <th>Max Attempts</th>
                        <th>Retake Interval</th>
                        <th>Concurrent</th>
                        <th>Total Attempts</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($exams as $exam): ?>
                        <tr>
                            <td>
                                <div class="fw-bold"><?php echo htmlspecialchars($exam['title']); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($exam['course_code']); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-primary"><?php echo $exam['exam_max_attempts'] ?? 1; ?></span>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark"><?php echo $exam['exam_retake_interval'] ?? 30; ?> min</span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $exam['exam_allow_concurrent'] ? 'success' : 'secondary'; ?>">
                                    <?php echo $exam['exam_allow_concurrent'] ? 'Yes' : 'No'; ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $exam['total_attempts'] > 0 ? 'info' : 'secondary'; ?>">
                                    <?php echo $exam['total_attempts']; ?> attempts
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-outline-primary btn-sm" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#editExamDefaultsModal"
                                        data-exam-id="<?php echo $exam['id']; ?>"
                                        data-exam-title="<?php echo htmlspecialchars($exam['title']); ?>"
                                        data-max-attempts="<?php echo $exam['exam_max_attempts'] ?? 1; ?>"
                                        data-min-retake-interval="<?php echo $exam['exam_retake_interval'] ?? 30; ?>"
                                        data-allow-concurrent="<?php echo $exam['exam_allow_concurrent'] ?? 0; ?>"
                                        onclick="editExamDefaults(this)">
                                    <i class="fas fa-edit"></i> Edit Defaults
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Edit Exam Defaults Modal -->
<div class="modal fade" id="editExamDefaultsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="editExamDefaultsForm">
                <input type="hidden" name="exam_id" id="edit_exam_defaults_id">
                
                <div class="modal-header">
                    <h5 class="modal-title">Edit Exam Default Limits</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">Default limits for: <strong id="edit_exam_defaults_title"></strong></p>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_exam_max_attempts" class="form-label">Max Attempts</label>
                                <input type="number" class="form-control" id="edit_exam_max_attempts" name="max_attempts" 
                                       min="1" max="10" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_exam_min_retake_interval" class="form-label">Retake Interval (min)</label>
                                <input type="number" class="form-control" id="edit_exam_min_retake_interval" name="min_retake_interval" 
                                       min="0" max="1440" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="edit_exam_allow_concurrent" name="allow_concurrent" value="1">
                            <label class="form-check-label" for="edit_exam_allow_concurrent">Allow Concurrent Attempts</label>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        These are the default limits that apply when no specific limit is set.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_exam_defaults" class="btn btn-primary">Save Defaults</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Auto-fill form with exam defaults when exam is selected
document.getElementById('add_exam_id').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    if (selectedOption.value) {
        const maxAttempts = selectedOption.getAttribute('data-max-attempts') || 1;
        const retakeInterval = selectedOption.getAttribute('data-retake-interval') || 30;
        const allowConcurrent = selectedOption.getAttribute('data-allow-concurrent') || 0;
        
        document.getElementById('add_max_attempts').value = maxAttempts;
        document.getElementById('add_min_retake_interval').value = retakeInterval;
        document.getElementById('add_allow_concurrent').checked = allowConcurrent == 1;
    }
});

function editAttemptLimit(button) {
    const limitId = button.getAttribute('data-limit-id');
    const examId = button.getAttribute('data-exam-id');
    const userId = button.getAttribute('data-user-id');
    const maxAttempts = button.getAttribute('data-max-attempts');
    const minRetakeInterval = button.getAttribute('data-min-retake-interval');
    const allowConcurrent = button.getAttribute('data-allow-concurrent');
    
    document.getElementById('edit_limit_id').value = limitId;
    document.getElementById('edit_exam_id').value = examId;
    document.getElementById('edit_user_id').value = userId;
    document.getElementById('edit_max_attempts').value = maxAttempts;
    document.getElementById('edit_min_retake_interval').value = minRetakeInterval;
    document.getElementById('edit_allow_concurrent').checked = allowConcurrent == 1;
}

function deleteAttemptLimit(button) {
    const limitId = button.getAttribute('data-limit-id');
    const examTitle = button.getAttribute('data-exam-title');
    const userName = button.getAttribute('data-user-name');
    
    document.getElementById('delete_limit_id').value = limitId;
    document.getElementById('delete_exam_title').textContent = examTitle;
    document.getElementById('delete_user_name').textContent = userName;
}

function editExamDefaults(button) {
    const examId = button.getAttribute('data-exam-id');
    const examTitle = button.getAttribute('data-exam-title');
    const maxAttempts = button.getAttribute('data-max-attempts');
    const minRetakeInterval = button.getAttribute('data-min-retake-interval');
    const allowConcurrent = button.getAttribute('data-allow-concurrent');
    
    document.getElementById('edit_exam_defaults_id').value = examId;
    document.getElementById('edit_exam_defaults_title').textContent = examTitle;
    document.getElementById('edit_exam_max_attempts').value = maxAttempts;
    document.getElementById('edit_exam_min_retake_interval').value = minRetakeInterval;
    document.getElementById('edit_exam_allow_concurrent').checked = allowConcurrent == 1;
}

// NEW: Student search functionality
document.getElementById('reset_student_search').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const studentSelect = document.getElementById('reset_student_id');
    const options = studentSelect.getElementsByTagName('option');
    
    for (let i = 0; i < options.length; i++) {
        const option = options[i];
        const text = option.textContent.toLowerCase();
        const name = option.getAttribute('data-name')?.toLowerCase() || '';
        const username = option.getAttribute('data-username')?.toLowerCase() || '';
        const universityId = option.getAttribute('data-university-id')?.toLowerCase() || '';
        
        if (text.includes(searchTerm) || name.includes(searchTerm) || username.includes(searchTerm) || universityId.includes(searchTerm)) {
            option.style.display = '';
        } else {
            option.style.display = 'none';
        }
    }
});

// NEW: Enable/disable reset all button based on confirmation
document.getElementById('confirm_reset_all').addEventListener('change', function() {
    document.getElementById('resetAllExamBtn').disabled = !this.checked;
});

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });
    
    // Auto-focus search field
    const searchField = document.getElementById('search');
    if (searchField) {
        searchField.focus();
    }
    
    // Initialize student search
    const studentSearch = document.getElementById('reset_student_search');
    if (studentSearch) {
        studentSearch.focus();
    }
});

// Quick actions for common configurations
function applyQuickSettings(preset) {
    const maxAttempts = document.getElementById('add_max_attempts');
    const retakeInterval = document.getElementById('add_min_retake_interval');
    const allowConcurrent = document.getElementById('add_allow_concurrent');
    
    switch(preset) {
        case 'strict':
            maxAttempts.value = 1;
            retakeInterval.value = 60;
            allowConcurrent.checked = false;
            break;
        case 'moderate':
            maxAttempts.value = 3;
            retakeInterval.value = 30;
            allowConcurrent.checked = false;
            break;
        case 'flexible':
            maxAttempts.value = 5;
            retakeInterval.value = 15;
            allowConcurrent.checked = true;
            break;
    }
}
</script>

<style>
.badge {
    font-size: 0.75em;
}

.table th {
    border-top: none;
    font-weight: 600;
}

.progress {
    background-color: #e9ecef;
}

.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
}

.modal-header {
    border-bottom: 2px solid #dee2e6;
}

.modal-footer {
    border-top: 2px solid #dee2e6;
}

.form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}

.quick-settings {
    margin-bottom: 1rem;
}

.quick-settings .btn {
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
}

/* Student search styling */
#reset_student_id {
    max-height: 200px;
    overflow-y: auto;
}

#reset_student_id option {
    padding: 8px 12px;
    border-bottom: 1px solid #eee;
}

#reset_student_id option:hover {
    background-color: #f8f9fa;
}

#reset_student_id option:last-child {
    border-bottom: none;
}
</style>

<?php require_once '../includes/footer.php'; ?>