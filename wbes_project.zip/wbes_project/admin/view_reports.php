<?php
require_once '../includes/auth_check.php';
if (!hasRole('admin')) {
    setFlash('error', 'You do not have permission to access this page.');
    redirect('../index.php');
}

$page_title = 'View Reports';
require_once '../includes/header.php';

// Default date range (last 30 days)
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$report_type = $_GET['report_type'] ?? 'overview';
$course_filter = $_GET['course'] ?? '';
$instructor_filter = $_GET['instructor'] ?? '';

try {
    // Get courses for filter
    $stmt = $pdo->prepare("SELECT id, course_code, course_name FROM courses WHERE is_active = 1 ORDER BY course_code");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get instructors for filter
    $stmt = $pdo->prepare("SELECT id, first_name, last_name FROM users WHERE role = 'instructor' AND is_active = 1 ORDER BY first_name");
    $stmt->execute();
    $instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Overview Statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT e.id) as total_exams,
            COUNT(DISTINCT ea.id) as total_attempts,
            COUNT(DISTINCT u.id) as total_students,
            AVG(r.percentage) as avg_score,
            COUNT(DISTINCT CASE WHEN r.status = 'pass' THEN r.id END) as passed_exams,
            COUNT(DISTINCT CASE WHEN r.status = 'fail' THEN r.id END) as failed_exams
        FROM exams e
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id
        LEFT JOIN users u ON ea.student_id = u.id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE e.created_at BETWEEN ? AND ?
    ");
    $stmt->execute([$start_date . ' 00:00:00', $end_date . ' 23:59:59']);
    $overview_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Exam Performance Report
    $exam_performance_query = "
        SELECT 
            e.id,
            e.title,
            c.course_code,
            c.course_name,
            u.first_name as instructor_first_name,
            u.last_name as instructor_last_name,
            COUNT(ea.id) as total_attempts,
            AVG(r.percentage) as avg_score,
            COUNT(CASE WHEN r.status = 'pass' THEN 1 END) as passed_count,
            COUNT(CASE WHEN r.status = 'fail' THEN 1 END) as failed_count,
            MIN(r.percentage) as min_score,
            MAX(r.percentage) as max_score
        FROM exams e
        LEFT JOIN courses c ON e.course_id = c.id
        LEFT JOIN users u ON e.instructor_id = u.id
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE e.created_at BETWEEN ? AND ?
    ";
    
    $exam_performance_params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
    
    if (!empty($course_filter)) {
        $exam_performance_query .= " AND e.course_id = ?";
        $exam_performance_params[] = $course_filter;
    }
    
    if (!empty($instructor_filter)) {
        $exam_performance_query .= " AND e.instructor_id = ?";
        $exam_performance_params[] = $instructor_filter;
    }
    
    $exam_performance_query .= " GROUP BY e.id ORDER BY avg_score DESC";
    
    $stmt = $pdo->prepare($exam_performance_query);
    $stmt->execute($exam_performance_params);
    $exam_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Student Performance Report
    $student_performance_query = "
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.username,
            u.university_id,
            u.department,
            COUNT(DISTINCT ea.exam_id) as exams_taken,
            AVG(r.percentage) as avg_score,
            COUNT(CASE WHEN r.status = 'pass' THEN 1 END) as passed_exams,
            COUNT(CASE WHEN r.status = 'fail' THEN 1 END) as failed_exams,
            MIN(r.percentage) as min_score,
            MAX(r.percentage) as max_score
        FROM users u
        LEFT JOIN exam_attempts ea ON u.id = ea.student_id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE u.role = 'student' AND u.is_active = 1
        AND ea.started_at BETWEEN ? AND ?
    ";
    
    $student_performance_params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
    
    $student_performance_query .= " GROUP BY u.id HAVING exams_taken > 0 ORDER BY avg_score DESC";
    
    $stmt = $pdo->prepare($student_performance_query);
    $stmt->execute($student_performance_params);
    $student_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Course-wise Performance
    $course_performance_query = "
        SELECT 
            c.id,
            c.course_code,
            c.course_name,
            COUNT(DISTINCT e.id) as total_exams,
            COUNT(DISTINCT ea.id) as total_attempts,
            AVG(r.percentage) as avg_score,
            COUNT(DISTINCT CASE WHEN r.status = 'pass' THEN r.id END) as passed_attempts,
            COUNT(DISTINCT CASE WHEN r.status = 'fail' THEN r.id END) as failed_attempts
        FROM courses c
        LEFT JOIN exams e ON c.id = e.course_id
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE e.created_at BETWEEN ? AND ?
    ";
    
    $course_performance_params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
    
    if (!empty($course_filter)) {
        $course_performance_query .= " AND c.id = ?";
        $course_performance_params[] = $course_filter;
    }
    
    $course_performance_query .= " GROUP BY c.id ORDER BY avg_score DESC";
    
    $stmt = $pdo->prepare($course_performance_query);
    $stmt->execute($course_performance_params);
    $course_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Activity Trends (Last 30 days)
    $activity_trends_query = "
        SELECT 
            DATE(ea.started_at) as activity_date,
            COUNT(DISTINCT ea.id) as daily_attempts,
            COUNT(DISTINCT ea.student_id) as daily_students,
            AVG(r.percentage) as daily_avg_score
        FROM exam_attempts ea
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE ea.started_at BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()
        GROUP BY DATE(ea.started_at)
        ORDER BY activity_date DESC
        LIMIT 30
    ";
    
    $stmt = $pdo->prepare($activity_trends_query);
    $stmt->execute();
    $activity_trends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Instructor Performance
    $instructor_performance_query = "
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.username,
            COUNT(DISTINCT e.id) as exams_created,
            COUNT(DISTINCT ea.id) as total_attempts,
            AVG(r.percentage) as avg_score,
            COUNT(DISTINCT CASE WHEN r.status = 'pass' THEN r.id END) as passed_attempts
        FROM users u
        LEFT JOIN exams e ON u.id = e.instructor_id
        LEFT JOIN exam_attempts ea ON e.id = ea.exam_id
        LEFT JOIN results r ON ea.id = r.attempt_id
        WHERE u.role = 'instructor' AND u.is_active = 1
        AND e.created_at BETWEEN ? AND ?
    ";
    
    $instructor_performance_params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
    
    if (!empty($instructor_filter)) {
        $instructor_performance_query .= " AND u.id = ?";
        $instructor_performance_params[] = $instructor_filter;
    }
    
    $instructor_performance_query .= " GROUP BY u.id ORDER BY avg_score DESC";
    
    $stmt = $pdo->prepare($instructor_performance_query);
    $stmt->execute($instructor_performance_params);
    $instructor_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Question Analysis
    $question_analysis_query = "
        SELECT 
            e.title as exam_title,
            c.course_code,
            q.question_type,
            COUNT(q.id) as question_count,
            AVG(q.marks) as avg_marks,
            SUM(q.marks) as total_marks,
            COUNT(CASE WHEN sa.student_answer = q.correct_answer THEN 1 END) as correct_answers,
            COUNT(sa.id) as total_answers
        FROM questions q
        LEFT JOIN exams e ON q.exam_id = e.id
        LEFT JOIN courses c ON e.course_id = c.id
        LEFT JOIN student_answers sa ON q.id = sa.question_id
        WHERE e.created_at BETWEEN ? AND ?
    ";
    
    $question_analysis_params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
    
    if (!empty($course_filter)) {
        $question_analysis_query .= " AND e.course_id = ?";
        $question_analysis_params[] = $course_filter;
    }
    
    $question_analysis_query .= " GROUP BY e.id, q.question_type ORDER BY e.title, q.question_type";
    
    $stmt = $pdo->prepare($question_analysis_query);
    $stmt->execute($question_analysis_params);
    $question_analysis = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    setFlash('error', 'Error generating reports: ' . $e->getMessage());
    $overview_stats = [];
    $exam_performance = [];
    $student_performance = [];
    $course_performance = [];
    $activity_trends = [];
    $instructor_performance = [];
    $question_analysis = [];
}
?>

<div class="row mb-4">
    <div class="col">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-1">System Reports & Analytics</h1>
                <p class="text-muted mb-0">Comprehensive analysis of exam performance and system usage</p>
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" onclick="exportReport()">
                    <i class="fas fa-download me-2"></i> Export Report
                </button>
                <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">
                    <span class="visually-hidden">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" onclick="exportReport('pdf')"><i class="fas fa-file-pdf me-2"></i>Export as PDF</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportReport('excel')"><i class="fas fa-file-excel me-2"></i>Export as Excel</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportReport('csv')"><i class="fas fa-file-csv me-2"></i>Export as CSV</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Report Filters -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-filter me-2 text-primary"></i> Report Filters
        </h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="report_type" class="form-label">Report Type</label>
                <select class="form-select" id="report_type" name="report_type">
                    <option value="overview" <?php echo $report_type == 'overview' ? 'selected' : ''; ?>>Overview</option>
                    <option value="exam_performance" <?php echo $report_type == 'exam_performance' ? 'selected' : ''; ?>>Exam Performance</option>
                    <option value="student_performance" <?php echo $report_type == 'student_performance' ? 'selected' : ''; ?>>Student Performance</option>
                    <option value="course_performance" <?php echo $report_type == 'course_performance' ? 'selected' : ''; ?>>Course Performance</option>
                    <option value="instructor_performance" <?php echo $report_type == 'instructor_performance' ? 'selected' : ''; ?>>Instructor Performance</option>
                    <option value="question_analysis" <?php echo $report_type == 'question_analysis' ? 'selected' : ''; ?>>Question Analysis</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
            </div>
            <div class="col-md-2">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
            </div>
            <div class="col-md-2">
                <label for="course" class="form-label">Course</label>
                <select class="form-select" id="course" name="course">
                    <option value="">All Courses</option>
                    <?php foreach($courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['course_code']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="instructor" class="form-label">Instructor</label>
                <select class="form-select" id="instructor" name="instructor">
                    <option value="">All Instructors</option>
                    <?php foreach($instructors as $instructor): ?>
                        <option value="<?php echo $instructor['id']; ?>" <?php echo $instructor_filter == $instructor['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <div class="btn-group w-100">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-chart-bar me-2"></i> Generate
                    </button>
                    <a href="view_reports.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Overview Statistics -->
<?php if($report_type == 'overview'): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-chart-line me-2 text-primary"></i> Overview Statistics
                    <small class="text-muted ms-2"><?php echo formatDate($start_date); ?> to <?php echo formatDate($end_date); ?></small>
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Exams
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overview_stats['total_exams'] ?? 0; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Exam Attempts
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overview_stats['total_attempts'] ?? 0; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Active Students
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overview_stats['total_students'] ?? 0; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Average Score
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo round($overview_stats['avg_score'] ?? 0, 1); ?>%</div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Passed Exams
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overview_stats['passed_exams'] ?? 0; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card border-left-danger shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Failed Exams
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $overview_stats['failed_exams'] ?? 0; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Activity Trends Chart -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h6 class="card-title mb-0">
                                    <i class="fas fa-chart-bar me-2 text-info"></i> Activity Trends (Last 30 Days)
                                </h6>
                            </div>
                            <div class="card-body">
                                <canvas id="activityTrendsChart" height="100"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Exam Performance Report -->
<?php if($report_type == 'exam_performance'): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="fas fa-file-alt me-2 text-primary"></i> Exam Performance Report
        </h5>
        <span class="badge bg-primary"><?php echo count($exam_performance); ?> exams</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Exam Details</th>
                        <th>Course</th>
                        <th>Instructor</th>
                        <th>Attempts</th>
                        <th>Average Score</th>
                        <th>Pass Rate</th>
                        <th>Score Range</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($exam_performance)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No exam data found</h5>
                                <p class="text-muted">Try adjusting your filters or date range.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($exam_performance as $exam): 
                            $pass_rate = $exam['total_attempts'] > 0 ? round(($exam['passed_count'] / $exam['total_attempts']) * 100, 1) : 0;
                            $performance_color = $pass_rate >= 70 ? 'success' : ($pass_rate >= 50 ? 'warning' : 'danger');
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($exam['title']); ?></h6>
                                    <small class="text-muted">ID: <?php echo $exam['id']; ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark"><?php echo htmlspecialchars($exam['course_code']); ?></span>
                                    <br>
                                    <small class="text-muted"><?php echo htmlspecialchars($exam['course_name']); ?></small>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($exam['instructor_first_name'] . ' ' . $exam['instructor_last_name']); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $exam['total_attempts']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-<?php echo $performance_color; ?>"><?php echo round($exam['avg_score'] ?? 0, 1); ?>%</div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo $pass_rate; ?>%</div>
                                    <small class="text-muted">
                                        (<?php echo $exam['passed_count']; ?>/<?php echo $exam['total_attempts']; ?>)
                                    </small>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo round($exam['min_score'] ?? 0, 1); ?>% - <?php echo round($exam['max_score'] ?? 0, 1); ?>%
                                    </small>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px; width: 100px;">
                                        <div class="progress-bar bg-<?php echo $performance_color; ?>" 
                                             style="width: <?php echo $pass_rate; ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo $pass_rate; ?>% pass rate</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Student Performance Report -->
<?php if($report_type == 'student_performance'): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="fas fa-user-graduate me-2 text-success"></i> Student Performance Report
        </h5>
        <span class="badge bg-success"><?php echo count($student_performance); ?> students</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Student Information</th>
                        <th>Department</th>
                        <th>Exams Taken</th>
                        <th>Average Score</th>
                        <th>Passed/Failed</th>
                        <th>Score Range</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($student_performance)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No student data found</h5>
                                <p class="text-muted">Try adjusting your filters or date range.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($student_performance as $student): 
                            $pass_rate = $student['exams_taken'] > 0 ? round(($student['passed_exams'] / $student['exams_taken']) * 100, 1) : 0;
                            $performance_color = $pass_rate >= 70 ? 'success' : ($pass_rate >= 50 ? 'warning' : 'danger');
                        ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></h6>
                                            <small class="text-muted">
                                                @<?php echo htmlspecialchars($student['username']); ?>
                                                <?php if(!empty($student['university_id'])): ?>
                                                    | ID: <?php echo htmlspecialchars($student['university_id']); ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if(!empty($student['department'])): ?>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($student['department']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $student['exams_taken']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-<?php echo $performance_color; ?>"><?php echo round($student['avg_score'] ?? 0, 1); ?>%</div>
                                </td>
                                <td>
                                    <div class="fw-bold text-success"><?php echo $student['passed_exams']; ?></div>
                                    <div class="fw-bold text-danger"><?php echo $student['failed_exams']; ?></div>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo round($student['min_score'] ?? 0, 1); ?>% - <?php echo round($student['max_score'] ?? 0, 1); ?>%
                                    </small>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px; width: 100px;">
                                        <div class="progress-bar bg-<?php echo $performance_color; ?>" 
                                             style="width: <?php echo $pass_rate; ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo $pass_rate; ?>% success</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Course Performance Report -->
<?php if($report_type == 'course_performance'): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="fas fa-book me-2 text-info"></i> Course Performance Report
        </h5>
        <span class="badge bg-info"><?php echo count($course_performance); ?> courses</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Course Details</th>
                        <th>Exams</th>
                        <th>Attempts</th>
                        <th>Average Score</th>
                        <th>Pass Rate</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($course_performance)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-book fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No course data found</h5>
                                <p class="text-muted">Try adjusting your filters or date range.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($course_performance as $course): 
                            $pass_rate = $course['total_attempts'] > 0 ? round(($course['passed_attempts'] / $course['total_attempts']) * 100, 1) : 0;
                            $performance_color = $pass_rate >= 70 ? 'success' : ($pass_rate >= 50 ? 'warning' : 'danger');
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($course['course_code']); ?></h6>
                                    <p class="mb-0 text-muted"><?php echo htmlspecialchars($course['course_name']); ?></p>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $course['total_exams']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-info"><?php echo $course['total_attempts']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-<?php echo $performance_color; ?>"><?php echo round($course['avg_score'] ?? 0, 1); ?>%</div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo $pass_rate; ?>%</div>
                                    <small class="text-muted">
                                        (<?php echo $course['passed_attempts']; ?>/<?php echo $course['total_attempts']; ?>)
                                    </small>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px; width: 100px;">
                                        <div class="progress-bar bg-<?php echo $performance_color; ?>" 
                                             style="width: <?php echo $pass_rate; ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo $pass_rate; ?>% pass rate</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Instructor Performance Report -->
<?php if($report_type == 'instructor_performance'): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="fas fa-chalkboard-teacher me-2 text-warning"></i> Instructor Performance Report
        </h5>
        <span class="badge bg-warning"><?php echo count($instructor_performance); ?> instructors</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Instructor</th>
                        <th>Exams Created</th>
                        <th>Total Attempts</th>
                        <th>Average Score</th>
                        <th>Pass Rate</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($instructor_performance)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No instructor data found</h5>
                                <p class="text-muted">Try adjusting your filters or date range.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($instructor_performance as $instructor): 
                            $pass_rate = $instructor['total_attempts'] > 0 ? round(($instructor['passed_attempts'] / $instructor['total_attempts']) * 100, 1) : 0;
                            $performance_color = $pass_rate >= 70 ? 'success' : ($pass_rate >= 50 ? 'warning' : 'danger');
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($instructor['first_name'] . ' ' . $instructor['last_name']); ?></h6>
                                    <small class="text-muted">@<?php echo htmlspecialchars($instructor['username']); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $instructor['exams_created']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-info"><?php echo $instructor['total_attempts']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-<?php echo $performance_color; ?>"><?php echo round($instructor['avg_score'] ?? 0, 1); ?>%</div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo $pass_rate; ?>%</div>
                                    <small class="text-muted">
                                        (<?php echo $instructor['passed_attempts']; ?>/<?php echo $instructor['total_attempts']; ?>)
                                    </small>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px; width: 100px;">
                                        <div class="progress-bar bg-<?php echo $performance_color; ?>" 
                                             style="width: <?php echo $pass_rate; ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo $pass_rate; ?>% pass rate</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Question Analysis Report -->
<?php if($report_type == 'question_analysis'): ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="fas fa-question-circle me-2 text-danger"></i> Question Analysis Report
        </h5>
        <span class="badge bg-danger"><?php echo count($question_analysis); ?> exam types</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Exam</th>
                        <th>Course</th>
                        <th>Question Type</th>
                        <th>Questions</th>
                        <th>Avg Marks</th>
                        <th>Total Marks</th>
                        <th>Correct Answers</th>
                        <th>Accuracy Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($question_analysis)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <i class="fas fa-question-circle fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No question data found</h5>
                                <p class="text-muted">Try adjusting your filters or date range.</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($question_analysis as $analysis): 
                            $accuracy_rate = $analysis['total_answers'] > 0 ? round(($analysis['correct_answers'] / $analysis['total_answers']) * 100, 1) : 0;
                            $accuracy_color = $accuracy_rate >= 70 ? 'success' : ($accuracy_rate >= 50 ? 'warning' : 'danger');
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($analysis['exam_title']); ?></h6>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark"><?php echo htmlspecialchars($analysis['course_code']); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php 
                                        switch($analysis['question_type']) {
                                            case 'multiple_choice': echo 'info'; break;
                                            case 'true_false': echo 'success'; break;
                                            case 'short_answer': echo 'warning'; break;
                                            case 'essay': echo 'danger'; break;
                                            default: echo 'secondary';
                                        }
                                    ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $analysis['question_type'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?php echo $analysis['question_count']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-info"><?php echo round($analysis['avg_marks'] ?? 0, 1); ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-warning"><?php echo $analysis['total_marks']; ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-<?php echo $accuracy_color; ?>">
                                        <?php echo $analysis['correct_answers']; ?>/<?php echo $analysis['total_answers']; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo $accuracy_rate; ?>%</div>
                                    <div class="progress mt-1" style="height: 6px; width: 80px;">
                                        <div class="progress-bar bg-<?php echo $accuracy_color; ?>" 
                                             style="width: <?php echo $accuracy_rate; ?>%"></div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Activity Trends Chart
document.addEventListener('DOMContentLoaded', function() {
    const activityTrends = <?php echo json_encode($activity_trends); ?>;
    
    if (activityTrends.length > 0 && document.getElementById('activityTrendsChart')) {
        const ctx = document.getElementById('activityTrendsChart').getContext('2d');
        const labels = activityTrends.map(item => item.activity_date).reverse();
        const attempts = activityTrends.map(item => item.daily_attempts).reverse();
        const students = activityTrends.map(item => item.daily_students).reverse();
        const scores = activityTrends.map(item => item.daily_avg_score || 0).reverse();
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Daily Attempts',
                        data: attempts,
                        borderColor: '#4e73df',
                        backgroundColor: 'rgba(78, 115, 223, 0.1)',
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Daily Students',
                        data: students,
                        borderColor: '#1cc88a',
                        backgroundColor: 'rgba(28, 200, 138, 0.1)',
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Average Score %',
                        data: scores,
                        borderColor: '#f6c23e',
                        backgroundColor: 'rgba(246, 194, 62, 0.1)',
                        fill: true,
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Count'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Score %'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                        min: 0,
                        max: 100
                    }
                }
            }
        });
    }
    
    // Auto-focus date fields
    const startDateField = document.getElementById('start_date');
    const endDateField = document.getElementById('end_date');
    
    if (startDateField && endDateField) {
        startDateField.addEventListener('change', function() {
            if (endDateField.value && this.value > endDateField.value) {
                alert('Start date cannot be after end date!');
                this.value = '';
            }
        });
        
        endDateField.addEventListener('change', function() {
            if (startDateField.value && this.value < startDateField.value) {
                alert('End date cannot be before start date!');
                this.value = '';
            }
        });
    }
});

// Export report functionality
function exportReport(format = 'pdf') {
    const reportType = document.getElementById('report_type').value;
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    const course = document.getElementById('course').value;
    const instructor = document.getElementById('instructor').value;
    
    const params = new URLSearchParams({
        export: format,
        report_type: reportType,
        start_date: startDate,
        end_date: endDate,
        course: course,
        instructor: instructor
    });
    
    const url = `../process/export_report.php?${params.toString()}`;
    window.open(url, '_blank');
    
    // Show success message
    showExportToast(format);
}

function showExportToast(format) {
    const toast = document.createElement('div');
    toast.className = 'toast align-items-center text-white bg-success border-0 position-fixed top-0 end-0 m-3';
    toast.style.zIndex = '1060';
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-download me-2"></i>
                Report exported as ${format.toUpperCase()} successfully!
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after hide
    toast.addEventListener('hidden.bs.toast', () => {
        document.body.removeChild(toast);
    });
}

// Print report
function printReport() {
    window.print();
}

// Auto-refresh report data every 5 minutes
setInterval(() => {
    if (document.visibilityState === 'visible') {
        // You can add AJAX refresh here if needed
        console.log('Auto-refresh report data');
    }
}, 300000);
</script>

<style>
.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    border: 1px solid #e3e6f0;
}

.table th {
    border-top: none;
    font-weight: 600;
    background-color: #f8f9fc;
}

.progress {
    background-color: #eaecf4;
}

.badge {
    font-size: 0.75em;
}

.toast {
    min-width: 300px;
}

@media print {
    .btn, .card-header .badge, .navbar, .footer {
        display: none !important;
    }
    
    .card {
        border: none;
        box-shadow: none;
    }
    
    .table {
        font-size: 12px;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?>